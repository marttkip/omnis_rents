<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-09-27 18:38:07 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:07 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Output Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Security Class Initialized
DEBUG - 2015-09-27 18:38:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:07 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Input Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:38:07 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Output Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Security Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Input Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:38:07 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Loader Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:38:07 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:38:07 --> Loader Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:38:07 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:38:07 --> Database Driver Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:38:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-27 18:38:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:38:07 --> Session Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Session Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:38:07 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:38:07 --> A session cookie was not found.
DEBUG - 2015-09-27 18:38:07 --> A session cookie was not found.
DEBUG - 2015-09-27 18:38:07 --> Session routines successfully run
DEBUG - 2015-09-27 18:38:07 --> Session routines successfully run
DEBUG - 2015-09-27 18:38:07 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Email Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Email Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Controller Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Controller Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 18:38:07 --> Branches MX_Controller Initialized
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:07 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Output Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Security Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Input Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:38:07 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Loader Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:38:07 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:38:07 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:38:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:38:07 --> Session Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:38:07 --> Session routines successfully run
DEBUG - 2015-09-27 18:38:07 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Email Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Controller Class Initialized
DEBUG - 2015-09-27 18:38:07 --> Auth MX_Controller Initialized
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:38:07 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 18:38:07 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-27 18:38:07 --> Final output sent to browser
DEBUG - 2015-09-27 18:38:07 --> Total execution time: 0.1151
DEBUG - 2015-09-27 18:38:08 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:08 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:08 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:08 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:08 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:08 --> URI Class Initialized
ERROR - 2015-09-27 18:38:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:08 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Config Class Initialized
ERROR - 2015-09-27 18:38:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:08 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:08 --> UTF-8 Support Enabled
ERROR - 2015-09-27 18:38:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:08 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:08 --> URI Class Initialized
ERROR - 2015-09-27 18:38:08 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:08 --> Router Class Initialized
ERROR - 2015-09-27 18:38:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:08 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:08 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Router Class Initialized
ERROR - 2015-09-27 18:38:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:08 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:08 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:08 --> Router Class Initialized
ERROR - 2015-09-27 18:38:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:19 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:19 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Output Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Security Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Input Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:38:19 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Loader Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:38:19 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:38:19 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:38:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:38:19 --> Session Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:38:19 --> Session routines successfully run
DEBUG - 2015-09-27 18:38:19 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Email Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Controller Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Auth MX_Controller Initialized
DEBUG - 2015-09-27 18:38:19 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:38:19 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:38:19 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-27 18:38:19 --> XSS Filtering completed
DEBUG - 2015-09-27 18:38:19 --> Unable to find validation rule: exists
DEBUG - 2015-09-27 18:38:19 --> XSS Filtering completed
DEBUG - 2015-09-27 18:38:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 18:38:19 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-27 18:38:19 --> Final output sent to browser
DEBUG - 2015-09-27 18:38:19 --> Total execution time: 0.1289
DEBUG - 2015-09-27 18:38:19 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:19 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:19 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:19 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:19 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:19 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:19 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Config Class Initialized
ERROR - 2015-09-27 18:38:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:19 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:19 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:19 --> Router Class Initialized
ERROR - 2015-09-27 18:38:19 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:19 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:26 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:26 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Output Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Security Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Input Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:38:26 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Loader Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:38:26 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:38:26 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:38:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:38:26 --> Session Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:38:26 --> Session routines successfully run
DEBUG - 2015-09-27 18:38:26 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Email Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Controller Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Auth MX_Controller Initialized
DEBUG - 2015-09-27 18:38:26 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:38:26 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:38:26 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-27 18:38:26 --> XSS Filtering completed
DEBUG - 2015-09-27 18:38:26 --> Unable to find validation rule: exists
DEBUG - 2015-09-27 18:38:26 --> XSS Filtering completed
DEBUG - 2015-09-27 18:38:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 18:38:26 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-27 18:38:26 --> Final output sent to browser
DEBUG - 2015-09-27 18:38:26 --> Total execution time: 0.1186
DEBUG - 2015-09-27 18:38:26 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:26 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:26 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:26 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:26 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:26 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:26 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:26 --> Router Class Initialized
ERROR - 2015-09-27 18:38:26 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:26 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:26 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:26 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:30 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:30 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Output Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Security Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Input Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:38:30 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Loader Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:38:30 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:38:30 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:38:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:38:30 --> Session Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:38:30 --> Session routines successfully run
DEBUG - 2015-09-27 18:38:30 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Email Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Controller Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Auth MX_Controller Initialized
DEBUG - 2015-09-27 18:38:30 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:38:30 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:38:30 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-27 18:38:30 --> XSS Filtering completed
DEBUG - 2015-09-27 18:38:30 --> Unable to find validation rule: exists
DEBUG - 2015-09-27 18:38:30 --> XSS Filtering completed
DEBUG - 2015-09-27 18:38:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 18:38:30 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-27 18:38:30 --> Final output sent to browser
DEBUG - 2015-09-27 18:38:30 --> Total execution time: 0.0997
DEBUG - 2015-09-27 18:38:30 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:30 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:30 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:30 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:30 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:30 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:30 --> URI Class Initialized
ERROR - 2015-09-27 18:38:30 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:30 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:30 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:30 --> URI Class Initialized
ERROR - 2015-09-27 18:38:30 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:30 --> Router Class Initialized
ERROR - 2015-09-27 18:38:30 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:30 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:38:43 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:43 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Output Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Security Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Input Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:38:43 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Language Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Loader Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:38:43 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:38:43 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:38:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:38:43 --> Session Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:38:43 --> Session routines successfully run
DEBUG - 2015-09-27 18:38:43 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Email Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Controller Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Auth MX_Controller Initialized
DEBUG - 2015-09-27 18:38:43 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:38:43 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:38:43 --> Model Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-27 18:38:43 --> XSS Filtering completed
DEBUG - 2015-09-27 18:38:43 --> Unable to find validation rule: exists
DEBUG - 2015-09-27 18:38:43 --> XSS Filtering completed
DEBUG - 2015-09-27 18:38:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 18:38:43 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-27 18:38:43 --> Final output sent to browser
DEBUG - 2015-09-27 18:38:43 --> Total execution time: 0.0964
DEBUG - 2015-09-27 18:38:43 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Config Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:43 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:43 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:43 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:38:43 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:43 --> URI Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Router Class Initialized
DEBUG - 2015-09-27 18:38:43 --> Router Class Initialized
ERROR - 2015-09-27 18:38:43 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:43 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:43 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:38:43 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:39:06 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:06 --> URI Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Router Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Output Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Security Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Input Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:39:06 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Loader Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:39:06 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:39:06 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:39:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:39:06 --> Session Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:39:06 --> Session routines successfully run
DEBUG - 2015-09-27 18:39:06 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Email Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Controller Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Auth MX_Controller Initialized
DEBUG - 2015-09-27 18:39:06 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:39:06 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:39:06 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-27 18:39:06 --> XSS Filtering completed
DEBUG - 2015-09-27 18:39:06 --> Unable to find validation rule: exists
DEBUG - 2015-09-27 18:39:06 --> XSS Filtering completed
DEBUG - 2015-09-27 18:39:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 18:39:06 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-27 18:39:06 --> Final output sent to browser
DEBUG - 2015-09-27 18:39:06 --> Total execution time: 0.0999
DEBUG - 2015-09-27 18:39:06 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:06 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:39:06 --> URI Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:06 --> Router Class Initialized
DEBUG - 2015-09-27 18:39:06 --> URI Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:06 --> Router Class Initialized
DEBUG - 2015-09-27 18:39:06 --> URI Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Router Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:06 --> Hooks Class Initialized
ERROR - 2015-09-27 18:39:06 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:39:06 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:06 --> URI Class Initialized
ERROR - 2015-09-27 18:39:06 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:39:06 --> Router Class Initialized
ERROR - 2015-09-27 18:39:06 --> 404 Page Not Found --> 
ERROR - 2015-09-27 18:39:06 --> 404 Page Not Found --> 
DEBUG - 2015-09-27 18:39:14 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:14 --> URI Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Router Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Output Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Security Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Input Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:39:14 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Loader Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:39:14 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:39:14 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:39:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:39:14 --> Session Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:39:14 --> Session routines successfully run
DEBUG - 2015-09-27 18:39:14 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Email Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Controller Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Auth MX_Controller Initialized
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-27 18:39:14 --> XSS Filtering completed
DEBUG - 2015-09-27 18:39:14 --> Unable to find validation rule: exists
DEBUG - 2015-09-27 18:39:14 --> XSS Filtering completed
DEBUG - 2015-09-27 18:39:14 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:14 --> URI Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Router Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Output Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Security Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Input Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:39:14 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Loader Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:39:14 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:39:14 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:39:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:39:14 --> Session Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:39:14 --> Session routines successfully run
DEBUG - 2015-09-27 18:39:14 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Email Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Controller Class Initialized
DEBUG - 2015-09-27 18:39:14 --> Admin MX_Controller Initialized
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-27 18:39:14 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 18:39:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 18:39:14 --> Final output sent to browser
DEBUG - 2015-09-27 18:39:14 --> Total execution time: 0.1133
DEBUG - 2015-09-27 18:39:24 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:24 --> URI Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Router Class Initialized
DEBUG - 2015-09-27 18:39:24 --> No URI present. Default controller set.
DEBUG - 2015-09-27 18:39:24 --> Output Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Security Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Input Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:39:24 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Loader Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:39:24 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:39:24 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:39:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:39:24 --> Session Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:39:24 --> Session routines successfully run
DEBUG - 2015-09-27 18:39:24 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Email Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Controller Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Auth MX_Controller Initialized
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:24 --> URI Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Router Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Output Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Security Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Input Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:39:24 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Loader Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:39:24 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:39:24 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:39:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:39:24 --> Session Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:39:24 --> Session routines successfully run
DEBUG - 2015-09-27 18:39:24 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Email Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Controller Class Initialized
DEBUG - 2015-09-27 18:39:24 --> Admin MX_Controller Initialized
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-27 18:39:24 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 18:39:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 18:39:24 --> Final output sent to browser
DEBUG - 2015-09-27 18:39:24 --> Total execution time: 0.1024
DEBUG - 2015-09-27 18:39:33 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Hooks Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Utf8 Class Initialized
DEBUG - 2015-09-27 18:39:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 18:39:33 --> URI Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Router Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Output Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Security Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Input Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 18:39:33 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Language Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Config Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Loader Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Helper loaded: url_helper
DEBUG - 2015-09-27 18:39:33 --> Helper loaded: form_helper
DEBUG - 2015-09-27 18:39:33 --> Database Driver Class Initialized
ERROR - 2015-09-27 18:39:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 18:39:33 --> Session Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Helper loaded: string_helper
DEBUG - 2015-09-27 18:39:33 --> Session routines successfully run
DEBUG - 2015-09-27 18:39:33 --> Form Validation Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Pagination Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Encrypt Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Email Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Controller Class Initialized
DEBUG - 2015-09-27 18:39:33 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 18:39:33 --> Model Class Initialized
DEBUG - 2015-09-27 18:39:34 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 18:39:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 18:39:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 18:39:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 18:39:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 18:39:34 --> Final output sent to browser
DEBUG - 2015-09-27 18:39:34 --> Total execution time: 0.1283
DEBUG - 2015-09-27 20:08:21 --> Config Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:08:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:08:21 --> URI Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Router Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Output Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Security Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Input Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:08:21 --> Language Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Language Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Config Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Loader Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:08:21 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:08:21 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:08:21 --> Session Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:08:21 --> Session routines successfully run
DEBUG - 2015-09-27 20:08:21 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Email Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Controller Class Initialized
DEBUG - 2015-09-27 20:08:21 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:08:21 --> Model Class Initialized
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:08:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:08:21 --> Final output sent to browser
DEBUG - 2015-09-27 20:08:21 --> Total execution time: 0.1363
DEBUG - 2015-09-27 20:10:14 --> Config Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:10:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:10:14 --> URI Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Router Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Output Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Security Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Input Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:10:14 --> Language Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Language Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Config Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Loader Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:10:14 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:10:14 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:10:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:10:14 --> Session Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:10:14 --> Session routines successfully run
DEBUG - 2015-09-27 20:10:14 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Email Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Controller Class Initialized
DEBUG - 2015-09-27 20:10:14 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:10:14 --> Model Class Initialized
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:10:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:10:14 --> Final output sent to browser
DEBUG - 2015-09-27 20:10:14 --> Total execution time: 0.1440
DEBUG - 2015-09-27 20:12:23 --> Config Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:12:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:12:23 --> URI Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Router Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Output Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Security Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Input Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:12:23 --> Language Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Language Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Config Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Loader Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:12:23 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:12:23 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:12:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:12:23 --> Session Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:12:23 --> Session routines successfully run
DEBUG - 2015-09-27 20:12:23 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Email Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Controller Class Initialized
DEBUG - 2015-09-27 20:12:23 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:12:23 --> Model Class Initialized
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:12:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:12:23 --> Final output sent to browser
DEBUG - 2015-09-27 20:12:23 --> Total execution time: 0.1375
DEBUG - 2015-09-27 20:15:33 --> Config Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:15:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:15:33 --> URI Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Router Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Output Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Security Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Input Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:15:33 --> Language Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Language Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Config Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Loader Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:15:33 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:15:33 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:15:33 --> Session Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:15:33 --> Session routines successfully run
DEBUG - 2015-09-27 20:15:33 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Email Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Controller Class Initialized
DEBUG - 2015-09-27 20:15:33 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:15:33 --> Model Class Initialized
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:15:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:15:33 --> Final output sent to browser
DEBUG - 2015-09-27 20:15:33 --> Total execution time: 0.1312
DEBUG - 2015-09-27 20:18:26 --> Config Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:18:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:18:26 --> URI Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Router Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Output Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Security Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Input Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:18:26 --> Language Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Language Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Config Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Loader Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:18:26 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:18:26 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:18:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:18:26 --> Session Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:18:26 --> Session routines successfully run
DEBUG - 2015-09-27 20:18:26 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Email Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Controller Class Initialized
DEBUG - 2015-09-27 20:18:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:18:26 --> Model Class Initialized
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:18:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:18:26 --> Final output sent to browser
DEBUG - 2015-09-27 20:18:26 --> Total execution time: 0.1329
DEBUG - 2015-09-27 20:23:09 --> Config Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:23:09 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:23:09 --> URI Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Router Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Output Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Security Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Input Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:23:09 --> Language Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Language Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Config Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Loader Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:23:09 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:23:09 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:23:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:23:09 --> Session Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:23:09 --> Session routines successfully run
DEBUG - 2015-09-27 20:23:09 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Email Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Controller Class Initialized
DEBUG - 2015-09-27 20:23:09 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:23:09 --> Model Class Initialized
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:23:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:23:09 --> Final output sent to browser
DEBUG - 2015-09-27 20:23:09 --> Total execution time: 0.1432
DEBUG - 2015-09-27 20:24:02 --> Config Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:24:02 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:24:02 --> URI Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Router Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Output Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Security Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Input Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:24:02 --> Language Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Language Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Config Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Loader Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:24:02 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:24:02 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:24:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:24:02 --> Session Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:24:02 --> Session routines successfully run
DEBUG - 2015-09-27 20:24:02 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Email Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Controller Class Initialized
DEBUG - 2015-09-27 20:24:02 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:24:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:24:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:24:02 --> Final output sent to browser
DEBUG - 2015-09-27 20:24:02 --> Total execution time: 0.1577
DEBUG - 2015-09-27 20:24:24 --> Config Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:24:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:24:24 --> URI Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Router Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Output Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Security Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Input Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:24:24 --> Language Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Language Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Config Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Loader Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:24:24 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:24:24 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:24:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:24:24 --> Session Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:24:24 --> Session routines successfully run
DEBUG - 2015-09-27 20:24:24 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Email Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Controller Class Initialized
DEBUG - 2015-09-27 20:24:24 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:24:24 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:24 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:24:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:24:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:24:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:24:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:24:25 --> Final output sent to browser
DEBUG - 2015-09-27 20:24:25 --> Total execution time: 0.1274
DEBUG - 2015-09-27 20:24:39 --> Config Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:24:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:24:39 --> URI Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Router Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Output Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Security Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Input Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:24:39 --> Language Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Language Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Config Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Loader Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:24:39 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:24:39 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:24:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:24:39 --> Session Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:24:39 --> Session routines successfully run
DEBUG - 2015-09-27 20:24:39 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Email Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Controller Class Initialized
DEBUG - 2015-09-27 20:24:39 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:24:39 --> Model Class Initialized
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:24:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:24:39 --> Final output sent to browser
DEBUG - 2015-09-27 20:24:39 --> Total execution time: 0.1497
DEBUG - 2015-09-27 20:40:38 --> Config Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:40:38 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:40:38 --> URI Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Router Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Output Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Security Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Input Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:40:38 --> Language Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Language Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Config Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Loader Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:40:38 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:40:38 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:40:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:40:38 --> Session Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:40:38 --> Session routines successfully run
DEBUG - 2015-09-27 20:40:38 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Email Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Controller Class Initialized
DEBUG - 2015-09-27 20:40:38 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:40:38 --> Model Class Initialized
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:40:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:40:38 --> Final output sent to browser
DEBUG - 2015-09-27 20:40:38 --> Total execution time: 0.1320
DEBUG - 2015-09-27 20:41:01 --> Config Class Initialized
DEBUG - 2015-09-27 20:41:01 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:41:01 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:41:01 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:41:01 --> URI Class Initialized
DEBUG - 2015-09-27 20:41:01 --> Router Class Initialized
DEBUG - 2015-09-27 20:41:01 --> Output Class Initialized
DEBUG - 2015-09-27 20:41:01 --> Security Class Initialized
DEBUG - 2015-09-27 20:41:01 --> Input Class Initialized
DEBUG - 2015-09-27 20:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:41:01 --> Language Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Language Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Config Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Loader Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:41:02 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:41:02 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:41:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:41:02 --> Session Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:41:02 --> Session routines successfully run
DEBUG - 2015-09-27 20:41:02 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Email Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Controller Class Initialized
DEBUG - 2015-09-27 20:41:02 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:41:02 --> Model Class Initialized
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:41:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:41:02 --> Final output sent to browser
DEBUG - 2015-09-27 20:41:02 --> Total execution time: 0.1346
DEBUG - 2015-09-27 20:44:31 --> Config Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:44:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:44:31 --> URI Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Router Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Output Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Security Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Input Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:44:31 --> Language Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Language Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Config Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Loader Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:44:31 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:44:31 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:44:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:44:31 --> Session Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:44:31 --> Session routines successfully run
DEBUG - 2015-09-27 20:44:31 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Email Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Controller Class Initialized
DEBUG - 2015-09-27 20:44:31 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:44:31 --> Model Class Initialized
ERROR - 2015-09-27 20:44:31 --> Severity: Notice  --> Undefined variable: loans_plan_custom_amount C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 72
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:44:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:44:31 --> Final output sent to browser
DEBUG - 2015-09-27 20:44:31 --> Total execution time: 0.1379
DEBUG - 2015-09-27 20:44:56 --> Config Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:44:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:44:56 --> URI Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Router Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Output Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Security Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Input Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:44:56 --> Language Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Language Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Config Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Loader Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:44:56 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:44:56 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:44:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:44:56 --> Session Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:44:56 --> Session routines successfully run
DEBUG - 2015-09-27 20:44:56 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Email Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Controller Class Initialized
DEBUG - 2015-09-27 20:44:56 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:44:56 --> Model Class Initialized
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:44:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:44:56 --> Final output sent to browser
DEBUG - 2015-09-27 20:44:56 --> Total execution time: 0.1357
DEBUG - 2015-09-27 20:45:47 --> Config Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:45:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:45:47 --> URI Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Router Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Output Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Security Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Input Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:45:47 --> Language Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Language Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Config Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Loader Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:45:47 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:45:47 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:45:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:45:47 --> Session Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:45:47 --> Session routines successfully run
DEBUG - 2015-09-27 20:45:47 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Email Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Controller Class Initialized
DEBUG - 2015-09-27 20:45:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:45:47 --> Model Class Initialized
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:45:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:45:47 --> Final output sent to browser
DEBUG - 2015-09-27 20:45:47 --> Total execution time: 0.1385
DEBUG - 2015-09-27 20:55:16 --> Config Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:55:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:55:16 --> URI Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Router Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Output Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Security Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Input Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:55:16 --> Language Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Language Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Config Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Loader Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:55:16 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:55:16 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:55:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:55:16 --> Session Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:55:16 --> Session routines successfully run
DEBUG - 2015-09-27 20:55:16 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Email Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Controller Class Initialized
DEBUG - 2015-09-27 20:55:16 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:55:16 --> Model Class Initialized
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:55:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:55:16 --> Final output sent to browser
DEBUG - 2015-09-27 20:55:16 --> Total execution time: 0.1312
DEBUG - 2015-09-27 20:57:20 --> Config Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:57:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:57:20 --> URI Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Router Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Output Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Security Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Input Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:57:20 --> Language Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Language Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Config Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Loader Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:57:20 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:57:20 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:57:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:57:20 --> Session Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:57:20 --> Session routines successfully run
DEBUG - 2015-09-27 20:57:20 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Email Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Controller Class Initialized
DEBUG - 2015-09-27 20:57:20 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:57:20 --> Model Class Initialized
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:57:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:57:20 --> Final output sent to browser
DEBUG - 2015-09-27 20:57:20 --> Total execution time: 0.1329
DEBUG - 2015-09-27 20:58:03 --> Config Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Hooks Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Utf8 Class Initialized
DEBUG - 2015-09-27 20:58:03 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 20:58:03 --> URI Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Router Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Output Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Security Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Input Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 20:58:03 --> Language Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Language Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Config Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Loader Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Helper loaded: url_helper
DEBUG - 2015-09-27 20:58:03 --> Helper loaded: form_helper
DEBUG - 2015-09-27 20:58:03 --> Database Driver Class Initialized
ERROR - 2015-09-27 20:58:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 20:58:03 --> Session Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Helper loaded: string_helper
DEBUG - 2015-09-27 20:58:03 --> Session routines successfully run
DEBUG - 2015-09-27 20:58:03 --> Form Validation Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Pagination Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Encrypt Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Email Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Controller Class Initialized
DEBUG - 2015-09-27 20:58:03 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 20:58:03 --> Model Class Initialized
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 20:58:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 20:58:03 --> Final output sent to browser
DEBUG - 2015-09-27 20:58:03 --> Total execution time: 0.1462
DEBUG - 2015-09-27 21:00:13 --> Config Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:00:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:00:13 --> URI Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Router Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Output Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Security Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Input Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:00:13 --> Language Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Language Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Config Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Loader Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:00:13 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:00:13 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:00:13 --> Session Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:00:13 --> Session routines successfully run
DEBUG - 2015-09-27 21:00:13 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Email Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Controller Class Initialized
DEBUG - 2015-09-27 21:00:13 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:00:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:00:13 --> Final output sent to browser
DEBUG - 2015-09-27 21:00:13 --> Total execution time: 0.1366
DEBUG - 2015-09-27 21:00:35 --> Config Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:00:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:00:35 --> URI Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Router Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Output Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Security Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Input Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:00:35 --> Language Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Language Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Config Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Loader Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:00:35 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:00:35 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:00:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:00:35 --> Session Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:00:35 --> Session routines successfully run
DEBUG - 2015-09-27 21:00:35 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Email Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Controller Class Initialized
DEBUG - 2015-09-27 21:00:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:00:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:00:35 --> Final output sent to browser
DEBUG - 2015-09-27 21:00:35 --> Total execution time: 0.1231
DEBUG - 2015-09-27 21:05:11 --> Config Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:05:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:05:11 --> URI Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Router Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Output Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Security Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Input Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:05:11 --> Language Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Language Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Config Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Loader Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:05:11 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:05:11 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:05:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:05:11 --> Session Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:05:11 --> Session routines successfully run
DEBUG - 2015-09-27 21:05:11 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Email Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Controller Class Initialized
DEBUG - 2015-09-27 21:05:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:05:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:05:12 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:05:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:05:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:05:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:05:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:05:12 --> Final output sent to browser
DEBUG - 2015-09-27 21:05:12 --> Total execution time: 0.1396
DEBUG - 2015-09-27 21:11:11 --> Config Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:11:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:11:11 --> URI Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Router Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Output Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Security Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Input Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:11:11 --> Language Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Language Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Config Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Loader Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:11:11 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:11:11 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:11:11 --> Session Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:11:11 --> Session routines successfully run
DEBUG - 2015-09-27 21:11:11 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Email Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Controller Class Initialized
DEBUG - 2015-09-27 21:11:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:11:11 --> Model Class Initialized
ERROR - 2015-09-27 21:11:11 --> Severity: Notice  --> Undefined variable: loans_plan_grace_period_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 120
ERROR - 2015-09-27 21:11:11 --> Severity: Notice  --> Undefined variable: loans_plan_grace_period_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 121
ERROR - 2015-09-27 21:11:11 --> Severity: Notice  --> Undefined variable: loans_plan_grace_period_default C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 122
ERROR - 2015-09-27 21:11:11 --> Severity: Notice  --> Undefined variable: loans_plan_grace_period_interest C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 123
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:11:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:11:11 --> Final output sent to browser
DEBUG - 2015-09-27 21:11:11 --> Total execution time: 0.1385
DEBUG - 2015-09-27 21:11:50 --> Config Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:11:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:11:50 --> URI Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Router Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Output Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Security Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Input Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:11:50 --> Language Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Language Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Config Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Loader Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:11:50 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:11:50 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:11:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:11:50 --> Session Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:11:50 --> Session routines successfully run
DEBUG - 2015-09-27 21:11:50 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Email Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Controller Class Initialized
DEBUG - 2015-09-27 21:11:50 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:11:50 --> Model Class Initialized
ERROR - 2015-09-27 21:11:50 --> Severity: Notice  --> Undefined variable: loans_plan_grace_period_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 122
ERROR - 2015-09-27 21:11:50 --> Severity: Notice  --> Undefined variable: loans_plan_grace_period_default C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 123
ERROR - 2015-09-27 21:11:50 --> Severity: Notice  --> Undefined variable: loans_plan_grace_period_interest C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 124
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:11:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:11:50 --> Final output sent to browser
DEBUG - 2015-09-27 21:11:50 --> Total execution time: 0.1345
DEBUG - 2015-09-27 21:13:20 --> Config Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:13:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:13:20 --> URI Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Router Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Output Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Security Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Input Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:13:20 --> Language Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Language Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Config Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Loader Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:13:20 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:13:20 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:13:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:13:20 --> Session Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:13:20 --> Session routines successfully run
DEBUG - 2015-09-27 21:13:20 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Email Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Controller Class Initialized
DEBUG - 2015-09-27 21:13:20 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:13:20 --> Model Class Initialized
ERROR - 2015-09-27 21:13:20 --> Severity: Notice  --> Undefined property: stdClass::$loans_plans_grace_period_default C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 53
ERROR - 2015-09-27 21:13:20 --> Severity: Notice  --> Undefined variable: loans_plan_grace_period_interest C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 126
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:13:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:13:20 --> Final output sent to browser
DEBUG - 2015-09-27 21:13:20 --> Total execution time: 0.1438
DEBUG - 2015-09-27 21:14:10 --> Config Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:14:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:14:10 --> URI Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Router Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Output Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Security Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Input Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:14:10 --> Language Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Language Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Config Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Loader Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:14:10 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:14:10 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:14:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:14:10 --> Session Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:14:10 --> Session routines successfully run
DEBUG - 2015-09-27 21:14:10 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Email Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Controller Class Initialized
DEBUG - 2015-09-27 21:14:10 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:14:10 --> Model Class Initialized
ERROR - 2015-09-27 21:14:10 --> Severity: Notice  --> Undefined property: stdClass::$loans_plans_grace_period_default C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 53
ERROR - 2015-09-27 21:14:10 --> Severity: Notice  --> Undefined property: stdClass::$loans_plans_grace_period_interest C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 54
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:14:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:14:10 --> Final output sent to browser
DEBUG - 2015-09-27 21:14:10 --> Total execution time: 0.1374
DEBUG - 2015-09-27 21:14:27 --> Config Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:14:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:14:27 --> URI Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Router Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Output Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Security Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Input Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:14:27 --> Language Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Language Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Config Class Initialized
DEBUG - 2015-09-27 21:14:27 --> Loader Class Initialized
DEBUG - 2015-09-27 21:14:28 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:14:28 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:14:28 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:14:28 --> Session Class Initialized
DEBUG - 2015-09-27 21:14:28 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:14:28 --> Session routines successfully run
DEBUG - 2015-09-27 21:14:28 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:14:28 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:14:28 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:14:28 --> Email Class Initialized
DEBUG - 2015-09-27 21:14:28 --> Controller Class Initialized
DEBUG - 2015-09-27 21:14:28 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:14:28 --> Model Class Initialized
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:14:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:14:28 --> Final output sent to browser
DEBUG - 2015-09-27 21:14:28 --> Total execution time: 0.1437
DEBUG - 2015-09-27 21:20:05 --> Config Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:20:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:20:05 --> URI Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Router Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Output Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Security Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Input Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:20:05 --> Language Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Language Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Config Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Loader Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:20:05 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:20:05 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:20:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:20:05 --> Session Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:20:05 --> Session routines successfully run
DEBUG - 2015-09-27 21:20:05 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Email Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Controller Class Initialized
DEBUG - 2015-09-27 21:20:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:20:05 --> Model Class Initialized
ERROR - 2015-09-27 21:20:05 --> Severity: Notice  --> Undefined variable: loans_plan_interest_scheme C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 147
ERROR - 2015-09-27 21:20:05 --> Severity: Notice  --> Undefined variable: loans_plan_funding_line C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 148
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:20:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:20:05 --> Final output sent to browser
DEBUG - 2015-09-27 21:20:05 --> Total execution time: 0.1404
DEBUG - 2015-09-27 21:21:08 --> Config Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:21:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:21:08 --> URI Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Router Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Output Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Security Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Input Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:21:08 --> Language Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Language Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Config Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Loader Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:21:08 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:21:08 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:21:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:21:08 --> Session Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:21:08 --> Session routines successfully run
DEBUG - 2015-09-27 21:21:08 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Email Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Controller Class Initialized
DEBUG - 2015-09-27 21:21:08 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:21:08 --> Model Class Initialized
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:21:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:21:08 --> Final output sent to browser
DEBUG - 2015-09-27 21:21:08 --> Total execution time: 0.1314
DEBUG - 2015-09-27 21:47:26 --> Config Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:47:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:47:26 --> URI Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Router Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Output Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Security Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Input Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:47:26 --> Language Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Language Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Config Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Loader Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:47:26 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:47:26 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:47:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:47:26 --> Session Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:47:26 --> Session routines successfully run
DEBUG - 2015-09-27 21:47:26 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Email Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Controller Class Initialized
DEBUG - 2015-09-27 21:47:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:47:26 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:47:26 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:47:26 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:47:26 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:47:26 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:47:27 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:47:27 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:47:27 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:47:27 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:47:27 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:47:27 --> Model Class Initialized
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:47:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:47:27 --> Final output sent to browser
DEBUG - 2015-09-27 21:47:27 --> Total execution time: 0.1261
DEBUG - 2015-09-27 21:55:55 --> Config Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:55:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:55:55 --> URI Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Router Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Output Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Security Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Input Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:55:55 --> Language Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Language Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Config Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Loader Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:55:55 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:55:55 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:55:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:55:55 --> Session Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:55:55 --> Session routines successfully run
DEBUG - 2015-09-27 21:55:55 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Email Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Controller Class Initialized
DEBUG - 2015-09-27 21:55:55 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:55:55 --> Model Class Initialized
ERROR - 2015-09-27 21:55:55 --> Severity: Notice  --> Undefined property: stdClass::$loans_plans_annual_max_interest C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 58
ERROR - 2015-09-27 21:55:55 --> Severity: Notice  --> Undefined property: stdClass::$loans_plans_annual_custom_interest C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 59
ERROR - 2015-09-27 21:55:55 --> Severity: Notice  --> Undefined variable: loans_plan_custom_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 202
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:55:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:55:55 --> Final output sent to browser
DEBUG - 2015-09-27 21:55:55 --> Total execution time: 0.1414
DEBUG - 2015-09-27 21:56:39 --> Config Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:56:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:56:39 --> URI Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Router Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Output Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Security Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Input Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:56:39 --> Language Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Language Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Config Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Loader Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:56:39 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:56:39 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:56:39 --> Session Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:56:39 --> Session routines successfully run
DEBUG - 2015-09-27 21:56:39 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Email Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Controller Class Initialized
DEBUG - 2015-09-27 21:56:39 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:56:39 --> Model Class Initialized
ERROR - 2015-09-27 21:56:39 --> Severity: Notice  --> Undefined variable: loans_plan_custom_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 202
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:56:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:56:39 --> Final output sent to browser
DEBUG - 2015-09-27 21:56:39 --> Total execution time: 0.1349
DEBUG - 2015-09-27 21:57:36 --> Config Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Hooks Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Utf8 Class Initialized
DEBUG - 2015-09-27 21:57:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 21:57:36 --> URI Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Router Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Output Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Security Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Input Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 21:57:36 --> Language Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Language Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Config Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Loader Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Helper loaded: url_helper
DEBUG - 2015-09-27 21:57:36 --> Helper loaded: form_helper
DEBUG - 2015-09-27 21:57:36 --> Database Driver Class Initialized
ERROR - 2015-09-27 21:57:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 21:57:36 --> Session Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Helper loaded: string_helper
DEBUG - 2015-09-27 21:57:36 --> Session routines successfully run
DEBUG - 2015-09-27 21:57:36 --> Form Validation Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Pagination Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Encrypt Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Email Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Controller Class Initialized
DEBUG - 2015-09-27 21:57:36 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 21:57:36 --> Model Class Initialized
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 21:57:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 21:57:36 --> Final output sent to browser
DEBUG - 2015-09-27 21:57:36 --> Total execution time: 0.1505
DEBUG - 2015-09-27 22:20:21 --> Config Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:20:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:20:21 --> URI Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Router Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Output Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Security Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Input Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:20:21 --> Language Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Language Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Config Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Loader Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:20:21 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:20:21 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:20:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:20:21 --> Session Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:20:21 --> Session routines successfully run
DEBUG - 2015-09-27 22:20:21 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Email Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Controller Class Initialized
DEBUG - 2015-09-27 22:20:21 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:20:21 --> Model Class Initialized
DEBUG - 2015-09-27 22:20:21 --> DB Transaction Failure
ERROR - 2015-09-27 22:20:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' loans_plan_entry_fees.loans_plan_id = loans_plan.loans_plan_id' at line 3
DEBUG - 2015-09-27 22:20:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:21:03 --> Config Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:21:03 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:21:03 --> URI Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Router Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Output Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Security Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Input Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:21:03 --> Language Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Language Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Config Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Loader Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:21:03 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:21:03 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:21:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:21:03 --> Session Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:21:03 --> Session routines successfully run
DEBUG - 2015-09-27 22:21:03 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Email Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Controller Class Initialized
DEBUG - 2015-09-27 22:21:03 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:21:03 --> Model Class Initialized
DEBUG - 2015-09-27 22:21:03 --> DB Transaction Failure
ERROR - 2015-09-27 22:21:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' loans_plan.loans_plan_id =loans_plan_entry_fees.loans_plan_id' at line 3
DEBUG - 2015-09-27 22:21:03 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:24:09 --> Config Class Initialized
DEBUG - 2015-09-27 22:24:09 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:24:09 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:24:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:24:10 --> URI Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Router Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Output Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Security Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Input Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:24:10 --> Language Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Language Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Config Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Loader Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:24:10 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:24:10 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:24:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:24:10 --> Session Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:24:10 --> Session routines successfully run
DEBUG - 2015-09-27 22:24:10 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Email Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Controller Class Initialized
DEBUG - 2015-09-27 22:24:10 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:24:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:24:10 --> DB Transaction Failure
ERROR - 2015-09-27 22:24:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' loans_plan.loans_plan_entry_fees_id =loans_plan_entry_fees.loans_plan_entry_fee' at line 3
DEBUG - 2015-09-27 22:24:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:25:59 --> Config Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:25:59 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:25:59 --> URI Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Router Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Output Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Security Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Input Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:25:59 --> Language Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Language Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Config Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Loader Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:25:59 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:25:59 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:25:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:25:59 --> Session Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:25:59 --> Session routines successfully run
DEBUG - 2015-09-27 22:25:59 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Email Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Controller Class Initialized
DEBUG - 2015-09-27 22:25:59 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:25:59 --> Model Class Initialized
DEBUG - 2015-09-27 22:25:59 --> DB Transaction Failure
ERROR - 2015-09-27 22:25:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' loans_plan.loans_plan_entry_fees_id = loans_plan_entry_fees.loans_plan_entry_fe' at line 3
DEBUG - 2015-09-27 22:25:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:27:18 --> Config Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:27:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:27:18 --> URI Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Router Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Output Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Security Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Input Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:27:18 --> Language Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Language Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Config Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Loader Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:27:18 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:27:18 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:27:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:27:18 --> Session Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:27:18 --> Session routines successfully run
DEBUG - 2015-09-27 22:27:18 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Email Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Controller Class Initialized
DEBUG - 2015-09-27 22:27:18 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:27:18 --> Model Class Initialized
DEBUG - 2015-09-27 22:27:18 --> DB Transaction Failure
ERROR - 2015-09-27 22:27:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' loans_plan.loans_plan_entry_fees_id = loans_plan_entry_fees.loans_plan_entry_fe' at line 3
DEBUG - 2015-09-27 22:27:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:28:14 --> Config Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:28:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:28:14 --> URI Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Router Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Output Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Security Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Input Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:28:14 --> Language Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Language Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Config Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Loader Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:28:14 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:28:14 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:28:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:28:14 --> Session Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:28:14 --> Session routines successfully run
DEBUG - 2015-09-27 22:28:14 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Email Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Controller Class Initialized
DEBUG - 2015-09-27 22:28:14 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:28:14 --> Model Class Initialized
DEBUG - 2015-09-27 22:28:14 --> DB Transaction Failure
ERROR - 2015-09-27 22:28:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' loans_plan_entry_fees_id = loans_plan_entry_fees.loans_plan_entry_fees_id' at line 3
DEBUG - 2015-09-27 22:28:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:29:05 --> Config Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:29:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:29:05 --> URI Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Router Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Output Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Security Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Input Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:29:05 --> Language Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Language Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Config Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Loader Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:29:05 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:29:05 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:29:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:29:05 --> Session Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:29:05 --> Session routines successfully run
DEBUG - 2015-09-27 22:29:05 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Email Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Controller Class Initialized
DEBUG - 2015-09-27 22:29:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:29:05 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:05 --> DB Transaction Failure
ERROR - 2015-09-27 22:29:05 --> Query error: Column 'loans_plan_entry_fees_id' in where clause is ambiguous
DEBUG - 2015-09-27 22:29:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:29:17 --> Config Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:29:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:29:17 --> URI Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Router Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Output Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Security Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Input Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:29:17 --> Language Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Language Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Config Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Loader Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:29:17 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:29:17 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:29:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:29:17 --> Session Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:29:17 --> Session routines successfully run
DEBUG - 2015-09-27 22:29:17 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Email Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Controller Class Initialized
DEBUG - 2015-09-27 22:29:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:29:17 --> Model Class Initialized
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:29:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:29:17 --> Final output sent to browser
DEBUG - 2015-09-27 22:29:17 --> Total execution time: 0.1318
DEBUG - 2015-09-27 22:31:55 --> Config Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:31:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:31:55 --> URI Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Router Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Output Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Security Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Input Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:31:55 --> Language Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Language Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Config Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Loader Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:31:55 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:31:55 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:31:55 --> Session Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:31:55 --> Session routines successfully run
DEBUG - 2015-09-27 22:31:55 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Email Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Controller Class Initialized
DEBUG - 2015-09-27 22:31:55 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:31:55 --> Model Class Initialized
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:31:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:31:55 --> Final output sent to browser
DEBUG - 2015-09-27 22:31:55 --> Total execution time: 0.1262
DEBUG - 2015-09-27 22:34:25 --> Config Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:34:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:34:25 --> URI Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Router Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Output Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Security Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Input Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:34:25 --> Language Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Language Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Config Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Loader Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:34:25 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:34:25 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:34:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:34:25 --> Session Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:34:25 --> Session routines successfully run
DEBUG - 2015-09-27 22:34:25 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Email Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Controller Class Initialized
DEBUG - 2015-09-27 22:34:25 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:34:25 --> Model Class Initialized
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:34:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:34:25 --> Final output sent to browser
DEBUG - 2015-09-27 22:34:25 --> Total execution time: 0.1348
DEBUG - 2015-09-27 22:37:35 --> Config Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:37:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:37:35 --> URI Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Router Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Output Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Security Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Input Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:37:35 --> Language Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Language Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Config Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Loader Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:37:35 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:37:35 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:37:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:37:35 --> Session Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:37:35 --> Session routines successfully run
DEBUG - 2015-09-27 22:37:35 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Email Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Controller Class Initialized
DEBUG - 2015-09-27 22:37:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:37:35 --> Model Class Initialized
ERROR - 2015-09-27 22:37:35 --> Severity: Notice  --> Undefined variable: loans_plan_entry_fees_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 242
ERROR - 2015-09-27 22:37:35 --> Severity: Notice  --> Undefined variable: loans_plan_entry_fees_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 243
ERROR - 2015-09-27 22:37:35 --> Severity: Notice  --> Undefined variable: loans_plan_entry_fees_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 244
ERROR - 2015-09-27 22:37:35 --> Severity: Notice  --> Undefined variable: loans_plan_entry_fees_rate C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 245
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:37:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:37:35 --> Final output sent to browser
DEBUG - 2015-09-27 22:37:35 --> Total execution time: 0.1400
DEBUG - 2015-09-27 22:39:11 --> Config Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:39:11 --> URI Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Router Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Output Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Security Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Input Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:39:11 --> Language Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Language Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Config Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Loader Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:39:11 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:39:11 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:39:11 --> Session Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:39:11 --> Session routines successfully run
DEBUG - 2015-09-27 22:39:11 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Email Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Controller Class Initialized
DEBUG - 2015-09-27 22:39:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:39:11 --> Model Class Initialized
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:39:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:39:11 --> Final output sent to browser
DEBUG - 2015-09-27 22:39:11 --> Total execution time: 0.1341
DEBUG - 2015-09-27 22:40:16 --> Config Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:40:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:40:16 --> URI Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Router Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Output Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Security Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Input Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:40:16 --> Language Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Language Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Config Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Loader Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:40:16 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:40:16 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:40:16 --> Session Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:40:16 --> Session routines successfully run
DEBUG - 2015-09-27 22:40:16 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Email Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Controller Class Initialized
DEBUG - 2015-09-27 22:40:16 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:40:16 --> Model Class Initialized
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:40:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:40:16 --> Final output sent to browser
DEBUG - 2015-09-27 22:40:16 --> Total execution time: 0.1325
DEBUG - 2015-09-27 22:42:42 --> Config Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:42:42 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:42:42 --> URI Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Router Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Output Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Security Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Input Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:42:42 --> Language Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Language Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Config Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Loader Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:42:42 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:42:42 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:42:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:42:42 --> Session Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:42:42 --> Session routines successfully run
DEBUG - 2015-09-27 22:42:42 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Email Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Controller Class Initialized
DEBUG - 2015-09-27 22:42:42 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:42:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:42:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:42:42 --> Final output sent to browser
DEBUG - 2015-09-27 22:42:42 --> Total execution time: 0.1319
DEBUG - 2015-09-27 22:43:30 --> Config Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:43:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:43:30 --> URI Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Router Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Output Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Security Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Input Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:43:30 --> Language Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Language Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Config Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Loader Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:43:30 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:43:30 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:43:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:43:30 --> Session Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:43:30 --> Session routines successfully run
DEBUG - 2015-09-27 22:43:30 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Email Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Controller Class Initialized
DEBUG - 2015-09-27 22:43:30 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:43:30 --> Model Class Initialized
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:43:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:43:30 --> Final output sent to browser
DEBUG - 2015-09-27 22:43:30 --> Total execution time: 0.1364
DEBUG - 2015-09-27 22:44:38 --> Config Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:44:38 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:44:38 --> URI Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Router Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Output Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Security Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Input Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:44:38 --> Language Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Language Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Config Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Loader Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:44:38 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:44:38 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:44:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:44:38 --> Session Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:44:38 --> Session routines successfully run
DEBUG - 2015-09-27 22:44:38 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Email Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Controller Class Initialized
DEBUG - 2015-09-27 22:44:38 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:44:38 --> Model Class Initialized
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:44:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:44:38 --> Final output sent to browser
DEBUG - 2015-09-27 22:44:38 --> Total execution time: 0.1352
DEBUG - 2015-09-27 22:45:22 --> Config Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:45:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:45:22 --> URI Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Router Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Output Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Security Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Input Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:45:22 --> Language Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Language Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Config Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Loader Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:45:22 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:45:22 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:45:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:45:22 --> Session Class Initialized
DEBUG - 2015-09-27 22:45:22 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:45:23 --> Session routines successfully run
DEBUG - 2015-09-27 22:45:23 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:45:23 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:45:23 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:45:23 --> Email Class Initialized
DEBUG - 2015-09-27 22:45:23 --> Controller Class Initialized
DEBUG - 2015-09-27 22:45:23 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:45:23 --> Model Class Initialized
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:45:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:45:23 --> Final output sent to browser
DEBUG - 2015-09-27 22:45:23 --> Total execution time: 0.1328
DEBUG - 2015-09-27 22:47:47 --> Config Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:47:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:47:47 --> URI Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Router Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Output Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Security Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Input Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:47:47 --> Language Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Language Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Config Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Loader Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:47:47 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:47:47 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:47:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:47:47 --> Session Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:47:47 --> Session routines successfully run
DEBUG - 2015-09-27 22:47:47 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Email Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Controller Class Initialized
DEBUG - 2015-09-27 22:47:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:47:47 --> Model Class Initialized
ERROR - 2015-09-27 22:47:47 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 72
ERROR - 2015-09-27 22:47:47 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 73
ERROR - 2015-09-27 22:47:47 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_custom_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 74
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:47:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:47:47 --> Final output sent to browser
DEBUG - 2015-09-27 22:47:47 --> Total execution time: 0.1297
DEBUG - 2015-09-27 22:54:15 --> Config Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:54:15 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:54:15 --> URI Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Router Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Output Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Security Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Input Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:54:15 --> Language Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Language Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Config Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Loader Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:54:15 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:54:15 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:54:15 --> Session Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:54:15 --> Session routines successfully run
DEBUG - 2015-09-27 22:54:15 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Email Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Controller Class Initialized
DEBUG - 2015-09-27 22:54:15 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:54:15 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:15 --> DB Transaction Failure
ERROR - 2015-09-27 22:54:15 --> Query error: Unknown table 'loans_plan_late_fee_on_total'
DEBUG - 2015-09-27 22:54:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:54:32 --> Config Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:54:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:54:32 --> URI Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Router Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Output Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Security Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Input Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:54:32 --> Language Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Language Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Config Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Loader Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:54:32 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:54:32 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:54:32 --> Session Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:54:32 --> Session routines successfully run
DEBUG - 2015-09-27 22:54:32 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Email Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Controller Class Initialized
DEBUG - 2015-09-27 22:54:32 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:54:32 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:32 --> DB Transaction Failure
ERROR - 2015-09-27 22:54:32 --> Query error: Unknown table 'loans_plan_late_fee_on_total'
DEBUG - 2015-09-27 22:54:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:54:47 --> Config Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:54:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:54:47 --> URI Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Router Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Output Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Security Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Input Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:54:47 --> Language Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Language Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Config Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Loader Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:54:47 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:54:47 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:54:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:54:47 --> Session Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:54:47 --> Session routines successfully run
DEBUG - 2015-09-27 22:54:47 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Email Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Controller Class Initialized
DEBUG - 2015-09-27 22:54:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:54:47 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:47 --> DB Transaction Failure
ERROR - 2015-09-27 22:54:47 --> Query error: Unknown table 'loans_plan_late_fee_on_total'
DEBUG - 2015-09-27 22:54:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:54:57 --> Config Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:54:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:54:57 --> URI Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Router Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Output Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Security Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Input Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:54:57 --> Language Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Language Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Config Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Loader Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:54:57 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:54:57 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:54:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:54:57 --> Session Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:54:57 --> Session routines successfully run
DEBUG - 2015-09-27 22:54:57 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Email Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Controller Class Initialized
DEBUG - 2015-09-27 22:54:57 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:54:57 --> Model Class Initialized
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:54:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:54:57 --> Final output sent to browser
DEBUG - 2015-09-27 22:54:57 --> Total execution time: 0.1233
DEBUG - 2015-09-27 22:55:41 --> Config Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:55:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:55:41 --> URI Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Router Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Output Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Security Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Input Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:55:41 --> Language Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Language Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Config Class Initialized
DEBUG - 2015-09-27 22:55:41 --> Loader Class Initialized
DEBUG - 2015-09-27 22:55:42 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:55:42 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:55:42 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:55:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:55:42 --> Session Class Initialized
DEBUG - 2015-09-27 22:55:42 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:55:42 --> Session routines successfully run
DEBUG - 2015-09-27 22:55:42 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:55:42 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:55:42 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:55:42 --> Email Class Initialized
DEBUG - 2015-09-27 22:55:42 --> Controller Class Initialized
DEBUG - 2015-09-27 22:55:42 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:55:42 --> Model Class Initialized
DEBUG - 2015-09-27 22:55:42 --> DB Transaction Failure
ERROR - 2015-09-27 22:55:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' loans_plan.loans_plan_late_fee_on_total_id = loans_plan_late_fee_on_total.loans' at line 3
DEBUG - 2015-09-27 22:55:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:57:10 --> Config Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:57:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:57:10 --> URI Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Router Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Output Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Security Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Input Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:57:10 --> Language Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Language Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Config Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Loader Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:57:10 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:57:10 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:57:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:57:10 --> Session Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:57:10 --> Session routines successfully run
DEBUG - 2015-09-27 22:57:10 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Email Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Controller Class Initialized
DEBUG - 2015-09-27 22:57:10 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:57:10 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:10 --> DB Transaction Failure
ERROR - 2015-09-27 22:57:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' loans_plan.loans_plan_late_fee_on_total_id = loans_plan_late_fee_on_total.loans' at line 3
DEBUG - 2015-09-27 22:57:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:57:12 --> Config Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:57:12 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:57:12 --> URI Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Router Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Output Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Security Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Input Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:57:12 --> Language Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Language Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Config Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Loader Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:57:12 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:57:12 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:57:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:57:12 --> Session Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:57:12 --> Session routines successfully run
DEBUG - 2015-09-27 22:57:12 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Email Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Controller Class Initialized
DEBUG - 2015-09-27 22:57:12 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:57:12 --> Model Class Initialized
DEBUG - 2015-09-27 22:57:12 --> DB Transaction Failure
ERROR - 2015-09-27 22:57:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' loans_plan.loans_plan_late_fee_on_total_id = loans_plan_late_fee_on_total.loans' at line 3
DEBUG - 2015-09-27 22:57:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 22:58:04 --> Config Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Hooks Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Utf8 Class Initialized
DEBUG - 2015-09-27 22:58:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 22:58:04 --> URI Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Router Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Output Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Security Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Input Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 22:58:04 --> Language Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Language Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Config Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Loader Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Helper loaded: url_helper
DEBUG - 2015-09-27 22:58:04 --> Helper loaded: form_helper
DEBUG - 2015-09-27 22:58:04 --> Database Driver Class Initialized
ERROR - 2015-09-27 22:58:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 22:58:04 --> Session Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Helper loaded: string_helper
DEBUG - 2015-09-27 22:58:04 --> Session routines successfully run
DEBUG - 2015-09-27 22:58:04 --> Form Validation Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Pagination Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Encrypt Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Email Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Controller Class Initialized
DEBUG - 2015-09-27 22:58:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 22:58:04 --> Model Class Initialized
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 22:58:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 22:58:04 --> Final output sent to browser
DEBUG - 2015-09-27 22:58:04 --> Total execution time: 0.1571
DEBUG - 2015-09-27 23:00:13 --> Config Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:00:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:00:13 --> URI Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Router Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Output Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Security Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Input Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:00:13 --> Language Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Language Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Config Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Loader Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:00:13 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:00:13 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:00:13 --> Session Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:00:13 --> Session routines successfully run
DEBUG - 2015-09-27 23:00:13 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Email Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Controller Class Initialized
DEBUG - 2015-09-27 23:00:13 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:00:13 --> Model Class Initialized
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:00:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:00:13 --> Final output sent to browser
DEBUG - 2015-09-27 23:00:13 --> Total execution time: 0.1253
DEBUG - 2015-09-27 23:10:35 --> Config Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:10:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:10:35 --> URI Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Router Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Output Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Security Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Input Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:10:35 --> Language Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Language Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Config Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Loader Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:10:35 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:10:35 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:10:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:10:35 --> Session Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:10:35 --> Session routines successfully run
DEBUG - 2015-09-27 23:10:35 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Email Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Controller Class Initialized
DEBUG - 2015-09-27 23:10:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:10:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:10:35 --> DB Transaction Failure
ERROR - 2015-09-27 23:10:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` loans_plan_entry_fees.loans_plan_entry_fees_id = loans_plan.loans_plan_id' at line 3
DEBUG - 2015-09-27 23:10:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:11:23 --> Config Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:11:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:11:23 --> URI Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Router Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Output Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Security Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Input Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:11:23 --> Language Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Language Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Config Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Loader Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:11:23 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:11:23 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:11:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:11:23 --> Session Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:11:23 --> Session routines successfully run
DEBUG - 2015-09-27 23:11:23 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Email Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Controller Class Initialized
DEBUG - 2015-09-27 23:11:23 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:11:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:11:23 --> DB Transaction Failure
ERROR - 2015-09-27 23:11:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` loans_plan_entry_fees.loans_plan_id = loans_plan.loans_plan_id' at line 3
DEBUG - 2015-09-27 23:11:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:12:16 --> Config Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:12:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:12:16 --> URI Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Router Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Output Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Security Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Input Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:12:16 --> Language Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Language Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Config Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Loader Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:12:16 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:12:16 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:12:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:12:16 --> Session Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:12:16 --> Session routines successfully run
DEBUG - 2015-09-27 23:12:16 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Email Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Controller Class Initialized
DEBUG - 2015-09-27 23:12:16 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:12:16 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:16 --> DB Transaction Failure
ERROR - 2015-09-27 23:12:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` loans_plan_entry_fees.loans_plan_id = loans_plan.loans_plan_id' at line 3
DEBUG - 2015-09-27 23:12:16 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:12:18 --> Config Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:12:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:12:18 --> URI Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Router Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Output Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Security Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Input Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:12:18 --> Language Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Language Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Config Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Loader Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:12:18 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:12:18 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:12:18 --> Session Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:12:18 --> Session routines successfully run
DEBUG - 2015-09-27 23:12:18 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Email Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Controller Class Initialized
DEBUG - 2015-09-27 23:12:18 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:12:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:18 --> DB Transaction Failure
ERROR - 2015-09-27 23:12:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` loans_plan_entry_fees.loans_plan_id = loans_plan.loans_plan_id' at line 3
DEBUG - 2015-09-27 23:12:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:12:46 --> Config Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:12:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:12:46 --> URI Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Router Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Output Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Security Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Input Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:12:46 --> Language Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Language Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Config Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Loader Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:12:46 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:12:46 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:12:46 --> Session Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:12:46 --> Session routines successfully run
DEBUG - 2015-09-27 23:12:46 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Email Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Controller Class Initialized
DEBUG - 2015-09-27 23:12:46 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:12:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:46 --> DB Transaction Failure
ERROR - 2015-09-27 23:12:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` loans_plan_entry_fees.loans_plan_id = loans_plan.loans_plan_id' at line 3
DEBUG - 2015-09-27 23:12:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:12:47 --> Config Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:12:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:12:47 --> URI Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Router Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Output Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Security Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Input Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:12:47 --> Language Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Language Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Config Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Loader Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:12:47 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:12:47 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:12:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:12:47 --> Session Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:12:47 --> Session routines successfully run
DEBUG - 2015-09-27 23:12:47 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Email Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Controller Class Initialized
DEBUG - 2015-09-27 23:12:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:12:47 --> Model Class Initialized
DEBUG - 2015-09-27 23:12:47 --> DB Transaction Failure
ERROR - 2015-09-27 23:12:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` loans_plan_entry_fees.loans_plan_id = loans_plan.loans_plan_id' at line 3
DEBUG - 2015-09-27 23:12:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:14:46 --> Config Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:14:46 --> URI Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Router Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Output Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Security Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Input Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:14:46 --> Language Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Language Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Config Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Loader Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:14:46 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:14:46 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:14:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:14:46 --> Session Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:14:46 --> Session routines successfully run
DEBUG - 2015-09-27 23:14:46 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Email Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Controller Class Initialized
DEBUG - 2015-09-27 23:14:46 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:14:46 --> Model Class Initialized
DEBUG - 2015-09-27 23:14:46 --> DB Transaction Failure
ERROR - 2015-09-27 23:14:46 --> Query error: Unknown table 'loans_plan_late_fee_on_total'
DEBUG - 2015-09-27 23:14:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:15:27 --> Config Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:15:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:15:27 --> URI Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Router Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Output Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Security Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Input Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:15:27 --> Language Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Language Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Config Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Loader Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:15:27 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:15:27 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:15:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:15:27 --> Session Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:15:27 --> Session routines successfully run
DEBUG - 2015-09-27 23:15:27 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Email Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Controller Class Initialized
DEBUG - 2015-09-27 23:15:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:15:27 --> Model Class Initialized
ERROR - 2015-09-27 23:15:27 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 72
ERROR - 2015-09-27 23:15:27 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 73
ERROR - 2015-09-27 23:15:27 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_custom_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 74
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:15:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:15:27 --> Final output sent to browser
DEBUG - 2015-09-27 23:15:27 --> Total execution time: 0.1521
DEBUG - 2015-09-27 23:17:14 --> Config Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:17:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:17:14 --> URI Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Router Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Output Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Security Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Input Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:17:14 --> Language Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Language Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Config Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Loader Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:17:14 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:17:14 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:17:14 --> Session Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:17:14 --> Session routines successfully run
DEBUG - 2015-09-27 23:17:14 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Email Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Controller Class Initialized
DEBUG - 2015-09-27 23:17:14 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:17:14 --> Model Class Initialized
ERROR - 2015-09-27 23:17:14 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 72
ERROR - 2015-09-27 23:17:14 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 73
ERROR - 2015-09-27 23:17:14 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_custom_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 74
ERROR - 2015-09-27 23:17:14 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 72
ERROR - 2015-09-27 23:17:14 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 73
ERROR - 2015-09-27 23:17:14 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_custom_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 74
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:17:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:17:14 --> Final output sent to browser
DEBUG - 2015-09-27 23:17:14 --> Total execution time: 0.1445
DEBUG - 2015-09-27 23:18:00 --> Config Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:18:00 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:18:00 --> URI Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Router Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Output Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Security Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Input Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:18:00 --> Language Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Language Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Config Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Loader Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:18:00 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:18:00 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:18:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:18:00 --> Session Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:18:00 --> Session routines successfully run
DEBUG - 2015-09-27 23:18:00 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Email Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Controller Class Initialized
DEBUG - 2015-09-27 23:18:00 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:18:00 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:00 --> DB Transaction Failure
ERROR - 2015-09-27 23:18:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` IS NULL' at line 3
DEBUG - 2015-09-27 23:18:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:18:21 --> Config Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:18:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:18:21 --> URI Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Router Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Output Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Security Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Input Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:18:21 --> Language Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Language Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Config Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Loader Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:18:21 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:18:21 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:18:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:18:21 --> Session Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:18:21 --> Session routines successfully run
DEBUG - 2015-09-27 23:18:21 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Email Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Controller Class Initialized
DEBUG - 2015-09-27 23:18:21 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:18:21 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:21 --> DB Transaction Failure
ERROR - 2015-09-27 23:18:21 --> Query error: Column 'loans_plan_id' in where clause is ambiguous
DEBUG - 2015-09-27 23:18:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:18:31 --> Config Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:18:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:18:31 --> URI Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Router Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Output Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Security Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Input Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:18:31 --> Language Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Language Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Config Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Loader Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:18:31 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:18:31 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:18:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:18:31 --> Session Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:18:31 --> Session routines successfully run
DEBUG - 2015-09-27 23:18:31 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Email Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Controller Class Initialized
DEBUG - 2015-09-27 23:18:31 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:18:31 --> Model Class Initialized
ERROR - 2015-09-27 23:18:31 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 72
ERROR - 2015-09-27 23:18:31 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 73
ERROR - 2015-09-27 23:18:31 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_custom_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 74
ERROR - 2015-09-27 23:18:31 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 72
ERROR - 2015-09-27 23:18:31 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 73
ERROR - 2015-09-27 23:18:31 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_custom_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 74
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:18:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:18:31 --> Final output sent to browser
DEBUG - 2015-09-27 23:18:31 --> Total execution time: 0.1419
DEBUG - 2015-09-27 23:19:14 --> Config Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:19:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:19:14 --> URI Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Router Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Output Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Security Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Input Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:19:14 --> Language Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Language Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Config Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Loader Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:19:14 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:19:14 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:19:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:19:14 --> Session Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:19:14 --> Session routines successfully run
DEBUG - 2015-09-27 23:19:14 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Email Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Controller Class Initialized
DEBUG - 2015-09-27 23:19:14 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:19:14 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:14 --> DB Transaction Failure
ERROR - 2015-09-27 23:19:14 --> Query error: Unknown table 'loans_plan_entry_fees'
DEBUG - 2015-09-27 23:19:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-27 23:19:25 --> Config Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:19:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:19:25 --> URI Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Router Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Output Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Security Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Input Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:19:25 --> Language Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Language Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Config Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Loader Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:19:25 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:19:25 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:19:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:19:25 --> Session Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:19:25 --> Session routines successfully run
DEBUG - 2015-09-27 23:19:25 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Email Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Controller Class Initialized
DEBUG - 2015-09-27 23:19:25 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:19:25 --> Model Class Initialized
ERROR - 2015-09-27 23:19:25 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 65
ERROR - 2015-09-27 23:19:25 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 66
ERROR - 2015-09-27 23:19:25 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 67
ERROR - 2015-09-27 23:19:25 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 68
ERROR - 2015-09-27 23:19:25 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_rate C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 69
ERROR - 2015-09-27 23:19:25 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 72
ERROR - 2015-09-27 23:19:25 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 73
ERROR - 2015-09-27 23:19:25 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_custom_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 74
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:19:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:19:25 --> Final output sent to browser
DEBUG - 2015-09-27 23:19:25 --> Total execution time: 0.1563
DEBUG - 2015-09-27 23:24:08 --> Config Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:24:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:24:08 --> URI Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Router Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Output Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Security Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Input Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:24:08 --> Language Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Language Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Config Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Loader Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:24:08 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:24:08 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:24:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:24:08 --> Session Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:24:08 --> Session routines successfully run
DEBUG - 2015-09-27 23:24:08 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Email Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Controller Class Initialized
DEBUG - 2015-09-27 23:24:08 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:24:08 --> Model Class Initialized
ERROR - 2015-09-27 23:24:08 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 65
ERROR - 2015-09-27 23:24:08 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 66
ERROR - 2015-09-27 23:24:08 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 67
ERROR - 2015-09-27 23:24:08 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 68
ERROR - 2015-09-27 23:24:08 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_rate C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 69
ERROR - 2015-09-27 23:24:08 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 73
ERROR - 2015-09-27 23:24:08 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_custom_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 74
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:24:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:24:08 --> Final output sent to browser
DEBUG - 2015-09-27 23:24:08 --> Total execution time: 0.1490
DEBUG - 2015-09-27 23:24:45 --> Config Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:24:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:24:45 --> URI Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Router Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Output Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Security Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Input Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:24:45 --> Language Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Language Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Config Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Loader Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:24:45 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:24:45 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:24:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:24:45 --> Session Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:24:45 --> Session routines successfully run
DEBUG - 2015-09-27 23:24:45 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Email Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Controller Class Initialized
DEBUG - 2015-09-27 23:24:45 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:24:45 --> Model Class Initialized
ERROR - 2015-09-27 23:24:45 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 65
ERROR - 2015-09-27 23:24:45 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 66
ERROR - 2015-09-27 23:24:45 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 67
ERROR - 2015-09-27 23:24:45 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 68
ERROR - 2015-09-27 23:24:45 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_rate C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 69
ERROR - 2015-09-27 23:24:45 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_late_fee_on_total_custom_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 74
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:24:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:24:45 --> Final output sent to browser
DEBUG - 2015-09-27 23:24:45 --> Total execution time: 0.1423
DEBUG - 2015-09-27 23:25:22 --> Config Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:25:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:25:22 --> URI Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Router Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Output Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Security Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Input Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:25:22 --> Language Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Language Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Config Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Loader Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:25:22 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:25:22 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:25:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:25:22 --> Session Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:25:22 --> Session routines successfully run
DEBUG - 2015-09-27 23:25:22 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Email Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Controller Class Initialized
DEBUG - 2015-09-27 23:25:22 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:25:22 --> Model Class Initialized
ERROR - 2015-09-27 23:25:22 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 65
ERROR - 2015-09-27 23:25:22 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 66
ERROR - 2015-09-27 23:25:22 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 67
ERROR - 2015-09-27 23:25:22 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 68
ERROR - 2015-09-27 23:25:22 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_rate C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 69
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:25:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:25:22 --> Final output sent to browser
DEBUG - 2015-09-27 23:25:22 --> Total execution time: 0.1302
DEBUG - 2015-09-27 23:27:53 --> Config Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:27:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:27:53 --> URI Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Router Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Output Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Security Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Input Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:27:53 --> Language Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Language Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Config Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Loader Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:27:53 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:27:53 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:27:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:27:53 --> Session Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:27:53 --> Session routines successfully run
DEBUG - 2015-09-27 23:27:53 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Email Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Controller Class Initialized
DEBUG - 2015-09-27 23:27:53 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:27:53 --> Model Class Initialized
ERROR - 2015-09-27 23:27:53 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 65
ERROR - 2015-09-27 23:27:53 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_min C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 66
ERROR - 2015-09-27 23:27:53 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_max C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 67
ERROR - 2015-09-27 23:27:53 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_value C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 68
ERROR - 2015-09-27 23:27:53 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_entry_fees_rate C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 69
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:27:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:27:53 --> Final output sent to browser
DEBUG - 2015-09-27 23:27:53 --> Total execution time: 0.1351
DEBUG - 2015-09-27 23:29:18 --> Config Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:29:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:29:18 --> URI Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Router Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Output Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Security Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Input Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:29:18 --> Language Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Language Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Config Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Loader Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:29:18 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:29:18 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:29:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:29:18 --> Session Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:29:18 --> Session routines successfully run
DEBUG - 2015-09-27 23:29:18 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Email Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Controller Class Initialized
DEBUG - 2015-09-27 23:29:18 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:29:18 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:53 --> Config Class Initialized
DEBUG - 2015-09-27 23:29:53 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:29:53 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:29:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:29:53 --> URI Class Initialized
DEBUG - 2015-09-27 23:29:53 --> Router Class Initialized
DEBUG - 2015-09-27 23:29:53 --> Output Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Security Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Input Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:29:54 --> Language Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Language Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Config Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Loader Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:29:54 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:29:54 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:29:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:29:54 --> Session Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:29:54 --> Session routines successfully run
DEBUG - 2015-09-27 23:29:54 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Email Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Controller Class Initialized
DEBUG - 2015-09-27 23:29:54 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:29:54 --> Model Class Initialized
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:29:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:29:54 --> Final output sent to browser
DEBUG - 2015-09-27 23:29:54 --> Total execution time: 0.1660
DEBUG - 2015-09-27 23:31:35 --> Config Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:31:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:31:35 --> URI Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Router Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Output Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Security Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Input Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:31:35 --> Language Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Language Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Config Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Loader Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:31:35 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:31:35 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:31:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:31:35 --> Session Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:31:35 --> Session routines successfully run
DEBUG - 2015-09-27 23:31:35 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Email Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Controller Class Initialized
DEBUG - 2015-09-27 23:31:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:31:35 --> Model Class Initialized
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:31:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:31:35 --> Final output sent to browser
DEBUG - 2015-09-27 23:31:35 --> Total execution time: 0.1420
DEBUG - 2015-09-27 23:32:43 --> Config Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:32:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:32:43 --> URI Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Router Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Output Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Security Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Input Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:32:43 --> Language Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Language Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Config Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Loader Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:32:43 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:32:43 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:32:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:32:43 --> Session Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:32:43 --> Session routines successfully run
DEBUG - 2015-09-27 23:32:43 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Email Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Controller Class Initialized
DEBUG - 2015-09-27 23:32:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:32:43 --> Model Class Initialized
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:32:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:32:43 --> Final output sent to browser
DEBUG - 2015-09-27 23:32:43 --> Total execution time: 0.1383
DEBUG - 2015-09-27 23:33:23 --> Config Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:33:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:33:23 --> URI Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Router Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Output Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Security Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Input Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:33:23 --> Language Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Language Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Config Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Loader Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:33:23 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:33:23 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:33:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:33:23 --> Session Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:33:23 --> Session routines successfully run
DEBUG - 2015-09-27 23:33:23 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Email Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Controller Class Initialized
DEBUG - 2015-09-27 23:33:23 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:33:23 --> Model Class Initialized
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:33:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:33:23 --> Final output sent to browser
DEBUG - 2015-09-27 23:33:23 --> Total execution time: 0.1267
DEBUG - 2015-09-27 23:38:39 --> Config Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Hooks Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Utf8 Class Initialized
DEBUG - 2015-09-27 23:38:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-27 23:38:39 --> URI Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Router Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Output Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Security Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Input Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-27 23:38:39 --> Language Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Language Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Config Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Loader Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Helper loaded: url_helper
DEBUG - 2015-09-27 23:38:39 --> Helper loaded: form_helper
DEBUG - 2015-09-27 23:38:39 --> Database Driver Class Initialized
ERROR - 2015-09-27 23:38:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-27 23:38:39 --> Session Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Helper loaded: string_helper
DEBUG - 2015-09-27 23:38:39 --> Session routines successfully run
DEBUG - 2015-09-27 23:38:39 --> Form Validation Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Pagination Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Encrypt Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Email Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Controller Class Initialized
DEBUG - 2015-09-27 23:38:39 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-27 23:38:39 --> Model Class Initialized
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-27 23:38:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-27 23:38:39 --> Final output sent to browser
DEBUG - 2015-09-27 23:38:39 --> Total execution time: 0.1424
