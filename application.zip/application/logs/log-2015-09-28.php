<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-09-28 00:03:26 --> Config Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:03:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:03:26 --> URI Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Router Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Output Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Security Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Input Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:03:26 --> Language Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Language Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Config Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Loader Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:03:26 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:03:26 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:03:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:03:26 --> Session Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:03:26 --> Session routines successfully run
DEBUG - 2015-09-28 00:03:26 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Email Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Controller Class Initialized
DEBUG - 2015-09-28 00:03:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:03:26 --> Model Class Initialized
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:03:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:03:26 --> Final output sent to browser
DEBUG - 2015-09-28 00:03:26 --> Total execution time: 0.1383
DEBUG - 2015-09-28 00:04:32 --> Config Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:04:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:04:32 --> URI Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Router Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Output Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Security Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Input Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:04:32 --> Language Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Language Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Config Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Loader Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:04:32 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:04:32 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:04:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:04:32 --> Session Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:04:32 --> Session routines successfully run
DEBUG - 2015-09-28 00:04:32 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Email Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Controller Class Initialized
DEBUG - 2015-09-28 00:04:32 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:04:32 --> Model Class Initialized
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:04:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:04:32 --> Final output sent to browser
DEBUG - 2015-09-28 00:04:32 --> Total execution time: 0.1277
DEBUG - 2015-09-28 00:10:27 --> Config Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:10:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:10:27 --> URI Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Router Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Output Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Security Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Input Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:10:27 --> Language Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Language Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Config Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Loader Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:10:27 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:10:27 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:10:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:10:27 --> Session Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:10:27 --> Session routines successfully run
DEBUG - 2015-09-28 00:10:27 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Email Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Controller Class Initialized
DEBUG - 2015-09-28 00:10:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:10:27 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:10:27 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:10:28 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:10:28 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:10:28 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:10:28 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:10:28 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:10:28 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:10:28 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:10:28 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:10:28 --> Model Class Initialized
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:10:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:10:28 --> Final output sent to browser
DEBUG - 2015-09-28 00:10:28 --> Total execution time: 0.1270
DEBUG - 2015-09-28 00:11:21 --> Config Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:11:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:11:21 --> URI Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Router Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Output Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Security Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Input Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:11:21 --> Language Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Language Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Config Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Loader Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:11:21 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:11:21 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:11:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:11:21 --> Session Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:11:21 --> Session routines successfully run
DEBUG - 2015-09-28 00:11:21 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Email Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Controller Class Initialized
DEBUG - 2015-09-28 00:11:21 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:11:21 --> Model Class Initialized
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:11:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:11:21 --> Final output sent to browser
DEBUG - 2015-09-28 00:11:21 --> Total execution time: 0.1255
DEBUG - 2015-09-28 00:12:04 --> Config Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:12:04 --> URI Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Router Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Output Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Security Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Input Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:12:04 --> Language Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Language Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Config Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Loader Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:12:04 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:12:04 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:12:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:12:04 --> Session Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:12:04 --> Session routines successfully run
DEBUG - 2015-09-28 00:12:04 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Email Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Controller Class Initialized
DEBUG - 2015-09-28 00:12:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:12:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:12:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:12:04 --> Final output sent to browser
DEBUG - 2015-09-28 00:12:04 --> Total execution time: 0.1438
DEBUG - 2015-09-28 00:21:16 --> Config Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:21:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:21:16 --> URI Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Router Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Output Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Security Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Input Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:21:16 --> Language Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Language Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Config Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Loader Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:21:16 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:21:16 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:21:16 --> Session Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:21:16 --> Session routines successfully run
DEBUG - 2015-09-28 00:21:16 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Email Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Controller Class Initialized
DEBUG - 2015-09-28 00:21:16 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:21:16 --> Model Class Initialized
DEBUG - 2015-09-28 00:21:17 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:21:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:21:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:21:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:21:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:21:17 --> Final output sent to browser
DEBUG - 2015-09-28 00:21:17 --> Total execution time: 0.1374
DEBUG - 2015-09-28 00:23:01 --> Config Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:23:01 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:23:01 --> URI Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Router Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Output Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Security Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Input Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:23:01 --> Language Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Language Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Config Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Loader Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:23:01 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:23:01 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:23:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:23:01 --> Session Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:23:01 --> Session routines successfully run
DEBUG - 2015-09-28 00:23:01 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Email Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Controller Class Initialized
DEBUG - 2015-09-28 00:23:01 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:23:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Config Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:23:12 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:23:12 --> URI Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Router Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Output Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Security Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Input Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:23:12 --> Language Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Language Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Config Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Loader Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:23:12 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:23:12 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:23:12 --> Session Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:23:12 --> Session routines successfully run
DEBUG - 2015-09-28 00:23:12 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Email Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Controller Class Initialized
DEBUG - 2015-09-28 00:23:12 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:23:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:23:12 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Config Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:24:01 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:24:01 --> URI Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Router Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Output Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Security Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Input Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:24:01 --> Language Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Language Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Config Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Loader Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:24:01 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:24:01 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:24:01 --> Session Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:24:01 --> Session routines successfully run
DEBUG - 2015-09-28 00:24:01 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Email Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Controller Class Initialized
DEBUG - 2015-09-28 00:24:01 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:24:01 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Config Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:24:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:24:33 --> URI Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Router Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Output Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Security Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Input Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:24:33 --> Language Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Language Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Config Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Loader Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:24:33 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:24:33 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:24:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:24:33 --> Session Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:24:33 --> Session routines successfully run
DEBUG - 2015-09-28 00:24:33 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Email Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Controller Class Initialized
DEBUG - 2015-09-28 00:24:33 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:24:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:24:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Config Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:25:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:25:10 --> URI Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Router Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Output Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Security Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Input Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:25:10 --> Language Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Language Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Config Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Loader Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:25:10 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:25:10 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:25:10 --> Session Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:25:10 --> Session routines successfully run
DEBUG - 2015-09-28 00:25:10 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Email Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Controller Class Initialized
DEBUG - 2015-09-28 00:25:10 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:25:10 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Config Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:25:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:25:33 --> URI Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Router Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Output Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Security Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Input Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:25:33 --> Language Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Language Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Config Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Loader Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:25:33 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:25:33 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:25:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:25:33 --> Session Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:25:33 --> Session routines successfully run
DEBUG - 2015-09-28 00:25:33 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Email Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Controller Class Initialized
DEBUG - 2015-09-28 00:25:33 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:25:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:25:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:25:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:25:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:25:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:25:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:25:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:25:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:25:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:25:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:25:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Config Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:25:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:25:52 --> URI Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Router Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Output Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Security Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Input Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:25:52 --> Language Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Language Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Config Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Loader Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:25:52 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:25:52 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:25:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:25:52 --> Session Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:25:52 --> Session routines successfully run
DEBUG - 2015-09-28 00:25:52 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Email Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Controller Class Initialized
DEBUG - 2015-09-28 00:25:52 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:25:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:25:52 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Config Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:27:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:27:56 --> URI Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Router Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Output Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Security Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Input Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:27:56 --> Language Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Language Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Config Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Loader Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:27:56 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:27:56 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:27:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:27:56 --> Session Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:27:56 --> Session routines successfully run
DEBUG - 2015-09-28 00:27:56 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Email Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Controller Class Initialized
DEBUG - 2015-09-28 00:27:56 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:27:56 --> Model Class Initialized
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:27:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:27:56 --> Final output sent to browser
DEBUG - 2015-09-28 00:27:56 --> Total execution time: 0.1580
DEBUG - 2015-09-28 00:28:33 --> Config Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:28:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:28:33 --> URI Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Router Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Output Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Security Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Input Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:28:33 --> Language Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Language Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Config Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Loader Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:28:33 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:28:33 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:28:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:28:33 --> Session Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:28:33 --> Session routines successfully run
DEBUG - 2015-09-28 00:28:33 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Email Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Controller Class Initialized
DEBUG - 2015-09-28 00:28:33 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:28:33 --> Model Class Initialized
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:28:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:28:33 --> Final output sent to browser
DEBUG - 2015-09-28 00:28:33 --> Total execution time: 0.1390
DEBUG - 2015-09-28 00:29:06 --> Config Class Initialized
DEBUG - 2015-09-28 00:29:06 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:29:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:29:07 --> URI Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Router Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Output Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Security Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Input Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:29:07 --> Language Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Language Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Config Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Loader Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:29:07 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:29:07 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:29:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:29:07 --> Session Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:29:07 --> Session routines successfully run
DEBUG - 2015-09-28 00:29:07 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Email Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Controller Class Initialized
DEBUG - 2015-09-28 00:29:07 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:29:07 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:29:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:29:07 --> Final output sent to browser
DEBUG - 2015-09-28 00:29:07 --> Total execution time: 0.1360
DEBUG - 2015-09-28 00:29:19 --> Config Class Initialized
DEBUG - 2015-09-28 00:29:19 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:29:19 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:29:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:29:19 --> URI Class Initialized
DEBUG - 2015-09-28 00:29:19 --> Router Class Initialized
ERROR - 2015-09-28 00:29:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 00:29:34 --> Config Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:29:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:29:34 --> URI Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Router Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Output Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Security Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Input Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:29:34 --> Language Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Language Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Config Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Loader Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:29:34 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:29:34 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:29:34 --> Session Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:29:34 --> Session routines successfully run
DEBUG - 2015-09-28 00:29:34 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Email Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Controller Class Initialized
DEBUG - 2015-09-28 00:29:34 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:29:34 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:29:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:29:34 --> Final output sent to browser
DEBUG - 2015-09-28 00:29:34 --> Total execution time: 0.1352
DEBUG - 2015-09-28 00:29:36 --> Config Class Initialized
DEBUG - 2015-09-28 00:29:36 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:29:36 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:29:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:29:36 --> URI Class Initialized
DEBUG - 2015-09-28 00:29:36 --> Router Class Initialized
ERROR - 2015-09-28 00:29:36 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 00:29:50 --> Config Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:29:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:29:50 --> URI Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Router Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Output Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Security Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Input Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:29:50 --> Language Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Language Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Config Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Loader Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:29:50 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:29:50 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:29:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:29:50 --> Session Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:29:50 --> Session routines successfully run
DEBUG - 2015-09-28 00:29:50 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Email Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Controller Class Initialized
DEBUG - 2015-09-28 00:29:50 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:29:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:29:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:29:50 --> Final output sent to browser
DEBUG - 2015-09-28 00:29:50 --> Total execution time: 0.1371
DEBUG - 2015-09-28 00:29:52 --> Config Class Initialized
DEBUG - 2015-09-28 00:29:52 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:29:52 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:29:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:29:52 --> URI Class Initialized
DEBUG - 2015-09-28 00:29:52 --> Router Class Initialized
ERROR - 2015-09-28 00:29:52 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 00:30:49 --> Config Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:30:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:30:49 --> URI Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Router Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Output Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Security Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Input Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:30:49 --> Language Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Language Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Config Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Loader Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:30:49 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:30:49 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:30:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:30:49 --> Session Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:30:49 --> Session routines successfully run
DEBUG - 2015-09-28 00:30:49 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Email Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Controller Class Initialized
DEBUG - 2015-09-28 00:30:49 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:30:49 --> Model Class Initialized
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:30:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:30:49 --> Final output sent to browser
DEBUG - 2015-09-28 00:30:49 --> Total execution time: 0.1431
DEBUG - 2015-09-28 00:30:51 --> Config Class Initialized
DEBUG - 2015-09-28 00:30:51 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:30:51 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:30:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:30:51 --> URI Class Initialized
DEBUG - 2015-09-28 00:30:51 --> Router Class Initialized
ERROR - 2015-09-28 00:30:51 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 00:32:04 --> Config Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:32:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:32:04 --> URI Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Router Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Output Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Security Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Input Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:32:04 --> Language Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Language Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Config Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Loader Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:32:04 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:32:04 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:32:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:32:04 --> Session Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:32:04 --> Session routines successfully run
DEBUG - 2015-09-28 00:32:04 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Email Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Controller Class Initialized
DEBUG - 2015-09-28 00:32:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:32:04 --> Model Class Initialized
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:32:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:32:04 --> Final output sent to browser
DEBUG - 2015-09-28 00:32:04 --> Total execution time: 0.1319
DEBUG - 2015-09-28 00:32:06 --> Config Class Initialized
DEBUG - 2015-09-28 00:32:06 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:32:06 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:32:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:32:06 --> URI Class Initialized
DEBUG - 2015-09-28 00:32:06 --> Router Class Initialized
ERROR - 2015-09-28 00:32:06 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 00:33:17 --> Config Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:33:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:33:17 --> URI Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Router Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Output Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Security Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Input Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:33:17 --> Language Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Language Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Config Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Loader Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:33:17 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:33:17 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:33:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:33:17 --> Session Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:33:17 --> Session routines successfully run
DEBUG - 2015-09-28 00:33:17 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Email Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Controller Class Initialized
DEBUG - 2015-09-28 00:33:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:33:17 --> Model Class Initialized
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:33:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:33:17 --> Final output sent to browser
DEBUG - 2015-09-28 00:33:17 --> Total execution time: 0.1349
DEBUG - 2015-09-28 00:33:18 --> Config Class Initialized
DEBUG - 2015-09-28 00:33:18 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:33:18 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:33:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:33:18 --> URI Class Initialized
DEBUG - 2015-09-28 00:33:18 --> Router Class Initialized
ERROR - 2015-09-28 00:33:18 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 00:37:51 --> Config Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:37:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:37:51 --> URI Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Router Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Output Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Security Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Input Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:37:51 --> Language Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Language Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Config Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Loader Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:37:51 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:37:51 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:37:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:37:51 --> Session Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:37:51 --> Session routines successfully run
DEBUG - 2015-09-28 00:37:51 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Email Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Controller Class Initialized
DEBUG - 2015-09-28 00:37:51 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:37:51 --> Model Class Initialized
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:37:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:37:51 --> Final output sent to browser
DEBUG - 2015-09-28 00:37:51 --> Total execution time: 0.1367
DEBUG - 2015-09-28 00:37:53 --> Config Class Initialized
DEBUG - 2015-09-28 00:37:53 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:37:53 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:37:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:37:53 --> URI Class Initialized
DEBUG - 2015-09-28 00:37:53 --> Router Class Initialized
ERROR - 2015-09-28 00:37:53 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 00:54:54 --> Config Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:54:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:54:54 --> URI Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Router Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Output Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Security Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Input Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:54:54 --> Language Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Language Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Config Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Loader Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:54:54 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:54:54 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:54:54 --> Session Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:54:54 --> Session routines successfully run
DEBUG - 2015-09-28 00:54:54 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Email Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Controller Class Initialized
DEBUG - 2015-09-28 00:54:54 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:54:54 --> Model Class Initialized
ERROR - 2015-09-28 00:54:54 --> Severity: Notice  --> Undefined property: stdClass::$use_compulsory_saving C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 111
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:54:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:54:54 --> Final output sent to browser
DEBUG - 2015-09-28 00:54:54 --> Total execution time: 0.2378
DEBUG - 2015-09-28 00:55:25 --> Config Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:55:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:55:25 --> URI Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Router Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Output Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Security Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Input Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:55:25 --> Language Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Language Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Config Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Loader Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:55:25 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:55:25 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:55:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:55:25 --> Session Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:55:25 --> Session routines successfully run
DEBUG - 2015-09-28 00:55:25 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Email Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Controller Class Initialized
DEBUG - 2015-09-28 00:55:25 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:55:25 --> Model Class Initialized
ERROR - 2015-09-28 00:55:25 --> Severity: Notice  --> Undefined property: stdClass::$use_compulsory_saving C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 111
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:55:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:55:25 --> Final output sent to browser
DEBUG - 2015-09-28 00:55:25 --> Total execution time: 0.2624
DEBUG - 2015-09-28 00:56:23 --> Config Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:56:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:56:23 --> URI Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Router Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Output Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Security Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Input Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:56:23 --> Language Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Language Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Config Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Loader Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:56:23 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:56:23 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:56:23 --> Session Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:56:23 --> Session routines successfully run
DEBUG - 2015-09-28 00:56:23 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Email Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Controller Class Initialized
DEBUG - 2015-09-28 00:56:23 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:56:23 --> Model Class Initialized
ERROR - 2015-09-28 00:56:23 --> Severity: Notice  --> Undefined property: stdClass::$use_compulsory_saving C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 111
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:56:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:56:23 --> Final output sent to browser
DEBUG - 2015-09-28 00:56:23 --> Total execution time: 0.2655
DEBUG - 2015-09-28 00:57:46 --> Config Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:57:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:57:46 --> URI Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Router Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Output Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Security Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Input Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:57:46 --> Language Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Language Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Config Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Loader Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:57:46 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:57:46 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:57:46 --> Session Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:57:46 --> Session routines successfully run
DEBUG - 2015-09-28 00:57:46 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Email Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Controller Class Initialized
DEBUG - 2015-09-28 00:57:46 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:57:46 --> Model Class Initialized
ERROR - 2015-09-28 00:57:46 --> Severity: Notice  --> Undefined property: stdClass::$use_compulsory_saving C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 111
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:57:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:57:46 --> Final output sent to browser
DEBUG - 2015-09-28 00:57:46 --> Total execution time: 0.2338
DEBUG - 2015-09-28 00:59:19 --> Config Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:59:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:59:19 --> URI Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Router Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Output Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Security Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Input Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:59:19 --> Language Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Language Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Config Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Loader Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:59:19 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:59:19 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:59:19 --> Session Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:59:19 --> Session routines successfully run
DEBUG - 2015-09-28 00:59:19 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Email Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Controller Class Initialized
DEBUG - 2015-09-28 00:59:19 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:59:19 --> Model Class Initialized
ERROR - 2015-09-28 00:59:19 --> Severity: Notice  --> Undefined property: stdClass::$use_compulsory_saving C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 111
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:59:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:59:19 --> Final output sent to browser
DEBUG - 2015-09-28 00:59:19 --> Total execution time: 0.2273
DEBUG - 2015-09-28 00:59:50 --> Config Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Hooks Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Utf8 Class Initialized
DEBUG - 2015-09-28 00:59:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 00:59:50 --> URI Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Router Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Output Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Security Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Input Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 00:59:50 --> Language Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Language Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Config Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Loader Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Helper loaded: url_helper
DEBUG - 2015-09-28 00:59:50 --> Helper loaded: form_helper
DEBUG - 2015-09-28 00:59:50 --> Database Driver Class Initialized
ERROR - 2015-09-28 00:59:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 00:59:50 --> Session Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Helper loaded: string_helper
DEBUG - 2015-09-28 00:59:50 --> Session routines successfully run
DEBUG - 2015-09-28 00:59:50 --> Form Validation Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Pagination Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Encrypt Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Email Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Controller Class Initialized
DEBUG - 2015-09-28 00:59:50 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 00:59:50 --> Model Class Initialized
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 00:59:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 00:59:50 --> Final output sent to browser
DEBUG - 2015-09-28 00:59:50 --> Total execution time: 0.2499
DEBUG - 2015-09-28 01:00:40 --> Config Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Hooks Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Utf8 Class Initialized
DEBUG - 2015-09-28 01:00:40 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 01:00:40 --> URI Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Router Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Output Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Security Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Input Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 01:00:40 --> Language Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Language Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Config Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Loader Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Helper loaded: url_helper
DEBUG - 2015-09-28 01:00:40 --> Helper loaded: form_helper
DEBUG - 2015-09-28 01:00:40 --> Database Driver Class Initialized
ERROR - 2015-09-28 01:00:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 01:00:40 --> Session Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Helper loaded: string_helper
DEBUG - 2015-09-28 01:00:40 --> Session routines successfully run
DEBUG - 2015-09-28 01:00:40 --> Form Validation Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Pagination Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Encrypt Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Email Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Controller Class Initialized
DEBUG - 2015-09-28 01:00:40 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
DEBUG - 2015-09-28 01:00:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 01:00:40 --> Model Class Initialized
ERROR - 2015-09-28 01:00:40 --> 404 Page Not Found --> microfinance/add-loans-plan
DEBUG - 2015-09-28 01:01:58 --> Config Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Hooks Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Utf8 Class Initialized
DEBUG - 2015-09-28 01:01:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 01:01:58 --> URI Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Router Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Output Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Security Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Input Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 01:01:58 --> Language Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Language Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Config Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Loader Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Helper loaded: url_helper
DEBUG - 2015-09-28 01:01:58 --> Helper loaded: form_helper
DEBUG - 2015-09-28 01:01:58 --> Database Driver Class Initialized
ERROR - 2015-09-28 01:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 01:01:58 --> Session Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Helper loaded: string_helper
DEBUG - 2015-09-28 01:01:58 --> Session routines successfully run
DEBUG - 2015-09-28 01:01:58 --> Form Validation Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Pagination Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Encrypt Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Email Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Controller Class Initialized
DEBUG - 2015-09-28 01:01:58 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 01:01:58 --> Model Class Initialized
ERROR - 2015-09-28 01:01:58 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 01:01:58 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 01:01:58 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 01:01:58 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 01:01:58 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 01:01:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 01:01:58 --> Final output sent to browser
DEBUG - 2015-09-28 01:01:58 --> Total execution time: 0.3689
DEBUG - 2015-09-28 01:04:29 --> Config Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Hooks Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Utf8 Class Initialized
DEBUG - 2015-09-28 01:04:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 01:04:29 --> URI Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Router Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Output Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Security Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Input Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 01:04:29 --> Language Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Language Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Config Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Loader Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Helper loaded: url_helper
DEBUG - 2015-09-28 01:04:29 --> Helper loaded: form_helper
DEBUG - 2015-09-28 01:04:29 --> Database Driver Class Initialized
ERROR - 2015-09-28 01:04:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 01:04:29 --> Session Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Helper loaded: string_helper
DEBUG - 2015-09-28 01:04:29 --> Session routines successfully run
DEBUG - 2015-09-28 01:04:29 --> Form Validation Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Pagination Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Encrypt Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Email Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Controller Class Initialized
DEBUG - 2015-09-28 01:04:29 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 01:04:29 --> Model Class Initialized
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 01:04:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 01:04:29 --> Final output sent to browser
DEBUG - 2015-09-28 01:04:29 --> Total execution time: 0.2477
DEBUG - 2015-09-28 01:05:05 --> Config Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Hooks Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Utf8 Class Initialized
DEBUG - 2015-09-28 01:05:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 01:05:05 --> URI Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Router Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Output Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Security Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Input Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 01:05:05 --> Language Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Language Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Config Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Loader Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Helper loaded: url_helper
DEBUG - 2015-09-28 01:05:05 --> Helper loaded: form_helper
DEBUG - 2015-09-28 01:05:05 --> Database Driver Class Initialized
ERROR - 2015-09-28 01:05:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 01:05:05 --> Session Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Helper loaded: string_helper
DEBUG - 2015-09-28 01:05:05 --> Session routines successfully run
DEBUG - 2015-09-28 01:05:05 --> Form Validation Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Pagination Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Encrypt Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Email Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Controller Class Initialized
DEBUG - 2015-09-28 01:05:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 01:05:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 01:05:05 --> Model Class Initialized
ERROR - 2015-09-28 01:05:05 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_onames C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\edit_loans_plan.php 5
ERROR - 2015-09-28 01:05:05 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_fname C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\edit_loans_plan.php 6
ERROR - 2015-09-28 01:05:05 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_email C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\edit_loans_plan.php 7
ERROR - 2015-09-28 01:05:05 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_phone C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\edit_loans_plan.php 8
DEBUG - 2015-09-28 16:52:20 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:20 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Output Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Security Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Input Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:52:20 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Loader Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:52:20 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:52:20 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-28 16:52:20 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:52:20 --> Session Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:52:20 --> A session cookie was not found.
DEBUG - 2015-09-28 16:52:20 --> Session routines successfully run
DEBUG - 2015-09-28 16:52:20 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Email Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Controller Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:20 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Output Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Security Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Input Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:52:20 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Loader Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:52:20 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:52:20 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:52:20 --> Session Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:52:20 --> Session routines successfully run
DEBUG - 2015-09-28 16:52:20 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Email Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Controller Class Initialized
DEBUG - 2015-09-28 16:52:20 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:52:20 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:52:20 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-28 16:52:20 --> Final output sent to browser
DEBUG - 2015-09-28 16:52:20 --> Total execution time: 0.1594
DEBUG - 2015-09-28 16:52:21 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:21 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:21 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:21 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:21 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:21 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:21 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:21 --> Router Class Initialized
ERROR - 2015-09-28 16:52:21 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:52:21 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:52:21 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:52:21 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:52:28 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:28 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:28 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:28 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:28 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:28 --> Output Class Initialized
DEBUG - 2015-09-28 16:52:28 --> Security Class Initialized
DEBUG - 2015-09-28 16:52:28 --> Input Class Initialized
DEBUG - 2015-09-28 16:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:52:29 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Loader Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:52:29 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:52:29 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-28 16:52:29 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:52:29 --> Session Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:52:29 --> Session routines successfully run
DEBUG - 2015-09-28 16:52:29 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Email Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Controller Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:52:29 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:52:29 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:52:29 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 16:52:29 --> XSS Filtering completed
DEBUG - 2015-09-28 16:52:29 --> Unable to find validation rule: exists
DEBUG - 2015-09-28 16:52:29 --> XSS Filtering completed
DEBUG - 2015-09-28 16:52:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:52:29 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-28 16:52:29 --> Final output sent to browser
DEBUG - 2015-09-28 16:52:29 --> Total execution time: 0.2128
DEBUG - 2015-09-28 16:52:30 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:30 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:30 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:30 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:30 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:30 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Router Class Initialized
ERROR - 2015-09-28 16:52:30 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:52:30 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:30 --> Utf8 Class Initialized
ERROR - 2015-09-28 16:52:30 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:52:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:30 --> URI Class Initialized
ERROR - 2015-09-28 16:52:30 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:52:30 --> Router Class Initialized
ERROR - 2015-09-28 16:52:30 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:52:40 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:40 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:40 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:40 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:40 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:40 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Output Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Security Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Input Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:52:41 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Loader Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:52:41 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:52:41 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-28 16:52:41 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:52:41 --> Session Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:52:41 --> Session routines successfully run
DEBUG - 2015-09-28 16:52:41 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Email Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Controller Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:52:41 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:52:41 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:52:41 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 16:52:41 --> XSS Filtering completed
DEBUG - 2015-09-28 16:52:41 --> Unable to find validation rule: exists
DEBUG - 2015-09-28 16:52:41 --> XSS Filtering completed
DEBUG - 2015-09-28 16:52:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:52:41 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-28 16:52:41 --> Final output sent to browser
DEBUG - 2015-09-28 16:52:41 --> Total execution time: 0.1749
DEBUG - 2015-09-28 16:52:41 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:41 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:41 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:41 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:41 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:41 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:41 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:41 --> UTF-8 Support Enabled
ERROR - 2015-09-28 16:52:41 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:52:41 --> URI Class Initialized
ERROR - 2015-09-28 16:52:41 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:52:41 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:52:41 --> Router Class Initialized
ERROR - 2015-09-28 16:52:41 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:52:47 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:47 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Output Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Security Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Input Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:52:47 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Language Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Loader Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:52:47 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:52:47 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:52:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:52:47 --> Session Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:52:47 --> Session routines successfully run
DEBUG - 2015-09-28 16:52:47 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Email Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Controller Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:52:47 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:52:47 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:52:47 --> Model Class Initialized
DEBUG - 2015-09-28 16:52:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 16:52:47 --> XSS Filtering completed
DEBUG - 2015-09-28 16:52:47 --> Unable to find validation rule: exists
DEBUG - 2015-09-28 16:52:47 --> XSS Filtering completed
DEBUG - 2015-09-28 16:52:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:52:47 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-28 16:52:47 --> Final output sent to browser
DEBUG - 2015-09-28 16:52:47 --> Total execution time: 0.1815
DEBUG - 2015-09-28 16:52:48 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:48 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:48 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:48 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:48 --> URI Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Config Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:52:48 --> Router Class Initialized
DEBUG - 2015-09-28 16:52:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:52:48 --> URI Class Initialized
ERROR - 2015-09-28 16:52:48 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:52:48 --> Router Class Initialized
ERROR - 2015-09-28 16:52:48 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:52:48 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:52:48 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:04 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:04 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Output Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Security Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Input Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:53:04 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Loader Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:53:04 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:53:04 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:53:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:53:04 --> Session Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:53:04 --> Session routines successfully run
DEBUG - 2015-09-28 16:53:04 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Email Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Controller Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:53:04 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:53:04 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:53:04 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 16:53:04 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:04 --> Unable to find validation rule: exists
DEBUG - 2015-09-28 16:53:04 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:53:04 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-28 16:53:04 --> Final output sent to browser
DEBUG - 2015-09-28 16:53:04 --> Total execution time: 0.2054
DEBUG - 2015-09-28 16:53:05 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:05 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:05 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:05 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:05 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:05 --> Router Class Initialized
ERROR - 2015-09-28 16:53:05 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:05 --> Router Class Initialized
ERROR - 2015-09-28 16:53:05 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:53:05 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:53:05 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:18 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:18 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Output Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Security Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Input Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:53:18 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Loader Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:53:18 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:53:18 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-28 16:53:18 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:53:18 --> Session Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:53:18 --> Session routines successfully run
DEBUG - 2015-09-28 16:53:18 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Email Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Controller Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:53:18 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:53:18 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:53:18 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 16:53:18 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:18 --> Unable to find validation rule: exists
DEBUG - 2015-09-28 16:53:18 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:53:18 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-28 16:53:18 --> Final output sent to browser
DEBUG - 2015-09-28 16:53:18 --> Total execution time: 0.2002
DEBUG - 2015-09-28 16:53:19 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:19 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:19 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:19 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:19 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Router Class Initialized
ERROR - 2015-09-28 16:53:19 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:53:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:19 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Utf8 Class Initialized
ERROR - 2015-09-28 16:53:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:19 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:19 --> Router Class Initialized
ERROR - 2015-09-28 16:53:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:26 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:26 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Output Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Security Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Input Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:53:26 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Loader Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:53:26 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:53:26 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:53:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:53:26 --> Session Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:53:26 --> Session routines successfully run
DEBUG - 2015-09-28 16:53:26 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Email Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Controller Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 16:53:26 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:26 --> Unable to find validation rule: exists
DEBUG - 2015-09-28 16:53:26 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:53:26 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-28 16:53:26 --> Final output sent to browser
DEBUG - 2015-09-28 16:53:26 --> Total execution time: 0.1802
DEBUG - 2015-09-28 16:53:26 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:26 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:26 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:26 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:26 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:26 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:26 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:27 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:27 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:27 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:27 --> Utf8 Class Initialized
ERROR - 2015-09-28 16:53:27 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:27 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:27 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:27 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:27 --> Router Class Initialized
ERROR - 2015-09-28 16:53:27 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:53:27 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:53:27 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:34 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:34 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Output Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Security Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Input Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:53:34 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Loader Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:53:34 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:53:34 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:53:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:53:34 --> Session Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:53:34 --> Session routines successfully run
DEBUG - 2015-09-28 16:53:34 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Email Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Controller Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:53:34 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:53:34 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:53:34 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 16:53:34 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:34 --> Unable to find validation rule: exists
DEBUG - 2015-09-28 16:53:34 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:53:34 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-28 16:53:34 --> Final output sent to browser
DEBUG - 2015-09-28 16:53:34 --> Total execution time: 0.1812
DEBUG - 2015-09-28 16:53:34 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:34 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:34 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:34 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:34 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:34 --> Router Class Initialized
ERROR - 2015-09-28 16:53:34 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:53:34 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:53:34 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:53:34 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:43 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:43 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Output Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Security Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Input Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:53:43 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Loader Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:53:43 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:53:43 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:53:43 --> Session Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:53:43 --> Session routines successfully run
DEBUG - 2015-09-28 16:53:43 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Email Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Controller Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:53:43 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:53:43 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:53:43 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 16:53:43 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:43 --> Unable to find validation rule: exists
DEBUG - 2015-09-28 16:53:43 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:53:43 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-28 16:53:43 --> Final output sent to browser
DEBUG - 2015-09-28 16:53:43 --> Total execution time: 0.1848
DEBUG - 2015-09-28 16:53:44 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:44 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:44 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:44 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:44 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:44 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:44 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:44 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:44 --> UTF-8 Support Enabled
ERROR - 2015-09-28 16:53:44 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:44 --> URI Class Initialized
ERROR - 2015-09-28 16:53:44 --> 404 Page Not Found --> 
ERROR - 2015-09-28 16:53:44 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:44 --> Router Class Initialized
ERROR - 2015-09-28 16:53:44 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:53:59 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:59 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:59 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Output Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Security Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Input Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:53:59 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Loader Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:53:59 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:53:59 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:53:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:53:59 --> Session Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:53:59 --> Session routines successfully run
DEBUG - 2015-09-28 16:53:59 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Email Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Controller Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Auth MX_Controller Initialized
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 16:53:59 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:59 --> Unable to find validation rule: exists
DEBUG - 2015-09-28 16:53:59 --> XSS Filtering completed
DEBUG - 2015-09-28 16:53:59 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:53:59 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:53:59 --> URI Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Router Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Output Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Security Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Input Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:53:59 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Language Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Config Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Loader Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:53:59 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:53:59 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:53:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:53:59 --> Session Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:53:59 --> Session routines successfully run
DEBUG - 2015-09-28 16:53:59 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Email Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Controller Class Initialized
DEBUG - 2015-09-28 16:53:59 --> Admin MX_Controller Initialized
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-28 16:53:59 --> Model Class Initialized
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 16:53:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 16:53:59 --> Final output sent to browser
DEBUG - 2015-09-28 16:53:59 --> Total execution time: 0.2026
DEBUG - 2015-09-28 16:54:11 --> Config Class Initialized
DEBUG - 2015-09-28 16:54:11 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:54:11 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:54:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:54:11 --> URI Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Router Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Output Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Security Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Input Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:54:12 --> Language Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Language Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Config Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Loader Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:54:12 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:54:12 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:54:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:54:12 --> Session Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:54:12 --> Session routines successfully run
DEBUG - 2015-09-28 16:54:12 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Email Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Controller Class Initialized
DEBUG - 2015-09-28 16:54:12 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 16:54:12 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 16:54:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 16:54:12 --> Final output sent to browser
DEBUG - 2015-09-28 16:54:12 --> Total execution time: 0.2384
DEBUG - 2015-09-28 16:54:23 --> Config Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:54:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:54:23 --> URI Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Router Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Output Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Security Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Input Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:54:23 --> Language Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Language Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Config Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Loader Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:54:23 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:54:23 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:54:23 --> Session Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:54:23 --> Session routines successfully run
DEBUG - 2015-09-28 16:54:23 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Email Class Initialized
DEBUG - 2015-09-28 16:54:23 --> Controller Class Initialized
DEBUG - 2015-09-28 16:54:24 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 16:54:24 --> Model Class Initialized
ERROR - 2015-09-28 16:54:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 16:54:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 16:54:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 16:54:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 16:54:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 16:54:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 16:54:24 --> Final output sent to browser
DEBUG - 2015-09-28 16:54:24 --> Total execution time: 0.2389
DEBUG - 2015-09-28 16:56:40 --> Config Class Initialized
DEBUG - 2015-09-28 16:56:40 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:56:40 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:56:40 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:56:40 --> URI Class Initialized
DEBUG - 2015-09-28 16:56:40 --> Router Class Initialized
ERROR - 2015-09-28 16:56:40 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 16:56:54 --> Config Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:56:54 --> URI Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Router Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Output Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Security Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Input Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 16:56:54 --> Language Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Language Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Config Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Loader Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Helper loaded: url_helper
DEBUG - 2015-09-28 16:56:54 --> Helper loaded: form_helper
DEBUG - 2015-09-28 16:56:54 --> Database Driver Class Initialized
ERROR - 2015-09-28 16:56:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 16:56:54 --> Session Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Helper loaded: string_helper
DEBUG - 2015-09-28 16:56:54 --> Session routines successfully run
DEBUG - 2015-09-28 16:56:54 --> Form Validation Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Pagination Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Encrypt Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Email Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Controller Class Initialized
DEBUG - 2015-09-28 16:56:54 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 16:56:54 --> Model Class Initialized
ERROR - 2015-09-28 16:56:54 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 16:56:54 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 16:56:54 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 16:56:54 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 16:56:54 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 16:56:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 16:56:54 --> Final output sent to browser
DEBUG - 2015-09-28 16:56:54 --> Total execution time: 0.2751
DEBUG - 2015-09-28 16:56:56 --> Config Class Initialized
DEBUG - 2015-09-28 16:56:56 --> Hooks Class Initialized
DEBUG - 2015-09-28 16:56:56 --> Utf8 Class Initialized
DEBUG - 2015-09-28 16:56:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 16:56:56 --> URI Class Initialized
DEBUG - 2015-09-28 16:56:56 --> Router Class Initialized
ERROR - 2015-09-28 16:56:56 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 17:12:44 --> Config Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:12:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:12:44 --> URI Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Router Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Output Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Security Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Input Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:12:44 --> Language Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Language Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Config Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Loader Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:12:44 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:12:44 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:12:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:12:44 --> Session Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:12:44 --> Session routines successfully run
DEBUG - 2015-09-28 17:12:44 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Email Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Controller Class Initialized
DEBUG - 2015-09-28 17:12:44 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
DEBUG - 2015-09-28 17:12:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:12:44 --> Model Class Initialized
ERROR - 2015-09-28 17:12:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:12:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:12:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:12:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:12:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
DEBUG - 2015-09-28 17:12:45 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:12:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:12:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:12:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:12:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:12:45 --> Final output sent to browser
DEBUG - 2015-09-28 17:12:45 --> Total execution time: 0.2242
DEBUG - 2015-09-28 17:12:47 --> Config Class Initialized
DEBUG - 2015-09-28 17:12:47 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:12:47 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:12:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:12:47 --> URI Class Initialized
DEBUG - 2015-09-28 17:12:47 --> Router Class Initialized
ERROR - 2015-09-28 17:12:47 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 17:13:37 --> Config Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:13:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:13:37 --> URI Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Router Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Output Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Security Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Input Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:13:37 --> Language Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Language Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Config Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Loader Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:13:37 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:13:37 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-28 17:13:37 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:13:37 --> Session Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:13:37 --> Session routines successfully run
DEBUG - 2015-09-28 17:13:37 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Email Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Controller Class Initialized
DEBUG - 2015-09-28 17:13:37 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:13:37 --> Model Class Initialized
ERROR - 2015-09-28 17:13:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:13:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:13:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:13:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:13:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:13:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:13:37 --> Final output sent to browser
DEBUG - 2015-09-28 17:13:37 --> Total execution time: 0.2532
DEBUG - 2015-09-28 17:13:40 --> Config Class Initialized
DEBUG - 2015-09-28 17:13:40 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:13:40 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:13:40 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:13:40 --> URI Class Initialized
DEBUG - 2015-09-28 17:13:40 --> Router Class Initialized
ERROR - 2015-09-28 17:13:40 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 17:13:59 --> Config Class Initialized
DEBUG - 2015-09-28 17:13:59 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:13:59 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:13:59 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:13:59 --> URI Class Initialized
DEBUG - 2015-09-28 17:13:59 --> Router Class Initialized
DEBUG - 2015-09-28 17:13:59 --> Output Class Initialized
DEBUG - 2015-09-28 17:13:59 --> Security Class Initialized
DEBUG - 2015-09-28 17:13:59 --> Input Class Initialized
DEBUG - 2015-09-28 17:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:13:59 --> Language Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Language Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Config Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Loader Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:14:00 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:14:00 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:14:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:14:00 --> Session Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:14:00 --> Session routines successfully run
DEBUG - 2015-09-28 17:14:00 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Email Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Controller Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:14:00 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-28 17:14:00 --> XSS Filtering completed
ERROR - 2015-09-28 17:14:00 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:14:00 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:14:00 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:14:00 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:14:00 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:14:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:14:00 --> Final output sent to browser
DEBUG - 2015-09-28 17:14:00 --> Total execution time: 0.2398
DEBUG - 2015-09-28 17:14:02 --> Config Class Initialized
DEBUG - 2015-09-28 17:14:02 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:14:02 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:14:02 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:14:02 --> URI Class Initialized
DEBUG - 2015-09-28 17:14:02 --> Router Class Initialized
ERROR - 2015-09-28 17:14:02 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 17:14:07 --> Config Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:14:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:14:07 --> URI Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Router Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Output Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Security Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Input Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:14:07 --> Language Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Language Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Config Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Loader Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:14:07 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:14:07 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:14:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:14:07 --> Session Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:14:07 --> Session routines successfully run
DEBUG - 2015-09-28 17:14:07 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Email Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Controller Class Initialized
DEBUG - 2015-09-28 17:14:07 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:14:07 --> Model Class Initialized
ERROR - 2015-09-28 17:14:07 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:14:07 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:14:07 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:14:07 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 17:14:07 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:14:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:14:07 --> Final output sent to browser
DEBUG - 2015-09-28 17:14:07 --> Total execution time: 0.2223
DEBUG - 2015-09-28 17:14:09 --> Config Class Initialized
DEBUG - 2015-09-28 17:14:09 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:14:09 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:14:09 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:14:09 --> URI Class Initialized
DEBUG - 2015-09-28 17:14:09 --> Router Class Initialized
ERROR - 2015-09-28 17:14:09 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 17:18:47 --> Config Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:18:47 --> URI Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Router Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Output Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Security Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Input Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:18:47 --> Language Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Language Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Config Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Loader Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:18:47 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:18:47 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:18:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:18:47 --> Session Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:18:47 --> Session routines successfully run
DEBUG - 2015-09-28 17:18:47 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Email Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Controller Class Initialized
DEBUG - 2015-09-28 17:18:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:18:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:18:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:18:47 --> Final output sent to browser
DEBUG - 2015-09-28 17:18:47 --> Total execution time: 0.2205
DEBUG - 2015-09-28 17:25:08 --> Config Class Initialized
DEBUG - 2015-09-28 17:25:08 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:25:08 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:25:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:25:08 --> URI Class Initialized
DEBUG - 2015-09-28 17:25:08 --> Router Class Initialized
DEBUG - 2015-09-28 17:25:08 --> Output Class Initialized
DEBUG - 2015-09-28 17:25:08 --> Security Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Input Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:25:09 --> Language Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Language Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Config Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Loader Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:25:09 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:25:09 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:25:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:25:09 --> Session Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:25:09 --> Session routines successfully run
DEBUG - 2015-09-28 17:25:09 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Email Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Controller Class Initialized
DEBUG - 2015-09-28 17:25:09 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:25:09 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:25:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:25:09 --> Final output sent to browser
DEBUG - 2015-09-28 17:25:09 --> Total execution time: 0.2423
DEBUG - 2015-09-28 17:25:14 --> Config Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:25:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:25:14 --> URI Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Router Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Output Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Security Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Input Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:25:14 --> Language Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Language Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Config Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Loader Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:25:14 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:25:14 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:25:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:25:14 --> Session Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:25:14 --> Session routines successfully run
DEBUG - 2015-09-28 17:25:14 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Email Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Controller Class Initialized
DEBUG - 2015-09-28 17:25:14 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:25:14 --> Model Class Initialized
ERROR - 2015-09-28 17:25:14 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-28 17:25:14 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-28 17:25:14 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-28 17:25:14 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-28 17:25:14 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/microfinance/views/savings_plan/add_savings_plan.php
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:25:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:25:14 --> Final output sent to browser
DEBUG - 2015-09-28 17:25:14 --> Total execution time: 0.2401
DEBUG - 2015-09-28 17:46:18 --> Config Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:46:18 --> URI Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Router Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Output Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Security Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Input Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:46:18 --> Language Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Language Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Config Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Loader Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:46:18 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:46:18 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:46:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:46:18 --> Session Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:46:18 --> Session routines successfully run
DEBUG - 2015-09-28 17:46:18 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Email Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Controller Class Initialized
DEBUG - 2015-09-28 17:46:18 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:46:18 --> Model Class Initialized
ERROR - 2015-09-28 17:46:18 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 106
ERROR - 2015-09-28 17:46:18 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 106
ERROR - 2015-09-28 17:46:18 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 106
ERROR - 2015-09-28 17:46:18 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 106
ERROR - 2015-09-28 17:46:18 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 106
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:46:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:46:18 --> Final output sent to browser
DEBUG - 2015-09-28 17:46:18 --> Total execution time: 0.2934
DEBUG - 2015-09-28 17:46:21 --> Config Class Initialized
DEBUG - 2015-09-28 17:46:21 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:46:21 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:46:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:46:21 --> URI Class Initialized
DEBUG - 2015-09-28 17:46:21 --> Router Class Initialized
ERROR - 2015-09-28 17:46:21 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 17:46:47 --> Config Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:46:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:46:47 --> URI Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Router Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Output Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Security Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Input Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:46:47 --> Language Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Language Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Config Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Loader Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:46:47 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:46:47 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:46:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:46:47 --> Session Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:46:47 --> Session routines successfully run
DEBUG - 2015-09-28 17:46:47 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Email Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Controller Class Initialized
DEBUG - 2015-09-28 17:46:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:46:47 --> Model Class Initialized
ERROR - 2015-09-28 17:46:47 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 113
ERROR - 2015-09-28 17:46:47 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 113
ERROR - 2015-09-28 17:46:47 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 113
ERROR - 2015-09-28 17:46:47 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 113
ERROR - 2015-09-28 17:46:47 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 113
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:46:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:46:47 --> Final output sent to browser
DEBUG - 2015-09-28 17:46:47 --> Total execution time: 0.2784
DEBUG - 2015-09-28 17:47:21 --> Config Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:47:21 --> URI Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Router Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Output Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Security Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Input Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:47:21 --> Language Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Language Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Config Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Loader Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:47:21 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:47:21 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:47:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:47:21 --> Session Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:47:21 --> Session routines successfully run
DEBUG - 2015-09-28 17:47:21 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Email Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Controller Class Initialized
DEBUG - 2015-09-28 17:47:21 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:47:21 --> Model Class Initialized
ERROR - 2015-09-28 17:47:21 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 121
ERROR - 2015-09-28 17:47:21 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 121
ERROR - 2015-09-28 17:47:21 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 121
ERROR - 2015-09-28 17:47:21 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 121
ERROR - 2015-09-28 17:47:21 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 121
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:47:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:47:21 --> Final output sent to browser
DEBUG - 2015-09-28 17:47:21 --> Total execution time: 0.3206
DEBUG - 2015-09-28 17:50:24 --> Config Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:50:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:50:24 --> URI Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Router Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Output Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Security Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Input Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:50:24 --> Language Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Language Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Config Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Loader Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:50:24 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:50:24 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:50:24 --> Session Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:50:24 --> Session routines successfully run
DEBUG - 2015-09-28 17:50:24 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Email Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Controller Class Initialized
DEBUG - 2015-09-28 17:50:24 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:50:24 --> Model Class Initialized
ERROR - 2015-09-28 17:50:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 135
ERROR - 2015-09-28 17:50:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 135
ERROR - 2015-09-28 17:50:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 135
ERROR - 2015-09-28 17:50:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 135
ERROR - 2015-09-28 17:50:24 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 135
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:50:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:50:24 --> Final output sent to browser
DEBUG - 2015-09-28 17:50:24 --> Total execution time: 0.2526
DEBUG - 2015-09-28 17:52:00 --> Config Class Initialized
DEBUG - 2015-09-28 17:52:00 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:52:00 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:52:00 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:52:00 --> URI Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Router Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Output Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Security Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Input Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:52:01 --> Language Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Language Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Config Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Loader Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:52:01 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:52:01 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:52:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:52:01 --> Session Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:52:01 --> Session routines successfully run
DEBUG - 2015-09-28 17:52:01 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Email Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Controller Class Initialized
DEBUG - 2015-09-28 17:52:01 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:52:01 --> Model Class Initialized
ERROR - 2015-09-28 17:52:01 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 156
ERROR - 2015-09-28 17:52:01 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 156
ERROR - 2015-09-28 17:52:01 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 156
ERROR - 2015-09-28 17:52:01 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 156
ERROR - 2015-09-28 17:52:01 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 156
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:52:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:52:01 --> Final output sent to browser
DEBUG - 2015-09-28 17:52:01 --> Total execution time: 0.2322
DEBUG - 2015-09-28 17:53:26 --> Config Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:53:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:53:26 --> URI Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Router Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Output Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Security Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Input Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:53:26 --> Language Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Language Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Config Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Loader Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:53:26 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:53:26 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:53:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:53:26 --> Session Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:53:26 --> Session routines successfully run
DEBUG - 2015-09-28 17:53:26 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Email Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Controller Class Initialized
DEBUG - 2015-09-28 17:53:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:53:26 --> Model Class Initialized
ERROR - 2015-09-28 17:53:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 177
ERROR - 2015-09-28 17:53:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 177
ERROR - 2015-09-28 17:53:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 177
ERROR - 2015-09-28 17:53:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 177
ERROR - 2015-09-28 17:53:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 177
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:53:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:53:26 --> Final output sent to browser
DEBUG - 2015-09-28 17:53:26 --> Total execution time: 0.3179
DEBUG - 2015-09-28 17:55:03 --> Config Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:55:03 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:55:03 --> URI Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Router Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Output Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Security Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Input Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:55:03 --> Language Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Language Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Config Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Loader Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:55:03 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:55:03 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:55:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:55:03 --> Session Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:55:03 --> Session routines successfully run
DEBUG - 2015-09-28 17:55:03 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:55:03 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:55:04 --> Email Class Initialized
DEBUG - 2015-09-28 17:55:04 --> Controller Class Initialized
DEBUG - 2015-09-28 17:55:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:55:04 --> Model Class Initialized
ERROR - 2015-09-28 17:55:04 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 179
ERROR - 2015-09-28 17:55:04 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 179
ERROR - 2015-09-28 17:55:04 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 179
ERROR - 2015-09-28 17:55:04 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 179
ERROR - 2015-09-28 17:55:04 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 179
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:55:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:55:04 --> Final output sent to browser
DEBUG - 2015-09-28 17:55:04 --> Total execution time: 0.5027
DEBUG - 2015-09-28 17:59:19 --> Config Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:59:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:59:19 --> URI Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Router Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Output Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Security Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Input Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:59:19 --> Language Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Language Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Config Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Loader Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:59:19 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:59:19 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:59:19 --> Session Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:59:19 --> Session routines successfully run
DEBUG - 2015-09-28 17:59:19 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Email Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Controller Class Initialized
DEBUG - 2015-09-28 17:59:19 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:59:19 --> Model Class Initialized
ERROR - 2015-09-28 17:59:19 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
ERROR - 2015-09-28 17:59:19 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
ERROR - 2015-09-28 17:59:19 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
ERROR - 2015-09-28 17:59:19 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
ERROR - 2015-09-28 17:59:19 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:59:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:59:19 --> Final output sent to browser
DEBUG - 2015-09-28 17:59:19 --> Total execution time: 0.2444
DEBUG - 2015-09-28 17:59:45 --> Config Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Hooks Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Utf8 Class Initialized
DEBUG - 2015-09-28 17:59:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 17:59:45 --> URI Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Router Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Output Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Security Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Input Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 17:59:45 --> Language Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Language Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Config Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Loader Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Helper loaded: url_helper
DEBUG - 2015-09-28 17:59:45 --> Helper loaded: form_helper
DEBUG - 2015-09-28 17:59:45 --> Database Driver Class Initialized
ERROR - 2015-09-28 17:59:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 17:59:45 --> Session Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Helper loaded: string_helper
DEBUG - 2015-09-28 17:59:45 --> Session routines successfully run
DEBUG - 2015-09-28 17:59:45 --> Form Validation Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Pagination Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Encrypt Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Email Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Controller Class Initialized
DEBUG - 2015-09-28 17:59:45 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 17:59:45 --> Model Class Initialized
ERROR - 2015-09-28 17:59:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
ERROR - 2015-09-28 17:59:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
ERROR - 2015-09-28 17:59:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
ERROR - 2015-09-28 17:59:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
ERROR - 2015-09-28 17:59:45 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 200
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 17:59:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 17:59:45 --> Final output sent to browser
DEBUG - 2015-09-28 17:59:45 --> Total execution time: 0.3040
DEBUG - 2015-09-28 18:03:27 --> Config Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Hooks Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Utf8 Class Initialized
DEBUG - 2015-09-28 18:03:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 18:03:27 --> URI Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Router Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Output Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Security Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Input Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 18:03:27 --> Language Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Language Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Config Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Loader Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Helper loaded: url_helper
DEBUG - 2015-09-28 18:03:27 --> Helper loaded: form_helper
DEBUG - 2015-09-28 18:03:27 --> Database Driver Class Initialized
ERROR - 2015-09-28 18:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-28 18:03:27 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 18:03:27 --> Session Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Helper loaded: string_helper
DEBUG - 2015-09-28 18:03:27 --> Session routines successfully run
DEBUG - 2015-09-28 18:03:27 --> Form Validation Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Pagination Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Encrypt Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Email Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Controller Class Initialized
DEBUG - 2015-09-28 18:03:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 18:03:27 --> Model Class Initialized
ERROR - 2015-09-28 18:03:27 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 221
ERROR - 2015-09-28 18:03:27 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 221
ERROR - 2015-09-28 18:03:27 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 221
ERROR - 2015-09-28 18:03:27 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 221
ERROR - 2015-09-28 18:03:27 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 221
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 18:03:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 18:03:27 --> Final output sent to browser
DEBUG - 2015-09-28 18:03:27 --> Total execution time: 0.2280
DEBUG - 2015-09-28 18:08:36 --> Config Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Hooks Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Utf8 Class Initialized
DEBUG - 2015-09-28 18:08:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 18:08:36 --> URI Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Router Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Output Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Security Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Input Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 18:08:36 --> Language Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Language Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Config Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Loader Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Helper loaded: url_helper
DEBUG - 2015-09-28 18:08:36 --> Helper loaded: form_helper
DEBUG - 2015-09-28 18:08:36 --> Database Driver Class Initialized
ERROR - 2015-09-28 18:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 18:08:36 --> Session Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Helper loaded: string_helper
DEBUG - 2015-09-28 18:08:36 --> Session routines successfully run
DEBUG - 2015-09-28 18:08:36 --> Form Validation Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Pagination Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Encrypt Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Email Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Controller Class Initialized
DEBUG - 2015-09-28 18:08:36 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 18:08:36 --> Model Class Initialized
ERROR - 2015-09-28 18:08:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 264
ERROR - 2015-09-28 18:08:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 264
ERROR - 2015-09-28 18:08:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 264
ERROR - 2015-09-28 18:08:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 264
ERROR - 2015-09-28 18:08:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 264
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 18:08:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 18:08:36 --> Final output sent to browser
DEBUG - 2015-09-28 18:08:36 --> Total execution time: 0.2440
DEBUG - 2015-09-28 18:18:48 --> Config Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Hooks Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Utf8 Class Initialized
DEBUG - 2015-09-28 18:18:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 18:18:48 --> URI Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Router Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Output Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Security Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Input Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 18:18:48 --> Language Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Language Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Config Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Loader Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Helper loaded: url_helper
DEBUG - 2015-09-28 18:18:48 --> Helper loaded: form_helper
DEBUG - 2015-09-28 18:18:48 --> Database Driver Class Initialized
ERROR - 2015-09-28 18:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 18:18:48 --> Session Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Helper loaded: string_helper
DEBUG - 2015-09-28 18:18:48 --> Session routines successfully run
DEBUG - 2015-09-28 18:18:48 --> Form Validation Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Pagination Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Encrypt Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Email Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Controller Class Initialized
DEBUG - 2015-09-28 18:18:48 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 18:18:48 --> Model Class Initialized
ERROR - 2015-09-28 18:18:48 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 305
ERROR - 2015-09-28 18:18:48 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 305
ERROR - 2015-09-28 18:18:48 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 305
ERROR - 2015-09-28 18:18:48 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 305
ERROR - 2015-09-28 18:18:48 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 305
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 18:18:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 18:18:48 --> Final output sent to browser
DEBUG - 2015-09-28 18:18:48 --> Total execution time: 0.4456
DEBUG - 2015-09-28 19:40:53 --> Config Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Hooks Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Utf8 Class Initialized
DEBUG - 2015-09-28 19:40:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 19:40:53 --> URI Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Router Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Output Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Security Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Input Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 19:40:53 --> Language Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Language Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Config Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Loader Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Helper loaded: url_helper
DEBUG - 2015-09-28 19:40:53 --> Helper loaded: form_helper
DEBUG - 2015-09-28 19:40:53 --> Database Driver Class Initialized
ERROR - 2015-09-28 19:40:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 19:40:53 --> Session Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Helper loaded: string_helper
DEBUG - 2015-09-28 19:40:53 --> Session routines successfully run
DEBUG - 2015-09-28 19:40:53 --> Form Validation Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Pagination Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Encrypt Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Email Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Controller Class Initialized
DEBUG - 2015-09-28 19:40:53 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 19:40:53 --> Model Class Initialized
ERROR - 2015-09-28 19:40:53 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 347
ERROR - 2015-09-28 19:40:53 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 347
ERROR - 2015-09-28 19:40:53 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 347
ERROR - 2015-09-28 19:40:53 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 347
ERROR - 2015-09-28 19:40:53 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 347
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 19:40:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 19:40:53 --> Final output sent to browser
DEBUG - 2015-09-28 19:40:53 --> Total execution time: 0.2848
DEBUG - 2015-09-28 19:50:26 --> Config Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Config Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Hooks Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Hooks Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Utf8 Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Utf8 Class Initialized
DEBUG - 2015-09-28 19:50:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 19:50:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 19:50:26 --> URI Class Initialized
DEBUG - 2015-09-28 19:50:26 --> URI Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Router Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Router Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Output Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Output Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Security Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Security Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Input Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Input Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 19:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 19:50:26 --> Language Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Language Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Language Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Language Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Config Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Config Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Loader Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Loader Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Helper loaded: url_helper
DEBUG - 2015-09-28 19:50:26 --> Helper loaded: url_helper
DEBUG - 2015-09-28 19:50:26 --> Helper loaded: form_helper
DEBUG - 2015-09-28 19:50:26 --> Helper loaded: form_helper
DEBUG - 2015-09-28 19:50:26 --> Database Driver Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Database Driver Class Initialized
ERROR - 2015-09-28 19:50:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-28 19:50:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 19:50:26 --> Session Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Helper loaded: string_helper
DEBUG - 2015-09-28 19:50:26 --> Session routines successfully run
DEBUG - 2015-09-28 19:50:26 --> Session Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Helper loaded: string_helper
DEBUG - 2015-09-28 19:50:26 --> Form Validation Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Session routines successfully run
DEBUG - 2015-09-28 19:50:26 --> Pagination Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Form Validation Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Encrypt Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Pagination Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Email Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Encrypt Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Controller Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 19:50:26 --> Email Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Controller Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 19:50:26 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
DEBUG - 2015-09-28 19:50:26 --> Model Class Initialized
ERROR - 2015-09-28 19:50:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 348
ERROR - 2015-09-28 19:50:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 348
ERROR - 2015-09-28 19:50:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 348
ERROR - 2015-09-28 19:50:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 348
ERROR - 2015-09-28 19:50:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 348
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 19:50:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 19:50:26 --> Final output sent to browser
DEBUG - 2015-09-28 19:50:26 --> Final output sent to browser
DEBUG - 2015-09-28 19:50:26 --> Total execution time: 0.2647
DEBUG - 2015-09-28 19:50:26 --> Total execution time: 0.3060
DEBUG - 2015-09-28 19:55:22 --> Config Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Hooks Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Utf8 Class Initialized
DEBUG - 2015-09-28 19:55:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 19:55:22 --> URI Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Router Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Output Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Security Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Input Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 19:55:22 --> Language Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Language Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Config Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Loader Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Helper loaded: url_helper
DEBUG - 2015-09-28 19:55:22 --> Helper loaded: form_helper
DEBUG - 2015-09-28 19:55:22 --> Database Driver Class Initialized
ERROR - 2015-09-28 19:55:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 19:55:22 --> Session Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Helper loaded: string_helper
DEBUG - 2015-09-28 19:55:22 --> Session routines successfully run
DEBUG - 2015-09-28 19:55:22 --> Form Validation Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Pagination Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Encrypt Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Email Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Controller Class Initialized
DEBUG - 2015-09-28 19:55:22 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 19:55:22 --> Model Class Initialized
ERROR - 2015-09-28 19:55:22 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 362
ERROR - 2015-09-28 19:55:22 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 362
ERROR - 2015-09-28 19:55:22 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 362
ERROR - 2015-09-28 19:55:22 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 362
ERROR - 2015-09-28 19:55:22 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 362
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 19:55:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 19:55:22 --> Final output sent to browser
DEBUG - 2015-09-28 19:55:22 --> Total execution time: 0.1469
DEBUG - 2015-09-28 20:04:08 --> Config Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Hooks Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Utf8 Class Initialized
DEBUG - 2015-09-28 20:04:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 20:04:08 --> URI Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Router Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Output Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Security Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Input Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 20:04:08 --> Language Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Language Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Config Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Loader Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Helper loaded: url_helper
DEBUG - 2015-09-28 20:04:08 --> Helper loaded: form_helper
DEBUG - 2015-09-28 20:04:08 --> Database Driver Class Initialized
ERROR - 2015-09-28 20:04:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 20:04:08 --> Session Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Helper loaded: string_helper
DEBUG - 2015-09-28 20:04:08 --> Session routines successfully run
DEBUG - 2015-09-28 20:04:08 --> Form Validation Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Pagination Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Encrypt Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Email Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Controller Class Initialized
DEBUG - 2015-09-28 20:04:08 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 20:04:08 --> Model Class Initialized
ERROR - 2015-09-28 20:04:08 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:04:08 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:04:08 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:04:08 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:04:08 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 20:04:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 20:04:08 --> Final output sent to browser
DEBUG - 2015-09-28 20:04:08 --> Total execution time: 0.1364
DEBUG - 2015-09-28 20:09:34 --> Config Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 20:09:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 20:09:34 --> URI Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Router Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Output Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Security Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Input Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 20:09:34 --> Language Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Language Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Config Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Loader Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Helper loaded: url_helper
DEBUG - 2015-09-28 20:09:34 --> Helper loaded: form_helper
DEBUG - 2015-09-28 20:09:34 --> Database Driver Class Initialized
ERROR - 2015-09-28 20:09:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 20:09:34 --> Session Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Helper loaded: string_helper
DEBUG - 2015-09-28 20:09:34 --> Session routines successfully run
DEBUG - 2015-09-28 20:09:34 --> Form Validation Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Pagination Class Initialized
DEBUG - 2015-09-28 20:09:34 --> Encrypt Class Initialized
DEBUG - 2015-09-28 20:09:35 --> Email Class Initialized
DEBUG - 2015-09-28 20:09:35 --> Controller Class Initialized
DEBUG - 2015-09-28 20:09:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 20:09:35 --> Model Class Initialized
ERROR - 2015-09-28 20:09:35 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:09:35 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:09:35 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:09:35 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:09:35 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 20:09:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 20:09:35 --> Final output sent to browser
DEBUG - 2015-09-28 20:09:35 --> Total execution time: 0.1422
DEBUG - 2015-09-28 20:10:20 --> Config Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Hooks Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Utf8 Class Initialized
DEBUG - 2015-09-28 20:10:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 20:10:20 --> URI Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Router Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Output Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Security Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Input Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 20:10:20 --> Language Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Language Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Config Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Loader Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Helper loaded: url_helper
DEBUG - 2015-09-28 20:10:20 --> Helper loaded: form_helper
DEBUG - 2015-09-28 20:10:20 --> Database Driver Class Initialized
ERROR - 2015-09-28 20:10:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 20:10:20 --> Session Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Helper loaded: string_helper
DEBUG - 2015-09-28 20:10:20 --> Session routines successfully run
DEBUG - 2015-09-28 20:10:20 --> Form Validation Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Pagination Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Encrypt Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Email Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Controller Class Initialized
DEBUG - 2015-09-28 20:10:20 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 20:10:20 --> Model Class Initialized
ERROR - 2015-09-28 20:10:20 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:10:20 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:10:20 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:10:20 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:10:20 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 20:10:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 20:10:20 --> Final output sent to browser
DEBUG - 2015-09-28 20:10:20 --> Total execution time: 0.1397
DEBUG - 2015-09-28 20:10:41 --> Config Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Hooks Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Utf8 Class Initialized
DEBUG - 2015-09-28 20:10:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 20:10:41 --> URI Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Router Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Output Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Security Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Input Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 20:10:41 --> Language Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Language Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Config Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Loader Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Helper loaded: url_helper
DEBUG - 2015-09-28 20:10:41 --> Helper loaded: form_helper
DEBUG - 2015-09-28 20:10:41 --> Database Driver Class Initialized
ERROR - 2015-09-28 20:10:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 20:10:41 --> Session Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Helper loaded: string_helper
DEBUG - 2015-09-28 20:10:41 --> Session routines successfully run
DEBUG - 2015-09-28 20:10:41 --> Form Validation Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Pagination Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Encrypt Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Email Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Controller Class Initialized
DEBUG - 2015-09-28 20:10:41 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 20:10:41 --> Model Class Initialized
ERROR - 2015-09-28 20:10:41 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:10:41 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:10:41 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:10:41 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
ERROR - 2015-09-28 20:10:41 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 424
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 20:10:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 20:10:41 --> Final output sent to browser
DEBUG - 2015-09-28 20:10:41 --> Total execution time: 0.1388
DEBUG - 2015-09-28 20:10:51 --> Config Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Hooks Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Utf8 Class Initialized
DEBUG - 2015-09-28 20:10:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 20:10:51 --> URI Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Router Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Output Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Security Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Input Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 20:10:51 --> Language Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Language Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Config Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Loader Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Helper loaded: url_helper
DEBUG - 2015-09-28 20:10:51 --> Helper loaded: form_helper
DEBUG - 2015-09-28 20:10:51 --> Database Driver Class Initialized
ERROR - 2015-09-28 20:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 20:10:51 --> Session Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Helper loaded: string_helper
DEBUG - 2015-09-28 20:10:51 --> Session routines successfully run
DEBUG - 2015-09-28 20:10:51 --> Form Validation Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Pagination Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Encrypt Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Email Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Controller Class Initialized
DEBUG - 2015-09-28 20:10:51 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 20:10:51 --> Model Class Initialized
ERROR - 2015-09-28 20:10:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:10:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:10:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:10:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:10:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 20:10:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 20:10:51 --> Final output sent to browser
DEBUG - 2015-09-28 20:10:51 --> Total execution time: 0.1358
DEBUG - 2015-09-28 20:11:37 --> Config Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Hooks Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Utf8 Class Initialized
DEBUG - 2015-09-28 20:11:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 20:11:37 --> URI Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Router Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Output Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Security Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Input Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 20:11:37 --> Language Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Language Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Config Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Loader Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Helper loaded: url_helper
DEBUG - 2015-09-28 20:11:37 --> Helper loaded: form_helper
DEBUG - 2015-09-28 20:11:37 --> Database Driver Class Initialized
ERROR - 2015-09-28 20:11:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 20:11:37 --> Session Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Helper loaded: string_helper
DEBUG - 2015-09-28 20:11:37 --> Session routines successfully run
DEBUG - 2015-09-28 20:11:37 --> Form Validation Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Pagination Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Encrypt Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Email Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Controller Class Initialized
DEBUG - 2015-09-28 20:11:37 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 20:11:37 --> Model Class Initialized
ERROR - 2015-09-28 20:11:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:11:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:11:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:11:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:11:37 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 20:11:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 20:11:37 --> Final output sent to browser
DEBUG - 2015-09-28 20:11:37 --> Total execution time: 0.1522
DEBUG - 2015-09-28 20:12:26 --> Config Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Hooks Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Utf8 Class Initialized
DEBUG - 2015-09-28 20:12:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 20:12:26 --> URI Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Router Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Output Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Security Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Input Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 20:12:26 --> Language Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Language Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Config Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Loader Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Helper loaded: url_helper
DEBUG - 2015-09-28 20:12:26 --> Helper loaded: form_helper
DEBUG - 2015-09-28 20:12:26 --> Database Driver Class Initialized
ERROR - 2015-09-28 20:12:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 20:12:26 --> Session Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Helper loaded: string_helper
DEBUG - 2015-09-28 20:12:26 --> Session routines successfully run
DEBUG - 2015-09-28 20:12:26 --> Form Validation Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Pagination Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Encrypt Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Email Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Controller Class Initialized
DEBUG - 2015-09-28 20:12:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 20:12:26 --> Model Class Initialized
ERROR - 2015-09-28 20:12:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:12:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:12:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:12:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
ERROR - 2015-09-28 20:12:26 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 427
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 20:12:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 20:12:26 --> Final output sent to browser
DEBUG - 2015-09-28 20:12:26 --> Total execution time: 0.1670
DEBUG - 2015-09-28 21:00:19 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:00:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:00:19 --> URI Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Router Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Output Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Security Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Input Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:00:19 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Loader Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:00:19 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:00:19 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:00:19 --> Session Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:00:19 --> Session routines successfully run
DEBUG - 2015-09-28 21:00:19 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Email Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Controller Class Initialized
DEBUG - 2015-09-28 21:00:19 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:00:19 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:00:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:00:22 --> URI Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Router Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Output Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Security Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Input Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:00:22 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Loader Class Initialized
DEBUG - 2015-09-28 21:00:22 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:00:22 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:00:23 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:00:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:00:23 --> Session Class Initialized
DEBUG - 2015-09-28 21:00:23 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:00:23 --> Session routines successfully run
DEBUG - 2015-09-28 21:00:23 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:00:23 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:00:23 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:00:23 --> Email Class Initialized
DEBUG - 2015-09-28 21:00:23 --> Controller Class Initialized
DEBUG - 2015-09-28 21:00:23 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:00:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:00:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:00:35 --> URI Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Router Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Output Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Security Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Input Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:00:35 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Loader Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:00:35 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:00:35 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:00:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:00:35 --> Session Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:00:35 --> Session routines successfully run
DEBUG - 2015-09-28 21:00:35 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Email Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Controller Class Initialized
DEBUG - 2015-09-28 21:00:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:00:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:00:38 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:00:38 --> URI Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Router Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Output Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Security Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Input Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:00:38 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Loader Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:00:38 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:00:38 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:00:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:00:38 --> Session Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:00:38 --> Session routines successfully run
DEBUG - 2015-09-28 21:00:38 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Email Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Controller Class Initialized
DEBUG - 2015-09-28 21:00:38 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:00:38 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:00:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:00:38 --> Final output sent to browser
DEBUG - 2015-09-28 21:00:38 --> Total execution time: 0.1306
DEBUG - 2015-09-28 21:00:40 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:40 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:00:40 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:00:40 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:00:40 --> URI Class Initialized
DEBUG - 2015-09-28 21:00:40 --> Router Class Initialized
ERROR - 2015-09-28 21:00:40 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:00:43 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:00:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:00:43 --> URI Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Router Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Output Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Security Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Input Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:00:43 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Language Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Config Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Loader Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:00:43 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:00:43 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:00:43 --> Session Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:00:43 --> Session routines successfully run
DEBUG - 2015-09-28 21:00:43 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Email Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Controller Class Initialized
DEBUG - 2015-09-28 21:00:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:00:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:00:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:00:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Config Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:02:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:02:04 --> URI Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Router Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Output Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Security Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Input Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:02:04 --> Language Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Language Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Config Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Loader Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:02:04 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:02:04 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:02:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:02:04 --> Session Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:02:04 --> Session routines successfully run
DEBUG - 2015-09-28 21:02:04 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Email Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Controller Class Initialized
DEBUG - 2015-09-28 21:02:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:02:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Config Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:02:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:02:06 --> URI Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Router Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Output Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Security Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Input Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:02:06 --> Language Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Language Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Config Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Loader Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:02:06 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:02:06 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:02:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:02:06 --> Session Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:02:06 --> Session routines successfully run
DEBUG - 2015-09-28 21:02:06 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Email Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Controller Class Initialized
DEBUG - 2015-09-28 21:02:06 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:02:06 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Config Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:02:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:02:07 --> URI Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Router Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Output Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Security Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Input Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:02:07 --> Language Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Language Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Config Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Loader Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:02:07 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:02:07 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:02:07 --> Session Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:02:07 --> Session routines successfully run
DEBUG - 2015-09-28 21:02:07 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Email Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Controller Class Initialized
DEBUG - 2015-09-28 21:02:07 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:02:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:02:07 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Config Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:03:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:03:04 --> URI Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Router Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Output Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Security Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Input Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:03:04 --> Language Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Language Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Config Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Loader Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:03:04 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:03:04 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:03:04 --> Session Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:03:04 --> Session routines successfully run
DEBUG - 2015-09-28 21:03:04 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Email Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Controller Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:03:04 --> Final output sent to browser
DEBUG - 2015-09-28 21:03:04 --> Total execution time: 0.1382
DEBUG - 2015-09-28 21:03:04 --> Config Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:03:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:03:04 --> URI Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Router Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Output Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Security Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Input Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:03:04 --> Language Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Language Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Config Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Loader Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:03:04 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:03:04 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:03:04 --> Session Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:03:04 --> Session routines successfully run
DEBUG - 2015-09-28 21:03:04 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Email Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Controller Class Initialized
DEBUG - 2015-09-28 21:03:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:03:04 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:03:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:03:04 --> Final output sent to browser
DEBUG - 2015-09-28 21:03:04 --> Total execution time: 0.1288
DEBUG - 2015-09-28 21:03:06 --> Config Class Initialized
DEBUG - 2015-09-28 21:03:06 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:03:06 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:03:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:03:06 --> URI Class Initialized
DEBUG - 2015-09-28 21:03:06 --> Router Class Initialized
ERROR - 2015-09-28 21:03:06 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:03:31 --> Config Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:03:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:03:31 --> URI Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Router Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Output Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Security Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Input Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:03:31 --> Language Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Language Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Config Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Loader Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:03:31 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:03:31 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:03:31 --> Session Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:03:31 --> Session routines successfully run
DEBUG - 2015-09-28 21:03:31 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Email Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Controller Class Initialized
DEBUG - 2015-09-28 21:03:31 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:03:31 --> Model Class Initialized
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:03:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:03:31 --> Final output sent to browser
DEBUG - 2015-09-28 21:03:31 --> Total execution time: 0.1394
DEBUG - 2015-09-28 21:03:33 --> Config Class Initialized
DEBUG - 2015-09-28 21:03:33 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:03:33 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:03:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:03:33 --> URI Class Initialized
DEBUG - 2015-09-28 21:03:33 --> Router Class Initialized
ERROR - 2015-09-28 21:03:33 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:04:02 --> Config Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:04:02 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:04:02 --> URI Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Router Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Output Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Security Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Input Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:04:02 --> Language Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Language Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Config Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Loader Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:04:02 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:04:02 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:04:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:04:02 --> Session Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:04:02 --> Session routines successfully run
DEBUG - 2015-09-28 21:04:02 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Email Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Controller Class Initialized
DEBUG - 2015-09-28 21:04:02 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:04:02 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Config Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:04:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:04:36 --> URI Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Router Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Output Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Security Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Input Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:04:36 --> Language Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Language Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Config Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Loader Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:04:36 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:04:36 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:04:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:04:36 --> Session Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:04:36 --> Session routines successfully run
DEBUG - 2015-09-28 21:04:36 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Email Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Controller Class Initialized
DEBUG - 2015-09-28 21:04:36 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:04:36 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:04:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:04:36 --> Final output sent to browser
DEBUG - 2015-09-28 21:04:36 --> Total execution time: 0.1528
DEBUG - 2015-09-28 21:04:37 --> Config Class Initialized
DEBUG - 2015-09-28 21:04:37 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:04:37 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:04:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:04:37 --> URI Class Initialized
DEBUG - 2015-09-28 21:04:37 --> Router Class Initialized
ERROR - 2015-09-28 21:04:37 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:04:52 --> Config Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:04:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:04:52 --> URI Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Router Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Output Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Security Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Input Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:04:52 --> Language Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Language Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Config Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Loader Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:04:52 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:04:52 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:04:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:04:52 --> Session Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:04:52 --> Session routines successfully run
DEBUG - 2015-09-28 21:04:52 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Email Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Controller Class Initialized
DEBUG - 2015-09-28 21:04:52 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:04:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:04:52 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Config Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:05:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:05:05 --> URI Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Router Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Output Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Security Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Input Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:05:05 --> Language Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Language Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Config Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Loader Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:05:05 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:05:05 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:05:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:05:05 --> Session Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:05:05 --> Session routines successfully run
DEBUG - 2015-09-28 21:05:05 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Email Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Controller Class Initialized
DEBUG - 2015-09-28 21:05:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:05:05 --> Model Class Initialized
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:05:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:05:05 --> Final output sent to browser
DEBUG - 2015-09-28 21:05:05 --> Total execution time: 0.1322
DEBUG - 2015-09-28 21:05:06 --> Config Class Initialized
DEBUG - 2015-09-28 21:05:06 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:05:06 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:05:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:05:06 --> URI Class Initialized
DEBUG - 2015-09-28 21:05:06 --> Router Class Initialized
ERROR - 2015-09-28 21:05:06 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:08:22 --> Config Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:08:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:08:22 --> URI Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Router Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Output Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Security Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Input Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:08:22 --> Language Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Language Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Config Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Loader Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:08:22 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:08:22 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:08:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:08:22 --> Session Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:08:22 --> Session routines successfully run
DEBUG - 2015-09-28 21:08:22 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Email Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Controller Class Initialized
DEBUG - 2015-09-28 21:08:22 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:08:22 --> Model Class Initialized
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:08:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:08:22 --> Final output sent to browser
DEBUG - 2015-09-28 21:08:22 --> Total execution time: 0.1352
DEBUG - 2015-09-28 21:08:23 --> Config Class Initialized
DEBUG - 2015-09-28 21:08:24 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:08:24 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:08:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:08:24 --> URI Class Initialized
DEBUG - 2015-09-28 21:08:24 --> Router Class Initialized
ERROR - 2015-09-28 21:08:24 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:09:08 --> Config Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:09:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:09:08 --> URI Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Router Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Output Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Security Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Input Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:09:08 --> Language Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Language Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Config Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Loader Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:09:08 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:09:08 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:09:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:09:08 --> Session Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:09:08 --> Session routines successfully run
DEBUG - 2015-09-28 21:09:08 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Email Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Controller Class Initialized
DEBUG - 2015-09-28 21:09:08 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:09:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:09:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:09:08 --> Final output sent to browser
DEBUG - 2015-09-28 21:09:08 --> Total execution time: 0.1375
DEBUG - 2015-09-28 21:09:10 --> Config Class Initialized
DEBUG - 2015-09-28 21:09:10 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:09:10 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:09:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:09:10 --> URI Class Initialized
DEBUG - 2015-09-28 21:09:10 --> Router Class Initialized
ERROR - 2015-09-28 21:09:10 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:12:43 --> Config Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:12:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:12:43 --> URI Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Router Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Output Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Security Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Input Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:12:43 --> Language Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Language Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Config Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Loader Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:12:43 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:12:43 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:12:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:12:43 --> Session Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:12:43 --> Session routines successfully run
DEBUG - 2015-09-28 21:12:43 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Email Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Controller Class Initialized
DEBUG - 2015-09-28 21:12:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:12:43 --> Model Class Initialized
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:12:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:12:43 --> Final output sent to browser
DEBUG - 2015-09-28 21:12:43 --> Total execution time: 0.1353
DEBUG - 2015-09-28 21:12:45 --> Config Class Initialized
DEBUG - 2015-09-28 21:12:45 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:12:45 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:12:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:12:45 --> URI Class Initialized
DEBUG - 2015-09-28 21:12:45 --> Router Class Initialized
ERROR - 2015-09-28 21:12:45 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:13:39 --> Config Class Initialized
DEBUG - 2015-09-28 21:13:39 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:13:39 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:13:39 --> URI Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Router Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Output Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Security Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Input Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:13:40 --> Language Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Language Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Config Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Loader Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:13:40 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:13:40 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:13:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:13:40 --> Session Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:13:40 --> Session routines successfully run
DEBUG - 2015-09-28 21:13:40 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Email Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Controller Class Initialized
DEBUG - 2015-09-28 21:13:40 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:13:40 --> Model Class Initialized
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:13:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:13:40 --> Final output sent to browser
DEBUG - 2015-09-28 21:13:40 --> Total execution time: 0.1364
DEBUG - 2015-09-28 21:13:41 --> Config Class Initialized
DEBUG - 2015-09-28 21:13:41 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:13:41 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:13:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:13:41 --> URI Class Initialized
DEBUG - 2015-09-28 21:13:41 --> Router Class Initialized
ERROR - 2015-09-28 21:13:41 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:15:35 --> Config Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:15:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:15:35 --> URI Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Router Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Output Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Security Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Input Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:15:35 --> Language Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Language Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Config Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Loader Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:15:35 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:15:35 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:15:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:15:35 --> Session Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:15:35 --> Session routines successfully run
DEBUG - 2015-09-28 21:15:35 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Email Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Controller Class Initialized
DEBUG - 2015-09-28 21:15:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:15:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:15:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:15:35 --> Final output sent to browser
DEBUG - 2015-09-28 21:15:35 --> Total execution time: 0.1479
DEBUG - 2015-09-28 21:15:37 --> Config Class Initialized
DEBUG - 2015-09-28 21:15:37 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:15:37 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:15:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:15:37 --> URI Class Initialized
DEBUG - 2015-09-28 21:15:37 --> Router Class Initialized
ERROR - 2015-09-28 21:15:37 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:16:32 --> Config Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:16:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:16:32 --> URI Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Router Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Output Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Security Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Input Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:16:32 --> Language Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Language Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Config Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Loader Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:16:32 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:16:32 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:16:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:16:32 --> Session Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:16:32 --> Session routines successfully run
DEBUG - 2015-09-28 21:16:32 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Email Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Controller Class Initialized
DEBUG - 2015-09-28 21:16:32 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:16:32 --> Model Class Initialized
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:16:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:16:32 --> Final output sent to browser
DEBUG - 2015-09-28 21:16:32 --> Total execution time: 0.1281
DEBUG - 2015-09-28 21:16:34 --> Config Class Initialized
DEBUG - 2015-09-28 21:16:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:16:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:16:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:16:34 --> URI Class Initialized
DEBUG - 2015-09-28 21:16:34 --> Router Class Initialized
ERROR - 2015-09-28 21:16:34 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:19:34 --> Config Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:19:34 --> URI Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Router Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Output Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Security Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Input Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:19:34 --> Language Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Language Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Config Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Loader Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:19:34 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:19:34 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:19:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:19:34 --> Session Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:19:34 --> Session routines successfully run
DEBUG - 2015-09-28 21:19:34 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Email Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Controller Class Initialized
DEBUG - 2015-09-28 21:19:34 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:19:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:19:34 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Config Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:20:12 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:20:12 --> URI Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Router Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Output Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Security Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Input Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:20:12 --> Language Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Language Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Config Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Loader Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:20:12 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:20:12 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:20:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:20:12 --> Session Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:20:12 --> Session routines successfully run
DEBUG - 2015-09-28 21:20:12 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Email Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Controller Class Initialized
DEBUG - 2015-09-28 21:20:12 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:20:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:20:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:20:12 --> Final output sent to browser
DEBUG - 2015-09-28 21:20:12 --> Total execution time: 0.1252
DEBUG - 2015-09-28 21:20:14 --> Config Class Initialized
DEBUG - 2015-09-28 21:20:14 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:20:14 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:20:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:20:14 --> URI Class Initialized
DEBUG - 2015-09-28 21:20:14 --> Router Class Initialized
ERROR - 2015-09-28 21:20:14 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:22:12 --> Config Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:22:12 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:22:12 --> URI Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Router Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Output Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Security Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Input Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:22:12 --> Language Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Language Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Config Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Loader Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:22:12 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:22:12 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:22:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:22:12 --> Session Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:22:12 --> Session routines successfully run
DEBUG - 2015-09-28 21:22:12 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Email Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Controller Class Initialized
DEBUG - 2015-09-28 21:22:12 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:22:12 --> Model Class Initialized
ERROR - 2015-09-28 21:22:12 --> Severity: Notice  --> Undefined variable: v_data C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 93
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:22:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:22:12 --> Final output sent to browser
DEBUG - 2015-09-28 21:22:12 --> Total execution time: 0.1611
DEBUG - 2015-09-28 21:22:14 --> Config Class Initialized
DEBUG - 2015-09-28 21:22:14 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:22:14 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:22:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:22:14 --> URI Class Initialized
DEBUG - 2015-09-28 21:22:14 --> Router Class Initialized
ERROR - 2015-09-28 21:22:14 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:22:28 --> Config Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:22:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:22:28 --> URI Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Router Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Output Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Security Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Input Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:22:28 --> Language Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Language Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Config Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Loader Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:22:28 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:22:28 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:22:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:22:28 --> Session Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:22:28 --> Session routines successfully run
DEBUG - 2015-09-28 21:22:28 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Email Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Controller Class Initialized
DEBUG - 2015-09-28 21:22:28 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:22:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:22:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:22:28 --> Final output sent to browser
DEBUG - 2015-09-28 21:22:28 --> Total execution time: 0.1372
DEBUG - 2015-09-28 21:22:29 --> Config Class Initialized
DEBUG - 2015-09-28 21:22:29 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:22:29 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:22:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:22:29 --> URI Class Initialized
DEBUG - 2015-09-28 21:22:29 --> Router Class Initialized
ERROR - 2015-09-28 21:22:29 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:40:37 --> Config Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:40:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:40:37 --> URI Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Router Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Output Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Security Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Input Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:40:37 --> Language Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Language Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Config Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Loader Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:40:37 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:40:37 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:40:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:40:37 --> Session Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:40:37 --> Session routines successfully run
DEBUG - 2015-09-28 21:40:37 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Email Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Controller Class Initialized
DEBUG - 2015-09-28 21:40:37 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:40:37 --> Model Class Initialized
ERROR - 2015-09-28 21:40:37 --> 404 Page Not Found --> loans_plan/add_loans_plan
DEBUG - 2015-09-28 21:40:44 --> Config Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:40:44 --> URI Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Router Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Output Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Security Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Input Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:40:44 --> Language Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Language Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Config Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Loader Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:40:44 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:40:44 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:40:44 --> Session Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:40:44 --> Session routines successfully run
DEBUG - 2015-09-28 21:40:44 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Email Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Controller Class Initialized
DEBUG - 2015-09-28 21:40:44 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:40:44 --> Model Class Initialized
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:40:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:40:44 --> Final output sent to browser
DEBUG - 2015-09-28 21:40:44 --> Total execution time: 0.1389
DEBUG - 2015-09-28 21:40:45 --> Config Class Initialized
DEBUG - 2015-09-28 21:40:45 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:40:45 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:40:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:40:45 --> URI Class Initialized
DEBUG - 2015-09-28 21:40:45 --> Router Class Initialized
ERROR - 2015-09-28 21:40:45 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:41:29 --> Config Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:41:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:41:29 --> URI Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Router Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Output Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Security Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Input Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:41:29 --> Language Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Language Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Config Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Loader Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:41:29 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:41:29 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:41:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:41:29 --> Session Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:41:29 --> Session routines successfully run
DEBUG - 2015-09-28 21:41:29 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Email Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Controller Class Initialized
DEBUG - 2015-09-28 21:41:29 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:41:29 --> Model Class Initialized
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:41:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:41:29 --> Final output sent to browser
DEBUG - 2015-09-28 21:41:29 --> Total execution time: 0.1300
DEBUG - 2015-09-28 21:41:31 --> Config Class Initialized
DEBUG - 2015-09-28 21:41:31 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:41:31 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:41:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:41:31 --> URI Class Initialized
DEBUG - 2015-09-28 21:41:31 --> Router Class Initialized
ERROR - 2015-09-28 21:41:31 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:42:14 --> Config Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:42:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:42:14 --> URI Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Router Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Output Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Security Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Input Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:42:14 --> Language Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Language Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Config Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Loader Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:42:14 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:42:14 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:42:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:42:14 --> Session Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:42:14 --> Session routines successfully run
DEBUG - 2015-09-28 21:42:14 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Email Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Controller Class Initialized
DEBUG - 2015-09-28 21:42:14 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:42:14 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:42:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:42:14 --> Final output sent to browser
DEBUG - 2015-09-28 21:42:14 --> Total execution time: 0.1356
DEBUG - 2015-09-28 21:42:15 --> Config Class Initialized
DEBUG - 2015-09-28 21:42:15 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:42:15 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:42:15 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:42:15 --> URI Class Initialized
DEBUG - 2015-09-28 21:42:15 --> Router Class Initialized
ERROR - 2015-09-28 21:42:15 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:42:27 --> Config Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:42:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:42:27 --> URI Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Router Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Output Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Security Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Input Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:42:27 --> Language Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Language Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Config Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Loader Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:42:27 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:42:27 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:42:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:42:27 --> Session Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:42:27 --> Session routines successfully run
DEBUG - 2015-09-28 21:42:27 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Email Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Controller Class Initialized
DEBUG - 2015-09-28 21:42:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:42:27 --> Model Class Initialized
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:42:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:42:27 --> Final output sent to browser
DEBUG - 2015-09-28 21:42:27 --> Total execution time: 0.1360
DEBUG - 2015-09-28 21:42:29 --> Config Class Initialized
DEBUG - 2015-09-28 21:42:29 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:42:29 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:42:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:42:29 --> URI Class Initialized
DEBUG - 2015-09-28 21:42:29 --> Router Class Initialized
ERROR - 2015-09-28 21:42:29 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:43:34 --> Config Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:43:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:43:34 --> URI Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Router Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Output Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Security Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Input Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:43:34 --> Language Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Language Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Config Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Loader Class Initialized
DEBUG - 2015-09-28 21:43:34 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:43:34 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:43:34 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:43:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:43:34 --> Session Class Initialized
DEBUG - 2015-09-28 21:43:35 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:43:35 --> Session routines successfully run
DEBUG - 2015-09-28 21:43:35 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:43:35 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:43:35 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:43:35 --> Email Class Initialized
DEBUG - 2015-09-28 21:43:35 --> Controller Class Initialized
DEBUG - 2015-09-28 21:43:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:43:35 --> Model Class Initialized
ERROR - 2015-09-28 21:43:35 --> Severity: Notice  --> Undefined variable: interest_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 21:43:35 --> Severity: Notice  --> Undefined variable: interest_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 21:43:35 --> Severity: Notice  --> Undefined variable: interest_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
ERROR - 2015-09-28 21:43:35 --> Severity: Notice  --> Undefined variable: interest_id C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 99
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:43:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:43:35 --> Final output sent to browser
DEBUG - 2015-09-28 21:43:35 --> Total execution time: 0.1563
DEBUG - 2015-09-28 21:43:36 --> Config Class Initialized
DEBUG - 2015-09-28 21:43:36 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:43:36 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:43:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:43:36 --> URI Class Initialized
DEBUG - 2015-09-28 21:43:36 --> Router Class Initialized
ERROR - 2015-09-28 21:43:36 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:44:28 --> Config Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:44:28 --> URI Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Router Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Output Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Security Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Input Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:44:28 --> Language Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Language Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Config Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Loader Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:44:28 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:44:28 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:44:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:44:28 --> Session Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:44:28 --> Session routines successfully run
DEBUG - 2015-09-28 21:44:28 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Email Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Controller Class Initialized
DEBUG - 2015-09-28 21:44:28 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:44:28 --> Model Class Initialized
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:44:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:44:28 --> Final output sent to browser
DEBUG - 2015-09-28 21:44:28 --> Total execution time: 0.1348
DEBUG - 2015-09-28 21:44:29 --> Config Class Initialized
DEBUG - 2015-09-28 21:44:29 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:44:29 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:44:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:44:29 --> URI Class Initialized
DEBUG - 2015-09-28 21:44:29 --> Router Class Initialized
ERROR - 2015-09-28 21:44:29 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:45:08 --> Config Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:45:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:45:08 --> URI Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Router Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Output Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Security Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Input Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:45:08 --> Language Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Language Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Config Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Loader Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:45:08 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:45:08 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:45:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:45:08 --> Session Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:45:08 --> Session routines successfully run
DEBUG - 2015-09-28 21:45:08 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Email Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Controller Class Initialized
DEBUG - 2015-09-28 21:45:08 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:45:08 --> Model Class Initialized
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:45:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:45:08 --> Final output sent to browser
DEBUG - 2015-09-28 21:45:08 --> Total execution time: 0.1402
DEBUG - 2015-09-28 21:45:10 --> Config Class Initialized
DEBUG - 2015-09-28 21:45:10 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:45:10 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:45:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:45:10 --> URI Class Initialized
DEBUG - 2015-09-28 21:45:10 --> Router Class Initialized
ERROR - 2015-09-28 21:45:10 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:46:49 --> Config Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:46:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:46:49 --> URI Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Router Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Output Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Security Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Input Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:46:49 --> Language Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Language Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Config Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Loader Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:46:49 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:46:49 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:46:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:46:49 --> Session Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:46:49 --> Session routines successfully run
DEBUG - 2015-09-28 21:46:49 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Email Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Controller Class Initialized
DEBUG - 2015-09-28 21:46:49 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:46:49 --> Model Class Initialized
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:46:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:46:49 --> Final output sent to browser
DEBUG - 2015-09-28 21:46:49 --> Total execution time: 0.1361
DEBUG - 2015-09-28 21:46:51 --> Config Class Initialized
DEBUG - 2015-09-28 21:46:51 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:46:51 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:46:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:46:51 --> URI Class Initialized
DEBUG - 2015-09-28 21:46:51 --> Router Class Initialized
ERROR - 2015-09-28 21:46:51 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 21:59:23 --> Config Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:59:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:59:23 --> URI Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Router Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Output Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Security Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Input Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 21:59:23 --> Language Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Language Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Config Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Loader Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Helper loaded: url_helper
DEBUG - 2015-09-28 21:59:23 --> Helper loaded: form_helper
DEBUG - 2015-09-28 21:59:23 --> Database Driver Class Initialized
ERROR - 2015-09-28 21:59:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 21:59:23 --> Session Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Helper loaded: string_helper
DEBUG - 2015-09-28 21:59:23 --> Session routines successfully run
DEBUG - 2015-09-28 21:59:23 --> Form Validation Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Pagination Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Encrypt Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Email Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Controller Class Initialized
DEBUG - 2015-09-28 21:59:23 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 21:59:23 --> Model Class Initialized
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 21:59:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 21:59:23 --> Final output sent to browser
DEBUG - 2015-09-28 21:59:23 --> Total execution time: 0.1361
DEBUG - 2015-09-28 21:59:25 --> Config Class Initialized
DEBUG - 2015-09-28 21:59:25 --> Hooks Class Initialized
DEBUG - 2015-09-28 21:59:25 --> Utf8 Class Initialized
DEBUG - 2015-09-28 21:59:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 21:59:25 --> URI Class Initialized
DEBUG - 2015-09-28 21:59:25 --> Router Class Initialized
ERROR - 2015-09-28 21:59:25 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 22:19:35 --> Config Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Hooks Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Utf8 Class Initialized
DEBUG - 2015-09-28 22:19:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 22:19:35 --> URI Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Router Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Output Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Security Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Input Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 22:19:35 --> Language Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Language Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Config Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Loader Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Helper loaded: url_helper
DEBUG - 2015-09-28 22:19:35 --> Helper loaded: form_helper
DEBUG - 2015-09-28 22:19:35 --> Database Driver Class Initialized
ERROR - 2015-09-28 22:19:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 22:19:35 --> Session Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Helper loaded: string_helper
DEBUG - 2015-09-28 22:19:35 --> Session routines successfully run
DEBUG - 2015-09-28 22:19:35 --> Form Validation Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Pagination Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Encrypt Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Email Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Controller Class Initialized
DEBUG - 2015-09-28 22:19:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 22:19:35 --> Model Class Initialized
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 22:19:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 22:19:35 --> Final output sent to browser
DEBUG - 2015-09-28 22:19:35 --> Total execution time: 0.1357
DEBUG - 2015-09-28 22:19:37 --> Config Class Initialized
DEBUG - 2015-09-28 22:19:37 --> Hooks Class Initialized
DEBUG - 2015-09-28 22:19:37 --> Utf8 Class Initialized
DEBUG - 2015-09-28 22:19:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 22:19:37 --> URI Class Initialized
DEBUG - 2015-09-28 22:19:37 --> Router Class Initialized
ERROR - 2015-09-28 22:19:37 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 23:02:50 --> Config Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Hooks Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Utf8 Class Initialized
DEBUG - 2015-09-28 23:02:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 23:02:50 --> URI Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Router Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Output Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Security Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Input Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 23:02:50 --> Language Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Language Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Config Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Loader Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Helper loaded: url_helper
DEBUG - 2015-09-28 23:02:50 --> Helper loaded: form_helper
DEBUG - 2015-09-28 23:02:50 --> Database Driver Class Initialized
ERROR - 2015-09-28 23:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 23:02:50 --> Session Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Helper loaded: string_helper
DEBUG - 2015-09-28 23:02:50 --> Session routines successfully run
DEBUG - 2015-09-28 23:02:50 --> Form Validation Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Pagination Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Encrypt Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Email Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Controller Class Initialized
DEBUG - 2015-09-28 23:02:50 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 23:02:50 --> Model Class Initialized
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 23:02:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 23:02:50 --> Final output sent to browser
DEBUG - 2015-09-28 23:02:50 --> Total execution time: 0.1323
DEBUG - 2015-09-28 23:02:51 --> Config Class Initialized
DEBUG - 2015-09-28 23:02:52 --> Hooks Class Initialized
DEBUG - 2015-09-28 23:02:52 --> Utf8 Class Initialized
DEBUG - 2015-09-28 23:02:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 23:02:52 --> URI Class Initialized
DEBUG - 2015-09-28 23:02:52 --> Router Class Initialized
ERROR - 2015-09-28 23:02:52 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 23:04:27 --> Config Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Hooks Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Utf8 Class Initialized
DEBUG - 2015-09-28 23:04:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 23:04:27 --> URI Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Router Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Output Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Security Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Input Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 23:04:27 --> Language Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Language Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Config Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Loader Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Helper loaded: url_helper
DEBUG - 2015-09-28 23:04:27 --> Helper loaded: form_helper
DEBUG - 2015-09-28 23:04:27 --> Database Driver Class Initialized
ERROR - 2015-09-28 23:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 23:04:27 --> Session Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Helper loaded: string_helper
DEBUG - 2015-09-28 23:04:27 --> Session routines successfully run
DEBUG - 2015-09-28 23:04:27 --> Form Validation Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Pagination Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Encrypt Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Email Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Controller Class Initialized
DEBUG - 2015-09-28 23:04:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 23:04:27 --> Model Class Initialized
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 23:04:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 23:04:27 --> Final output sent to browser
DEBUG - 2015-09-28 23:04:27 --> Total execution time: 0.1397
DEBUG - 2015-09-28 23:04:28 --> Config Class Initialized
DEBUG - 2015-09-28 23:04:28 --> Hooks Class Initialized
DEBUG - 2015-09-28 23:04:28 --> Utf8 Class Initialized
DEBUG - 2015-09-28 23:04:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 23:04:28 --> URI Class Initialized
DEBUG - 2015-09-28 23:04:28 --> Router Class Initialized
ERROR - 2015-09-28 23:04:28 --> 404 Page Not Found --> 
DEBUG - 2015-09-28 23:05:51 --> Config Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Hooks Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Utf8 Class Initialized
DEBUG - 2015-09-28 23:05:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 23:05:51 --> URI Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Router Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Output Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Security Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Input Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 23:05:51 --> Language Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Language Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Config Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Loader Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Helper loaded: url_helper
DEBUG - 2015-09-28 23:05:51 --> Helper loaded: form_helper
DEBUG - 2015-09-28 23:05:51 --> Database Driver Class Initialized
ERROR - 2015-09-28 23:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 23:05:51 --> Session Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Helper loaded: string_helper
DEBUG - 2015-09-28 23:05:51 --> Session routines successfully run
DEBUG - 2015-09-28 23:05:51 --> Form Validation Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Pagination Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Encrypt Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Email Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Controller Class Initialized
DEBUG - 2015-09-28 23:05:51 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 23:05:51 --> Model Class Initialized
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 23:05:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 23:05:51 --> Final output sent to browser
DEBUG - 2015-09-28 23:05:51 --> Total execution time: 0.1402
DEBUG - 2015-09-28 23:12:31 --> Config Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Hooks Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Utf8 Class Initialized
DEBUG - 2015-09-28 23:12:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 23:12:31 --> URI Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Router Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Output Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Security Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Input Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 23:12:31 --> Language Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Language Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Config Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Loader Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Helper loaded: url_helper
DEBUG - 2015-09-28 23:12:31 --> Helper loaded: form_helper
DEBUG - 2015-09-28 23:12:31 --> Database Driver Class Initialized
ERROR - 2015-09-28 23:12:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 23:12:31 --> Session Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Helper loaded: string_helper
DEBUG - 2015-09-28 23:12:31 --> Session routines successfully run
DEBUG - 2015-09-28 23:12:31 --> Form Validation Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Pagination Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Encrypt Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Email Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Controller Class Initialized
DEBUG - 2015-09-28 23:12:31 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 23:12:31 --> Model Class Initialized
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 23:12:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 23:12:31 --> Final output sent to browser
DEBUG - 2015-09-28 23:12:31 --> Total execution time: 0.1395
DEBUG - 2015-09-28 23:24:04 --> Config Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Hooks Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Utf8 Class Initialized
DEBUG - 2015-09-28 23:24:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 23:24:04 --> URI Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Router Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Output Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Security Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Input Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 23:24:04 --> Language Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Language Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Config Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Loader Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Helper loaded: url_helper
DEBUG - 2015-09-28 23:24:04 --> Helper loaded: form_helper
DEBUG - 2015-09-28 23:24:04 --> Database Driver Class Initialized
ERROR - 2015-09-28 23:24:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 23:24:04 --> Session Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Helper loaded: string_helper
DEBUG - 2015-09-28 23:24:04 --> Session routines successfully run
DEBUG - 2015-09-28 23:24:04 --> Form Validation Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Pagination Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Encrypt Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Email Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Controller Class Initialized
DEBUG - 2015-09-28 23:24:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 23:24:04 --> Model Class Initialized
ERROR - 2015-09-28 23:24:04 --> Severity: Notice  --> Undefined variable: minimum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 170
ERROR - 2015-09-28 23:24:04 --> Severity: Notice  --> Undefined variable: maximum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 177
ERROR - 2015-09-28 23:24:04 --> Severity: Notice  --> Undefined variable: custom_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 184
ERROR - 2015-09-28 23:24:04 --> Severity: Notice  --> Undefined variable: minimum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 192
ERROR - 2015-09-28 23:24:04 --> Severity: Notice  --> Undefined variable: maximum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 199
ERROR - 2015-09-28 23:24:04 --> Severity: Notice  --> Undefined variable: custom_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 206
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 23:24:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 23:24:04 --> Final output sent to browser
DEBUG - 2015-09-28 23:24:04 --> Total execution time: 0.1458
DEBUG - 2015-09-28 23:59:28 --> Config Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Hooks Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Utf8 Class Initialized
DEBUG - 2015-09-28 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-28 23:59:28 --> URI Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Router Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Output Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Security Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Input Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-28 23:59:28 --> Language Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Language Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Config Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Loader Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Helper loaded: url_helper
DEBUG - 2015-09-28 23:59:28 --> Helper loaded: form_helper
DEBUG - 2015-09-28 23:59:28 --> Database Driver Class Initialized
ERROR - 2015-09-28 23:59:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-28 23:59:28 --> Session Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Helper loaded: string_helper
DEBUG - 2015-09-28 23:59:28 --> Session routines successfully run
DEBUG - 2015-09-28 23:59:28 --> Form Validation Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Pagination Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Encrypt Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Email Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Controller Class Initialized
DEBUG - 2015-09-28 23:59:28 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-28 23:59:28 --> Model Class Initialized
ERROR - 2015-09-28 23:59:28 --> Severity: Notice  --> Undefined variable: minimum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 170
ERROR - 2015-09-28 23:59:28 --> Severity: Notice  --> Undefined variable: maximum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 177
ERROR - 2015-09-28 23:59:28 --> Severity: Notice  --> Undefined variable: custom_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 184
ERROR - 2015-09-28 23:59:28 --> Severity: Notice  --> Undefined variable: minimum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 192
ERROR - 2015-09-28 23:59:28 --> Severity: Notice  --> Undefined variable: maximum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 199
ERROR - 2015-09-28 23:59:28 --> Severity: Notice  --> Undefined variable: custom_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 206
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-28 23:59:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-28 23:59:28 --> Final output sent to browser
DEBUG - 2015-09-28 23:59:28 --> Total execution time: 0.1347
