<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-13 16:29:08 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:08 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Router Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Output Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Security Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Input Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:29:08 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Loader Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:29:08 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:29:08 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:29:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-13 16:29:08 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:29:08 --> Session Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:29:08 --> A session cookie was not found.
DEBUG - 2015-10-13 16:29:08 --> Session routines successfully run
DEBUG - 2015-10-13 16:29:08 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Email Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Controller Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Individual MX_Controller Initialized
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:08 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Router Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Output Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Security Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Input Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:29:08 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Loader Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:29:08 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:29:08 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:29:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:29:08 --> Session Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:29:08 --> Session routines successfully run
DEBUG - 2015-10-13 16:29:08 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Email Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Controller Class Initialized
DEBUG - 2015-10-13 16:29:08 --> Auth MX_Controller Initialized
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:29:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:29:08 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-10-13 16:29:08 --> Final output sent to browser
DEBUG - 2015-10-13 16:29:08 --> Total execution time: 0.1042
DEBUG - 2015-10-13 16:29:09 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:09 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Router Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:09 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:09 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:09 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Router Class Initialized
ERROR - 2015-10-13 16:29:09 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 16:29:09 --> Router Class Initialized
ERROR - 2015-10-13 16:29:09 --> 404 Page Not Found --> 
ERROR - 2015-10-13 16:29:09 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 16:29:09 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:09 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Router Class Initialized
ERROR - 2015-10-13 16:29:09 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 16:29:09 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:09 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:09 --> Router Class Initialized
ERROR - 2015-10-13 16:29:09 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 16:29:32 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:32 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Router Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Output Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Security Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Input Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:29:32 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Loader Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:29:32 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:29:32 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:29:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-13 16:29:32 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:29:32 --> Session Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:29:32 --> Session routines successfully run
DEBUG - 2015-10-13 16:29:32 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Email Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Controller Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Auth MX_Controller Initialized
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 16:29:32 --> XSS Filtering completed
DEBUG - 2015-10-13 16:29:32 --> Unable to find validation rule: exists
DEBUG - 2015-10-13 16:29:32 --> XSS Filtering completed
DEBUG - 2015-10-13 16:29:32 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:32 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Router Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Output Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Security Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Input Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:29:32 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Loader Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:29:32 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:29:32 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:29:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:29:32 --> Session Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:29:32 --> Session routines successfully run
DEBUG - 2015-10-13 16:29:32 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Email Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Controller Class Initialized
DEBUG - 2015-10-13 16:29:32 --> Admin MX_Controller Initialized
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-13 16:29:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:29:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:29:32 --> Final output sent to browser
DEBUG - 2015-10-13 16:29:32 --> Total execution time: 0.1217
DEBUG - 2015-10-13 16:29:34 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:34 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:34 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:34 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:34 --> Router Class Initialized
ERROR - 2015-10-13 16:29:34 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 16:29:41 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:29:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:29:41 --> URI Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Router Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Output Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Security Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Input Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:29:41 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Language Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Config Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Loader Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:29:41 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:29:41 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:29:41 --> Session Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:29:41 --> Session routines successfully run
DEBUG - 2015-10-13 16:29:41 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Email Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Controller Class Initialized
DEBUG - 2015-10-13 16:29:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:29:41 --> Model Class Initialized
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:29:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:29:41 --> Final output sent to browser
DEBUG - 2015-10-13 16:29:41 --> Total execution time: 0.1405
DEBUG - 2015-10-13 16:32:22 --> Config Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:32:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:32:22 --> URI Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Router Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Output Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Security Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Input Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:32:22 --> Language Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Language Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Config Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Loader Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:32:22 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:32:22 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:32:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:32:22 --> Session Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:32:22 --> Session routines successfully run
DEBUG - 2015-10-13 16:32:22 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Email Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Controller Class Initialized
DEBUG - 2015-10-13 16:32:22 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:32:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:22 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-13 16:32:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:32:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:32:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:32:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:32:23 --> Final output sent to browser
DEBUG - 2015-10-13 16:32:23 --> Total execution time: 0.1402
DEBUG - 2015-10-13 16:32:36 --> Config Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:32:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:32:36 --> URI Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Router Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Output Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Security Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Input Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:32:36 --> Language Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Language Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Config Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Loader Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:32:36 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:32:36 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:32:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:32:36 --> Session Class Initialized
DEBUG - 2015-10-13 16:32:36 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:32:36 --> Session routines successfully run
DEBUG - 2015-10-13 16:32:37 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:32:37 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:32:37 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:32:37 --> Email Class Initialized
DEBUG - 2015-10-13 16:32:37 --> Controller Class Initialized
DEBUG - 2015-10-13 16:32:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:32:37 --> Model Class Initialized
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:32:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:32:37 --> Final output sent to browser
DEBUG - 2015-10-13 16:32:37 --> Total execution time: 0.1288
DEBUG - 2015-10-13 16:40:50 --> Config Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:40:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:40:50 --> URI Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Router Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Output Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Security Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Input Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:40:50 --> Language Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Language Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Config Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Loader Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:40:50 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:40:50 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:40:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:40:50 --> Session Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:40:50 --> Session routines successfully run
DEBUG - 2015-10-13 16:40:50 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Email Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Controller Class Initialized
DEBUG - 2015-10-13 16:40:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:40:50 --> Model Class Initialized
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:40:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:40:50 --> Final output sent to browser
DEBUG - 2015-10-13 16:40:50 --> Total execution time: 0.1366
DEBUG - 2015-10-13 16:42:42 --> Config Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:42:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:42:42 --> URI Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Router Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Output Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Security Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Input Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:42:42 --> Language Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Language Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Config Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Loader Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:42:42 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:42:42 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:42:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:42:42 --> Session Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:42:42 --> Session routines successfully run
DEBUG - 2015-10-13 16:42:42 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Email Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Controller Class Initialized
DEBUG - 2015-10-13 16:42:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:42:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:42:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Config Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:43:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:43:29 --> URI Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Router Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Output Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Security Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Input Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:43:29 --> Language Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Language Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Config Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Loader Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:43:29 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:43:29 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-13 16:43:29 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:43:29 --> Session Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:43:29 --> Session routines successfully run
DEBUG - 2015-10-13 16:43:29 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Email Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Controller Class Initialized
DEBUG - 2015-10-13 16:43:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:43:29 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Config Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:43:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:43:56 --> URI Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Router Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Output Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Security Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Input Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:43:56 --> Language Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Language Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Config Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Loader Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:43:56 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:43:56 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:43:56 --> Session Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:43:56 --> Session routines successfully run
DEBUG - 2015-10-13 16:43:56 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Email Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Controller Class Initialized
DEBUG - 2015-10-13 16:43:56 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:43:56 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:43:56 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Config Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:44:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:44:16 --> URI Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Router Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Output Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Security Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Input Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:44:16 --> Language Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Language Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Config Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Loader Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:44:16 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:44:16 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:44:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:44:16 --> Session Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:44:16 --> Session routines successfully run
DEBUG - 2015-10-13 16:44:16 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Email Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Controller Class Initialized
DEBUG - 2015-10-13 16:44:16 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:44:16 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Config Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:44:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:44:39 --> URI Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Router Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Output Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Security Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Input Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:44:39 --> Language Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Language Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Config Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Loader Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:44:39 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:44:39 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:44:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:44:39 --> Session Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:44:39 --> Session routines successfully run
DEBUG - 2015-10-13 16:44:39 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Email Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Controller Class Initialized
DEBUG - 2015-10-13 16:44:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:44:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:44:39 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Config Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:45:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:45:19 --> URI Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Router Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Output Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Security Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Input Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:45:19 --> Language Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Language Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Config Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Loader Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:45:19 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:45:19 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-13 16:45:19 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:45:19 --> Session Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:45:19 --> Session routines successfully run
DEBUG - 2015-10-13 16:45:19 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Email Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Controller Class Initialized
DEBUG - 2015-10-13 16:45:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:45:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Config Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:45:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:45:20 --> URI Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Router Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Output Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Security Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Input Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:45:20 --> Language Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Language Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Config Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Loader Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:45:20 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:45:20 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:45:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:45:20 --> Session Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:45:20 --> Session routines successfully run
DEBUG - 2015-10-13 16:45:20 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Email Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Controller Class Initialized
DEBUG - 2015-10-13 16:45:20 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:20 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:45:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Config Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:45:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:45:45 --> URI Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Router Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Output Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Security Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Input Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:45:45 --> Language Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Language Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Config Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Loader Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:45:45 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:45:45 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:45:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:45:45 --> Session Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:45:45 --> Session routines successfully run
DEBUG - 2015-10-13 16:45:45 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Email Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Controller Class Initialized
DEBUG - 2015-10-13 16:45:45 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:45:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Config Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:46:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:46:51 --> URI Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Router Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Output Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Security Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Input Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:46:51 --> Language Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Language Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Config Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Loader Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:46:51 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:46:51 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:46:51 --> Session Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:46:51 --> Session routines successfully run
DEBUG - 2015-10-13 16:46:51 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Email Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Controller Class Initialized
DEBUG - 2015-10-13 16:46:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:46:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:46:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Config Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:47:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:47:21 --> URI Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Router Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Output Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Security Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Input Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:47:21 --> Language Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Language Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Config Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Loader Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:47:21 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:47:21 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:47:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-13 16:47:21 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:47:21 --> Session Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:47:21 --> Session routines successfully run
DEBUG - 2015-10-13 16:47:21 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Email Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Controller Class Initialized
DEBUG - 2015-10-13 16:47:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:47:21 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Config Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:47:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:47:48 --> URI Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Router Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Output Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Security Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Input Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:47:48 --> Language Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Language Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Config Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Loader Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:47:48 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:47:48 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:47:48 --> Session Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:47:48 --> Session routines successfully run
DEBUG - 2015-10-13 16:47:48 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Email Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Controller Class Initialized
DEBUG - 2015-10-13 16:47:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:47:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:47:48 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Config Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:48:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:48:07 --> URI Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Router Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Output Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Security Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Input Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:48:07 --> Language Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Language Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Config Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Loader Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:48:07 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:48:07 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:48:07 --> Session Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:48:07 --> Session routines successfully run
DEBUG - 2015-10-13 16:48:07 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Email Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Controller Class Initialized
DEBUG - 2015-10-13 16:48:07 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:48:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:48:07 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:49:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:49:19 --> URI Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Router Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Output Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Security Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Input Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:49:19 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Loader Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:49:19 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:49:19 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:49:19 --> Session Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:49:19 --> Session routines successfully run
DEBUG - 2015-10-13 16:49:19 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Email Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Controller Class Initialized
DEBUG - 2015-10-13 16:49:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:49:19 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:49:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:49:20 --> URI Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Router Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Output Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Security Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Input Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:49:20 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Loader Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:49:20 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:49:20 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:49:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:49:20 --> Session Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:49:20 --> Session routines successfully run
DEBUG - 2015-10-13 16:49:20 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Email Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Controller Class Initialized
DEBUG - 2015-10-13 16:49:20 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:20 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:49:20 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:49:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:49:22 --> URI Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Router Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Output Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Security Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Input Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:49:22 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Loader Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:49:22 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:49:22 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:49:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:49:22 --> Session Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:49:22 --> Session routines successfully run
DEBUG - 2015-10-13 16:49:22 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Email Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Controller Class Initialized
DEBUG - 2015-10-13 16:49:22 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:49:22 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:49:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:49:23 --> URI Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Router Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Output Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Security Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Input Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:49:23 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Loader Class Initialized
DEBUG - 2015-10-13 16:49:23 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:49:23 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:49:24 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:49:24 --> Session Class Initialized
DEBUG - 2015-10-13 16:49:24 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:49:24 --> Session routines successfully run
DEBUG - 2015-10-13 16:49:24 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:49:24 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:49:24 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:49:24 --> Email Class Initialized
DEBUG - 2015-10-13 16:49:24 --> Controller Class Initialized
DEBUG - 2015-10-13 16:49:24 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:49:24 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:49:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:49:40 --> URI Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Router Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Output Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Security Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Input Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:49:40 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Loader Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:49:40 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:49:40 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:49:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:49:40 --> Session Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:49:40 --> Session routines successfully run
DEBUG - 2015-10-13 16:49:40 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Email Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Controller Class Initialized
DEBUG - 2015-10-13 16:49:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:49:40 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:49:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:49:42 --> URI Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Router Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Output Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Security Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Input Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:49:42 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Language Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Config Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Loader Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:49:42 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:49:42 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:49:42 --> Session Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:49:42 --> Session routines successfully run
DEBUG - 2015-10-13 16:49:42 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Email Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Controller Class Initialized
DEBUG - 2015-10-13 16:49:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:49:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:49:42 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Config Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:50:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:50:06 --> URI Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Router Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Output Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Security Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Input Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:50:06 --> Language Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Language Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Config Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Loader Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:50:06 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:50:06 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:50:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:50:06 --> Session Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:50:06 --> Session routines successfully run
DEBUG - 2015-10-13 16:50:06 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Email Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Controller Class Initialized
DEBUG - 2015-10-13 16:50:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Config Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:50:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:50:32 --> URI Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Router Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Output Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Security Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Input Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:50:32 --> Language Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Language Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Config Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Loader Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:50:32 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:50:32 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:50:32 --> Session Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:50:32 --> Session routines successfully run
DEBUG - 2015-10-13 16:50:32 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Email Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Controller Class Initialized
DEBUG - 2015-10-13 16:50:32 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:50:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:50:32 --> Final output sent to browser
DEBUG - 2015-10-13 16:50:32 --> Total execution time: 0.1291
DEBUG - 2015-10-13 16:50:55 --> Config Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:50:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:50:55 --> URI Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Router Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Output Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Security Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Input Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:50:55 --> Language Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Language Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Config Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Loader Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:50:55 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:50:55 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:50:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:50:55 --> Session Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:50:55 --> Session routines successfully run
DEBUG - 2015-10-13 16:50:55 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Email Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Controller Class Initialized
DEBUG - 2015-10-13 16:50:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:50:55 --> Model Class Initialized
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:50:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:50:55 --> Final output sent to browser
DEBUG - 2015-10-13 16:50:55 --> Total execution time: 0.1330
DEBUG - 2015-10-13 16:51:10 --> Config Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:51:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:51:10 --> URI Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Router Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Output Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Security Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Input Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:51:10 --> Language Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Language Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Config Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Loader Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:51:10 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:51:10 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-13 16:51:10 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:51:10 --> Session Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:51:10 --> Session routines successfully run
DEBUG - 2015-10-13 16:51:10 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Email Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Controller Class Initialized
DEBUG - 2015-10-13 16:51:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:51:10 --> Model Class Initialized
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:51:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:51:10 --> Final output sent to browser
DEBUG - 2015-10-13 16:51:10 --> Total execution time: 0.1551
DEBUG - 2015-10-13 16:53:13 --> Config Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:53:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:53:13 --> URI Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Router Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Output Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Security Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Input Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:53:13 --> Language Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Language Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Config Class Initialized
DEBUG - 2015-10-13 16:53:13 --> Loader Class Initialized
DEBUG - 2015-10-13 16:53:14 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:53:14 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:53:14 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:53:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:53:14 --> Session Class Initialized
DEBUG - 2015-10-13 16:53:14 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:53:14 --> Session routines successfully run
DEBUG - 2015-10-13 16:53:14 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:53:14 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:53:14 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:53:14 --> Email Class Initialized
DEBUG - 2015-10-13 16:53:14 --> Controller Class Initialized
DEBUG - 2015-10-13 16:53:14 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:53:14 --> Model Class Initialized
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:53:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:53:14 --> Final output sent to browser
DEBUG - 2015-10-13 16:53:14 --> Total execution time: 0.1617
DEBUG - 2015-10-13 16:57:08 --> Config Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:57:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:57:08 --> URI Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Router Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Output Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Security Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Input Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:57:08 --> Language Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Language Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Config Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Loader Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:57:08 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:57:08 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:57:08 --> Session Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:57:08 --> Session routines successfully run
DEBUG - 2015-10-13 16:57:08 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Email Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Controller Class Initialized
DEBUG - 2015-10-13 16:57:08 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:08 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:57:08 --> Model Class Initialized
ERROR - 2015-10-13 16:57:08 --> 404 Page Not Found --> microfinance/show-individual-payment
DEBUG - 2015-10-13 16:57:51 --> Config Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:57:51 --> URI Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Router Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Output Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Security Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Input Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:57:51 --> Language Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Language Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Config Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Loader Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:57:51 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:57:51 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:57:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:57:51 --> Session Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:57:51 --> Session routines successfully run
DEBUG - 2015-10-13 16:57:51 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Email Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Controller Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:57:51 --> Model Class Initialized
DEBUG - 2015-10-13 16:57:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:57:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:57:51 --> Final output sent to browser
DEBUG - 2015-10-13 16:57:51 --> Total execution time: 0.1690
DEBUG - 2015-10-13 16:59:03 --> Config Class Initialized
DEBUG - 2015-10-13 16:59:03 --> Hooks Class Initialized
DEBUG - 2015-10-13 16:59:03 --> Utf8 Class Initialized
DEBUG - 2015-10-13 16:59:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 16:59:04 --> URI Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Router Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Output Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Security Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Input Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 16:59:04 --> Language Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Language Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Config Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Loader Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Helper loaded: url_helper
DEBUG - 2015-10-13 16:59:04 --> Helper loaded: form_helper
DEBUG - 2015-10-13 16:59:04 --> Database Driver Class Initialized
ERROR - 2015-10-13 16:59:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 16:59:04 --> Session Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Helper loaded: string_helper
DEBUG - 2015-10-13 16:59:04 --> Session routines successfully run
DEBUG - 2015-10-13 16:59:04 --> Form Validation Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Pagination Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Encrypt Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Email Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Controller Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 16:59:04 --> Model Class Initialized
DEBUG - 2015-10-13 16:59:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 16:59:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 16:59:04 --> Final output sent to browser
DEBUG - 2015-10-13 16:59:04 --> Total execution time: 0.1402
DEBUG - 2015-10-13 17:00:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:00:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:00:40 --> URI Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Router Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Output Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Security Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Input Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:00:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Loader Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:00:40 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:00:40 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:00:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:00:40 --> Session Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:00:40 --> Session routines successfully run
DEBUG - 2015-10-13 17:00:40 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Email Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Controller Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:00:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:00:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:00:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:00:40 --> Final output sent to browser
DEBUG - 2015-10-13 17:00:40 --> Total execution time: 0.1383
DEBUG - 2015-10-13 17:02:38 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:02:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:02:38 --> URI Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Router Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Output Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Security Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Input Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:02:38 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Loader Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:02:38 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:02:38 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:02:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:02:38 --> Session Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:02:38 --> Session routines successfully run
DEBUG - 2015-10-13 17:02:38 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Email Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Controller Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:02:38 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:02:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:02:38 --> Final output sent to browser
DEBUG - 2015-10-13 17:02:38 --> Total execution time: 0.1447
DEBUG - 2015-10-13 17:02:41 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:02:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:02:41 --> URI Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Router Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Output Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Security Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Input Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:02:41 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Loader Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:02:41 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:02:41 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:02:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:02:41 --> Session Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:02:41 --> Session routines successfully run
DEBUG - 2015-10-13 17:02:41 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Email Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Controller Class Initialized
DEBUG - 2015-10-13 17:02:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:02:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:02:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:02:41 --> Final output sent to browser
DEBUG - 2015-10-13 17:02:41 --> Total execution time: 0.1332
DEBUG - 2015-10-13 17:02:46 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:02:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:02:46 --> URI Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Router Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Output Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Security Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Input Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:02:46 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Loader Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:02:46 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:02:46 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:02:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:02:46 --> Session Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:02:46 --> Session routines successfully run
DEBUG - 2015-10-13 17:02:46 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Email Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Controller Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:02:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:02:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:02:46 --> Final output sent to browser
DEBUG - 2015-10-13 17:02:46 --> Total execution time: 0.1407
DEBUG - 2015-10-13 17:02:48 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:48 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:02:48 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:02:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:02:48 --> URI Class Initialized
DEBUG - 2015-10-13 17:02:48 --> Router Class Initialized
DEBUG - 2015-10-13 17:02:48 --> Output Class Initialized
DEBUG - 2015-10-13 17:02:48 --> Security Class Initialized
DEBUG - 2015-10-13 17:02:48 --> Input Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:02:49 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Loader Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:02:49 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:02:49 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:02:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:02:49 --> Session Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:02:49 --> Session routines successfully run
DEBUG - 2015-10-13 17:02:49 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Email Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Controller Class Initialized
DEBUG - 2015-10-13 17:02:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:02:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:02:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:02:49 --> Final output sent to browser
DEBUG - 2015-10-13 17:02:49 --> Total execution time: 0.1369
DEBUG - 2015-10-13 17:02:54 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:02:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:02:54 --> URI Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Router Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Output Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Security Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Input Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:02:54 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Language Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Config Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Loader Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:02:54 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:02:54 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:02:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:02:54 --> Session Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:02:54 --> Session routines successfully run
DEBUG - 2015-10-13 17:02:54 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Email Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Controller Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:02:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:02:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:02:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:02:54 --> Final output sent to browser
DEBUG - 2015-10-13 17:02:54 --> Total execution time: 0.1447
DEBUG - 2015-10-13 17:03:48 --> Config Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:03:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:03:48 --> URI Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Router Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Output Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Security Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Input Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:03:48 --> Language Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Language Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Config Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Loader Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:03:48 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:03:48 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:03:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:03:48 --> Session Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:03:48 --> Session routines successfully run
DEBUG - 2015-10-13 17:03:48 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Email Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Controller Class Initialized
DEBUG - 2015-10-13 17:03:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:03:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:03:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:03:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:03:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:03:49 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:03:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:03:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:03:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:03:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:03:49 --> Final output sent to browser
DEBUG - 2015-10-13 17:03:49 --> Total execution time: 0.1441
DEBUG - 2015-10-13 17:10:45 --> Config Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:10:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:10:45 --> URI Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Router Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Output Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Security Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Input Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:10:45 --> Language Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Language Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Config Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Loader Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:10:45 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:10:45 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:10:45 --> Session Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:10:45 --> Session routines successfully run
DEBUG - 2015-10-13 17:10:45 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Email Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Controller Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:10:45 --> Model Class Initialized
DEBUG - 2015-10-13 17:10:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:10:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:10:45 --> Final output sent to browser
DEBUG - 2015-10-13 17:10:45 --> Total execution time: 0.1389
DEBUG - 2015-10-13 17:11:23 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:11:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:11:23 --> URI Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Router Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Output Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Security Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Input Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:11:23 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Loader Class Initialized
DEBUG - 2015-10-13 17:11:23 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:11:24 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:11:24 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:11:24 --> Session Class Initialized
DEBUG - 2015-10-13 17:11:24 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:11:24 --> Session routines successfully run
DEBUG - 2015-10-13 17:11:24 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:11:24 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:11:24 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:11:24 --> Email Class Initialized
DEBUG - 2015-10-13 17:11:24 --> Controller Class Initialized
DEBUG - 2015-10-13 17:11:24 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:11:24 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:11:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:11:24 --> Final output sent to browser
DEBUG - 2015-10-13 17:11:24 --> Total execution time: 0.1639
DEBUG - 2015-10-13 17:11:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:11:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:11:30 --> URI Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Router Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Output Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Security Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Input Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:11:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Loader Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:11:30 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:11:30 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:11:30 --> Session Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:11:30 --> Session routines successfully run
DEBUG - 2015-10-13 17:11:30 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Email Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Controller Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:11:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:11:30 --> URI Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Router Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Output Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Security Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Input Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:11:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Loader Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:11:30 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:11:30 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:11:30 --> Session Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:11:30 --> Session routines successfully run
DEBUG - 2015-10-13 17:11:30 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Email Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Controller Class Initialized
DEBUG - 2015-10-13 17:11:30 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:11:30 --> Model Class Initialized
ERROR - 2015-10-13 17:11:30 --> 404 Page Not Found --> microfinance/show-individual-payment
DEBUG - 2015-10-13 17:11:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:11:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:11:40 --> URI Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Router Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Output Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Security Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Input Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:11:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Loader Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:11:40 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:11:40 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:11:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:11:40 --> Session Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:11:40 --> Session routines successfully run
DEBUG - 2015-10-13 17:11:40 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Email Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Controller Class Initialized
DEBUG - 2015-10-13 17:11:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:11:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:11:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:11:40 --> Final output sent to browser
DEBUG - 2015-10-13 17:11:40 --> Total execution time: 0.1303
DEBUG - 2015-10-13 17:11:44 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:11:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:11:44 --> URI Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Router Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Output Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Security Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Input Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:11:44 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Language Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Config Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Loader Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:11:44 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:11:44 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:11:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:11:44 --> Session Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:11:44 --> Session routines successfully run
DEBUG - 2015-10-13 17:11:44 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Email Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Controller Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:11:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:11:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:11:45 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:11:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:11:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:11:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:11:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:11:45 --> Final output sent to browser
DEBUG - 2015-10-13 17:11:45 --> Total execution time: 0.1405
DEBUG - 2015-10-13 17:12:01 --> Config Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:12:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:12:01 --> URI Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Router Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Output Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Security Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Input Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:12:01 --> Language Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Language Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Config Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Loader Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:12:01 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:12:01 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:12:01 --> Session Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:12:01 --> Session routines successfully run
DEBUG - 2015-10-13 17:12:01 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Email Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Controller Class Initialized
DEBUG - 2015-10-13 17:12:01 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:12:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:12:01 --> Model Class Initialized
ERROR - 2015-10-13 17:12:01 --> 404 Page Not Found --> microfinance/show-individual-payment
DEBUG - 2015-10-13 17:13:18 --> Config Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:13:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:13:19 --> URI Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Router Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Output Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Security Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Input Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:13:19 --> Language Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Language Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Config Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Loader Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:13:19 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:13:19 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:13:19 --> Session Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:13:19 --> Session routines successfully run
DEBUG - 2015-10-13 17:13:19 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Email Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Controller Class Initialized
DEBUG - 2015-10-13 17:13:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:13:19 --> Model Class Initialized
ERROR - 2015-10-13 17:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 416
ERROR - 2015-10-13 17:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 425
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:13:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:13:19 --> Final output sent to browser
DEBUG - 2015-10-13 17:13:19 --> Total execution time: 0.1391
DEBUG - 2015-10-13 17:13:25 --> Config Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:13:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:13:25 --> URI Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Router Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Output Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Security Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Input Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:13:25 --> Language Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Language Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Config Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Loader Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:13:25 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:13:25 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:13:25 --> Session Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:13:25 --> Session routines successfully run
DEBUG - 2015-10-13 17:13:25 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Email Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Controller Class Initialized
DEBUG - 2015-10-13 17:13:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:13:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:13:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:13:25 --> Final output sent to browser
DEBUG - 2015-10-13 17:13:25 --> Total execution time: 0.1686
DEBUG - 2015-10-13 17:14:05 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:14:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:14:05 --> URI Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Router Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Output Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Security Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Input Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:14:05 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Loader Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:14:05 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:14:05 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:14:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:14:05 --> Session Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:14:05 --> Session routines successfully run
DEBUG - 2015-10-13 17:14:05 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Email Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Controller Class Initialized
DEBUG - 2015-10-13 17:14:05 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:14:05 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:14:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:14:05 --> Final output sent to browser
DEBUG - 2015-10-13 17:14:05 --> Total execution time: 0.1311
DEBUG - 2015-10-13 17:14:11 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:14:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:14:11 --> URI Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Router Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Output Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Security Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Input Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:14:11 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Loader Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:14:11 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:14:11 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:14:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:14:11 --> Session Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:14:11 --> Session routines successfully run
DEBUG - 2015-10-13 17:14:11 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Email Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Controller Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:14:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:14:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:14:11 --> Final output sent to browser
DEBUG - 2015-10-13 17:14:11 --> Total execution time: 0.1373
DEBUG - 2015-10-13 17:14:22 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:14:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:14:22 --> URI Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Router Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Output Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Security Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Input Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:14:22 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Loader Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:14:22 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:14:22 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:14:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:14:22 --> Session Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:14:22 --> Session routines successfully run
DEBUG - 2015-10-13 17:14:22 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Email Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Controller Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:14:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:14:22 --> URI Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Router Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Output Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Security Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Input Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:14:22 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Loader Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:14:22 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:14:22 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:14:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:14:22 --> Session Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:14:22 --> Session routines successfully run
DEBUG - 2015-10-13 17:14:22 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Email Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Controller Class Initialized
DEBUG - 2015-10-13 17:14:22 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:14:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:22 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:14:22 --> Final output sent to browser
DEBUG - 2015-10-13 17:14:22 --> Total execution time: 0.1217
DEBUG - 2015-10-13 17:14:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:14:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:14:30 --> URI Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Router Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Output Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Security Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Input Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:14:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Loader Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:14:30 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:14:30 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:14:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:14:30 --> Session Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:14:30 --> Session routines successfully run
DEBUG - 2015-10-13 17:14:30 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Email Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Controller Class Initialized
DEBUG - 2015-10-13 17:14:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:14:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:14:30 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:14:30 --> Final output sent to browser
DEBUG - 2015-10-13 17:14:30 --> Total execution time: 0.1268
DEBUG - 2015-10-13 17:15:23 --> Config Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:15:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:15:23 --> URI Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Router Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Output Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Security Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Input Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:15:23 --> Language Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Language Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Config Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Loader Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:15:23 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:15:23 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:15:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:15:23 --> Session Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:15:23 --> Session routines successfully run
DEBUG - 2015-10-13 17:15:23 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Email Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Controller Class Initialized
DEBUG - 2015-10-13 17:15:23 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:15:23 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:23 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:15:23 --> Final output sent to browser
DEBUG - 2015-10-13 17:15:23 --> Total execution time: 0.1225
DEBUG - 2015-10-13 17:15:50 --> Config Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:15:50 --> URI Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Router Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Output Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Security Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Input Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:15:50 --> Language Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Language Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Config Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Loader Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:15:50 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:15:50 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:15:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:15:50 --> Session Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:15:50 --> Session routines successfully run
DEBUG - 2015-10-13 17:15:50 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Email Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Controller Class Initialized
DEBUG - 2015-10-13 17:15:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:15:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:15:50 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:15:50 --> Final output sent to browser
DEBUG - 2015-10-13 17:15:50 --> Total execution time: 0.1377
DEBUG - 2015-10-13 17:16:09 --> Config Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:16:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:16:09 --> URI Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Router Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Output Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Security Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Input Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:16:09 --> Language Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Language Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Config Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Loader Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:16:09 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:16:09 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:16:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:16:09 --> Session Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:16:09 --> Session routines successfully run
DEBUG - 2015-10-13 17:16:09 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Email Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Controller Class Initialized
DEBUG - 2015-10-13 17:16:09 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:16:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:09 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:16:09 --> Final output sent to browser
DEBUG - 2015-10-13 17:16:09 --> Total execution time: 0.1288
DEBUG - 2015-10-13 17:16:25 --> Config Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:16:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:16:25 --> URI Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Router Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Output Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Security Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Input Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:16:25 --> Language Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Language Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Config Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Loader Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:16:25 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:16:25 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:16:25 --> Session Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:16:25 --> Session routines successfully run
DEBUG - 2015-10-13 17:16:25 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Email Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Controller Class Initialized
DEBUG - 2015-10-13 17:16:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:16:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:25 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:16:25 --> Final output sent to browser
DEBUG - 2015-10-13 17:16:25 --> Total execution time: 0.1219
DEBUG - 2015-10-13 17:16:57 --> Config Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:16:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:16:57 --> URI Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Router Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Output Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Security Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Input Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:16:57 --> Language Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Language Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Config Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Loader Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:16:57 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:16:57 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:16:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:16:57 --> Session Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:16:57 --> Session routines successfully run
DEBUG - 2015-10-13 17:16:57 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Email Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Controller Class Initialized
DEBUG - 2015-10-13 17:16:57 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:16:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:16:57 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:16:57 --> Final output sent to browser
DEBUG - 2015-10-13 17:16:57 --> Total execution time: 0.1327
DEBUG - 2015-10-13 17:17:43 --> Config Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:17:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:17:43 --> URI Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Router Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Output Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Security Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Input Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:17:43 --> Language Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Language Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Config Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Loader Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:17:43 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:17:43 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:17:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:17:43 --> Session Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:17:43 --> Session routines successfully run
DEBUG - 2015-10-13 17:17:43 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Email Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Controller Class Initialized
DEBUG - 2015-10-13 17:17:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:17:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:43 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:17:43 --> Final output sent to browser
DEBUG - 2015-10-13 17:17:43 --> Total execution time: 0.1192
DEBUG - 2015-10-13 17:17:58 --> Config Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:17:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:17:58 --> URI Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Router Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Output Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Security Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Input Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:17:58 --> Language Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Language Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Config Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Loader Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:17:58 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:17:58 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:17:58 --> Session Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:17:58 --> Session routines successfully run
DEBUG - 2015-10-13 17:17:58 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Email Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Controller Class Initialized
DEBUG - 2015-10-13 17:17:58 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:17:58 --> Model Class Initialized
DEBUG - 2015-10-13 17:17:58 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:17:58 --> Final output sent to browser
DEBUG - 2015-10-13 17:17:58 --> Total execution time: 0.1484
DEBUG - 2015-10-13 17:18:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:18:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:18:40 --> URI Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Router Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Output Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Security Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Input Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:18:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Loader Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:18:40 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:18:40 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:18:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:18:40 --> Session Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:18:40 --> Session routines successfully run
DEBUG - 2015-10-13 17:18:40 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Email Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Controller Class Initialized
DEBUG - 2015-10-13 17:18:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:18:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:40 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:18:40 --> Final output sent to browser
DEBUG - 2015-10-13 17:18:40 --> Total execution time: 0.1239
DEBUG - 2015-10-13 17:18:47 --> Config Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:18:47 --> URI Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Router Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Output Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Security Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Input Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:18:47 --> Language Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Language Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Config Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Loader Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:18:47 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:18:47 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:18:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:18:47 --> Session Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:18:47 --> Session routines successfully run
DEBUG - 2015-10-13 17:18:47 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Email Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Controller Class Initialized
DEBUG - 2015-10-13 17:18:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:18:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:18:47 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:18:48 --> Final output sent to browser
DEBUG - 2015-10-13 17:18:48 --> Total execution time: 0.1341
DEBUG - 2015-10-13 17:19:31 --> Config Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:19:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:19:31 --> URI Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Router Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Output Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Security Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Input Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:19:31 --> Language Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Language Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Config Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Loader Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:19:31 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:19:31 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:19:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:19:31 --> Session Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:19:31 --> Session routines successfully run
DEBUG - 2015-10-13 17:19:31 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Email Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Controller Class Initialized
DEBUG - 2015-10-13 17:19:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:19:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:19:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:19:31 --> Final output sent to browser
DEBUG - 2015-10-13 17:19:31 --> Total execution time: 0.1551
DEBUG - 2015-10-13 17:19:33 --> Config Class Initialized
DEBUG - 2015-10-13 17:19:33 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:19:33 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:19:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:19:33 --> URI Class Initialized
DEBUG - 2015-10-13 17:19:33 --> Router Class Initialized
ERROR - 2015-10-13 17:19:33 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:19:39 --> Config Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:19:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:19:39 --> URI Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Router Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Output Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Security Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Input Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:19:39 --> Language Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Language Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Config Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Loader Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:19:39 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:19:39 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:19:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:19:39 --> Session Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:19:39 --> Session routines successfully run
DEBUG - 2015-10-13 17:19:39 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Email Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Controller Class Initialized
DEBUG - 2015-10-13 17:19:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:19:39 --> Model Class Initialized
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:19:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:19:39 --> Final output sent to browser
DEBUG - 2015-10-13 17:19:39 --> Total execution time: 0.1539
DEBUG - 2015-10-13 17:19:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:19:40 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:19:40 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:19:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:19:40 --> URI Class Initialized
DEBUG - 2015-10-13 17:19:40 --> Router Class Initialized
ERROR - 2015-10-13 17:19:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:20:47 --> Config Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:20:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:20:47 --> URI Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Router Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Output Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Security Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Input Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:20:47 --> Language Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Language Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Config Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Loader Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:20:47 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:20:47 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:20:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:20:47 --> Session Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:20:47 --> Session routines successfully run
DEBUG - 2015-10-13 17:20:47 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Email Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Controller Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Config Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:20:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:20:47 --> URI Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Router Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Output Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Security Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Input Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:20:47 --> Language Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Language Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Config Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Loader Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:20:47 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:20:47 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:20:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:20:47 --> Session Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:20:47 --> Session routines successfully run
DEBUG - 2015-10-13 17:20:47 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Email Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Controller Class Initialized
DEBUG - 2015-10-13 17:20:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:20:47 --> Model Class Initialized
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:20:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:20:47 --> Final output sent to browser
DEBUG - 2015-10-13 17:20:47 --> Total execution time: 0.1491
DEBUG - 2015-10-13 17:20:48 --> Config Class Initialized
DEBUG - 2015-10-13 17:20:48 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:20:48 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:20:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:20:48 --> URI Class Initialized
DEBUG - 2015-10-13 17:20:48 --> Router Class Initialized
ERROR - 2015-10-13 17:20:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:22:44 --> Config Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:22:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:22:44 --> URI Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Router Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Output Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Security Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Input Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:22:44 --> Language Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Language Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Config Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Loader Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:22:44 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:22:44 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:22:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:22:44 --> Session Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:22:44 --> Session routines successfully run
DEBUG - 2015-10-13 17:22:44 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Email Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Controller Class Initialized
DEBUG - 2015-10-13 17:22:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:22:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:22:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:22:44 --> Final output sent to browser
DEBUG - 2015-10-13 17:22:44 --> Total execution time: 0.1603
DEBUG - 2015-10-13 17:22:46 --> Config Class Initialized
DEBUG - 2015-10-13 17:22:46 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:22:46 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:22:46 --> URI Class Initialized
DEBUG - 2015-10-13 17:22:46 --> Router Class Initialized
ERROR - 2015-10-13 17:22:46 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:25:14 --> Config Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:25:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:25:14 --> URI Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Router Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Output Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Security Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Input Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:25:14 --> Language Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Language Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Config Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Loader Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:25:14 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:25:14 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:25:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:25:14 --> Session Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:25:14 --> Session routines successfully run
DEBUG - 2015-10-13 17:25:14 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Email Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Controller Class Initialized
DEBUG - 2015-10-13 17:25:14 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:25:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:25:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:25:14 --> Final output sent to browser
DEBUG - 2015-10-13 17:25:14 --> Total execution time: 0.1549
DEBUG - 2015-10-13 17:25:15 --> Config Class Initialized
DEBUG - 2015-10-13 17:25:15 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:25:15 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:25:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:25:15 --> URI Class Initialized
DEBUG - 2015-10-13 17:25:15 --> Router Class Initialized
ERROR - 2015-10-13 17:25:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:25:47 --> Config Class Initialized
DEBUG - 2015-10-13 17:25:47 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:25:47 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:25:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:25:47 --> URI Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Router Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Output Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Security Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Input Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:25:48 --> Language Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Language Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Config Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Loader Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:25:48 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:25:48 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:25:48 --> Session Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:25:48 --> Session routines successfully run
DEBUG - 2015-10-13 17:25:48 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Email Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Controller Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:25:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:25:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:25:48 --> Final output sent to browser
DEBUG - 2015-10-13 17:25:48 --> Total execution time: 0.1419
DEBUG - 2015-10-13 17:25:48 --> Config Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:25:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:25:48 --> URI Class Initialized
DEBUG - 2015-10-13 17:25:48 --> Router Class Initialized
ERROR - 2015-10-13 17:25:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:26:13 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:13 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Router Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Output Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Security Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Input Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:26:13 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Loader Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:26:13 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:26:13 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:26:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:26:13 --> Session Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:26:13 --> Session routines successfully run
DEBUG - 2015-10-13 17:26:13 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Email Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Controller Class Initialized
DEBUG - 2015-10-13 17:26:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:26:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:26:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:26:13 --> Final output sent to browser
DEBUG - 2015-10-13 17:26:13 --> Total execution time: 0.1472
DEBUG - 2015-10-13 17:26:14 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:14 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:14 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:14 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:14 --> Router Class Initialized
ERROR - 2015-10-13 17:26:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:26:16 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:16 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Router Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Output Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Security Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Input Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:26:16 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Loader Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:26:16 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:26:16 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:26:16 --> Session Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:26:16 --> Session routines successfully run
DEBUG - 2015-10-13 17:26:16 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Email Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Controller Class Initialized
DEBUG - 2015-10-13 17:26:16 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:26:16 --> Model Class Initialized
ERROR - 2015-10-13 17:26:16 --> 404 Page Not Found --> microfinance/add-individual-payments
DEBUG - 2015-10-13 17:26:26 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:26 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:26 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:26 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:26 --> Router Class Initialized
ERROR - 2015-10-13 17:26:26 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:26:28 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:28 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Router Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Output Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Security Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Input Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:26:28 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Loader Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:26:28 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:26:28 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:26:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:26:28 --> Session Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:26:28 --> Session routines successfully run
DEBUG - 2015-10-13 17:26:28 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Email Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Controller Class Initialized
DEBUG - 2015-10-13 17:26:28 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:26:28 --> Model Class Initialized
ERROR - 2015-10-13 17:26:28 --> 404 Page Not Found --> microfinance/add-individual-payments
DEBUG - 2015-10-13 17:26:32 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:32 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:32 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:32 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:32 --> Router Class Initialized
ERROR - 2015-10-13 17:26:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:26:33 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:33 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Router Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Output Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Security Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Input Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:26:33 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Loader Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:26:33 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:26:33 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:26:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:26:33 --> Session Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:26:33 --> Session routines successfully run
DEBUG - 2015-10-13 17:26:33 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Email Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Controller Class Initialized
DEBUG - 2015-10-13 17:26:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:26:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:26:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:26:33 --> Final output sent to browser
DEBUG - 2015-10-13 17:26:33 --> Total execution time: 0.1400
DEBUG - 2015-10-13 17:26:34 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:34 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Router Class Initialized
ERROR - 2015-10-13 17:26:34 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:26:34 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:34 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Router Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Output Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Security Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Input Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:26:34 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Loader Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:26:34 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:26:34 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:26:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:26:34 --> Session Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:26:34 --> Session routines successfully run
DEBUG - 2015-10-13 17:26:34 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Email Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Controller Class Initialized
DEBUG - 2015-10-13 17:26:34 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:26:34 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:26:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:26:34 --> Final output sent to browser
DEBUG - 2015-10-13 17:26:34 --> Total execution time: 0.1344
DEBUG - 2015-10-13 17:26:35 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:35 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:35 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:35 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:35 --> Router Class Initialized
ERROR - 2015-10-13 17:26:35 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:26:49 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:49 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Router Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Output Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Security Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Input Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:26:49 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Loader Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:26:49 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:26:49 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:26:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:26:49 --> Session Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:26:49 --> Session routines successfully run
DEBUG - 2015-10-13 17:26:49 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Email Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Controller Class Initialized
DEBUG - 2015-10-13 17:26:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:26:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:26:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:26:49 --> Final output sent to browser
DEBUG - 2015-10-13 17:26:49 --> Total execution time: 0.1466
DEBUG - 2015-10-13 17:26:51 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:51 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:51 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:51 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:51 --> Router Class Initialized
ERROR - 2015-10-13 17:26:51 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:26:56 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:56 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Router Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Output Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Security Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Input Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:26:56 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Language Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Loader Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:26:56 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:26:56 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:26:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:26:56 --> Session Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:26:56 --> Session routines successfully run
DEBUG - 2015-10-13 17:26:56 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Email Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Controller Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:26:56 --> Model Class Initialized
DEBUG - 2015-10-13 17:26:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:26:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:26:56 --> Final output sent to browser
DEBUG - 2015-10-13 17:26:56 --> Total execution time: 0.1441
DEBUG - 2015-10-13 17:26:57 --> Config Class Initialized
DEBUG - 2015-10-13 17:26:57 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:26:57 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:26:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:26:57 --> URI Class Initialized
DEBUG - 2015-10-13 17:26:57 --> Router Class Initialized
ERROR - 2015-10-13 17:26:57 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:27:22 --> Config Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:27:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:27:22 --> URI Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Router Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Output Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Security Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Input Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:27:22 --> Language Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Language Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Config Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Loader Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:27:22 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:27:22 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:27:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:27:22 --> Session Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:27:22 --> Session routines successfully run
DEBUG - 2015-10-13 17:27:22 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Email Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Controller Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:27:22 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:27:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:27:22 --> Final output sent to browser
DEBUG - 2015-10-13 17:27:22 --> Total execution time: 0.1392
DEBUG - 2015-10-13 17:27:23 --> Config Class Initialized
DEBUG - 2015-10-13 17:27:23 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:27:23 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:27:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:27:23 --> URI Class Initialized
DEBUG - 2015-10-13 17:27:23 --> Router Class Initialized
ERROR - 2015-10-13 17:27:23 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:27:46 --> Config Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:27:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:27:46 --> URI Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Router Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Output Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Security Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Input Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:27:46 --> Language Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Language Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Config Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Loader Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:27:46 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:27:46 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:27:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:27:46 --> Session Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:27:46 --> Session routines successfully run
DEBUG - 2015-10-13 17:27:46 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Email Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Controller Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:27:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:27:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:27:46 --> Final output sent to browser
DEBUG - 2015-10-13 17:27:46 --> Total execution time: 0.1678
DEBUG - 2015-10-13 17:27:49 --> Config Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:27:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:27:49 --> URI Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Router Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Output Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Security Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Input Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:27:49 --> Language Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Language Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Config Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Loader Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:27:49 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:27:49 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:27:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:27:49 --> Session Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:27:49 --> Session routines successfully run
DEBUG - 2015-10-13 17:27:49 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Email Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Controller Class Initialized
DEBUG - 2015-10-13 17:27:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:27:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:27:49 --> Model Class Initialized
ERROR - 2015-10-13 17:27:49 --> 404 Page Not Found --> payments/edit_individual_payment
DEBUG - 2015-10-13 17:29:25 --> Config Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:29:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:29:25 --> URI Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Router Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Output Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Security Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Input Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:29:25 --> Language Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Language Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Config Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Loader Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:29:25 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:29:25 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:29:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:29:25 --> Session Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:29:25 --> Session routines successfully run
DEBUG - 2015-10-13 17:29:25 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Email Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Controller Class Initialized
DEBUG - 2015-10-13 17:29:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:29:25 --> Model Class Initialized
ERROR - 2015-10-13 17:29:25 --> 404 Page Not Found --> payments/edit_individual_payment
DEBUG - 2015-10-13 17:29:50 --> Config Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:29:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:29:50 --> URI Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Router Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Output Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Security Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Input Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:29:50 --> Language Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Language Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Config Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Loader Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:29:50 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:29:50 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:29:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:29:50 --> Session Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:29:50 --> Session routines successfully run
DEBUG - 2015-10-13 17:29:50 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Email Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Controller Class Initialized
DEBUG - 2015-10-13 17:29:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:29:50 --> Model Class Initialized
ERROR - 2015-10-13 17:29:50 --> 404 Page Not Found --> payments/edit_individual_payment
DEBUG - 2015-10-13 17:29:51 --> Config Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:29:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:29:51 --> URI Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Router Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Output Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Security Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Input Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:29:51 --> Language Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Language Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Config Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Loader Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:29:51 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:29:51 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:29:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:29:51 --> Session Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:29:51 --> Session routines successfully run
DEBUG - 2015-10-13 17:29:51 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Email Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Controller Class Initialized
DEBUG - 2015-10-13 17:29:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:29:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:29:51 --> Model Class Initialized
ERROR - 2015-10-13 17:29:51 --> 404 Page Not Found --> payments/edit_individual_payment
DEBUG - 2015-10-13 17:32:28 --> Config Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:32:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:32:28 --> URI Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Router Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Output Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Security Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Input Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:32:28 --> Language Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Language Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Config Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Loader Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:32:28 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:32:28 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:32:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:32:28 --> Session Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:32:28 --> Session routines successfully run
DEBUG - 2015-10-13 17:32:28 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Email Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Controller Class Initialized
DEBUG - 2015-10-13 17:32:28 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:32:28 --> Model Class Initialized
ERROR - 2015-10-13 17:32:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 244
ERROR - 2015-10-13 17:32:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 245
ERROR - 2015-10-13 17:32:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 247
ERROR - 2015-10-13 17:32:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 248
ERROR - 2015-10-13 17:32:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 249
ERROR - 2015-10-13 17:32:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 250
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:32:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:32:28 --> Final output sent to browser
DEBUG - 2015-10-13 17:32:28 --> Total execution time: 0.1564
DEBUG - 2015-10-13 17:35:24 --> Config Class Initialized
DEBUG - 2015-10-13 17:35:24 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:35:24 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:35:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:35:24 --> URI Class Initialized
DEBUG - 2015-10-13 17:35:24 --> Router Class Initialized
ERROR - 2015-10-13 17:35:24 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:37:59 --> Config Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:37:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:37:59 --> URI Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Router Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Output Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Security Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Input Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:37:59 --> Language Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Language Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Config Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Loader Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:37:59 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:37:59 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:37:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:37:59 --> Session Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:37:59 --> Session routines successfully run
DEBUG - 2015-10-13 17:37:59 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Email Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Controller Class Initialized
DEBUG - 2015-10-13 17:37:59 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:37:59 --> Model Class Initialized
ERROR - 2015-10-13 17:37:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 245
ERROR - 2015-10-13 17:37:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 246
ERROR - 2015-10-13 17:37:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 248
ERROR - 2015-10-13 17:37:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 249
ERROR - 2015-10-13 17:37:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 250
ERROR - 2015-10-13 17:37:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 251
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:37:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:37:59 --> Final output sent to browser
DEBUG - 2015-10-13 17:37:59 --> Total execution time: 0.1421
DEBUG - 2015-10-13 17:38:00 --> Config Class Initialized
DEBUG - 2015-10-13 17:38:00 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:38:00 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:38:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:38:00 --> URI Class Initialized
DEBUG - 2015-10-13 17:38:00 --> Router Class Initialized
ERROR - 2015-10-13 17:38:00 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:38:44 --> Config Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:38:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:38:44 --> URI Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Router Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Output Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Security Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Input Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:38:44 --> Language Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Language Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Config Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Loader Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:38:44 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:38:44 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:38:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:38:44 --> Session Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:38:44 --> Session routines successfully run
DEBUG - 2015-10-13 17:38:44 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Email Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Controller Class Initialized
DEBUG - 2015-10-13 17:38:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:38:44 --> Model Class Initialized
ERROR - 2015-10-13 17:38:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 246
ERROR - 2015-10-13 17:38:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 247
ERROR - 2015-10-13 17:38:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 249
ERROR - 2015-10-13 17:38:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 250
ERROR - 2015-10-13 17:38:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 251
ERROR - 2015-10-13 17:38:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 252
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:38:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:38:44 --> Final output sent to browser
DEBUG - 2015-10-13 17:38:44 --> Total execution time: 0.1766
DEBUG - 2015-10-13 17:38:46 --> Config Class Initialized
DEBUG - 2015-10-13 17:38:46 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:38:46 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:38:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:38:46 --> URI Class Initialized
DEBUG - 2015-10-13 17:38:46 --> Router Class Initialized
ERROR - 2015-10-13 17:38:46 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:42:21 --> Config Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:42:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:42:21 --> URI Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Router Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Output Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Security Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Input Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:42:21 --> Language Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Language Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Config Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Loader Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:42:21 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:42:21 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:42:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:42:21 --> Session Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:42:21 --> Session routines successfully run
DEBUG - 2015-10-13 17:42:21 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Email Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Controller Class Initialized
DEBUG - 2015-10-13 17:42:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:42:21 --> Model Class Initialized
ERROR - 2015-10-13 17:42:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 246
ERROR - 2015-10-13 17:42:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 247
ERROR - 2015-10-13 17:42:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 249
ERROR - 2015-10-13 17:42:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 250
ERROR - 2015-10-13 17:42:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 251
ERROR - 2015-10-13 17:42:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 252
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:42:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:42:21 --> Final output sent to browser
DEBUG - 2015-10-13 17:42:21 --> Total execution time: 0.1471
DEBUG - 2015-10-13 17:42:22 --> Config Class Initialized
DEBUG - 2015-10-13 17:42:22 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:42:22 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:42:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:42:22 --> URI Class Initialized
DEBUG - 2015-10-13 17:42:22 --> Router Class Initialized
ERROR - 2015-10-13 17:42:22 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:43:06 --> Config Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:43:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:43:06 --> URI Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Router Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Output Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Security Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Input Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:43:06 --> Language Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Language Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Config Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Loader Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:43:06 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:43:06 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:43:06 --> Session Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:43:06 --> Session routines successfully run
DEBUG - 2015-10-13 17:43:06 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Email Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Controller Class Initialized
DEBUG - 2015-10-13 17:43:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:43:06 --> Model Class Initialized
ERROR - 2015-10-13 17:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 245
ERROR - 2015-10-13 17:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 246
ERROR - 2015-10-13 17:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 248
ERROR - 2015-10-13 17:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 249
ERROR - 2015-10-13 17:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 250
ERROR - 2015-10-13 17:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 251
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:43:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:43:06 --> Final output sent to browser
DEBUG - 2015-10-13 17:43:06 --> Total execution time: 0.2407
DEBUG - 2015-10-13 17:43:07 --> Config Class Initialized
DEBUG - 2015-10-13 17:43:07 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:43:07 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:43:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:43:07 --> URI Class Initialized
DEBUG - 2015-10-13 17:43:07 --> Router Class Initialized
ERROR - 2015-10-13 17:43:07 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:44:43 --> Config Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:44:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:44:43 --> URI Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Router Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Output Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Security Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Input Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:44:43 --> Language Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Language Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Config Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Loader Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:44:43 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:44:43 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:44:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:44:43 --> Session Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:44:43 --> Session routines successfully run
DEBUG - 2015-10-13 17:44:43 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Email Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Controller Class Initialized
DEBUG - 2015-10-13 17:44:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:44:43 --> Model Class Initialized
ERROR - 2015-10-13 17:44:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 245
ERROR - 2015-10-13 17:44:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 246
ERROR - 2015-10-13 17:44:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 248
ERROR - 2015-10-13 17:44:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 249
ERROR - 2015-10-13 17:44:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 250
ERROR - 2015-10-13 17:44:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 251
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:44:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:44:43 --> Final output sent to browser
DEBUG - 2015-10-13 17:44:43 --> Total execution time: 0.1486
DEBUG - 2015-10-13 17:44:44 --> Config Class Initialized
DEBUG - 2015-10-13 17:44:44 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:44:44 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:44:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:44:44 --> URI Class Initialized
DEBUG - 2015-10-13 17:44:44 --> Router Class Initialized
ERROR - 2015-10-13 17:44:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:44:57 --> Config Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:44:57 --> URI Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Router Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Output Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Security Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Input Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:44:57 --> Language Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Language Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Config Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Loader Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:44:57 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:44:57 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:44:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:44:57 --> Session Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:44:57 --> Session routines successfully run
DEBUG - 2015-10-13 17:44:57 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Email Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Controller Class Initialized
DEBUG - 2015-10-13 17:44:57 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:44:57 --> Model Class Initialized
ERROR - 2015-10-13 17:44:57 --> Severity: Notice  --> Undefined property: stdClass::$group_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 246
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:44:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:44:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:44:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:44:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:44:58 --> Final output sent to browser
DEBUG - 2015-10-13 17:44:58 --> Total execution time: 0.1352
DEBUG - 2015-10-13 17:44:58 --> Config Class Initialized
DEBUG - 2015-10-13 17:44:58 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:44:58 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:44:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:44:58 --> URI Class Initialized
DEBUG - 2015-10-13 17:44:58 --> Router Class Initialized
ERROR - 2015-10-13 17:44:58 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:45:28 --> Config Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:45:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:45:28 --> URI Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Router Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Output Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Security Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Input Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:45:28 --> Language Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Language Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Config Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Loader Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:45:28 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:45:28 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:45:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:45:28 --> Session Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:45:28 --> Session routines successfully run
DEBUG - 2015-10-13 17:45:28 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Email Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Controller Class Initialized
DEBUG - 2015-10-13 17:45:28 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:45:28 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:45:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:45:28 --> Final output sent to browser
DEBUG - 2015-10-13 17:45:28 --> Total execution time: 0.1424
DEBUG - 2015-10-13 17:45:29 --> Config Class Initialized
DEBUG - 2015-10-13 17:45:29 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:45:29 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:45:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:45:29 --> URI Class Initialized
DEBUG - 2015-10-13 17:45:29 --> Router Class Initialized
ERROR - 2015-10-13 17:45:29 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:45:49 --> Config Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:45:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:45:49 --> URI Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Router Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Output Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Security Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Input Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:45:49 --> Language Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Language Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Config Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Loader Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:45:49 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:45:49 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:45:49 --> Session Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:45:49 --> Session routines successfully run
DEBUG - 2015-10-13 17:45:49 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Email Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Controller Class Initialized
DEBUG - 2015-10-13 17:45:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:45:49 --> Model Class Initialized
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:45:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:45:49 --> Final output sent to browser
DEBUG - 2015-10-13 17:45:49 --> Total execution time: 0.1450
DEBUG - 2015-10-13 17:45:50 --> Config Class Initialized
DEBUG - 2015-10-13 17:45:50 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:45:50 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:45:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:45:50 --> URI Class Initialized
DEBUG - 2015-10-13 17:45:50 --> Router Class Initialized
ERROR - 2015-10-13 17:45:50 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:46:10 --> Config Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:46:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:46:10 --> URI Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Router Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Output Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Security Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Input Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:46:10 --> Language Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Language Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Config Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Loader Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:46:10 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:46:10 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:46:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:46:10 --> Session Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:46:10 --> Session routines successfully run
DEBUG - 2015-10-13 17:46:10 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Email Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Controller Class Initialized
DEBUG - 2015-10-13 17:46:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:46:10 --> Model Class Initialized
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:46:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:46:10 --> Final output sent to browser
DEBUG - 2015-10-13 17:46:10 --> Total execution time: 0.1453
DEBUG - 2015-10-13 17:46:11 --> Config Class Initialized
DEBUG - 2015-10-13 17:46:11 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:46:11 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:46:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:46:11 --> URI Class Initialized
DEBUG - 2015-10-13 17:46:11 --> Router Class Initialized
ERROR - 2015-10-13 17:46:11 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:47:11 --> Config Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:47:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:47:11 --> URI Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Router Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Output Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Security Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Input Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:47:11 --> Language Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Language Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Config Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Loader Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:47:11 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:47:11 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:47:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:47:11 --> Session Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:47:11 --> Session routines successfully run
DEBUG - 2015-10-13 17:47:11 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Email Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Controller Class Initialized
DEBUG - 2015-10-13 17:47:11 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:47:11 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:47:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:47:11 --> Final output sent to browser
DEBUG - 2015-10-13 17:47:11 --> Total execution time: 0.1334
DEBUG - 2015-10-13 17:47:13 --> Config Class Initialized
DEBUG - 2015-10-13 17:47:13 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:47:13 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:47:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:47:13 --> URI Class Initialized
DEBUG - 2015-10-13 17:47:13 --> Router Class Initialized
ERROR - 2015-10-13 17:47:13 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:47:53 --> Config Class Initialized
DEBUG - 2015-10-13 17:47:53 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:47:53 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:47:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:47:53 --> URI Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Router Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Output Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Security Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Input Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:47:54 --> Language Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Language Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Config Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Loader Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:47:54 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:47:54 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:47:54 --> Session Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:47:54 --> Session routines successfully run
DEBUG - 2015-10-13 17:47:54 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Email Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Controller Class Initialized
DEBUG - 2015-10-13 17:47:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:47:54 --> Model Class Initialized
ERROR - 2015-10-13 17:47:54 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_single_individual_payment.php 70
ERROR - 2015-10-13 17:47:54 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_single_individual_payment.php 70
ERROR - 2015-10-13 17:47:54 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_single_individual_payment.php 70
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:47:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:47:54 --> Final output sent to browser
DEBUG - 2015-10-13 17:47:54 --> Total execution time: 0.1530
DEBUG - 2015-10-13 17:47:55 --> Config Class Initialized
DEBUG - 2015-10-13 17:47:55 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:47:55 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:47:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:47:55 --> URI Class Initialized
DEBUG - 2015-10-13 17:47:55 --> Router Class Initialized
ERROR - 2015-10-13 17:47:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:48:31 --> Config Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:48:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:48:31 --> URI Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Router Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Output Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Security Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Input Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:48:31 --> Language Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Language Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Config Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Loader Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:48:31 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:48:31 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:48:31 --> Session Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:48:31 --> Session routines successfully run
DEBUG - 2015-10-13 17:48:31 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Email Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Controller Class Initialized
DEBUG - 2015-10-13 17:48:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:48:31 --> Model Class Initialized
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:48:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:48:31 --> Final output sent to browser
DEBUG - 2015-10-13 17:48:31 --> Total execution time: 0.1418
DEBUG - 2015-10-13 17:48:32 --> Config Class Initialized
DEBUG - 2015-10-13 17:48:32 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:48:32 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:48:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:48:32 --> URI Class Initialized
DEBUG - 2015-10-13 17:48:32 --> Router Class Initialized
ERROR - 2015-10-13 17:48:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:49:51 --> Config Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:49:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:49:51 --> URI Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Router Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Output Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Security Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Input Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:49:51 --> Language Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Language Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Config Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Loader Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:49:51 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:49:51 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:49:51 --> Session Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:49:51 --> Session routines successfully run
DEBUG - 2015-10-13 17:49:51 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Email Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Controller Class Initialized
DEBUG - 2015-10-13 17:49:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:49:51 --> Model Class Initialized
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:49:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:49:51 --> Final output sent to browser
DEBUG - 2015-10-13 17:49:51 --> Total execution time: 0.1528
DEBUG - 2015-10-13 17:49:52 --> Config Class Initialized
DEBUG - 2015-10-13 17:49:52 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:49:52 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:49:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:49:52 --> URI Class Initialized
DEBUG - 2015-10-13 17:49:52 --> Router Class Initialized
ERROR - 2015-10-13 17:49:52 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:50:01 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:01 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:01 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:01 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:01 --> Router Class Initialized
ERROR - 2015-10-13 17:50:01 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:50:06 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:06 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Router Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Output Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Security Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Input Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:50:06 --> Language Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Language Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Loader Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:50:06 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:50:06 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:50:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:50:06 --> Session Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:50:06 --> Session routines successfully run
DEBUG - 2015-10-13 17:50:06 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Email Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Controller Class Initialized
DEBUG - 2015-10-13 17:50:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:50:06 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:50:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:50:06 --> Final output sent to browser
DEBUG - 2015-10-13 17:50:06 --> Total execution time: 0.1557
DEBUG - 2015-10-13 17:50:07 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:07 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:07 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:07 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:07 --> Router Class Initialized
ERROR - 2015-10-13 17:50:07 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:50:11 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:11 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:11 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:11 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:11 --> Router Class Initialized
ERROR - 2015-10-13 17:50:11 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:50:14 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:14 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Router Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Output Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Security Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Input Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:50:14 --> Language Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Language Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Loader Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:50:14 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:50:14 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:50:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:50:14 --> Session Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:50:14 --> Session routines successfully run
DEBUG - 2015-10-13 17:50:14 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Email Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Controller Class Initialized
DEBUG - 2015-10-13 17:50:14 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:50:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:50:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:50:14 --> Final output sent to browser
DEBUG - 2015-10-13 17:50:14 --> Total execution time: 0.1396
DEBUG - 2015-10-13 17:50:15 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:15 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:15 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:15 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:15 --> Router Class Initialized
ERROR - 2015-10-13 17:50:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:50:28 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:28 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:28 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:28 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:28 --> Router Class Initialized
ERROR - 2015-10-13 17:50:28 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:50:33 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:33 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Router Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Output Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Security Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Input Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:50:33 --> Language Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Language Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Loader Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:50:33 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:50:33 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:50:33 --> Session Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:50:33 --> Session routines successfully run
DEBUG - 2015-10-13 17:50:33 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Email Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Controller Class Initialized
DEBUG - 2015-10-13 17:50:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:50:33 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:50:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:50:33 --> Final output sent to browser
DEBUG - 2015-10-13 17:50:33 --> Total execution time: 0.1345
DEBUG - 2015-10-13 17:50:34 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:34 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:34 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:34 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:34 --> Router Class Initialized
ERROR - 2015-10-13 17:50:34 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:50:38 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:38 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:38 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:38 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:38 --> Router Class Initialized
ERROR - 2015-10-13 17:50:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:50:46 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:46 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Router Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Output Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Security Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Input Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:50:46 --> Language Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Language Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Loader Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:50:46 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:50:46 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:50:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:50:46 --> Session Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:50:46 --> Session routines successfully run
DEBUG - 2015-10-13 17:50:46 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Email Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Controller Class Initialized
DEBUG - 2015-10-13 17:50:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:50:46 --> Model Class Initialized
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:50:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:50:46 --> Final output sent to browser
DEBUG - 2015-10-13 17:50:46 --> Total execution time: 0.1327
DEBUG - 2015-10-13 17:50:47 --> Config Class Initialized
DEBUG - 2015-10-13 17:50:47 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:50:47 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:50:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:50:47 --> URI Class Initialized
DEBUG - 2015-10-13 17:50:47 --> Router Class Initialized
ERROR - 2015-10-13 17:50:47 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:51:13 --> Config Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:51:13 --> URI Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Router Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Output Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Security Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Input Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:51:13 --> Language Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Language Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Config Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Loader Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:51:13 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:51:13 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:51:13 --> Session Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:51:13 --> Session routines successfully run
DEBUG - 2015-10-13 17:51:13 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Email Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Controller Class Initialized
DEBUG - 2015-10-13 17:51:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:51:13 --> Model Class Initialized
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:51:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:51:13 --> Final output sent to browser
DEBUG - 2015-10-13 17:51:13 --> Total execution time: 0.1754
DEBUG - 2015-10-13 17:51:15 --> Config Class Initialized
DEBUG - 2015-10-13 17:51:15 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:51:15 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:51:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:51:15 --> URI Class Initialized
DEBUG - 2015-10-13 17:51:15 --> Router Class Initialized
ERROR - 2015-10-13 17:51:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:52:48 --> Config Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:52:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:52:48 --> URI Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Router Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Output Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Security Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Input Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:52:48 --> Language Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Language Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Config Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Loader Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:52:48 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:52:48 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:52:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:52:48 --> Session Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:52:48 --> Session routines successfully run
DEBUG - 2015-10-13 17:52:48 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Email Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Controller Class Initialized
DEBUG - 2015-10-13 17:52:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:52:48 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:52:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:52:48 --> Final output sent to browser
DEBUG - 2015-10-13 17:52:48 --> Total execution time: 0.1442
DEBUG - 2015-10-13 17:52:49 --> Config Class Initialized
DEBUG - 2015-10-13 17:52:49 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:52:49 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:52:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:52:49 --> URI Class Initialized
DEBUG - 2015-10-13 17:52:49 --> Router Class Initialized
ERROR - 2015-10-13 17:52:49 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:52:52 --> Config Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:52:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:52:52 --> URI Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Router Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Output Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Security Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Input Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:52:52 --> Language Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Language Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Config Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Loader Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:52:52 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:52:52 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:52:52 --> Session Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:52:52 --> Session routines successfully run
DEBUG - 2015-10-13 17:52:52 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Email Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Controller Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:52:52 --> Config Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:52:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:52:52 --> URI Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Router Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Output Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Security Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Input Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:52:52 --> Language Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Language Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Config Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Loader Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:52:52 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:52:52 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:52:52 --> Session Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:52:52 --> Session routines successfully run
DEBUG - 2015-10-13 17:52:52 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Email Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Controller Class Initialized
DEBUG - 2015-10-13 17:52:52 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:52:52 --> Model Class Initialized
ERROR - 2015-10-13 17:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 534
ERROR - 2015-10-13 17:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 535
ERROR - 2015-10-13 17:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 537
ERROR - 2015-10-13 17:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 538
ERROR - 2015-10-13 17:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 539
ERROR - 2015-10-13 17:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 540
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:52:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:52:52 --> Final output sent to browser
DEBUG - 2015-10-13 17:52:52 --> Total execution time: 0.1412
DEBUG - 2015-10-13 17:52:53 --> Config Class Initialized
DEBUG - 2015-10-13 17:52:53 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:52:53 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:52:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:52:53 --> URI Class Initialized
DEBUG - 2015-10-13 17:52:53 --> Router Class Initialized
ERROR - 2015-10-13 17:52:53 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:53:21 --> Config Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:53:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:53:21 --> URI Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Router Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Output Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Security Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Input Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:53:21 --> Language Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Language Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Config Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Loader Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:53:21 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:53:21 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:53:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:53:21 --> Session Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:53:21 --> Session routines successfully run
DEBUG - 2015-10-13 17:53:21 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Email Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Controller Class Initialized
DEBUG - 2015-10-13 17:53:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:53:21 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:53:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:53:21 --> Final output sent to browser
DEBUG - 2015-10-13 17:53:21 --> Total execution time: 0.1339
DEBUG - 2015-10-13 17:53:22 --> Config Class Initialized
DEBUG - 2015-10-13 17:53:22 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:53:22 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:53:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:53:22 --> URI Class Initialized
DEBUG - 2015-10-13 17:53:22 --> Router Class Initialized
ERROR - 2015-10-13 17:53:22 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:53:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:53:30 --> URI Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Router Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Output Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Security Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Input Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:53:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Loader Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:53:30 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:53:30 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:53:30 --> Session Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:53:30 --> Session routines successfully run
DEBUG - 2015-10-13 17:53:30 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Email Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Controller Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:53:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:53:30 --> URI Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Router Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Output Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Security Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Input Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:53:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Language Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Loader Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:53:30 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:53:30 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:53:30 --> Session Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:53:30 --> Session routines successfully run
DEBUG - 2015-10-13 17:53:30 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Email Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Controller Class Initialized
DEBUG - 2015-10-13 17:53:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:53:30 --> Model Class Initialized
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:53:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:53:30 --> Final output sent to browser
DEBUG - 2015-10-13 17:53:30 --> Total execution time: 0.1366
DEBUG - 2015-10-13 17:53:31 --> Config Class Initialized
DEBUG - 2015-10-13 17:53:31 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:53:31 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:53:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:53:31 --> URI Class Initialized
DEBUG - 2015-10-13 17:53:31 --> Router Class Initialized
ERROR - 2015-10-13 17:53:31 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:54:00 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:54:00 --> URI Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Router Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Output Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Security Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Input Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:54:00 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Loader Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:54:00 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:54:00 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:54:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:54:00 --> Session Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:54:00 --> Session routines successfully run
DEBUG - 2015-10-13 17:54:00 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Email Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Controller Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:54:00 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:54:00 --> URI Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Router Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Output Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Security Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Input Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:54:00 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Loader Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:54:00 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:54:00 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:54:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:54:00 --> Session Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:54:00 --> Session routines successfully run
DEBUG - 2015-10-13 17:54:00 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Email Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Controller Class Initialized
DEBUG - 2015-10-13 17:54:00 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:54:00 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:54:01 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:54:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:54:01 --> Final output sent to browser
DEBUG - 2015-10-13 17:54:01 --> Total execution time: 0.1353
DEBUG - 2015-10-13 17:54:02 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:02 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:54:02 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:54:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:54:02 --> URI Class Initialized
DEBUG - 2015-10-13 17:54:02 --> Router Class Initialized
ERROR - 2015-10-13 17:54:02 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:54:29 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:54:29 --> URI Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Router Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Output Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Security Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Input Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:54:29 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Loader Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:54:29 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:54:29 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:54:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:54:29 --> Session Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:54:29 --> Session routines successfully run
DEBUG - 2015-10-13 17:54:29 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Email Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Controller Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:54:29 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:54:29 --> URI Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Router Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Output Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Security Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Input Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:54:29 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Loader Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:54:29 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:54:29 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:54:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:54:29 --> Session Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:54:29 --> Session routines successfully run
DEBUG - 2015-10-13 17:54:29 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Email Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Controller Class Initialized
DEBUG - 2015-10-13 17:54:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:54:29 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:54:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:54:29 --> Final output sent to browser
DEBUG - 2015-10-13 17:54:29 --> Total execution time: 0.1347
DEBUG - 2015-10-13 17:54:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:30 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:54:30 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:54:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:54:30 --> URI Class Initialized
DEBUG - 2015-10-13 17:54:30 --> Router Class Initialized
ERROR - 2015-10-13 17:54:30 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:54:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:54:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:54:40 --> URI Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Router Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Output Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Security Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Input Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:54:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Loader Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:54:40 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:54:40 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:54:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:54:40 --> Session Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:54:40 --> Session routines successfully run
DEBUG - 2015-10-13 17:54:40 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Email Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Controller Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:54:40 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:54:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:54:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:54:40 --> URI Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Router Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Output Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Security Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Input Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:54:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Language Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Loader Class Initialized
DEBUG - 2015-10-13 17:54:40 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:54:40 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:54:41 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:54:41 --> Session Class Initialized
DEBUG - 2015-10-13 17:54:41 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:54:41 --> Session routines successfully run
DEBUG - 2015-10-13 17:54:41 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:54:41 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:54:41 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:54:41 --> Email Class Initialized
DEBUG - 2015-10-13 17:54:41 --> Controller Class Initialized
DEBUG - 2015-10-13 17:54:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:54:41 --> Model Class Initialized
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:54:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:54:41 --> Final output sent to browser
DEBUG - 2015-10-13 17:54:41 --> Total execution time: 0.1429
DEBUG - 2015-10-13 17:54:42 --> Config Class Initialized
DEBUG - 2015-10-13 17:54:42 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:54:42 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:54:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:54:42 --> URI Class Initialized
DEBUG - 2015-10-13 17:54:42 --> Router Class Initialized
ERROR - 2015-10-13 17:54:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:55:30 --> Config Class Initialized
DEBUG - 2015-10-13 17:55:30 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:55:30 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:55:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:55:30 --> URI Class Initialized
DEBUG - 2015-10-13 17:55:30 --> Router Class Initialized
ERROR - 2015-10-13 17:55:30 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:55:44 --> Config Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:55:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:55:44 --> URI Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Router Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Output Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Security Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Input Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:55:44 --> Language Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Language Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Config Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Loader Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:55:44 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:55:44 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:55:44 --> Session Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:55:44 --> Session routines successfully run
DEBUG - 2015-10-13 17:55:44 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Email Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Controller Class Initialized
DEBUG - 2015-10-13 17:55:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:55:44 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/microfinance/views/payments/list_individual.php
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:55:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:55:44 --> Final output sent to browser
DEBUG - 2015-10-13 17:55:44 --> Total execution time: 0.1278
DEBUG - 2015-10-13 17:55:45 --> Config Class Initialized
DEBUG - 2015-10-13 17:55:45 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:55:45 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:55:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:55:45 --> URI Class Initialized
DEBUG - 2015-10-13 17:55:45 --> Router Class Initialized
ERROR - 2015-10-13 17:55:45 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:55:50 --> Config Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:55:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:55:50 --> URI Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Router Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Output Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Security Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Input Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:55:50 --> Language Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Language Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Config Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Loader Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:55:50 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:55:50 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:55:50 --> Session Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:55:50 --> Session routines successfully run
DEBUG - 2015-10-13 17:55:50 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Email Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Controller Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:55:50 --> Model Class Initialized
DEBUG - 2015-10-13 17:55:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/microfinance/views/payments/show_individual_payment.php
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:55:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:55:50 --> Final output sent to browser
DEBUG - 2015-10-13 17:55:50 --> Total execution time: 0.1423
DEBUG - 2015-10-13 17:55:51 --> Config Class Initialized
DEBUG - 2015-10-13 17:55:51 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:55:51 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:55:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:55:51 --> URI Class Initialized
DEBUG - 2015-10-13 17:55:51 --> Router Class Initialized
ERROR - 2015-10-13 17:55:51 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:56:04 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:56:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:56:04 --> URI Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Router Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Output Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Security Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Input Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:56:04 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Loader Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:56:04 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:56:04 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:56:04 --> Session Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:56:04 --> Session routines successfully run
DEBUG - 2015-10-13 17:56:04 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Email Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Controller Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:56:04 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:56:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:56:04 --> Final output sent to browser
DEBUG - 2015-10-13 17:56:04 --> Total execution time: 0.1447
DEBUG - 2015-10-13 17:56:04 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:56:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:56:04 --> URI Class Initialized
DEBUG - 2015-10-13 17:56:04 --> Router Class Initialized
ERROR - 2015-10-13 17:56:04 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:56:09 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:56:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:56:09 --> URI Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Router Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Output Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Security Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Input Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:56:09 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Loader Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:56:09 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:56:09 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:56:09 --> Session Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:56:09 --> Session routines successfully run
DEBUG - 2015-10-13 17:56:09 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Email Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Controller Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:56:09 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:56:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:56:09 --> URI Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Router Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Output Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Security Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Input Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:56:09 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Loader Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:56:09 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:56:09 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:56:09 --> Session Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:56:09 --> Session routines successfully run
DEBUG - 2015-10-13 17:56:09 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Email Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Controller Class Initialized
DEBUG - 2015-10-13 17:56:09 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:56:09 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:56:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:56:09 --> Final output sent to browser
DEBUG - 2015-10-13 17:56:09 --> Total execution time: 0.1410
DEBUG - 2015-10-13 17:56:10 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:10 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:56:10 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:56:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:56:10 --> URI Class Initialized
DEBUG - 2015-10-13 17:56:10 --> Router Class Initialized
ERROR - 2015-10-13 17:56:10 --> 404 Page Not Found --> 
DEBUG - 2015-10-13 17:56:14 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:56:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:56:14 --> URI Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Router Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Output Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Security Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Input Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:56:14 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Loader Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:56:14 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:56:14 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:56:14 --> Session Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:56:14 --> Session routines successfully run
DEBUG - 2015-10-13 17:56:14 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Email Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Controller Class Initialized
DEBUG - 2015-10-13 17:56:14 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:56:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:56:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:56:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:56:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:56:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:56:14 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-13 17:56:15 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:56:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:56:15 --> URI Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Router Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Output Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Security Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Input Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-13 17:56:15 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Language Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Loader Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Helper loaded: url_helper
DEBUG - 2015-10-13 17:56:15 --> Helper loaded: form_helper
DEBUG - 2015-10-13 17:56:15 --> Database Driver Class Initialized
ERROR - 2015-10-13 17:56:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-13 17:56:15 --> Session Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Helper loaded: string_helper
DEBUG - 2015-10-13 17:56:15 --> Session routines successfully run
DEBUG - 2015-10-13 17:56:15 --> Form Validation Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Pagination Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Encrypt Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Email Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Controller Class Initialized
DEBUG - 2015-10-13 17:56:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-13 17:56:15 --> Model Class Initialized
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/microfinance/views/payments/edit_single_individual_payment.php
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-13 17:56:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-13 17:56:15 --> Final output sent to browser
DEBUG - 2015-10-13 17:56:15 --> Total execution time: 0.1435
DEBUG - 2015-10-13 17:56:16 --> Config Class Initialized
DEBUG - 2015-10-13 17:56:16 --> Hooks Class Initialized
DEBUG - 2015-10-13 17:56:16 --> Utf8 Class Initialized
DEBUG - 2015-10-13 17:56:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-13 17:56:16 --> URI Class Initialized
DEBUG - 2015-10-13 17:56:16 --> Router Class Initialized
ERROR - 2015-10-13 17:56:16 --> 404 Page Not Found --> 
