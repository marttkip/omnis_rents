<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-03-14 18:13:11 --> Config Class Initialized
DEBUG - 2016-03-14 18:13:11 --> Hooks Class Initialized
DEBUG - 2016-03-14 18:13:11 --> Utf8 Class Initialized
DEBUG - 2016-03-14 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 18:13:11 --> URI Class Initialized
DEBUG - 2016-03-14 18:13:11 --> Router Class Initialized
DEBUG - 2016-03-14 18:13:12 --> No URI present. Default controller set.
DEBUG - 2016-03-14 18:13:12 --> Output Class Initialized
DEBUG - 2016-03-14 18:13:12 --> Security Class Initialized
DEBUG - 2016-03-14 18:13:12 --> Input Class Initialized
DEBUG - 2016-03-14 18:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 18:13:12 --> Language Class Initialized
DEBUG - 2016-03-14 18:13:13 --> Language Class Initialized
DEBUG - 2016-03-14 18:13:13 --> Config Class Initialized
DEBUG - 2016-03-14 18:13:13 --> Loader Class Initialized
DEBUG - 2016-03-14 18:13:13 --> Helper loaded: url_helper
DEBUG - 2016-03-14 18:13:13 --> Helper loaded: form_helper
DEBUG - 2016-03-14 18:13:13 --> Database Driver Class Initialized
DEBUG - 2016-03-14 18:13:15 --> Session Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Helper loaded: string_helper
ERROR - 2016-03-14 18:13:16 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-03-14 18:13:16 --> Session routines successfully run
DEBUG - 2016-03-14 18:13:16 --> Form Validation Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Pagination Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Encrypt Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Email Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Controller Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Auth MX_Controller Initialized
DEBUG - 2016-03-14 18:13:16 --> Model Class Initialized
DEBUG - 2016-03-14 18:13:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-03-14 18:13:16 --> Model Class Initialized
DEBUG - 2016-03-14 18:13:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-03-14 18:13:16 --> Model Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Config Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Hooks Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Utf8 Class Initialized
DEBUG - 2016-03-14 18:13:16 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 18:13:16 --> URI Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Router Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Output Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Security Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Input Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 18:13:16 --> Language Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Language Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Config Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Loader Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Helper loaded: url_helper
DEBUG - 2016-03-14 18:13:16 --> Helper loaded: form_helper
DEBUG - 2016-03-14 18:13:16 --> Database Driver Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Session Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Helper loaded: string_helper
DEBUG - 2016-03-14 18:13:16 --> Session routines successfully run
DEBUG - 2016-03-14 18:13:16 --> Form Validation Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Pagination Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Encrypt Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Email Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Controller Class Initialized
DEBUG - 2016-03-14 18:13:16 --> Auth MX_Controller Initialized
DEBUG - 2016-03-14 18:13:16 --> Model Class Initialized
DEBUG - 2016-03-14 18:13:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-03-14 18:13:16 --> Model Class Initialized
DEBUG - 2016-03-14 18:13:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-03-14 18:13:16 --> Model Class Initialized
DEBUG - 2016-03-14 18:13:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-03-14 18:13:19 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-03-14 18:13:19 --> Final output sent to browser
DEBUG - 2016-03-14 18:13:19 --> Total execution time: 2.4551
DEBUG - 2016-03-14 18:13:34 --> Config Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Hooks Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Utf8 Class Initialized
DEBUG - 2016-03-14 18:13:34 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 18:13:34 --> URI Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Config Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Hooks Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Utf8 Class Initialized
DEBUG - 2016-03-14 18:13:34 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 18:13:34 --> URI Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Router Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Router Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Config Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Hooks Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Utf8 Class Initialized
DEBUG - 2016-03-14 18:13:34 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 18:13:34 --> URI Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Router Class Initialized
ERROR - 2016-03-14 18:13:34 --> 404 Page Not Found --> 
DEBUG - 2016-03-14 18:13:34 --> Config Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Hooks Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Utf8 Class Initialized
DEBUG - 2016-03-14 18:13:34 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 18:13:34 --> URI Class Initialized
DEBUG - 2016-03-14 18:13:34 --> Router Class Initialized
ERROR - 2016-03-14 18:13:34 --> 404 Page Not Found --> 
ERROR - 2016-03-14 18:13:34 --> 404 Page Not Found --> 
ERROR - 2016-03-14 18:13:34 --> 404 Page Not Found --> 
DEBUG - 2016-03-14 18:25:19 --> Config Class Initialized
DEBUG - 2016-03-14 18:25:19 --> Hooks Class Initialized
DEBUG - 2016-03-14 18:25:19 --> Utf8 Class Initialized
DEBUG - 2016-03-14 18:25:19 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 18:25:19 --> URI Class Initialized
DEBUG - 2016-03-14 18:25:19 --> Router Class Initialized
DEBUG - 2016-03-14 18:25:20 --> Output Class Initialized
DEBUG - 2016-03-14 18:25:20 --> Security Class Initialized
DEBUG - 2016-03-14 18:25:20 --> Input Class Initialized
DEBUG - 2016-03-14 18:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 18:25:20 --> Language Class Initialized
DEBUG - 2016-03-14 18:25:20 --> Language Class Initialized
DEBUG - 2016-03-14 18:25:20 --> Config Class Initialized
DEBUG - 2016-03-14 18:25:20 --> Loader Class Initialized
DEBUG - 2016-03-14 18:25:20 --> Helper loaded: url_helper
DEBUG - 2016-03-14 18:25:20 --> Helper loaded: form_helper
DEBUG - 2016-03-14 18:25:20 --> Database Driver Class Initialized
DEBUG - 2016-03-14 18:25:21 --> Session Class Initialized
DEBUG - 2016-03-14 18:25:21 --> Helper loaded: string_helper
DEBUG - 2016-03-14 18:25:21 --> Session routines successfully run
DEBUG - 2016-03-14 18:25:21 --> Form Validation Class Initialized
DEBUG - 2016-03-14 18:25:21 --> Pagination Class Initialized
DEBUG - 2016-03-14 18:25:21 --> Encrypt Class Initialized
DEBUG - 2016-03-14 18:25:21 --> Email Class Initialized
DEBUG - 2016-03-14 18:25:21 --> Controller Class Initialized
DEBUG - 2016-03-14 18:25:21 --> Auth MX_Controller Initialized
DEBUG - 2016-03-14 18:25:21 --> Model Class Initialized
DEBUG - 2016-03-14 18:25:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-03-14 18:25:21 --> Model Class Initialized
DEBUG - 2016-03-14 18:25:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-03-14 18:25:22 --> Model Class Initialized
DEBUG - 2016-03-14 18:25:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-14 18:25:22 --> XSS Filtering completed
DEBUG - 2016-03-14 18:25:22 --> Unable to find validation rule: exists
DEBUG - 2016-03-14 18:25:22 --> XSS Filtering completed
DEBUG - 2016-03-14 20:01:11 --> Config Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Hooks Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Utf8 Class Initialized
DEBUG - 2016-03-14 20:01:11 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 20:01:11 --> URI Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Router Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Output Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Security Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Input Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 20:01:11 --> Language Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Language Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Config Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Loader Class Initialized
DEBUG - 2016-03-14 20:01:11 --> Helper loaded: url_helper
DEBUG - 2016-03-14 20:01:12 --> Helper loaded: form_helper
DEBUG - 2016-03-14 20:01:12 --> Database Driver Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Session Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Helper loaded: string_helper
DEBUG - 2016-03-14 20:01:12 --> Session routines successfully run
DEBUG - 2016-03-14 20:01:12 --> Form Validation Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Pagination Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Encrypt Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Email Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Controller Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Auth MX_Controller Initialized
DEBUG - 2016-03-14 20:01:12 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-03-14 20:01:12 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-03-14 20:01:12 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-14 20:01:12 --> XSS Filtering completed
DEBUG - 2016-03-14 20:01:12 --> Unable to find validation rule: exists
DEBUG - 2016-03-14 20:01:12 --> XSS Filtering completed
DEBUG - 2016-03-14 20:01:12 --> Config Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Hooks Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Utf8 Class Initialized
DEBUG - 2016-03-14 20:01:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 20:01:12 --> URI Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Router Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Output Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Security Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Input Class Initialized
DEBUG - 2016-03-14 20:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 20:01:12 --> Language Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Language Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Config Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Loader Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Helper loaded: url_helper
DEBUG - 2016-03-14 20:01:13 --> Helper loaded: form_helper
DEBUG - 2016-03-14 20:01:13 --> Database Driver Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Session Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Helper loaded: string_helper
DEBUG - 2016-03-14 20:01:13 --> Session routines successfully run
DEBUG - 2016-03-14 20:01:13 --> Form Validation Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Pagination Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Encrypt Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Email Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Controller Class Initialized
DEBUG - 2016-03-14 20:01:13 --> Admin MX_Controller Initialized
DEBUG - 2016-03-14 20:01:13 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-03-14 20:01:13 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-03-14 20:01:13 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-03-14 20:01:13 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-03-14 20:01:13 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-03-14 20:01:13 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-03-14 20:01:13 --> Model Class Initialized
DEBUG - 2016-03-14 20:01:14 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-03-14 20:01:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-03-14 20:01:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-03-14 20:01:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-03-14 20:01:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-03-14 20:01:14 --> Final output sent to browser
DEBUG - 2016-03-14 20:01:14 --> Total execution time: 1.9663
