<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-01 17:07:26 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Hooks Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Utf8 Class Initialized
DEBUG - 2015-10-01 17:07:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 17:07:26 --> URI Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Router Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Output Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Security Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Input Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 17:07:26 --> Language Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Language Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Loader Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Helper loaded: url_helper
DEBUG - 2015-10-01 17:07:26 --> Helper loaded: form_helper
DEBUG - 2015-10-01 17:07:26 --> Database Driver Class Initialized
ERROR - 2015-10-01 17:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-01 17:07:26 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 17:07:26 --> Session Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Helper loaded: string_helper
DEBUG - 2015-10-01 17:07:26 --> A session cookie was not found.
DEBUG - 2015-10-01 17:07:26 --> Session routines successfully run
DEBUG - 2015-10-01 17:07:26 --> Form Validation Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Pagination Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Encrypt Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Email Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Controller Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Hooks Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Utf8 Class Initialized
DEBUG - 2015-10-01 17:07:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 17:07:26 --> URI Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Router Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Output Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Security Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Input Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 17:07:26 --> Language Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Language Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Loader Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Helper loaded: url_helper
DEBUG - 2015-10-01 17:07:26 --> Helper loaded: form_helper
DEBUG - 2015-10-01 17:07:26 --> Database Driver Class Initialized
ERROR - 2015-10-01 17:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 17:07:26 --> Session Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Helper loaded: string_helper
DEBUG - 2015-10-01 17:07:26 --> Session routines successfully run
DEBUG - 2015-10-01 17:07:26 --> Form Validation Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Pagination Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Encrypt Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Email Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Controller Class Initialized
DEBUG - 2015-10-01 17:07:26 --> Auth MX_Controller Initialized
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 17:07:26 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-01 17:07:26 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-10-01 17:07:26 --> Final output sent to browser
DEBUG - 2015-10-01 17:07:26 --> Total execution time: 0.0943
DEBUG - 2015-10-01 17:07:27 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Hooks Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Utf8 Class Initialized
DEBUG - 2015-10-01 17:07:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 17:07:27 --> Hooks Class Initialized
DEBUG - 2015-10-01 17:07:27 --> URI Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Utf8 Class Initialized
DEBUG - 2015-10-01 17:07:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 17:07:27 --> URI Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Router Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Router Class Initialized
ERROR - 2015-10-01 17:07:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-01 17:07:27 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Hooks Class Initialized
ERROR - 2015-10-01 17:07:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-01 17:07:27 --> Utf8 Class Initialized
DEBUG - 2015-10-01 17:07:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 17:07:27 --> URI Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Router Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Hooks Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Utf8 Class Initialized
DEBUG - 2015-10-01 17:07:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 17:07:27 --> URI Class Initialized
DEBUG - 2015-10-01 17:07:27 --> Router Class Initialized
ERROR - 2015-10-01 17:07:27 --> 404 Page Not Found --> 
ERROR - 2015-10-01 17:07:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-01 17:07:56 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Hooks Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Utf8 Class Initialized
DEBUG - 2015-10-01 17:07:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 17:07:56 --> URI Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Router Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Output Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Security Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Input Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 17:07:56 --> Language Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Language Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Loader Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Helper loaded: url_helper
DEBUG - 2015-10-01 17:07:56 --> Helper loaded: form_helper
DEBUG - 2015-10-01 17:07:56 --> Database Driver Class Initialized
ERROR - 2015-10-01 17:07:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 17:07:56 --> Session Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Helper loaded: string_helper
DEBUG - 2015-10-01 17:07:56 --> Session routines successfully run
DEBUG - 2015-10-01 17:07:56 --> Form Validation Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Pagination Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Encrypt Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Email Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Controller Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Auth MX_Controller Initialized
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-01 17:07:56 --> XSS Filtering completed
DEBUG - 2015-10-01 17:07:56 --> Unable to find validation rule: exists
DEBUG - 2015-10-01 17:07:56 --> XSS Filtering completed
DEBUG - 2015-10-01 17:07:56 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Hooks Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Utf8 Class Initialized
DEBUG - 2015-10-01 17:07:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 17:07:56 --> URI Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Router Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Output Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Security Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Input Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 17:07:56 --> Language Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Language Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Config Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Loader Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Helper loaded: url_helper
DEBUG - 2015-10-01 17:07:56 --> Helper loaded: form_helper
DEBUG - 2015-10-01 17:07:56 --> Database Driver Class Initialized
ERROR - 2015-10-01 17:07:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 17:07:56 --> Session Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Helper loaded: string_helper
DEBUG - 2015-10-01 17:07:56 --> Session routines successfully run
DEBUG - 2015-10-01 17:07:56 --> Form Validation Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Pagination Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Encrypt Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Email Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Controller Class Initialized
DEBUG - 2015-10-01 17:07:56 --> Admin MX_Controller Initialized
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-01 17:07:56 --> Model Class Initialized
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-01 17:07:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-01 17:07:56 --> Final output sent to browser
DEBUG - 2015-10-01 17:07:56 --> Total execution time: 0.1368
DEBUG - 2015-10-01 17:08:03 --> Config Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Hooks Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Utf8 Class Initialized
DEBUG - 2015-10-01 17:08:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 17:08:03 --> URI Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Router Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Output Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Security Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Input Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 17:08:03 --> Language Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Language Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Config Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Loader Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Helper loaded: url_helper
DEBUG - 2015-10-01 17:08:03 --> Helper loaded: form_helper
DEBUG - 2015-10-01 17:08:03 --> Database Driver Class Initialized
ERROR - 2015-10-01 17:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-01 17:08:03 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 17:08:03 --> Session Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Helper loaded: string_helper
DEBUG - 2015-10-01 17:08:03 --> Session routines successfully run
DEBUG - 2015-10-01 17:08:03 --> Form Validation Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Pagination Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Encrypt Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Email Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Controller Class Initialized
DEBUG - 2015-10-01 17:08:03 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-01 17:08:03 --> Model Class Initialized
DEBUG - 2015-10-01 17:08:03 --> DB Transaction Failure
ERROR - 2015-10-01 17:08:03 --> Query error: Table 'mfi.loans_plan' doesn't exist
DEBUG - 2015-10-01 17:08:03 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-01 18:45:30 --> Config Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:45:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:45:30 --> URI Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Router Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Output Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Security Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Input Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:45:30 --> Language Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Language Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Config Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Loader Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:45:30 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:45:30 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:45:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:45:30 --> Session Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:45:30 --> Session routines successfully run
DEBUG - 2015-10-01 18:45:30 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Email Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Controller Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Auth MX_Controller Initialized
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-01 18:45:30 --> XSS Filtering completed
DEBUG - 2015-10-01 18:45:30 --> Unable to find validation rule: exists
DEBUG - 2015-10-01 18:45:30 --> XSS Filtering completed
DEBUG - 2015-10-01 18:45:30 --> Config Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:45:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:45:30 --> URI Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Router Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Output Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Security Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Input Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:45:30 --> Language Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Language Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Config Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Loader Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:45:30 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:45:30 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:45:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:45:30 --> Session Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:45:30 --> Session routines successfully run
DEBUG - 2015-10-01 18:45:30 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Email Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Controller Class Initialized
DEBUG - 2015-10-01 18:45:30 --> Admin MX_Controller Initialized
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-01 18:45:30 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-01 18:45:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-01 18:45:30 --> Final output sent to browser
DEBUG - 2015-10-01 18:45:30 --> Total execution time: 0.1410
DEBUG - 2015-10-01 18:45:39 --> Config Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:45:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:45:39 --> URI Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Router Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Output Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Security Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Input Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:45:39 --> Language Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Language Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Config Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Loader Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:45:39 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:45:39 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:45:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:45:39 --> Session Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:45:39 --> Session routines successfully run
DEBUG - 2015-10-01 18:45:39 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Email Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Controller Class Initialized
DEBUG - 2015-10-01 18:45:39 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-01 18:45:39 --> Model Class Initialized
DEBUG - 2015-10-01 18:45:39 --> DB Transaction Failure
ERROR - 2015-10-01 18:45:39 --> Query error: Table 'mfi.loans_plan' doesn't exist
DEBUG - 2015-10-01 18:45:39 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-01 18:46:31 --> Config Class Initialized
DEBUG - 2015-10-01 18:46:31 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:46:31 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:46:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:46:31 --> URI Class Initialized
DEBUG - 2015-10-01 18:46:31 --> Router Class Initialized
DEBUG - 2015-10-01 18:46:31 --> Output Class Initialized
DEBUG - 2015-10-01 18:46:31 --> Security Class Initialized
DEBUG - 2015-10-01 18:46:31 --> Input Class Initialized
DEBUG - 2015-10-01 18:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:46:31 --> Language Class Initialized
DEBUG - 2015-10-01 18:46:31 --> Language Class Initialized
DEBUG - 2015-10-01 18:46:31 --> Config Class Initialized
DEBUG - 2015-10-01 18:46:32 --> Loader Class Initialized
DEBUG - 2015-10-01 18:46:32 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:46:32 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:46:32 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:46:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:46:32 --> Session Class Initialized
DEBUG - 2015-10-01 18:46:32 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:46:32 --> Session routines successfully run
DEBUG - 2015-10-01 18:46:32 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:46:32 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:46:32 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:46:32 --> Email Class Initialized
DEBUG - 2015-10-01 18:46:32 --> Controller Class Initialized
DEBUG - 2015-10-01 18:46:32 --> Admin MX_Controller Initialized
DEBUG - 2015-10-01 18:46:32 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-01 18:46:32 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:46:32 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:46:32 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-01 18:46:32 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-01 18:46:32 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-01 18:46:32 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-01 18:46:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-01 18:46:32 --> Final output sent to browser
DEBUG - 2015-10-01 18:46:32 --> Total execution time: 0.1312
DEBUG - 2015-10-01 18:46:40 --> Config Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:46:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:46:40 --> URI Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Router Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Output Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Security Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Input Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:46:40 --> Language Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Language Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Config Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Loader Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:46:40 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:46:40 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:46:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-01 18:46:40 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:46:40 --> Session Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:46:40 --> Session routines successfully run
DEBUG - 2015-10-01 18:46:40 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Email Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Controller Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Auth MX_Controller Initialized
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-01 18:46:40 --> XSS Filtering completed
DEBUG - 2015-10-01 18:46:40 --> Unable to find validation rule: exists
DEBUG - 2015-10-01 18:46:40 --> XSS Filtering completed
DEBUG - 2015-10-01 18:46:40 --> Config Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:46:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:46:40 --> URI Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Router Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Output Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Security Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Input Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:46:40 --> Language Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Language Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Config Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Loader Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:46:40 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:46:40 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:46:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:46:40 --> Session Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:46:40 --> Session routines successfully run
DEBUG - 2015-10-01 18:46:40 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Email Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Controller Class Initialized
DEBUG - 2015-10-01 18:46:40 --> Admin MX_Controller Initialized
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-01 18:46:40 --> Model Class Initialized
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-01 18:46:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-01 18:46:40 --> Final output sent to browser
DEBUG - 2015-10-01 18:46:40 --> Total execution time: 0.1184
DEBUG - 2015-10-01 18:47:45 --> Config Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:47:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:47:45 --> URI Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Router Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Output Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Security Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Input Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:47:45 --> Language Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Language Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Config Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Loader Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:47:45 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:47:45 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:47:45 --> Session Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:47:45 --> Session routines successfully run
DEBUG - 2015-10-01 18:47:45 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Email Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Controller Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Auth MX_Controller Initialized
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-01 18:47:45 --> XSS Filtering completed
DEBUG - 2015-10-01 18:47:45 --> Unable to find validation rule: exists
DEBUG - 2015-10-01 18:47:45 --> XSS Filtering completed
DEBUG - 2015-10-01 18:47:45 --> Config Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:47:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:47:45 --> URI Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Router Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Output Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Security Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Input Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:47:45 --> Language Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Language Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Config Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Loader Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:47:45 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:47:45 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:47:45 --> Session Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:47:45 --> Session routines successfully run
DEBUG - 2015-10-01 18:47:45 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Email Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Controller Class Initialized
DEBUG - 2015-10-01 18:47:45 --> Admin MX_Controller Initialized
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-01 18:47:45 --> Model Class Initialized
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-01 18:47:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-01 18:47:45 --> Final output sent to browser
DEBUG - 2015-10-01 18:47:45 --> Total execution time: 0.1170
DEBUG - 2015-10-01 18:57:08 --> Config Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:57:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:57:08 --> URI Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Router Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Output Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Security Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Input Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:57:08 --> Language Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Language Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Config Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Loader Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:57:08 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:57:08 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:57:08 --> Session Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:57:08 --> Session routines successfully run
DEBUG - 2015-10-01 18:57:08 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Email Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Controller Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Auth MX_Controller Initialized
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-01 18:57:08 --> XSS Filtering completed
DEBUG - 2015-10-01 18:57:08 --> Unable to find validation rule: exists
DEBUG - 2015-10-01 18:57:08 --> XSS Filtering completed
DEBUG - 2015-10-01 18:57:08 --> Config Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:57:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:57:08 --> URI Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Router Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Output Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Security Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Input Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-01 18:57:08 --> Language Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Language Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Config Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Loader Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Helper loaded: url_helper
DEBUG - 2015-10-01 18:57:08 --> Helper loaded: form_helper
DEBUG - 2015-10-01 18:57:08 --> Database Driver Class Initialized
ERROR - 2015-10-01 18:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-01 18:57:08 --> Session Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Helper loaded: string_helper
DEBUG - 2015-10-01 18:57:08 --> Session routines successfully run
DEBUG - 2015-10-01 18:57:08 --> Form Validation Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Pagination Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Encrypt Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Email Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Controller Class Initialized
DEBUG - 2015-10-01 18:57:08 --> Admin MX_Controller Initialized
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-01 18:57:08 --> Model Class Initialized
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-01 18:57:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-01 18:57:08 --> Final output sent to browser
DEBUG - 2015-10-01 18:57:08 --> Total execution time: 0.1245
DEBUG - 2015-10-01 18:57:20 --> Config Class Initialized
DEBUG - 2015-10-01 18:57:20 --> Hooks Class Initialized
DEBUG - 2015-10-01 18:57:20 --> Utf8 Class Initialized
DEBUG - 2015-10-01 18:57:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 18:57:20 --> URI Class Initialized
DEBUG - 2015-10-01 18:57:20 --> Router Class Initialized
ERROR - 2015-10-01 18:57:20 --> 404 Page Not Found --> 
DEBUG - 2015-10-01 19:01:18 --> Config Class Initialized
DEBUG - 2015-10-01 19:01:18 --> Hooks Class Initialized
DEBUG - 2015-10-01 19:01:18 --> Utf8 Class Initialized
DEBUG - 2015-10-01 19:01:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 19:01:18 --> URI Class Initialized
DEBUG - 2015-10-01 19:01:18 --> Router Class Initialized
ERROR - 2015-10-01 19:01:18 --> 404 Page Not Found --> 
DEBUG - 2015-10-01 19:02:38 --> Config Class Initialized
DEBUG - 2015-10-01 19:02:38 --> Hooks Class Initialized
DEBUG - 2015-10-01 19:02:38 --> Utf8 Class Initialized
DEBUG - 2015-10-01 19:02:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-01 19:02:38 --> URI Class Initialized
DEBUG - 2015-10-01 19:02:38 --> Router Class Initialized
ERROR - 2015-10-01 19:02:38 --> 404 Page Not Found --> 
