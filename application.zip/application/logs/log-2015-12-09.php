<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-09 12:08:16 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:16 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:08:16 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:08:16 --> URI Class Initialized
DEBUG - 2015-12-09 12:08:16 --> Router Class Initialized
DEBUG - 2015-12-09 12:08:16 --> No URI present. Default controller set.
DEBUG - 2015-12-09 12:08:16 --> Output Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Security Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Input Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:08:17 --> Language Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Language Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Loader Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:08:17 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:08:17 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Session Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:08:17 --> Session routines successfully run
DEBUG - 2015-12-09 12:08:17 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Email Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Controller Class Initialized
DEBUG - 2015-12-09 12:08:17 --> Auth MX_Controller Initialized
DEBUG - 2015-12-09 12:08:17 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:08:18 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:08:18 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:08:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:08:18 --> URI Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Router Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Output Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Security Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Input Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:08:18 --> Language Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Language Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Loader Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:08:18 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:08:18 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Session Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:08:18 --> Session routines successfully run
DEBUG - 2015-12-09 12:08:18 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Email Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Controller Class Initialized
DEBUG - 2015-12-09 12:08:18 --> Auth MX_Controller Initialized
DEBUG - 2015-12-09 12:08:18 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:08:18 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:08:18 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:08:18 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-09 12:08:18 --> Final output sent to browser
DEBUG - 2015-12-09 12:08:18 --> Total execution time: 0.4272
DEBUG - 2015-12-09 12:08:20 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:08:20 --> URI Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:08:20 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:08:20 --> URI Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Router Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:08:20 --> URI Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Router Class Initialized
DEBUG - 2015-12-09 12:08:20 --> URI Class Initialized
DEBUG - 2015-12-09 12:08:20 --> Router Class Initialized
ERROR - 2015-12-09 12:08:20 --> 404 Page Not Found --> 
ERROR - 2015-12-09 12:08:20 --> 404 Page Not Found --> 
DEBUG - 2015-12-09 12:08:20 --> Router Class Initialized
ERROR - 2015-12-09 12:08:20 --> 404 Page Not Found --> 
ERROR - 2015-12-09 12:08:20 --> 404 Page Not Found --> 
DEBUG - 2015-12-09 12:08:22 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:08:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:08:22 --> URI Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Router Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Output Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Security Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Input Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:08:22 --> Language Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Language Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Loader Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:08:22 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:08:22 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Session Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:08:22 --> Session routines successfully run
DEBUG - 2015-12-09 12:08:22 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Email Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Controller Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Auth MX_Controller Initialized
DEBUG - 2015-12-09 12:08:22 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:08:22 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:08:22 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 12:08:22 --> XSS Filtering completed
DEBUG - 2015-12-09 12:08:22 --> Unable to find validation rule: exists
DEBUG - 2015-12-09 12:08:22 --> XSS Filtering completed
DEBUG - 2015-12-09 12:08:22 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:08:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:08:22 --> URI Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Router Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Output Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Security Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Input Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:08:22 --> Language Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Language Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Loader Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:08:22 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:08:22 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Session Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:08:22 --> Session routines successfully run
DEBUG - 2015-12-09 12:08:22 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Email Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Controller Class Initialized
DEBUG - 2015-12-09 12:08:22 --> Admin MX_Controller Initialized
DEBUG - 2015-12-09 12:08:22 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:08:22 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:08:22 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:08:22 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:08:22 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:08:22 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:08:23 --> Model Class Initialized
DEBUG - 2015-12-09 12:08:23 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-09 12:08:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:08:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:08:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:08:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:08:23 --> Final output sent to browser
DEBUG - 2015-12-09 12:08:23 --> Total execution time: 0.6266
DEBUG - 2015-12-09 12:08:28 --> Config Class Initialized
DEBUG - 2015-12-09 12:08:28 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:08:28 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:08:28 --> URI Class Initialized
DEBUG - 2015-12-09 12:08:28 --> Router Class Initialized
ERROR - 2015-12-09 12:08:28 --> 404 Page Not Found --> 
DEBUG - 2015-12-09 12:09:20 --> Config Class Initialized
DEBUG - 2015-12-09 12:09:20 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:09:20 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:09:20 --> URI Class Initialized
DEBUG - 2015-12-09 12:09:20 --> Router Class Initialized
ERROR - 2015-12-09 12:09:20 --> 404 Page Not Found --> 
DEBUG - 2015-12-09 12:09:55 --> Config Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:09:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:09:55 --> URI Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Router Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Output Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Security Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Input Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:09:55 --> Language Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Language Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Config Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Loader Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:09:55 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:09:55 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Session Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:09:55 --> Session routines successfully run
DEBUG - 2015-12-09 12:09:55 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Email Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Controller Class Initialized
DEBUG - 2015-12-09 12:09:55 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:09:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:09:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:09:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:09:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:09:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:09:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:09:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:09:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:09:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:09:55 --> Final output sent to browser
DEBUG - 2015-12-09 12:09:55 --> Total execution time: 0.3760
DEBUG - 2015-12-09 12:10:00 --> Config Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:10:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:10:00 --> URI Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Router Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Output Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Security Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Input Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:10:00 --> Language Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Language Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Config Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Loader Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:10:00 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:10:00 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Session Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:10:00 --> Session routines successfully run
DEBUG - 2015-12-09 12:10:00 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Email Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Controller Class Initialized
DEBUG - 2015-12-09 12:10:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:10:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:10:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:10:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:10:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:10:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:10:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:10:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:10:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:10:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:10:00 --> Final output sent to browser
DEBUG - 2015-12-09 12:10:00 --> Total execution time: 0.2237
DEBUG - 2015-12-09 12:10:30 --> Config Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:10:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:10:30 --> URI Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Router Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Output Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Security Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Input Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:10:30 --> Language Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Language Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Config Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Loader Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:10:30 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:10:30 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Session Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:10:30 --> Session routines successfully run
DEBUG - 2015-12-09 12:10:30 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Email Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Controller Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:10:30 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:10:30 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:10:30 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:10:30 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:10:30 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:10:30 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:10:30 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:10:30 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 12:10:30 --> XSS Filtering completed
DEBUG - 2015-12-09 12:10:30 --> XSS Filtering completed
DEBUG - 2015-12-09 12:10:30 --> XSS Filtering completed
DEBUG - 2015-12-09 12:10:30 --> XSS Filtering completed
DEBUG - 2015-12-09 12:10:30 --> XSS Filtering completed
DEBUG - 2015-12-09 12:10:30 --> Config Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:10:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:10:30 --> URI Class Initialized
DEBUG - 2015-12-09 12:10:30 --> Router Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Output Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Security Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Input Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:10:31 --> Language Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Language Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Config Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Loader Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:10:31 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:10:31 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Session Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:10:31 --> Session routines successfully run
DEBUG - 2015-12-09 12:10:31 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Email Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Controller Class Initialized
DEBUG - 2015-12-09 12:10:31 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:10:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:10:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:10:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:10:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:10:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:10:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:10:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:10:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:10:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:10:31 --> Final output sent to browser
DEBUG - 2015-12-09 12:10:31 --> Total execution time: 0.2458
DEBUG - 2015-12-09 12:10:43 --> Config Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:10:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:10:43 --> URI Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Router Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Output Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Security Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Input Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:10:43 --> Language Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Language Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Config Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Loader Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:10:43 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:10:43 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Session Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:10:43 --> Session routines successfully run
DEBUG - 2015-12-09 12:10:43 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Email Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Controller Class Initialized
DEBUG - 2015-12-09 12:10:43 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:10:43 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:10:43 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:10:43 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:10:43 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:10:43 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:10:43 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:10:43 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:10:43 --> Model Class Initialized
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:10:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:10:44 --> Final output sent to browser
DEBUG - 2015-12-09 12:10:44 --> Total execution time: 0.2423
DEBUG - 2015-12-09 12:11:00 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:11:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:11:00 --> URI Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Router Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Output Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Security Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Input Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:11:00 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Loader Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:11:00 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:11:00 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Session Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:11:00 --> Session routines successfully run
DEBUG - 2015-12-09 12:11:00 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Email Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Controller Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 12:11:00 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:00 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:00 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:00 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:00 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:00 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:11:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:11:00 --> URI Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Router Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Output Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Security Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Input Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:11:00 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Loader Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:11:00 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:11:00 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Session Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:11:00 --> Session routines successfully run
DEBUG - 2015-12-09 12:11:00 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Email Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Controller Class Initialized
DEBUG - 2015-12-09 12:11:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:11:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:11:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:11:00 --> Final output sent to browser
DEBUG - 2015-12-09 12:11:00 --> Total execution time: 0.2147
DEBUG - 2015-12-09 12:11:33 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:11:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:11:33 --> URI Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Router Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Output Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Security Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Input Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:11:33 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Loader Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:11:33 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:11:33 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Session Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:11:33 --> Session routines successfully run
DEBUG - 2015-12-09 12:11:33 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Email Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Controller Class Initialized
DEBUG - 2015-12-09 12:11:33 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:11:33 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:11:33 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:11:33 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:11:33 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:11:33 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:11:33 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:11:33 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:11:33 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:34 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-09 12:11:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:11:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:11:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:11:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:11:34 --> Final output sent to browser
DEBUG - 2015-12-09 12:11:34 --> Total execution time: 0.2551
DEBUG - 2015-12-09 12:11:49 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:11:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:11:49 --> URI Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Router Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Output Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Security Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Input Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:11:49 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Loader Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:11:49 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:11:49 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Session Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:11:49 --> Session routines successfully run
DEBUG - 2015-12-09 12:11:49 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Email Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Controller Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 12:11:49 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:49 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:49 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:49 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:49 --> XSS Filtering completed
DEBUG - 2015-12-09 12:11:49 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:11:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:11:49 --> URI Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Router Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Output Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Security Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Input Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:11:49 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Language Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Config Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Loader Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:11:49 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:11:49 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Session Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:11:49 --> Session routines successfully run
DEBUG - 2015-12-09 12:11:49 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Email Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Controller Class Initialized
DEBUG - 2015-12-09 12:11:49 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:11:49 --> Model Class Initialized
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:11:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:11:49 --> Final output sent to browser
DEBUG - 2015-12-09 12:11:49 --> Total execution time: 0.2133
DEBUG - 2015-12-09 12:15:42 --> Config Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:15:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:15:42 --> URI Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Router Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Output Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Security Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Input Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:15:42 --> Language Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Language Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Config Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Loader Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:15:42 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:15:42 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Session Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:15:42 --> Session routines successfully run
DEBUG - 2015-12-09 12:15:42 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Email Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Controller Class Initialized
DEBUG - 2015-12-09 12:15:42 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:15:42 --> Model Class Initialized
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:15:42 --> Model Class Initialized
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:15:42 --> Model Class Initialized
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:15:42 --> Model Class Initialized
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:15:42 --> Model Class Initialized
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:15:42 --> Model Class Initialized
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:15:42 --> Model Class Initialized
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:15:42 --> Model Class Initialized
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:15:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:15:42 --> Final output sent to browser
DEBUG - 2015-12-09 12:15:42 --> Total execution time: 0.2208
DEBUG - 2015-12-09 12:32:26 --> Config Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:32:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:32:26 --> URI Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Router Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Output Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Security Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Input Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:32:26 --> Language Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Language Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Config Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Loader Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:32:26 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:32:26 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Session Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:32:26 --> Session routines successfully run
DEBUG - 2015-12-09 12:32:26 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Email Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Controller Class Initialized
DEBUG - 2015-12-09 12:32:26 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:32:26 --> Model Class Initialized
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:32:26 --> Model Class Initialized
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:32:26 --> Model Class Initialized
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:32:26 --> Model Class Initialized
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:32:26 --> Model Class Initialized
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:32:26 --> Model Class Initialized
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:32:26 --> Model Class Initialized
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:32:26 --> Model Class Initialized
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:32:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:32:26 --> Final output sent to browser
DEBUG - 2015-12-09 12:32:26 --> Total execution time: 0.2919
DEBUG - 2015-12-09 12:43:55 --> Config Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:43:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:43:55 --> URI Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Router Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Output Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Security Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Input Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:43:55 --> Language Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Language Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Config Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Loader Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:43:55 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:43:55 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Session Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:43:55 --> Session routines successfully run
DEBUG - 2015-12-09 12:43:55 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Email Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Controller Class Initialized
DEBUG - 2015-12-09 12:43:55 --> Sections MX_Controller Initialized
DEBUG - 2015-12-09 12:43:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-09 12:43:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-09 12:43:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-09 12:43:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-09 12:43:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-09 12:43:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-09 12:43:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-09 12:43:55 --> Model Class Initialized
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-09 12:43:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-09 12:43:55 --> Final output sent to browser
DEBUG - 2015-12-09 12:43:55 --> Total execution time: 0.2227
DEBUG - 2015-12-09 12:43:59 --> Config Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:43:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:43:59 --> URI Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Router Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Output Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Security Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Input Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:43:59 --> Language Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Language Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Config Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Loader Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:43:59 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:43:59 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Session Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:43:59 --> Session routines successfully run
DEBUG - 2015-12-09 12:43:59 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Email Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Controller Class Initialized
DEBUG - 2015-12-09 12:43:59 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-09 12:45:18 --> Config Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:45:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:45:18 --> URI Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Router Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Output Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Security Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Input Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:45:18 --> Language Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Language Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Config Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Loader Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:45:18 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:45:18 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Session Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:45:18 --> Session routines successfully run
DEBUG - 2015-12-09 12:45:18 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Email Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Controller Class Initialized
DEBUG - 2015-12-09 12:45:18 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-09 12:46:06 --> Config Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:46:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:46:06 --> URI Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Router Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Output Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Security Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Input Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:46:06 --> Language Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Language Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Config Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Loader Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:46:06 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:46:06 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Session Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:46:06 --> Session routines successfully run
DEBUG - 2015-12-09 12:46:06 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Email Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Controller Class Initialized
DEBUG - 2015-12-09 12:46:06 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-09 12:46:07 --> Config Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:46:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:46:07 --> URI Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Router Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Output Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Security Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Input Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:46:07 --> Language Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Language Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Config Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Loader Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:46:07 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:46:07 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:46:07 --> Session Class Initialized
DEBUG - 2015-12-09 12:46:08 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:46:08 --> Session routines successfully run
DEBUG - 2015-12-09 12:46:08 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:46:08 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:46:08 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:46:08 --> Email Class Initialized
DEBUG - 2015-12-09 12:46:08 --> Controller Class Initialized
DEBUG - 2015-12-09 12:46:08 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-09 12:50:57 --> Config Class Initialized
DEBUG - 2015-12-09 12:50:57 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:50:57 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:50:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:50:57 --> URI Class Initialized
DEBUG - 2015-12-09 12:50:57 --> Router Class Initialized
DEBUG - 2015-12-09 12:50:57 --> Output Class Initialized
DEBUG - 2015-12-09 12:50:57 --> Security Class Initialized
DEBUG - 2015-12-09 12:50:57 --> Input Class Initialized
DEBUG - 2015-12-09 12:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:50:57 --> Language Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Language Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Config Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Loader Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:50:58 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:50:58 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Session Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:50:58 --> Session routines successfully run
DEBUG - 2015-12-09 12:50:58 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Email Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Controller Class Initialized
DEBUG - 2015-12-09 12:50:58 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-09 12:51:17 --> Config Class Initialized
DEBUG - 2015-12-09 12:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:51:17 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:51:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:51:17 --> URI Class Initialized
DEBUG - 2015-12-09 12:51:17 --> Router Class Initialized
DEBUG - 2015-12-09 12:51:17 --> Output Class Initialized
DEBUG - 2015-12-09 12:51:17 --> Security Class Initialized
DEBUG - 2015-12-09 12:51:17 --> Input Class Initialized
DEBUG - 2015-12-09 12:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:51:17 --> Language Class Initialized
ERROR - 2015-12-09 12:51:17 --> 404 Page Not Found --> property_owners/index
DEBUG - 2015-12-09 12:51:35 --> Config Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:51:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:51:35 --> URI Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Router Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Output Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Security Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Input Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:51:35 --> Language Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Language Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Config Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Loader Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:51:35 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:51:35 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Session Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:51:35 --> Session routines successfully run
DEBUG - 2015-12-09 12:51:35 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Encrypt Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Email Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Controller Class Initialized
DEBUG - 2015-12-09 12:51:35 --> Property_owners MX_Controller Initialized
