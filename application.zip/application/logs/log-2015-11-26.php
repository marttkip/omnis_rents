<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-11-26 13:18:58 --> Config Class Initialized
DEBUG - 2015-11-26 13:18:58 --> Hooks Class Initialized
DEBUG - 2015-11-26 13:18:59 --> Utf8 Class Initialized
DEBUG - 2015-11-26 13:18:59 --> UTF-8 Support Enabled
DEBUG - 2015-11-26 13:19:00 --> URI Class Initialized
DEBUG - 2015-11-26 13:19:02 --> Router Class Initialized
DEBUG - 2015-11-26 13:19:03 --> No URI present. Default controller set.
DEBUG - 2015-11-26 13:19:05 --> Output Class Initialized
DEBUG - 2015-11-26 13:19:05 --> Security Class Initialized
DEBUG - 2015-11-26 13:19:06 --> Input Class Initialized
DEBUG - 2015-11-26 13:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-26 13:19:06 --> Language Class Initialized
DEBUG - 2015-11-26 13:19:07 --> Language Class Initialized
DEBUG - 2015-11-26 13:19:07 --> Config Class Initialized
DEBUG - 2015-11-26 13:19:08 --> Loader Class Initialized
DEBUG - 2015-11-26 13:19:10 --> Helper loaded: url_helper
DEBUG - 2015-11-26 13:19:12 --> Helper loaded: form_helper
DEBUG - 2015-11-26 13:19:17 --> Database Driver Class Initialized
ERROR - 2015-11-26 13:19:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-26 13:19:20 --> Session Class Initialized
DEBUG - 2015-11-26 13:19:20 --> Helper loaded: string_helper
ERROR - 2015-11-26 13:19:20 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-11-26 13:19:21 --> Session routines successfully run
DEBUG - 2015-11-26 13:19:22 --> Form Validation Class Initialized
DEBUG - 2015-11-26 13:19:22 --> Pagination Class Initialized
DEBUG - 2015-11-26 13:19:23 --> Encrypt Class Initialized
DEBUG - 2015-11-26 13:19:23 --> Email Class Initialized
DEBUG - 2015-11-26 13:19:23 --> Controller Class Initialized
DEBUG - 2015-11-26 13:19:23 --> Auth MX_Controller Initialized
DEBUG - 2015-11-26 13:19:23 --> Model Class Initialized
DEBUG - 2015-11-26 13:19:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-26 13:19:23 --> Model Class Initialized
DEBUG - 2015-11-26 13:19:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-26 13:19:25 --> Model Class Initialized
DEBUG - 2015-11-26 13:20:22 --> Config Class Initialized
DEBUG - 2015-11-26 13:20:22 --> Hooks Class Initialized
DEBUG - 2015-11-26 13:20:22 --> Utf8 Class Initialized
DEBUG - 2015-11-26 13:20:22 --> UTF-8 Support Enabled
DEBUG - 2015-11-26 13:20:22 --> URI Class Initialized
DEBUG - 2015-11-26 13:20:23 --> Router Class Initialized
DEBUG - 2015-11-26 13:20:23 --> Output Class Initialized
DEBUG - 2015-11-26 13:20:23 --> Security Class Initialized
DEBUG - 2015-11-26 13:20:23 --> Input Class Initialized
DEBUG - 2015-11-26 13:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-26 13:20:23 --> Language Class Initialized
DEBUG - 2015-11-26 13:20:24 --> Language Class Initialized
DEBUG - 2015-11-26 13:20:24 --> Config Class Initialized
DEBUG - 2015-11-26 13:20:24 --> Loader Class Initialized
DEBUG - 2015-11-26 13:20:24 --> Helper loaded: url_helper
DEBUG - 2015-11-26 13:20:24 --> Helper loaded: form_helper
DEBUG - 2015-11-26 13:20:25 --> Database Driver Class Initialized
ERROR - 2015-11-26 13:20:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-26 13:20:25 --> Session Class Initialized
DEBUG - 2015-11-26 13:20:26 --> Helper loaded: string_helper
DEBUG - 2015-11-26 13:20:26 --> Session routines successfully run
DEBUG - 2015-11-26 13:20:26 --> Form Validation Class Initialized
DEBUG - 2015-11-26 13:20:26 --> Pagination Class Initialized
DEBUG - 2015-11-26 13:20:26 --> Encrypt Class Initialized
DEBUG - 2015-11-26 13:20:26 --> Email Class Initialized
DEBUG - 2015-11-26 13:20:26 --> Controller Class Initialized
DEBUG - 2015-11-26 13:20:26 --> Auth MX_Controller Initialized
DEBUG - 2015-11-26 13:20:26 --> Model Class Initialized
DEBUG - 2015-11-26 13:20:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-26 13:20:27 --> Model Class Initialized
DEBUG - 2015-11-26 13:20:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-26 13:20:27 --> Model Class Initialized
DEBUG - 2015-11-26 13:20:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-26 13:20:38 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-11-26 13:20:38 --> Final output sent to browser
DEBUG - 2015-11-26 13:20:38 --> Total execution time: 16.2557
DEBUG - 2015-11-26 13:21:33 --> Config Class Initialized
DEBUG - 2015-11-26 13:21:33 --> Hooks Class Initialized
DEBUG - 2015-11-26 13:21:33 --> Utf8 Class Initialized
DEBUG - 2015-11-26 13:21:33 --> UTF-8 Support Enabled
DEBUG - 2015-11-26 13:21:34 --> Config Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Hooks Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Config Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Utf8 Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Hooks Class Initialized
DEBUG - 2015-11-26 13:21:34 --> UTF-8 Support Enabled
DEBUG - 2015-11-26 13:21:34 --> Utf8 Class Initialized
DEBUG - 2015-11-26 13:21:34 --> UTF-8 Support Enabled
DEBUG - 2015-11-26 13:21:34 --> URI Class Initialized
DEBUG - 2015-11-26 13:21:34 --> URI Class Initialized
DEBUG - 2015-11-26 13:21:34 --> URI Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Config Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Hooks Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Utf8 Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Router Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Router Class Initialized
DEBUG - 2015-11-26 13:21:34 --> UTF-8 Support Enabled
DEBUG - 2015-11-26 13:21:34 --> Router Class Initialized
DEBUG - 2015-11-26 13:21:34 --> URI Class Initialized
DEBUG - 2015-11-26 13:21:34 --> Router Class Initialized
ERROR - 2015-11-26 13:21:35 --> 404 Page Not Found --> 
ERROR - 2015-11-26 13:21:35 --> 404 Page Not Found --> 
ERROR - 2015-11-26 13:21:35 --> 404 Page Not Found --> 
ERROR - 2015-11-26 13:21:35 --> 404 Page Not Found --> 
