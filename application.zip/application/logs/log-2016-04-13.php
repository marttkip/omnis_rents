<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-04-13 08:31:16 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:16 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:31:16 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:31:16 --> URI Class Initialized
DEBUG - 2016-04-13 08:31:16 --> Router Class Initialized
DEBUG - 2016-04-13 08:31:17 --> Output Class Initialized
DEBUG - 2016-04-13 08:31:17 --> Security Class Initialized
DEBUG - 2016-04-13 08:31:17 --> Input Class Initialized
DEBUG - 2016-04-13 08:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:31:17 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:17 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:17 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:17 --> Loader Class Initialized
DEBUG - 2016-04-13 08:31:17 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:31:17 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:31:17 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Session Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:31:18 --> A session cookie was not found.
DEBUG - 2016-04-13 08:31:18 --> Session routines successfully run
DEBUG - 2016-04-13 08:31:18 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Email Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Controller Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 08:31:18 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 08:31:18 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 08:31:18 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:31:18 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:18 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 08:31:18 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 08:31:18 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 08:31:18 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:31:18 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:31:18 --> URI Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Router Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Output Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Security Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Input Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:31:18 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Loader Class Initialized
DEBUG - 2016-04-13 08:31:18 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:31:18 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:31:18 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Session Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:31:19 --> Session routines successfully run
DEBUG - 2016-04-13 08:31:19 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Email Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Controller Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Auth MX_Controller Initialized
DEBUG - 2016-04-13 08:31:19 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 08:31:19 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:31:19 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 08:31:19 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-04-13 08:31:19 --> Final output sent to browser
DEBUG - 2016-04-13 08:31:19 --> Total execution time: 0.4697
DEBUG - 2016-04-13 08:31:19 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:31:19 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:31:19 --> URI Class Initialized
DEBUG - 2016-04-13 08:31:19 --> Router Class Initialized
ERROR - 2016-04-13 08:31:19 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 08:31:22 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:31:22 --> URI Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Router Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:31:22 --> URI Class Initialized
DEBUG - 2016-04-13 08:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:31:22 --> URI Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Router Class Initialized
DEBUG - 2016-04-13 08:31:22 --> Router Class Initialized
ERROR - 2016-04-13 08:31:22 --> 404 Page Not Found --> 
ERROR - 2016-04-13 08:31:22 --> 404 Page Not Found --> 
ERROR - 2016-04-13 08:31:22 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 08:31:26 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:31:26 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:31:26 --> URI Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Router Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Output Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Security Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Input Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:31:26 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Loader Class Initialized
DEBUG - 2016-04-13 08:31:26 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:31:26 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:31:26 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Session Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:31:27 --> Session routines successfully run
DEBUG - 2016-04-13 08:31:27 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Email Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Controller Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Auth MX_Controller Initialized
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-04-13 08:31:27 --> XSS Filtering completed
DEBUG - 2016-04-13 08:31:27 --> Unable to find validation rule: exists
DEBUG - 2016-04-13 08:31:27 --> XSS Filtering completed
DEBUG - 2016-04-13 08:31:27 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:31:27 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:31:27 --> URI Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Router Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Output Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Security Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Input Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:31:27 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Loader Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:31:27 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:31:27 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Session Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:31:27 --> Session routines successfully run
DEBUG - 2016-04-13 08:31:27 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Email Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Controller Class Initialized
DEBUG - 2016-04-13 08:31:27 --> Admin MX_Controller Initialized
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 08:31:27 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 08:31:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 08:31:27 --> Final output sent to browser
DEBUG - 2016-04-13 08:31:27 --> Total execution time: 0.3516
DEBUG - 2016-04-13 08:31:48 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:31:48 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:31:48 --> URI Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Router Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Output Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Security Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Input Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:31:48 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Language Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Config Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Loader Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:31:48 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:31:48 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Session Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:31:48 --> Session routines successfully run
DEBUG - 2016-04-13 08:31:48 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Email Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Controller Class Initialized
DEBUG - 2016-04-13 08:31:48 --> Reports MX_Controller Initialized
DEBUG - 2016-04-13 08:31:48 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 08:31:48 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 08:31:48 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-04-13 08:31:49 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:31:49 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 08:31:49 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 08:31:49 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-04-13 08:31:49 --> Model Class Initialized
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 08:31:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 08:31:49 --> Final output sent to browser
DEBUG - 2016-04-13 08:31:49 --> Total execution time: 0.7955
DEBUG - 2016-04-13 08:33:05 --> Config Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:33:05 --> URI Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Router Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Output Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Security Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Input Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:33:05 --> Language Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Language Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Config Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Loader Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:33:05 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:33:05 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Session Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:33:05 --> Session routines successfully run
DEBUG - 2016-04-13 08:33:05 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Email Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Controller Class Initialized
DEBUG - 2016-04-13 08:33:05 --> Reports MX_Controller Initialized
DEBUG - 2016-04-13 08:33:05 --> Model Class Initialized
DEBUG - 2016-04-13 08:33:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 08:33:05 --> Model Class Initialized
DEBUG - 2016-04-13 08:33:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 08:33:05 --> Model Class Initialized
DEBUG - 2016-04-13 08:33:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-04-13 08:33:05 --> Model Class Initialized
DEBUG - 2016-04-13 08:33:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:33:05 --> Model Class Initialized
DEBUG - 2016-04-13 08:33:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 08:33:05 --> Model Class Initialized
DEBUG - 2016-04-13 08:33:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 08:33:05 --> Model Class Initialized
DEBUG - 2016-04-13 08:33:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-04-13 08:33:05 --> Model Class Initialized
DEBUG - 2016-04-13 08:33:05 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-04-13 08:33:06 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-04-13 08:33:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 08:33:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 08:33:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 08:33:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 08:33:06 --> Final output sent to browser
DEBUG - 2016-04-13 08:33:06 --> Total execution time: 0.4064
DEBUG - 2016-04-13 08:36:25 --> Config Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:36:25 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:36:25 --> URI Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Router Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Output Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Security Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Input Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:36:25 --> Language Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Language Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Config Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Loader Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:36:25 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:36:25 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Session Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:36:25 --> Session routines successfully run
DEBUG - 2016-04-13 08:36:25 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Email Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Controller Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Points_category MX_Controller Initialized
DEBUG - 2016-04-13 08:36:25 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 08:36:25 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 08:36:25 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:36:25 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 08:36:25 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 08:36:25 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 08:36:25 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 08:36:25 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/real_estate_administration/models/points_category_model.php
DEBUG - 2016-04-13 08:36:25 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:25 --> Image Lib Class Initialized
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/real_estate_administration/views/points_category/all_points_categories.php
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 08:36:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 08:36:25 --> Final output sent to browser
DEBUG - 2016-04-13 08:36:25 --> Total execution time: 0.4524
DEBUG - 2016-04-13 08:36:57 --> Config Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:36:57 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:36:57 --> URI Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Router Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Output Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Security Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Input Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:36:57 --> Language Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Language Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Config Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Loader Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:36:57 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:36:57 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Session Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:36:57 --> Session routines successfully run
DEBUG - 2016-04-13 08:36:57 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Email Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Controller Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 08:36:57 --> Model Class Initialized
DEBUG - 2016-04-13 08:36:57 --> Image Lib Class Initialized
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/real_estate_administration/views/rental_unit/search/rental_unit_search.php
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 08:36:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 08:36:57 --> Final output sent to browser
DEBUG - 2016-04-13 08:36:57 --> Total execution time: 0.3358
DEBUG - 2016-04-13 08:37:03 --> Config Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:37:03 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:37:03 --> URI Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Router Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Output Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Security Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Input Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:37:03 --> Language Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Language Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Config Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Loader Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:37:03 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:37:03 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Session Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:37:03 --> Session routines successfully run
DEBUG - 2016-04-13 08:37:03 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Email Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Controller Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> Image Lib Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-04-13 08:37:03 --> Model Class Initialized
ERROR - 2016-04-13 08:37:03 --> Severity: Notice  --> Undefined property: stdClass::$arrears_bf C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 52
ERROR - 2016-04-13 08:37:03 --> Severity: Notice  --> Undefined property: stdClass::$arrears_bf C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 52
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 08:37:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 08:37:03 --> Final output sent to browser
DEBUG - 2016-04-13 08:37:03 --> Total execution time: 0.4083
DEBUG - 2016-04-13 08:37:07 --> Config Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Hooks Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Utf8 Class Initialized
DEBUG - 2016-04-13 08:37:07 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 08:37:07 --> URI Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Router Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Output Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Security Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Input Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 08:37:07 --> Language Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Language Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Config Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Loader Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Helper loaded: url_helper
DEBUG - 2016-04-13 08:37:07 --> Helper loaded: form_helper
DEBUG - 2016-04-13 08:37:07 --> Database Driver Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Session Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Helper loaded: string_helper
DEBUG - 2016-04-13 08:37:07 --> Session routines successfully run
DEBUG - 2016-04-13 08:37:07 --> Form Validation Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Pagination Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Encrypt Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Email Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Controller Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 08:37:07 --> Model Class Initialized
DEBUG - 2016-04-13 08:37:07 --> Image Lib Class Initialized
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/real_estate_administration/views/rental_unit/search/rental_unit_search.php
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 08:37:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 08:37:07 --> Final output sent to browser
DEBUG - 2016-04-13 08:37:07 --> Total execution time: 0.2429
DEBUG - 2016-04-13 10:06:44 --> Config Class Initialized
DEBUG - 2016-04-13 10:06:44 --> Hooks Class Initialized
DEBUG - 2016-04-13 10:06:44 --> Utf8 Class Initialized
DEBUG - 2016-04-13 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 10:06:44 --> URI Class Initialized
DEBUG - 2016-04-13 10:06:44 --> Router Class Initialized
DEBUG - 2016-04-13 10:06:45 --> Output Class Initialized
DEBUG - 2016-04-13 10:06:45 --> Security Class Initialized
DEBUG - 2016-04-13 10:06:45 --> Input Class Initialized
DEBUG - 2016-04-13 10:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 10:06:45 --> Language Class Initialized
DEBUG - 2016-04-13 10:06:45 --> Language Class Initialized
DEBUG - 2016-04-13 10:06:45 --> Config Class Initialized
DEBUG - 2016-04-13 10:06:45 --> Loader Class Initialized
DEBUG - 2016-04-13 10:06:46 --> Helper loaded: url_helper
DEBUG - 2016-04-13 10:06:46 --> Helper loaded: form_helper
DEBUG - 2016-04-13 10:06:46 --> Database Driver Class Initialized
DEBUG - 2016-04-13 10:06:46 --> Session Class Initialized
DEBUG - 2016-04-13 10:06:46 --> Helper loaded: string_helper
ERROR - 2016-04-13 10:06:46 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-04-13 10:06:46 --> Session routines successfully run
DEBUG - 2016-04-13 10:06:46 --> Form Validation Class Initialized
DEBUG - 2016-04-13 10:06:46 --> Pagination Class Initialized
DEBUG - 2016-04-13 10:06:46 --> Encrypt Class Initialized
DEBUG - 2016-04-13 10:06:46 --> Email Class Initialized
DEBUG - 2016-04-13 10:06:46 --> Controller Class Initialized
DEBUG - 2016-04-13 10:06:46 --> Auth MX_Controller Initialized
DEBUG - 2016-04-13 10:06:46 --> Model Class Initialized
DEBUG - 2016-04-13 10:06:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 10:06:46 --> Model Class Initialized
DEBUG - 2016-04-13 10:06:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 10:06:46 --> Model Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Config Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Hooks Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Utf8 Class Initialized
DEBUG - 2016-04-13 10:06:47 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 10:06:47 --> URI Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Router Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Output Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Security Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Input Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 10:06:47 --> Language Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Language Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Config Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Loader Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Helper loaded: url_helper
DEBUG - 2016-04-13 10:06:47 --> Helper loaded: form_helper
DEBUG - 2016-04-13 10:06:47 --> Database Driver Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Session Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Helper loaded: string_helper
DEBUG - 2016-04-13 10:06:47 --> A session cookie was not found.
DEBUG - 2016-04-13 10:06:47 --> Session routines successfully run
DEBUG - 2016-04-13 10:06:47 --> Form Validation Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Pagination Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Encrypt Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Email Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Controller Class Initialized
DEBUG - 2016-04-13 10:06:47 --> Auth MX_Controller Initialized
DEBUG - 2016-04-13 10:06:47 --> Model Class Initialized
DEBUG - 2016-04-13 10:06:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 10:06:47 --> Model Class Initialized
DEBUG - 2016-04-13 10:06:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 10:06:47 --> Model Class Initialized
DEBUG - 2016-04-13 10:06:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 10:06:47 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-04-13 10:06:47 --> Final output sent to browser
DEBUG - 2016-04-13 10:06:47 --> Total execution time: 0.4395
DEBUG - 2016-04-13 10:06:48 --> Config Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Hooks Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Utf8 Class Initialized
DEBUG - 2016-04-13 10:06:48 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 10:06:48 --> URI Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Router Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Config Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Hooks Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Utf8 Class Initialized
DEBUG - 2016-04-13 10:06:48 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 10:06:48 --> Config Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Hooks Class Initialized
DEBUG - 2016-04-13 10:06:48 --> URI Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Utf8 Class Initialized
DEBUG - 2016-04-13 10:06:48 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 10:06:48 --> URI Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Router Class Initialized
DEBUG - 2016-04-13 10:06:48 --> Router Class Initialized
DEBUG - 2016-04-13 10:06:49 --> Config Class Initialized
DEBUG - 2016-04-13 10:06:49 --> Hooks Class Initialized
DEBUG - 2016-04-13 10:06:49 --> Utf8 Class Initialized
DEBUG - 2016-04-13 10:06:49 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 10:06:49 --> URI Class Initialized
DEBUG - 2016-04-13 10:06:49 --> Router Class Initialized
ERROR - 2016-04-13 10:06:49 --> 404 Page Not Found --> 
ERROR - 2016-04-13 10:06:49 --> 404 Page Not Found --> 
ERROR - 2016-04-13 10:06:49 --> 404 Page Not Found --> 
ERROR - 2016-04-13 10:06:49 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:04 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:04 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:04 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:04 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:04 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:05 --> Router Class Initialized
DEBUG - 2016-04-13 16:31:06 --> No URI present. Default controller set.
DEBUG - 2016-04-13 16:31:07 --> Output Class Initialized
DEBUG - 2016-04-13 16:31:07 --> Security Class Initialized
DEBUG - 2016-04-13 16:31:07 --> Input Class Initialized
DEBUG - 2016-04-13 16:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 16:31:08 --> Language Class Initialized
DEBUG - 2016-04-13 16:31:12 --> Language Class Initialized
DEBUG - 2016-04-13 16:31:12 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:12 --> Loader Class Initialized
DEBUG - 2016-04-13 16:31:12 --> Helper loaded: url_helper
DEBUG - 2016-04-13 16:31:12 --> Helper loaded: form_helper
DEBUG - 2016-04-13 16:31:13 --> Database Driver Class Initialized
DEBUG - 2016-04-13 16:31:13 --> Session Class Initialized
DEBUG - 2016-04-13 16:31:13 --> Helper loaded: string_helper
ERROR - 2016-04-13 16:31:13 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-04-13 16:31:13 --> Session routines successfully run
DEBUG - 2016-04-13 16:31:13 --> Form Validation Class Initialized
DEBUG - 2016-04-13 16:31:13 --> Pagination Class Initialized
DEBUG - 2016-04-13 16:31:13 --> Encrypt Class Initialized
DEBUG - 2016-04-13 16:31:13 --> Email Class Initialized
DEBUG - 2016-04-13 16:31:13 --> Controller Class Initialized
DEBUG - 2016-04-13 16:31:13 --> Auth MX_Controller Initialized
DEBUG - 2016-04-13 16:31:13 --> Model Class Initialized
DEBUG - 2016-04-13 16:31:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 16:31:13 --> Model Class Initialized
DEBUG - 2016-04-13 16:31:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 16:31:14 --> Model Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:14 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:14 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Router Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Output Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Security Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Input Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 16:31:14 --> Language Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Language Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Loader Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Helper loaded: url_helper
DEBUG - 2016-04-13 16:31:14 --> Helper loaded: form_helper
DEBUG - 2016-04-13 16:31:14 --> Database Driver Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Session Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Helper loaded: string_helper
DEBUG - 2016-04-13 16:31:14 --> Session routines successfully run
DEBUG - 2016-04-13 16:31:14 --> Form Validation Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Pagination Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Encrypt Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Email Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Controller Class Initialized
DEBUG - 2016-04-13 16:31:14 --> Auth MX_Controller Initialized
DEBUG - 2016-04-13 16:31:14 --> Model Class Initialized
DEBUG - 2016-04-13 16:31:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 16:31:14 --> Model Class Initialized
DEBUG - 2016-04-13 16:31:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 16:31:14 --> Model Class Initialized
DEBUG - 2016-04-13 16:31:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 16:31:15 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-04-13 16:31:15 --> Final output sent to browser
DEBUG - 2016-04-13 16:31:15 --> Total execution time: 0.9342
DEBUG - 2016-04-13 16:31:16 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:16 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:16 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:16 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:16 --> Router Class Initialized
DEBUG - 2016-04-13 16:31:16 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:16 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:16 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:16 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:16 --> Router Class Initialized
ERROR - 2016-04-13 16:31:18 --> 404 Page Not Found --> 
ERROR - 2016-04-13 16:31:18 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:20 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:20 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:20 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:20 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:20 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:20 --> Router Class Initialized
DEBUG - 2016-04-13 16:31:22 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:22 --> Hooks Class Initialized
ERROR - 2016-04-13 16:31:22 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:22 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:22 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:22 --> Router Class Initialized
ERROR - 2016-04-13 16:31:23 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:33 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:33 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:33 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:33 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:33 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:33 --> Router Class Initialized
ERROR - 2016-04-13 16:31:33 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:33 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:33 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:33 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:33 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:33 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:33 --> Router Class Initialized
ERROR - 2016-04-13 16:31:33 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:33 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:33 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:33 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:33 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:33 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:33 --> Router Class Initialized
ERROR - 2016-04-13 16:31:33 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:36 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:36 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:36 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Router Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Output Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Security Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Input Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 16:31:36 --> Language Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Language Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Loader Class Initialized
DEBUG - 2016-04-13 16:31:36 --> Helper loaded: url_helper
DEBUG - 2016-04-13 16:31:36 --> Helper loaded: form_helper
DEBUG - 2016-04-13 16:31:36 --> Database Driver Class Initialized
DEBUG - 2016-04-13 16:31:37 --> Session Class Initialized
DEBUG - 2016-04-13 16:31:37 --> Helper loaded: string_helper
DEBUG - 2016-04-13 16:31:37 --> Session routines successfully run
DEBUG - 2016-04-13 16:31:37 --> Form Validation Class Initialized
DEBUG - 2016-04-13 16:31:37 --> Pagination Class Initialized
DEBUG - 2016-04-13 16:31:37 --> Encrypt Class Initialized
DEBUG - 2016-04-13 16:31:37 --> Email Class Initialized
DEBUG - 2016-04-13 16:31:37 --> Controller Class Initialized
DEBUG - 2016-04-13 16:31:37 --> Auth MX_Controller Initialized
DEBUG - 2016-04-13 16:31:37 --> Model Class Initialized
DEBUG - 2016-04-13 16:31:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 16:31:37 --> Model Class Initialized
DEBUG - 2016-04-13 16:31:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 16:31:37 --> Model Class Initialized
DEBUG - 2016-04-13 16:31:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-04-13 16:31:37 --> XSS Filtering completed
DEBUG - 2016-04-13 16:31:37 --> Unable to find validation rule: exists
DEBUG - 2016-04-13 16:31:37 --> XSS Filtering completed
DEBUG - 2016-04-13 16:31:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 16:31:37 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-04-13 16:31:37 --> Final output sent to browser
DEBUG - 2016-04-13 16:31:37 --> Total execution time: 1.0389
DEBUG - 2016-04-13 16:31:38 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:38 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Router Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:38 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Router Class Initialized
ERROR - 2016-04-13 16:31:38 --> 404 Page Not Found --> 
ERROR - 2016-04-13 16:31:38 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:38 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:38 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:38 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:38 --> Router Class Initialized
ERROR - 2016-04-13 16:31:38 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:38 --> Router Class Initialized
ERROR - 2016-04-13 16:31:38 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 16:31:39 --> Config Class Initialized
DEBUG - 2016-04-13 16:31:39 --> Hooks Class Initialized
DEBUG - 2016-04-13 16:31:39 --> Utf8 Class Initialized
DEBUG - 2016-04-13 16:31:39 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 16:31:39 --> URI Class Initialized
DEBUG - 2016-04-13 16:31:39 --> Router Class Initialized
ERROR - 2016-04-13 16:31:39 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 17:10:08 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:10:08 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:10:08 --> URI Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Router Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Output Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Security Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Input Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 17:10:08 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Loader Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Helper loaded: url_helper
DEBUG - 2016-04-13 17:10:08 --> Helper loaded: form_helper
DEBUG - 2016-04-13 17:10:08 --> Database Driver Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Session Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Helper loaded: string_helper
ERROR - 2016-04-13 17:10:08 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-04-13 17:10:08 --> Session routines successfully run
DEBUG - 2016-04-13 17:10:08 --> Form Validation Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Pagination Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Encrypt Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Email Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Controller Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Auth MX_Controller Initialized
DEBUG - 2016-04-13 17:10:08 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 17:10:08 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 17:10:08 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-04-13 17:10:08 --> XSS Filtering completed
DEBUG - 2016-04-13 17:10:08 --> Unable to find validation rule: exists
DEBUG - 2016-04-13 17:10:08 --> XSS Filtering completed
DEBUG - 2016-04-13 17:10:09 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:10:09 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:10:09 --> URI Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Router Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Output Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Security Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Input Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 17:10:09 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Loader Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Helper loaded: url_helper
DEBUG - 2016-04-13 17:10:09 --> Helper loaded: form_helper
DEBUG - 2016-04-13 17:10:09 --> Database Driver Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Session Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Helper loaded: string_helper
DEBUG - 2016-04-13 17:10:09 --> Session routines successfully run
DEBUG - 2016-04-13 17:10:09 --> Form Validation Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Pagination Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Encrypt Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Email Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Controller Class Initialized
DEBUG - 2016-04-13 17:10:09 --> Admin MX_Controller Initialized
DEBUG - 2016-04-13 17:10:09 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 17:10:09 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 17:10:09 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 17:10:09 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 17:10:09 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 17:10:09 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 17:10:09 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 17:10:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 17:10:09 --> Final output sent to browser
DEBUG - 2016-04-13 17:10:09 --> Total execution time: 0.7534
DEBUG - 2016-04-13 17:10:12 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:12 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:10:12 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:10:12 --> URI Class Initialized
DEBUG - 2016-04-13 17:10:12 --> Router Class Initialized
ERROR - 2016-04-13 17:10:12 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 17:10:30 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:10:30 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:10:30 --> URI Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Router Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Output Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Security Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Input Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 17:10:30 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Loader Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Helper loaded: url_helper
DEBUG - 2016-04-13 17:10:30 --> Helper loaded: form_helper
DEBUG - 2016-04-13 17:10:30 --> Database Driver Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Session Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Helper loaded: string_helper
DEBUG - 2016-04-13 17:10:30 --> Session routines successfully run
DEBUG - 2016-04-13 17:10:30 --> Form Validation Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Pagination Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Encrypt Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Email Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Controller Class Initialized
DEBUG - 2016-04-13 17:10:30 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 17:10:30 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 17:10:30 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 17:10:30 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 17:10:30 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:30 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 17:10:30 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 17:10:31 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 17:10:31 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 17:10:31 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-04-13 17:10:31 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 17:10:31 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:31 --> Image Lib Class Initialized
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-04-13 17:10:31 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 17:10:31 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-04-13 17:10:31 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/views/tenants/search/tenants_search.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 17:10:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 17:10:31 --> Final output sent to browser
DEBUG - 2016-04-13 17:10:31 --> Total execution time: 1.2202
DEBUG - 2016-04-13 17:10:32 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:32 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:10:32 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:10:32 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:10:32 --> URI Class Initialized
DEBUG - 2016-04-13 17:10:33 --> Router Class Initialized
ERROR - 2016-04-13 17:10:33 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 17:10:52 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:10:52 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:10:52 --> URI Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Router Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Output Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Security Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Input Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 17:10:52 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Loader Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Helper loaded: url_helper
DEBUG - 2016-04-13 17:10:52 --> Helper loaded: form_helper
DEBUG - 2016-04-13 17:10:52 --> Database Driver Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Session Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Helper loaded: string_helper
DEBUG - 2016-04-13 17:10:52 --> Session routines successfully run
DEBUG - 2016-04-13 17:10:52 --> Form Validation Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Pagination Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Encrypt Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Email Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Controller Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Image Lib Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-04-13 17:10:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-04-13 17:10:52 --> XSS Filtering completed
DEBUG - 2016-04-13 17:10:52 --> XSS Filtering completed
DEBUG - 2016-04-13 17:10:53 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:10:53 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:10:53 --> URI Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Router Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Output Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Security Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Input Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 17:10:53 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Language Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Loader Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Helper loaded: url_helper
DEBUG - 2016-04-13 17:10:53 --> Helper loaded: form_helper
DEBUG - 2016-04-13 17:10:53 --> Database Driver Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Session Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Helper loaded: string_helper
DEBUG - 2016-04-13 17:10:53 --> Session routines successfully run
DEBUG - 2016-04-13 17:10:53 --> Form Validation Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Pagination Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Encrypt Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Email Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Controller Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> Image Lib Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-04-13 17:10:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/search/tenants_search.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 17:10:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 17:10:53 --> Final output sent to browser
DEBUG - 2016-04-13 17:10:53 --> Total execution time: 0.2769
DEBUG - 2016-04-13 17:10:54 --> Config Class Initialized
DEBUG - 2016-04-13 17:10:54 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:10:54 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:10:54 --> URI Class Initialized
DEBUG - 2016-04-13 17:10:54 --> Router Class Initialized
ERROR - 2016-04-13 17:10:54 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 17:11:27 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:27 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:11:27 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:11:27 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:11:27 --> URI Class Initialized
DEBUG - 2016-04-13 17:11:27 --> Router Class Initialized
DEBUG - 2016-04-13 17:11:27 --> Output Class Initialized
DEBUG - 2016-04-13 17:11:27 --> Security Class Initialized
DEBUG - 2016-04-13 17:11:27 --> Input Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 17:11:28 --> Language Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Language Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Loader Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Helper loaded: url_helper
DEBUG - 2016-04-13 17:11:28 --> Helper loaded: form_helper
DEBUG - 2016-04-13 17:11:28 --> Database Driver Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Session Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Helper loaded: string_helper
DEBUG - 2016-04-13 17:11:28 --> Session routines successfully run
DEBUG - 2016-04-13 17:11:28 --> Form Validation Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Pagination Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Encrypt Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Email Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Controller Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Image Lib Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-04-13 17:11:28 --> XSS Filtering completed
DEBUG - 2016-04-13 17:11:28 --> XSS Filtering completed
DEBUG - 2016-04-13 17:11:28 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:11:28 --> URI Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Router Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Output Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Security Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Input Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 17:11:28 --> Language Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Language Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Loader Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Helper loaded: url_helper
DEBUG - 2016-04-13 17:11:28 --> Helper loaded: form_helper
DEBUG - 2016-04-13 17:11:28 --> Database Driver Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Session Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Helper loaded: string_helper
DEBUG - 2016-04-13 17:11:28 --> Session routines successfully run
DEBUG - 2016-04-13 17:11:28 --> Form Validation Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Pagination Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Encrypt Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Email Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Controller Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> Image Lib Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-04-13 17:11:28 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/search/tenants_search.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 17:11:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 17:11:28 --> Final output sent to browser
DEBUG - 2016-04-13 17:11:28 --> Total execution time: 0.3496
DEBUG - 2016-04-13 17:11:29 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:29 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:11:29 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:11:29 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:11:29 --> URI Class Initialized
DEBUG - 2016-04-13 17:11:29 --> Router Class Initialized
ERROR - 2016-04-13 17:11:29 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 17:11:52 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:11:52 --> URI Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Router Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Output Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Security Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Input Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 17:11:52 --> Language Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Language Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Loader Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Helper loaded: url_helper
DEBUG - 2016-04-13 17:11:52 --> Helper loaded: form_helper
DEBUG - 2016-04-13 17:11:52 --> Database Driver Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Session Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Helper loaded: string_helper
DEBUG - 2016-04-13 17:11:52 --> Session routines successfully run
DEBUG - 2016-04-13 17:11:52 --> Form Validation Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Pagination Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Encrypt Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Email Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Controller Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Image Lib Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-04-13 17:11:52 --> XSS Filtering completed
DEBUG - 2016-04-13 17:11:52 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:11:52 --> URI Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Router Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Output Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Security Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Input Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 17:11:52 --> Language Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Language Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Loader Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Helper loaded: url_helper
DEBUG - 2016-04-13 17:11:52 --> Helper loaded: form_helper
DEBUG - 2016-04-13 17:11:52 --> Database Driver Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Session Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Helper loaded: string_helper
DEBUG - 2016-04-13 17:11:52 --> Session routines successfully run
DEBUG - 2016-04-13 17:11:52 --> Form Validation Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Pagination Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Encrypt Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Email Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Controller Class Initialized
DEBUG - 2016-04-13 17:11:52 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 17:11:52 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 17:11:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 17:11:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-13 17:11:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-04-13 17:11:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-04-13 17:11:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:53 --> Image Lib Class Initialized
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-04-13 17:11:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-04-13 17:11:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-04-13 17:11:53 --> Model Class Initialized
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/search/tenants_search.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-13 17:11:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-13 17:11:53 --> Final output sent to browser
DEBUG - 2016-04-13 17:11:53 --> Total execution time: 0.3015
DEBUG - 2016-04-13 17:11:54 --> Config Class Initialized
DEBUG - 2016-04-13 17:11:54 --> Hooks Class Initialized
DEBUG - 2016-04-13 17:11:54 --> Utf8 Class Initialized
DEBUG - 2016-04-13 17:11:54 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 17:11:54 --> URI Class Initialized
DEBUG - 2016-04-13 17:11:54 --> Router Class Initialized
ERROR - 2016-04-13 17:11:54 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 18:32:25 --> Config Class Initialized
DEBUG - 2016-04-13 18:32:25 --> Hooks Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Utf8 Class Initialized
DEBUG - 2016-04-13 18:32:26 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 18:32:26 --> URI Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Router Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Output Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Security Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Input Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 18:32:26 --> Language Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Language Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Config Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Loader Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Helper loaded: url_helper
DEBUG - 2016-04-13 18:32:26 --> Helper loaded: form_helper
DEBUG - 2016-04-13 18:32:26 --> Database Driver Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Session Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Helper loaded: string_helper
ERROR - 2016-04-13 18:32:26 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-04-13 18:32:26 --> Session routines successfully run
DEBUG - 2016-04-13 18:32:26 --> Form Validation Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Pagination Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Encrypt Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Email Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Controller Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Config Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Hooks Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Utf8 Class Initialized
DEBUG - 2016-04-13 18:32:26 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 18:32:26 --> URI Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Router Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Output Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Security Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Input Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-13 18:32:26 --> Language Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Language Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Config Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Loader Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Helper loaded: url_helper
DEBUG - 2016-04-13 18:32:26 --> Helper loaded: form_helper
DEBUG - 2016-04-13 18:32:26 --> Database Driver Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Session Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Helper loaded: string_helper
DEBUG - 2016-04-13 18:32:26 --> Session routines successfully run
DEBUG - 2016-04-13 18:32:26 --> Form Validation Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Pagination Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Encrypt Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Email Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Controller Class Initialized
DEBUG - 2016-04-13 18:32:26 --> Auth MX_Controller Initialized
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-13 18:32:26 --> Model Class Initialized
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-13 18:32:26 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-04-13 18:32:26 --> Final output sent to browser
DEBUG - 2016-04-13 18:32:26 --> Total execution time: 0.1709
DEBUG - 2016-04-13 18:32:27 --> Config Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Hooks Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Utf8 Class Initialized
DEBUG - 2016-04-13 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 18:32:27 --> URI Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Config Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Hooks Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Utf8 Class Initialized
DEBUG - 2016-04-13 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 18:32:27 --> URI Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Router Class Initialized
ERROR - 2016-04-13 18:32:27 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 18:32:27 --> Config Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Hooks Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Utf8 Class Initialized
DEBUG - 2016-04-13 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 18:32:27 --> URI Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Config Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Router Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Router Class Initialized
ERROR - 2016-04-13 18:32:27 --> 404 Page Not Found --> 
DEBUG - 2016-04-13 18:32:27 --> Hooks Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Utf8 Class Initialized
DEBUG - 2016-04-13 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2016-04-13 18:32:27 --> URI Class Initialized
DEBUG - 2016-04-13 18:32:27 --> Router Class Initialized
ERROR - 2016-04-13 18:32:27 --> 404 Page Not Found --> 
ERROR - 2016-04-13 18:32:28 --> 404 Page Not Found --> 
