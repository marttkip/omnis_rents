<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-07 13:38:17 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:38:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:38:17 --> URI Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Router Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Output Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Security Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Input Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:38:17 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Loader Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:38:17 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:38:17 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:38:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:38:17 --> Session Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:38:17 --> A session cookie was not found.
DEBUG - 2015-10-07 13:38:17 --> Session routines successfully run
DEBUG - 2015-10-07 13:38:17 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Email Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Controller Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:38:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:38:17 --> URI Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Router Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Output Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Security Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Input Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:38:17 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Loader Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:38:17 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:38:17 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:38:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:38:17 --> Session Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:38:17 --> Session routines successfully run
DEBUG - 2015-10-07 13:38:17 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Email Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Controller Class Initialized
DEBUG - 2015-10-07 13:38:17 --> Auth MX_Controller Initialized
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:38:17 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:38:17 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-10-07 13:38:17 --> Final output sent to browser
DEBUG - 2015-10-07 13:38:17 --> Total execution time: 0.1051
DEBUG - 2015-10-07 13:38:18 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:38:18 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:38:18 --> URI Class Initialized
DEBUG - 2015-10-07 13:38:18 --> URI Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Router Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Router Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:38:18 --> URI Class Initialized
ERROR - 2015-10-07 13:38:18 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 13:38:18 --> Router Class Initialized
ERROR - 2015-10-07 13:38:18 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 13:38:18 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:38:18 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:38:18 --> URI Class Initialized
ERROR - 2015-10-07 13:38:18 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 13:38:18 --> Router Class Initialized
ERROR - 2015-10-07 13:38:18 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 13:38:23 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:38:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:38:23 --> URI Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Router Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Output Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Security Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Input Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:38:23 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Loader Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:38:23 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:38:23 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:38:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:38:23 --> Session Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:38:23 --> Session routines successfully run
DEBUG - 2015-10-07 13:38:23 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Email Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Controller Class Initialized
DEBUG - 2015-10-07 13:38:23 --> Auth MX_Controller Initialized
DEBUG - 2015-10-07 13:38:23 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:38:24 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:38:24 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-07 13:38:24 --> XSS Filtering completed
DEBUG - 2015-10-07 13:38:24 --> Unable to find validation rule: exists
DEBUG - 2015-10-07 13:38:24 --> XSS Filtering completed
DEBUG - 2015-10-07 13:38:24 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:38:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:38:24 --> URI Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Router Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Output Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Security Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Input Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:38:24 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Loader Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:38:24 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:38:24 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:38:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:38:24 --> Session Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:38:24 --> Session routines successfully run
DEBUG - 2015-10-07 13:38:24 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Email Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Controller Class Initialized
DEBUG - 2015-10-07 13:38:24 --> Admin MX_Controller Initialized
DEBUG - 2015-10-07 13:38:24 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:38:24 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:38:24 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:38:24 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-07 13:38:24 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:38:24 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-07 13:38:24 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:38:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:38:24 --> Final output sent to browser
DEBUG - 2015-10-07 13:38:24 --> Total execution time: 0.1436
DEBUG - 2015-10-07 13:38:31 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:38:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:38:31 --> URI Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Router Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Output Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Security Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Input Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:38:31 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Language Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Config Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Loader Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:38:31 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:38:31 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:38:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:38:31 --> Session Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:38:31 --> Session routines successfully run
DEBUG - 2015-10-07 13:38:31 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Email Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Controller Class Initialized
DEBUG - 2015-10-07 13:38:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:38:31 --> Model Class Initialized
DEBUG - 2015-10-07 13:38:31 --> DB Transaction Failure
ERROR - 2015-10-07 13:38:31 --> Query error: Unknown table 'loans_plan'
DEBUG - 2015-10-07 13:38:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-07 13:46:19 --> Config Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:46:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:46:19 --> URI Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Router Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Output Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Security Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Input Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:46:19 --> Language Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Language Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Config Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Loader Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:46:19 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:46:19 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:46:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:46:19 --> Session Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:46:19 --> Session routines successfully run
DEBUG - 2015-10-07 13:46:19 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Email Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Controller Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:46:19 --> Model Class Initialized
DEBUG - 2015-10-07 13:46:19 --> Final output sent to browser
DEBUG - 2015-10-07 13:46:19 --> Total execution time: 0.1400
DEBUG - 2015-10-07 13:47:20 --> Config Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:47:20 --> URI Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Router Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Output Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Security Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Input Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:47:20 --> Language Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Language Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Config Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Loader Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:47:20 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:47:20 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:47:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:47:20 --> Session Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:47:20 --> Session routines successfully run
DEBUG - 2015-10-07 13:47:20 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Email Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Controller Class Initialized
DEBUG - 2015-10-07 13:47:20 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:47:20 --> Model Class Initialized
ERROR - 2015-10-07 13:47:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\mfi\application\modules\admin\views\includes\header.php 4
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
ERROR - 2015-10-07 13:47:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\mfi\application\modules\admin\views\includes\sidebar.php 37
ERROR - 2015-10-07 13:47:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\mfi\application\modules\admin\views\includes\sidebar.php 58
ERROR - 2015-10-07 13:47:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\mfi\application\modules\admin\views\includes\sidebar.php 58
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
ERROR - 2015-10-07 13:47:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\mfi\application\modules\admin\views\templates\general_page.php 32
ERROR - 2015-10-07 13:47:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\mfi\application\modules\admin\views\templates\general_page.php 36
ERROR - 2015-10-07 13:47:20 --> Severity: Notice  --> Undefined variable: content C:\wamp\www\mfi\application\modules\admin\views\templates\general_page.php 43
DEBUG - 2015-10-07 13:47:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:47:20 --> Final output sent to browser
DEBUG - 2015-10-07 13:47:20 --> Total execution time: 0.2206
DEBUG - 2015-10-07 13:47:58 --> Config Class Initialized
DEBUG - 2015-10-07 13:47:58 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:47:58 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:47:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:47:58 --> URI Class Initialized
DEBUG - 2015-10-07 13:47:58 --> Router Class Initialized
DEBUG - 2015-10-07 13:47:58 --> Output Class Initialized
DEBUG - 2015-10-07 13:47:58 --> Security Class Initialized
DEBUG - 2015-10-07 13:47:58 --> Input Class Initialized
DEBUG - 2015-10-07 13:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:47:58 --> Language Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Config Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:48:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:48:07 --> URI Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Router Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Output Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Security Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Input Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:48:07 --> Language Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Language Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Config Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Loader Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:48:07 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:48:07 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:48:07 --> Session Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:48:07 --> Session routines successfully run
DEBUG - 2015-10-07 13:48:07 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Email Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Controller Class Initialized
DEBUG - 2015-10-07 13:48:07 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:48:07 --> Model Class Initialized
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
ERROR - 2015-10-07 13:48:07 --> Severity: Notice  --> Undefined variable: content C:\wamp\www\mfi\application\modules\admin\views\templates\general_page.php 43
DEBUG - 2015-10-07 13:48:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:48:07 --> Final output sent to browser
DEBUG - 2015-10-07 13:48:07 --> Total execution time: 0.1780
DEBUG - 2015-10-07 13:49:21 --> Config Class Initialized
DEBUG - 2015-10-07 13:49:21 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:49:21 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:49:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:49:21 --> URI Class Initialized
DEBUG - 2015-10-07 13:49:21 --> Router Class Initialized
DEBUG - 2015-10-07 13:49:21 --> Output Class Initialized
DEBUG - 2015-10-07 13:49:21 --> Security Class Initialized
DEBUG - 2015-10-07 13:49:21 --> Input Class Initialized
DEBUG - 2015-10-07 13:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:49:21 --> Language Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Config Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:49:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:49:39 --> URI Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Router Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Output Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Security Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Input Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:49:39 --> Language Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Language Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Config Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Loader Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:49:39 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:49:39 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:49:39 --> Session Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:49:39 --> Session routines successfully run
DEBUG - 2015-10-07 13:49:39 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Email Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Controller Class Initialized
DEBUG - 2015-10-07 13:49:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:49:39 --> Model Class Initialized
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:49:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:49:39 --> Final output sent to browser
DEBUG - 2015-10-07 13:49:39 --> Total execution time: 0.1551
DEBUG - 2015-10-07 13:51:24 --> Config Class Initialized
DEBUG - 2015-10-07 13:51:24 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:51:24 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:51:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:51:24 --> URI Class Initialized
DEBUG - 2015-10-07 13:51:24 --> Router Class Initialized
DEBUG - 2015-10-07 13:51:24 --> Output Class Initialized
DEBUG - 2015-10-07 13:51:24 --> Security Class Initialized
DEBUG - 2015-10-07 13:51:24 --> Input Class Initialized
DEBUG - 2015-10-07 13:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:51:24 --> Language Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Config Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:51:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:51:36 --> URI Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Router Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Output Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Security Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Input Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:51:36 --> Language Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Language Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Config Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Loader Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:51:36 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:51:36 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:51:36 --> Session Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:51:36 --> Session routines successfully run
DEBUG - 2015-10-07 13:51:36 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Email Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Controller Class Initialized
DEBUG - 2015-10-07 13:51:36 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:51:36 --> Model Class Initialized
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:51:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:51:36 --> Final output sent to browser
DEBUG - 2015-10-07 13:51:36 --> Total execution time: 0.3479
DEBUG - 2015-10-07 13:53:43 --> Config Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:53:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:53:43 --> URI Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Router Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Output Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Security Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Input Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:53:43 --> Language Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Language Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Config Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Loader Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:53:43 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:53:43 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:53:43 --> Session Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:53:43 --> Session routines successfully run
DEBUG - 2015-10-07 13:53:43 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Email Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Controller Class Initialized
DEBUG - 2015-10-07 13:53:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:53:43 --> Model Class Initialized
ERROR - 2015-10-07 13:53:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 8
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:53:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:53:43 --> Final output sent to browser
DEBUG - 2015-10-07 13:53:43 --> Total execution time: 0.1721
DEBUG - 2015-10-07 13:55:29 --> Config Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:55:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:55:29 --> URI Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Router Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Output Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Security Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Input Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:55:29 --> Language Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Language Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Config Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Loader Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:55:29 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:55:29 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:55:29 --> Session Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:55:29 --> Session routines successfully run
DEBUG - 2015-10-07 13:55:29 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Email Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Controller Class Initialized
DEBUG - 2015-10-07 13:55:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:55:29 --> Model Class Initialized
ERROR - 2015-10-07 13:55:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 8
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:55:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:55:29 --> Final output sent to browser
DEBUG - 2015-10-07 13:55:29 --> Total execution time: 0.1419
DEBUG - 2015-10-07 13:55:50 --> Config Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:55:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:55:50 --> URI Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Router Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Output Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Security Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Input Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:55:50 --> Language Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Language Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Config Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Loader Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:55:50 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:55:50 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:55:50 --> Session Class Initialized
DEBUG - 2015-10-07 13:55:50 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:55:50 --> Session routines successfully run
DEBUG - 2015-10-07 13:55:51 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:55:51 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:55:51 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:55:51 --> Email Class Initialized
DEBUG - 2015-10-07 13:55:51 --> Controller Class Initialized
DEBUG - 2015-10-07 13:55:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:55:51 --> Model Class Initialized
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:55:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:55:51 --> Final output sent to browser
DEBUG - 2015-10-07 13:55:51 --> Total execution time: 0.2133
DEBUG - 2015-10-07 13:56:17 --> Config Class Initialized
DEBUG - 2015-10-07 13:56:17 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:56:17 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:56:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:56:17 --> URI Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Router Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Output Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Security Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Input Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:56:18 --> Language Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Language Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Config Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Loader Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:56:18 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:56:18 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:56:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:56:18 --> Session Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:56:18 --> Session routines successfully run
DEBUG - 2015-10-07 13:56:18 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Email Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Controller Class Initialized
DEBUG - 2015-10-07 13:56:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:56:18 --> Model Class Initialized
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:56:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:56:18 --> Final output sent to browser
DEBUG - 2015-10-07 13:56:18 --> Total execution time: 0.2844
DEBUG - 2015-10-07 13:57:02 --> Config Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:57:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:57:02 --> URI Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Router Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Output Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Security Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Input Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:57:02 --> Language Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Language Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Config Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Loader Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:57:02 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:57:02 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:57:02 --> Session Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:57:02 --> Session routines successfully run
DEBUG - 2015-10-07 13:57:02 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Email Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Controller Class Initialized
DEBUG - 2015-10-07 13:57:02 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:57:02 --> Model Class Initialized
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:57:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:57:02 --> Final output sent to browser
DEBUG - 2015-10-07 13:57:02 --> Total execution time: 0.2661
DEBUG - 2015-10-07 13:57:18 --> Config Class Initialized
DEBUG - 2015-10-07 13:57:18 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:57:18 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:57:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:57:18 --> URI Class Initialized
DEBUG - 2015-10-07 13:57:18 --> Router Class Initialized
ERROR - 2015-10-07 13:57:18 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 13:58:10 --> Config Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:58:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:58:10 --> URI Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Router Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Output Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Security Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Input Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:58:10 --> Language Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Language Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Config Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Loader Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:58:10 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:58:10 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:58:10 --> Session Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:58:10 --> Session routines successfully run
DEBUG - 2015-10-07 13:58:10 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Email Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Controller Class Initialized
DEBUG - 2015-10-07 13:58:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:58:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:58:10 --> Final output sent to browser
DEBUG - 2015-10-07 13:58:10 --> Total execution time: 0.1485
DEBUG - 2015-10-07 13:58:12 --> Config Class Initialized
DEBUG - 2015-10-07 13:58:12 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:58:12 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:58:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:58:12 --> URI Class Initialized
DEBUG - 2015-10-07 13:58:12 --> Router Class Initialized
ERROR - 2015-10-07 13:58:12 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 13:59:13 --> Config Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:59:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:59:13 --> URI Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Router Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Output Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Security Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Input Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:59:13 --> Language Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Language Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Config Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Loader Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:59:13 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:59:13 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:59:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:59:13 --> Session Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:59:13 --> Session routines successfully run
DEBUG - 2015-10-07 13:59:13 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Email Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Controller Class Initialized
DEBUG - 2015-10-07 13:59:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:59:13 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:59:13 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:59:13 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:59:13 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:59:13 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:59:13 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:59:13 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:59:14 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:59:14 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:59:14 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:59:14 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:59:14 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:59:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:59:14 --> Final output sent to browser
DEBUG - 2015-10-07 13:59:14 --> Total execution time: 0.3123
DEBUG - 2015-10-07 13:59:15 --> Config Class Initialized
DEBUG - 2015-10-07 13:59:15 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:59:15 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:59:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:59:15 --> URI Class Initialized
DEBUG - 2015-10-07 13:59:15 --> Router Class Initialized
ERROR - 2015-10-07 13:59:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 13:59:33 --> Config Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:59:33 --> URI Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Router Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Output Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Security Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Input Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 13:59:33 --> Language Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Language Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Config Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Loader Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Helper loaded: url_helper
DEBUG - 2015-10-07 13:59:33 --> Helper loaded: form_helper
DEBUG - 2015-10-07 13:59:33 --> Database Driver Class Initialized
ERROR - 2015-10-07 13:59:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 13:59:33 --> Session Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Helper loaded: string_helper
DEBUG - 2015-10-07 13:59:33 --> Session routines successfully run
DEBUG - 2015-10-07 13:59:33 --> Form Validation Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Pagination Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Encrypt Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Email Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Controller Class Initialized
DEBUG - 2015-10-07 13:59:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 13:59:33 --> Model Class Initialized
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 13:59:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 13:59:33 --> Final output sent to browser
DEBUG - 2015-10-07 13:59:33 --> Total execution time: 0.2140
DEBUG - 2015-10-07 13:59:34 --> Config Class Initialized
DEBUG - 2015-10-07 13:59:34 --> Hooks Class Initialized
DEBUG - 2015-10-07 13:59:34 --> Utf8 Class Initialized
DEBUG - 2015-10-07 13:59:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 13:59:34 --> URI Class Initialized
DEBUG - 2015-10-07 13:59:34 --> Router Class Initialized
ERROR - 2015-10-07 13:59:34 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:00:54 --> Config Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:00:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:00:54 --> URI Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Router Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Output Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Security Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Input Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:00:54 --> Language Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Language Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Config Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Loader Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:00:54 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:00:54 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:00:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:00:54 --> Session Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:00:54 --> Session routines successfully run
DEBUG - 2015-10-07 14:00:54 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Email Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Controller Class Initialized
DEBUG - 2015-10-07 14:00:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:00:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:00:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:00:54 --> Final output sent to browser
DEBUG - 2015-10-07 14:00:54 --> Total execution time: 0.1885
DEBUG - 2015-10-07 14:00:56 --> Config Class Initialized
DEBUG - 2015-10-07 14:00:56 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:00:56 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:00:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:00:56 --> URI Class Initialized
DEBUG - 2015-10-07 14:00:56 --> Router Class Initialized
ERROR - 2015-10-07 14:00:56 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:01:44 --> Config Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:01:44 --> URI Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Router Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Output Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Security Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Input Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:01:44 --> Language Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Language Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Config Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Loader Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:01:44 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:01:44 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:01:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:01:44 --> Session Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:01:44 --> Session routines successfully run
DEBUG - 2015-10-07 14:01:44 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Email Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Controller Class Initialized
DEBUG - 2015-10-07 14:01:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:01:44 --> Model Class Initialized
ERROR - 2015-10-07 14:01:44 --> Severity: Notice  --> Undefined variable: interest_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:01:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:01:44 --> Final output sent to browser
DEBUG - 2015-10-07 14:01:44 --> Total execution time: 0.1864
DEBUG - 2015-10-07 14:01:45 --> Config Class Initialized
DEBUG - 2015-10-07 14:01:45 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:01:45 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:01:45 --> URI Class Initialized
DEBUG - 2015-10-07 14:01:45 --> Router Class Initialized
ERROR - 2015-10-07 14:01:45 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:03:13 --> Config Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:03:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:03:13 --> URI Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Router Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Output Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Security Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Input Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:03:13 --> Language Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Language Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Config Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Loader Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:03:13 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:03:13 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:03:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:03:13 --> Session Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:03:13 --> Session routines successfully run
DEBUG - 2015-10-07 14:03:13 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Email Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Controller Class Initialized
DEBUG - 2015-10-07 14:03:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:03:13 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Config Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:03:22 --> URI Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Router Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Output Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Security Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Input Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:03:22 --> Language Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Language Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Config Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Loader Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:03:22 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:03:22 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:03:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:03:22 --> Session Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:03:22 --> Session routines successfully run
DEBUG - 2015-10-07 14:03:22 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Email Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Controller Class Initialized
DEBUG - 2015-10-07 14:03:22 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:03:22 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:03:22 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:03:22 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:03:22 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:03:22 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:03:22 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:03:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:03:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:03:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:03:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:03:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:23 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:03:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Config Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:03:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:03:33 --> URI Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Router Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Output Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Security Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Input Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:03:33 --> Language Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Language Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Config Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Loader Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:03:33 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:03:33 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:03:33 --> Session Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:03:33 --> Session routines successfully run
DEBUG - 2015-10-07 14:03:33 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Email Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Controller Class Initialized
DEBUG - 2015-10-07 14:03:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:03:33 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:03:33 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:03:34 --> Model Class Initialized
ERROR - 2015-10-07 14:03:34 --> Severity: Notice  --> Undefined variable: customer_id C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
ERROR - 2015-10-07 14:03:34 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:03:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:03:34 --> Final output sent to browser
DEBUG - 2015-10-07 14:03:34 --> Total execution time: 0.1566
DEBUG - 2015-10-07 14:03:35 --> Config Class Initialized
DEBUG - 2015-10-07 14:03:35 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:03:35 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:03:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:03:35 --> URI Class Initialized
DEBUG - 2015-10-07 14:03:35 --> Router Class Initialized
ERROR - 2015-10-07 14:03:35 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:04:37 --> Config Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:04:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:04:37 --> URI Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Router Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Output Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Security Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Input Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:04:37 --> Language Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Language Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Config Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Loader Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:04:37 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:04:37 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:04:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:04:37 --> Session Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:04:37 --> Session routines successfully run
DEBUG - 2015-10-07 14:04:37 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Email Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Controller Class Initialized
DEBUG - 2015-10-07 14:04:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:04:37 --> Model Class Initialized
ERROR - 2015-10-07 14:04:37 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:04:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:04:37 --> Final output sent to browser
DEBUG - 2015-10-07 14:04:37 --> Total execution time: 0.3659
DEBUG - 2015-10-07 14:04:38 --> Config Class Initialized
DEBUG - 2015-10-07 14:04:38 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:04:38 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:04:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:04:38 --> URI Class Initialized
DEBUG - 2015-10-07 14:04:39 --> Router Class Initialized
ERROR - 2015-10-07 14:04:39 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:05:14 --> Config Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:05:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:05:14 --> URI Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Router Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Output Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Security Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Input Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:05:14 --> Language Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Language Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Config Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Loader Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:05:14 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:05:14 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:05:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:05:14 --> Session Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:05:14 --> Session routines successfully run
DEBUG - 2015-10-07 14:05:14 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Email Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Controller Class Initialized
DEBUG - 2015-10-07 14:05:14 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:05:14 --> Model Class Initialized
ERROR - 2015-10-07 14:05:14 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:05:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:05:14 --> Final output sent to browser
DEBUG - 2015-10-07 14:05:14 --> Total execution time: 0.1596
DEBUG - 2015-10-07 14:05:15 --> Config Class Initialized
DEBUG - 2015-10-07 14:05:15 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:05:15 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:05:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:05:15 --> URI Class Initialized
DEBUG - 2015-10-07 14:05:15 --> Router Class Initialized
ERROR - 2015-10-07 14:05:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:05:49 --> Config Class Initialized
DEBUG - 2015-10-07 14:05:49 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:05:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:05:50 --> URI Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Router Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Output Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Security Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Input Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:05:50 --> Language Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Language Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Config Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Loader Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:05:50 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:05:50 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:05:50 --> Session Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:05:50 --> Session routines successfully run
DEBUG - 2015-10-07 14:05:50 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Email Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Controller Class Initialized
DEBUG - 2015-10-07 14:05:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:05:50 --> Model Class Initialized
ERROR - 2015-10-07 14:05:50 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:05:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:05:50 --> Final output sent to browser
DEBUG - 2015-10-07 14:05:50 --> Total execution time: 0.2776
DEBUG - 2015-10-07 14:05:51 --> Config Class Initialized
DEBUG - 2015-10-07 14:05:51 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:05:51 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:05:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:05:51 --> URI Class Initialized
DEBUG - 2015-10-07 14:05:51 --> Router Class Initialized
ERROR - 2015-10-07 14:05:51 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:06:27 --> Config Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:06:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:06:27 --> URI Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Router Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Output Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Security Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Input Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:06:27 --> Language Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Language Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Config Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Loader Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:06:27 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:06:27 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:06:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:06:27 --> Session Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:06:27 --> Session routines successfully run
DEBUG - 2015-10-07 14:06:27 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Email Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Controller Class Initialized
DEBUG - 2015-10-07 14:06:27 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:06:27 --> Model Class Initialized
ERROR - 2015-10-07 14:06:27 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:06:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:06:27 --> Final output sent to browser
DEBUG - 2015-10-07 14:06:27 --> Total execution time: 0.2903
DEBUG - 2015-10-07 14:06:28 --> Config Class Initialized
DEBUG - 2015-10-07 14:06:28 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:06:28 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:06:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:06:28 --> URI Class Initialized
DEBUG - 2015-10-07 14:06:28 --> Router Class Initialized
ERROR - 2015-10-07 14:06:28 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:06:54 --> Config Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:06:54 --> URI Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Router Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Output Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Security Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Input Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:06:54 --> Language Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Language Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Config Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Loader Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:06:54 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:06:54 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:06:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:06:54 --> Session Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:06:54 --> Session routines successfully run
DEBUG - 2015-10-07 14:06:54 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Email Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Controller Class Initialized
DEBUG - 2015-10-07 14:06:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:06:54 --> Model Class Initialized
ERROR - 2015-10-07 14:06:54 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:06:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:06:54 --> Final output sent to browser
DEBUG - 2015-10-07 14:06:54 --> Total execution time: 0.3398
DEBUG - 2015-10-07 14:06:56 --> Config Class Initialized
DEBUG - 2015-10-07 14:06:56 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:06:56 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:06:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:06:56 --> URI Class Initialized
DEBUG - 2015-10-07 14:06:56 --> Router Class Initialized
ERROR - 2015-10-07 14:06:56 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:07:45 --> Config Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:07:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:07:45 --> URI Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Router Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Output Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Security Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Input Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:07:45 --> Language Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Language Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Config Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Loader Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:07:45 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:07:45 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:07:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:07:45 --> Session Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:07:45 --> Session routines successfully run
DEBUG - 2015-10-07 14:07:45 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Email Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Controller Class Initialized
DEBUG - 2015-10-07 14:07:45 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:07:45 --> Model Class Initialized
ERROR - 2015-10-07 14:07:45 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:07:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:07:45 --> Final output sent to browser
DEBUG - 2015-10-07 14:07:45 --> Total execution time: 0.2951
DEBUG - 2015-10-07 14:07:47 --> Config Class Initialized
DEBUG - 2015-10-07 14:07:47 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:07:47 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:07:47 --> URI Class Initialized
DEBUG - 2015-10-07 14:07:47 --> Router Class Initialized
ERROR - 2015-10-07 14:07:47 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:17:02 --> Config Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:17:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:17:02 --> URI Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Router Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Output Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Security Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Input Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:17:02 --> Language Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Language Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Config Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Loader Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:17:02 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:17:02 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:17:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:17:02 --> Session Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:17:02 --> Session routines successfully run
DEBUG - 2015-10-07 14:17:02 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Email Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Controller Class Initialized
DEBUG - 2015-10-07 14:17:02 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:17:02 --> Model Class Initialized
ERROR - 2015-10-07 14:17:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:17:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:17:02 --> Final output sent to browser
DEBUG - 2015-10-07 14:17:02 --> Total execution time: 0.1950
DEBUG - 2015-10-07 14:17:04 --> Config Class Initialized
DEBUG - 2015-10-07 14:17:04 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:17:04 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:17:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:17:04 --> URI Class Initialized
DEBUG - 2015-10-07 14:17:04 --> Router Class Initialized
ERROR - 2015-10-07 14:17:04 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:18:12 --> Config Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:18:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:18:12 --> URI Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Router Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Output Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Security Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Input Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:18:12 --> Language Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Language Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Config Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Loader Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:18:12 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:18:12 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:18:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:18:12 --> Session Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:18:12 --> Session routines successfully run
DEBUG - 2015-10-07 14:18:12 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Email Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Controller Class Initialized
DEBUG - 2015-10-07 14:18:12 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:18:12 --> Model Class Initialized
ERROR - 2015-10-07 14:18:12 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:18:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:18:12 --> Final output sent to browser
DEBUG - 2015-10-07 14:18:12 --> Total execution time: 0.1789
DEBUG - 2015-10-07 14:18:14 --> Config Class Initialized
DEBUG - 2015-10-07 14:18:14 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:18:14 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:18:14 --> URI Class Initialized
DEBUG - 2015-10-07 14:18:14 --> Router Class Initialized
ERROR - 2015-10-07 14:18:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:24:05 --> Config Class Initialized
DEBUG - 2015-10-07 14:24:05 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:24:05 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:24:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:24:05 --> URI Class Initialized
DEBUG - 2015-10-07 14:24:05 --> Router Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Output Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Security Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Input Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:24:06 --> Language Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Language Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Config Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Loader Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:24:06 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:24:06 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:24:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:24:06 --> Session Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:24:06 --> Session routines successfully run
DEBUG - 2015-10-07 14:24:06 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Email Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Controller Class Initialized
DEBUG - 2015-10-07 14:24:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:24:06 --> Model Class Initialized
ERROR - 2015-10-07 14:24:06 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 38
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:24:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:24:06 --> Final output sent to browser
DEBUG - 2015-10-07 14:24:06 --> Total execution time: 0.3305
DEBUG - 2015-10-07 14:24:07 --> Config Class Initialized
DEBUG - 2015-10-07 14:24:07 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:24:07 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:24:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:24:07 --> URI Class Initialized
DEBUG - 2015-10-07 14:24:07 --> Router Class Initialized
ERROR - 2015-10-07 14:24:07 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:27:10 --> Config Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:27:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:27:10 --> URI Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Router Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Output Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Security Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Input Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:27:10 --> Language Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Language Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Config Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Loader Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:27:10 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:27:10 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:27:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:27:10 --> Session Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:27:10 --> Session routines successfully run
DEBUG - 2015-10-07 14:27:10 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Email Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Controller Class Initialized
DEBUG - 2015-10-07 14:27:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:27:10 --> Model Class Initialized
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:27:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:27:10 --> Final output sent to browser
DEBUG - 2015-10-07 14:27:10 --> Total execution time: 0.2100
DEBUG - 2015-10-07 14:27:11 --> Config Class Initialized
DEBUG - 2015-10-07 14:27:11 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:27:11 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:27:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:27:11 --> URI Class Initialized
DEBUG - 2015-10-07 14:27:11 --> Router Class Initialized
ERROR - 2015-10-07 14:27:11 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:28:44 --> Config Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:28:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:28:44 --> URI Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Router Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Output Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Security Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Input Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:28:44 --> Language Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Language Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Config Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Loader Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:28:44 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:28:44 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:28:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:28:44 --> Session Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:28:44 --> Session routines successfully run
DEBUG - 2015-10-07 14:28:44 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Email Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Controller Class Initialized
DEBUG - 2015-10-07 14:28:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:28:44 --> Model Class Initialized
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:28:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:28:44 --> Final output sent to browser
DEBUG - 2015-10-07 14:28:44 --> Total execution time: 0.2935
DEBUG - 2015-10-07 14:28:46 --> Config Class Initialized
DEBUG - 2015-10-07 14:28:46 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:28:46 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:28:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:28:46 --> URI Class Initialized
DEBUG - 2015-10-07 14:28:46 --> Router Class Initialized
ERROR - 2015-10-07 14:28:46 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:31:54 --> Config Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:31:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:31:54 --> URI Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Router Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Output Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Security Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Input Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:31:54 --> Language Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Language Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Config Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Loader Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:31:54 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:31:54 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:31:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:31:54 --> Session Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:31:54 --> Session routines successfully run
DEBUG - 2015-10-07 14:31:54 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Email Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Controller Class Initialized
DEBUG - 2015-10-07 14:31:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:31:54 --> Model Class Initialized
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:31:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:31:54 --> Final output sent to browser
DEBUG - 2015-10-07 14:31:54 --> Total execution time: 0.1632
DEBUG - 2015-10-07 14:31:56 --> Config Class Initialized
DEBUG - 2015-10-07 14:31:56 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:31:56 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:31:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:31:56 --> URI Class Initialized
DEBUG - 2015-10-07 14:31:56 --> Router Class Initialized
ERROR - 2015-10-07 14:31:56 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:32:07 --> Config Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:32:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:32:07 --> URI Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Router Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Output Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Security Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Input Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:32:07 --> Language Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Language Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Config Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Loader Class Initialized
DEBUG - 2015-10-07 14:32:07 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:32:07 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:32:08 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:32:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:32:08 --> Session Class Initialized
DEBUG - 2015-10-07 14:32:08 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:32:08 --> Session routines successfully run
DEBUG - 2015-10-07 14:32:08 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:32:08 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:32:08 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:32:08 --> Email Class Initialized
DEBUG - 2015-10-07 14:32:08 --> Controller Class Initialized
DEBUG - 2015-10-07 14:32:08 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:32:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:32:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:32:08 --> Final output sent to browser
DEBUG - 2015-10-07 14:32:08 --> Total execution time: 0.3111
DEBUG - 2015-10-07 14:32:09 --> Config Class Initialized
DEBUG - 2015-10-07 14:32:09 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:32:09 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:32:09 --> URI Class Initialized
DEBUG - 2015-10-07 14:32:09 --> Router Class Initialized
ERROR - 2015-10-07 14:32:09 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:33:35 --> Config Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:33:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:33:35 --> URI Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Router Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Output Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Security Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Input Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:33:35 --> Language Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Language Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Config Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Loader Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:33:35 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:33:35 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:33:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:33:35 --> Session Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:33:35 --> Session routines successfully run
DEBUG - 2015-10-07 14:33:35 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Email Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Controller Class Initialized
DEBUG - 2015-10-07 14:33:35 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:33:35 --> Model Class Initialized
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:33:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:33:35 --> Final output sent to browser
DEBUG - 2015-10-07 14:33:35 --> Total execution time: 0.1846
DEBUG - 2015-10-07 14:33:36 --> Config Class Initialized
DEBUG - 2015-10-07 14:33:36 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:33:36 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:33:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:33:36 --> URI Class Initialized
DEBUG - 2015-10-07 14:33:36 --> Router Class Initialized
ERROR - 2015-10-07 14:33:36 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:34:08 --> Config Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:34:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:34:08 --> URI Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Router Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Output Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Security Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Input Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:34:08 --> Language Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Language Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Config Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Loader Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:34:08 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:34:08 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:34:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:34:08 --> Session Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:34:08 --> Session routines successfully run
DEBUG - 2015-10-07 14:34:08 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Email Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Controller Class Initialized
DEBUG - 2015-10-07 14:34:08 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:34:08 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:34:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:34:08 --> Final output sent to browser
DEBUG - 2015-10-07 14:34:08 --> Total execution time: 0.2365
DEBUG - 2015-10-07 14:34:10 --> Config Class Initialized
DEBUG - 2015-10-07 14:34:10 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:34:10 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:34:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:34:10 --> URI Class Initialized
DEBUG - 2015-10-07 14:34:10 --> Router Class Initialized
ERROR - 2015-10-07 14:34:10 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:34:36 --> Config Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:34:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:34:36 --> URI Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Router Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Output Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Security Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Input Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:34:36 --> Language Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Language Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Config Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Loader Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:34:36 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:34:36 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:34:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:34:36 --> Session Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:34:36 --> Session routines successfully run
DEBUG - 2015-10-07 14:34:36 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:34:36 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:34:37 --> Email Class Initialized
DEBUG - 2015-10-07 14:34:37 --> Controller Class Initialized
DEBUG - 2015-10-07 14:34:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:34:37 --> Model Class Initialized
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:34:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:34:37 --> Final output sent to browser
DEBUG - 2015-10-07 14:34:37 --> Total execution time: 0.2944
DEBUG - 2015-10-07 14:34:38 --> Config Class Initialized
DEBUG - 2015-10-07 14:34:38 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:34:38 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:34:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:34:38 --> URI Class Initialized
DEBUG - 2015-10-07 14:34:38 --> Router Class Initialized
ERROR - 2015-10-07 14:34:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:34:38 --> Config Class Initialized
DEBUG - 2015-10-07 14:34:38 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:34:38 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:34:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:34:38 --> URI Class Initialized
DEBUG - 2015-10-07 14:34:38 --> Router Class Initialized
ERROR - 2015-10-07 14:34:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:34:38 --> Config Class Initialized
DEBUG - 2015-10-07 14:34:38 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:34:38 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:34:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:34:38 --> URI Class Initialized
DEBUG - 2015-10-07 14:34:38 --> Router Class Initialized
ERROR - 2015-10-07 14:34:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:34:42 --> Config Class Initialized
DEBUG - 2015-10-07 14:34:42 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:34:42 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:34:42 --> URI Class Initialized
DEBUG - 2015-10-07 14:34:42 --> Router Class Initialized
ERROR - 2015-10-07 14:34:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:36:23 --> Config Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:36:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:36:23 --> URI Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Router Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Output Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Security Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Input Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:36:23 --> Language Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Language Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Config Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Loader Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:36:23 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:36:23 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:36:23 --> Session Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:36:23 --> Session routines successfully run
DEBUG - 2015-10-07 14:36:23 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Email Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Controller Class Initialized
DEBUG - 2015-10-07 14:36:23 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:36:23 --> Model Class Initialized
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:36:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:36:23 --> Final output sent to browser
DEBUG - 2015-10-07 14:36:23 --> Total execution time: 0.2210
DEBUG - 2015-10-07 14:36:24 --> Config Class Initialized
DEBUG - 2015-10-07 14:36:24 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:36:24 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:36:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:36:24 --> URI Class Initialized
DEBUG - 2015-10-07 14:36:24 --> Router Class Initialized
ERROR - 2015-10-07 14:36:24 --> 404 Page Not Found --> 
DEBUG - 2015-10-07 14:37:43 --> Config Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:37:43 --> URI Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Router Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Output Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Security Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Input Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-07 14:37:43 --> Language Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Language Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Config Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Loader Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Helper loaded: url_helper
DEBUG - 2015-10-07 14:37:43 --> Helper loaded: form_helper
DEBUG - 2015-10-07 14:37:43 --> Database Driver Class Initialized
ERROR - 2015-10-07 14:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-07 14:37:43 --> Session Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Helper loaded: string_helper
DEBUG - 2015-10-07 14:37:43 --> Session routines successfully run
DEBUG - 2015-10-07 14:37:43 --> Form Validation Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Pagination Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Encrypt Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Email Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Controller Class Initialized
DEBUG - 2015-10-07 14:37:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-07 14:37:43 --> Model Class Initialized
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-07 14:37:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-07 14:37:43 --> Final output sent to browser
DEBUG - 2015-10-07 14:37:43 --> Total execution time: 0.1822
DEBUG - 2015-10-07 14:37:44 --> Config Class Initialized
DEBUG - 2015-10-07 14:37:44 --> Hooks Class Initialized
DEBUG - 2015-10-07 14:37:44 --> Utf8 Class Initialized
DEBUG - 2015-10-07 14:37:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-07 14:37:44 --> URI Class Initialized
DEBUG - 2015-10-07 14:37:44 --> Router Class Initialized
ERROR - 2015-10-07 14:37:44 --> 404 Page Not Found --> 
