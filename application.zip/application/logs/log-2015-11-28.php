<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-11-28 08:25:03 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:03 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:03 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:03 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:03 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:03 --> Router Class Initialized
DEBUG - 2015-11-28 08:25:04 --> No URI present. Default controller set.
DEBUG - 2015-11-28 08:25:04 --> Output Class Initialized
DEBUG - 2015-11-28 08:25:04 --> Security Class Initialized
DEBUG - 2015-11-28 08:25:04 --> Input Class Initialized
DEBUG - 2015-11-28 08:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 08:25:04 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:04 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:04 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:04 --> Loader Class Initialized
DEBUG - 2015-11-28 08:25:05 --> Helper loaded: url_helper
DEBUG - 2015-11-28 08:25:05 --> Helper loaded: form_helper
DEBUG - 2015-11-28 08:25:05 --> Database Driver Class Initialized
ERROR - 2015-11-28 08:25:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 08:25:05 --> Session Class Initialized
DEBUG - 2015-11-28 08:25:05 --> Helper loaded: string_helper
DEBUG - 2015-11-28 08:25:05 --> A session cookie was not found.
DEBUG - 2015-11-28 08:25:05 --> Session routines successfully run
DEBUG - 2015-11-28 08:25:05 --> Form Validation Class Initialized
DEBUG - 2015-11-28 08:25:05 --> Pagination Class Initialized
DEBUG - 2015-11-28 08:25:05 --> Encrypt Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Email Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Controller Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Auth MX_Controller Initialized
DEBUG - 2015-11-28 08:25:06 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 08:25:06 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 08:25:06 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:06 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:06 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Router Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Output Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Security Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Input Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 08:25:06 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Loader Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Helper loaded: url_helper
DEBUG - 2015-11-28 08:25:06 --> Helper loaded: form_helper
DEBUG - 2015-11-28 08:25:06 --> Database Driver Class Initialized
ERROR - 2015-11-28 08:25:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 08:25:06 --> Session Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Helper loaded: string_helper
DEBUG - 2015-11-28 08:25:06 --> Session routines successfully run
DEBUG - 2015-11-28 08:25:06 --> Form Validation Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Pagination Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Encrypt Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Email Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Controller Class Initialized
DEBUG - 2015-11-28 08:25:06 --> Auth MX_Controller Initialized
DEBUG - 2015-11-28 08:25:06 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 08:25:06 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 08:25:06 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 08:25:08 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-11-28 08:25:08 --> Final output sent to browser
DEBUG - 2015-11-28 08:25:08 --> Total execution time: 1.8892
DEBUG - 2015-11-28 08:25:10 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:10 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:10 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:11 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:11 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:11 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:11 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:11 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:11 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:11 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:11 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:11 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Router Class Initialized
DEBUG - 2015-11-28 08:25:11 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Router Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Router Class Initialized
DEBUG - 2015-11-28 08:25:11 --> Router Class Initialized
ERROR - 2015-11-28 08:25:11 --> 404 Page Not Found --> 
ERROR - 2015-11-28 08:25:11 --> 404 Page Not Found --> 
ERROR - 2015-11-28 08:25:11 --> 404 Page Not Found --> 
ERROR - 2015-11-28 08:25:11 --> 404 Page Not Found --> 
DEBUG - 2015-11-28 08:25:19 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:19 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:19 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Router Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Output Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Security Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Input Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 08:25:19 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Loader Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Helper loaded: url_helper
DEBUG - 2015-11-28 08:25:19 --> Helper loaded: form_helper
DEBUG - 2015-11-28 08:25:19 --> Database Driver Class Initialized
ERROR - 2015-11-28 08:25:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 08:25:19 --> Session Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Helper loaded: string_helper
DEBUG - 2015-11-28 08:25:19 --> Session routines successfully run
DEBUG - 2015-11-28 08:25:19 --> Form Validation Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Pagination Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Encrypt Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Email Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Controller Class Initialized
DEBUG - 2015-11-28 08:25:19 --> Auth MX_Controller Initialized
DEBUG - 2015-11-28 08:25:19 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 08:25:19 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 08:25:19 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-11-28 08:25:20 --> XSS Filtering completed
DEBUG - 2015-11-28 08:25:20 --> Unable to find validation rule: exists
DEBUG - 2015-11-28 08:25:20 --> XSS Filtering completed
DEBUG - 2015-11-28 08:25:20 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:20 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:20 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Router Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Output Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Security Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Input Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 08:25:20 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Loader Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Helper loaded: url_helper
DEBUG - 2015-11-28 08:25:20 --> Helper loaded: form_helper
DEBUG - 2015-11-28 08:25:20 --> Database Driver Class Initialized
ERROR - 2015-11-28 08:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 08:25:20 --> Session Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Helper loaded: string_helper
DEBUG - 2015-11-28 08:25:20 --> Session routines successfully run
DEBUG - 2015-11-28 08:25:20 --> Form Validation Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Pagination Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Encrypt Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Email Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Controller Class Initialized
DEBUG - 2015-11-28 08:25:20 --> Admin MX_Controller Initialized
DEBUG - 2015-11-28 08:25:20 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 08:25:20 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 08:25:20 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 08:25:20 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-11-28 08:25:20 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 08:25:20 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-11-28 08:25:20 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:21 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-11-28 08:25:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 08:25:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 08:25:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 08:25:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 08:25:21 --> Final output sent to browser
DEBUG - 2015-11-28 08:25:21 --> Total execution time: 1.3376
DEBUG - 2015-11-28 08:25:32 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:32 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:32 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Router Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Output Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Security Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Input Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 08:25:32 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Loader Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Helper loaded: url_helper
DEBUG - 2015-11-28 08:25:32 --> Helper loaded: form_helper
DEBUG - 2015-11-28 08:25:32 --> Database Driver Class Initialized
ERROR - 2015-11-28 08:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 08:25:32 --> Session Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Helper loaded: string_helper
DEBUG - 2015-11-28 08:25:32 --> Session routines successfully run
DEBUG - 2015-11-28 08:25:32 --> Form Validation Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Pagination Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Encrypt Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Email Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Controller Class Initialized
DEBUG - 2015-11-28 08:25:32 --> Branches MX_Controller Initialized
DEBUG - 2015-11-28 08:25:32 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 08:25:32 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 08:25:32 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 08:25:32 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-11-28 08:25:32 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 08:25:32 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-11-28 08:25:32 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 08:25:32 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:33 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-11-28 08:25:33 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 08:25:33 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:33 --> Image Lib Class Initialized
DEBUG - 2015-11-28 08:25:33 --> File loaded: application/modules/admin/views/branches/all_branches.php
DEBUG - 2015-11-28 08:25:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 08:25:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 08:25:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 08:25:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 08:25:33 --> Final output sent to browser
DEBUG - 2015-11-28 08:25:33 --> Total execution time: 1.2235
DEBUG - 2015-11-28 08:25:36 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:36 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:36 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:36 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:36 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:36 --> Router Class Initialized
DEBUG - 2015-11-28 08:25:36 --> Output Class Initialized
DEBUG - 2015-11-28 08:25:36 --> Security Class Initialized
DEBUG - 2015-11-28 08:25:36 --> Input Class Initialized
DEBUG - 2015-11-28 08:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 08:25:37 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Language Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Loader Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Helper loaded: url_helper
DEBUG - 2015-11-28 08:25:37 --> Helper loaded: form_helper
DEBUG - 2015-11-28 08:25:37 --> Database Driver Class Initialized
ERROR - 2015-11-28 08:25:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 08:25:37 --> Session Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Helper loaded: string_helper
DEBUG - 2015-11-28 08:25:37 --> Session routines successfully run
DEBUG - 2015-11-28 08:25:37 --> Form Validation Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Pagination Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Encrypt Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Email Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Controller Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Branches MX_Controller Initialized
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 08:25:37 --> Model Class Initialized
DEBUG - 2015-11-28 08:25:37 --> Image Lib Class Initialized
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/views/branches/edit_branch.php
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 08:25:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 08:25:37 --> Final output sent to browser
DEBUG - 2015-11-28 08:25:37 --> Total execution time: 0.9667
DEBUG - 2015-11-28 08:25:38 --> Config Class Initialized
DEBUG - 2015-11-28 08:25:38 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:25:38 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:25:38 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:25:38 --> URI Class Initialized
DEBUG - 2015-11-28 08:25:38 --> Router Class Initialized
ERROR - 2015-11-28 08:25:38 --> 404 Page Not Found --> 
DEBUG - 2015-11-28 08:26:54 --> Config Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:26:54 --> URI Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Router Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Output Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Security Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Input Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 08:26:54 --> Language Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Language Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Config Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Loader Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Helper loaded: url_helper
DEBUG - 2015-11-28 08:26:54 --> Helper loaded: form_helper
DEBUG - 2015-11-28 08:26:54 --> Database Driver Class Initialized
ERROR - 2015-11-28 08:26:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 08:26:54 --> Session Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Helper loaded: string_helper
DEBUG - 2015-11-28 08:26:54 --> Session routines successfully run
DEBUG - 2015-11-28 08:26:54 --> Form Validation Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Pagination Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Encrypt Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Email Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Controller Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Branches MX_Controller Initialized
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 08:26:54 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Image Lib Class Initialized
DEBUG - 2015-11-28 08:26:54 --> Upload Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> XSS Filtering completed
DEBUG - 2015-11-28 08:26:55 --> Config Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:26:55 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:26:55 --> URI Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Router Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Output Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Security Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Input Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 08:26:55 --> Language Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Language Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Config Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Loader Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Helper loaded: url_helper
DEBUG - 2015-11-28 08:26:55 --> Helper loaded: form_helper
DEBUG - 2015-11-28 08:26:55 --> Database Driver Class Initialized
ERROR - 2015-11-28 08:26:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 08:26:55 --> Session Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Helper loaded: string_helper
DEBUG - 2015-11-28 08:26:55 --> Session routines successfully run
DEBUG - 2015-11-28 08:26:55 --> Form Validation Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Pagination Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Encrypt Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Email Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Controller Class Initialized
DEBUG - 2015-11-28 08:26:55 --> Branches MX_Controller Initialized
DEBUG - 2015-11-28 08:26:55 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 08:26:55 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 08:26:55 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 08:26:56 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-11-28 08:26:56 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 08:26:56 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-11-28 08:26:56 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 08:26:56 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-11-28 08:26:56 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 08:26:56 --> Model Class Initialized
DEBUG - 2015-11-28 08:26:56 --> Image Lib Class Initialized
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/views/branches/all_branches.php
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 08:26:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 08:26:56 --> Final output sent to browser
DEBUG - 2015-11-28 08:26:56 --> Total execution time: 0.8186
DEBUG - 2015-11-28 08:53:49 --> Config Class Initialized
DEBUG - 2015-11-28 08:53:50 --> Hooks Class Initialized
DEBUG - 2015-11-28 08:53:50 --> Utf8 Class Initialized
DEBUG - 2015-11-28 08:53:50 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 08:53:50 --> URI Class Initialized
DEBUG - 2015-11-28 08:53:50 --> Router Class Initialized
DEBUG - 2015-11-28 08:53:50 --> Output Class Initialized
DEBUG - 2015-11-28 08:53:50 --> Security Class Initialized
DEBUG - 2015-11-28 08:53:50 --> Input Class Initialized
DEBUG - 2015-11-28 08:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 08:53:50 --> Language Class Initialized
DEBUG - 2015-11-28 08:53:50 --> Language Class Initialized
DEBUG - 2015-11-28 08:53:50 --> Config Class Initialized
DEBUG - 2015-11-28 08:53:51 --> Loader Class Initialized
DEBUG - 2015-11-28 08:53:51 --> Helper loaded: url_helper
DEBUG - 2015-11-28 08:53:51 --> Helper loaded: form_helper
DEBUG - 2015-11-28 08:53:52 --> Database Driver Class Initialized
ERROR - 2015-11-28 08:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 08:53:52 --> Session Class Initialized
DEBUG - 2015-11-28 08:53:52 --> Helper loaded: string_helper
DEBUG - 2015-11-28 08:53:52 --> Session routines successfully run
DEBUG - 2015-11-28 08:53:52 --> Form Validation Class Initialized
DEBUG - 2015-11-28 08:53:52 --> Pagination Class Initialized
DEBUG - 2015-11-28 08:53:52 --> Encrypt Class Initialized
DEBUG - 2015-11-28 08:53:52 --> Email Class Initialized
DEBUG - 2015-11-28 08:53:52 --> Controller Class Initialized
DEBUG - 2015-11-28 08:53:52 --> Individual MX_Controller Initialized
DEBUG - 2015-11-28 08:53:52 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 08:53:52 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 08:53:52 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 08:53:52 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 08:53:53 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 08:53:53 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 08:53:53 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 08:53:53 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 08:53:53 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 08:53:53 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 08:53:53 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 08:53:53 --> Model Class Initialized
DEBUG - 2015-11-28 08:53:53 --> Image Lib Class Initialized
DEBUG - 2015-11-28 08:53:53 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-11-28 08:53:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 08:53:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 08:53:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 08:53:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 08:53:54 --> Final output sent to browser
DEBUG - 2015-11-28 08:53:54 --> Total execution time: 4.5887
DEBUG - 2015-11-28 09:00:10 --> Config Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Hooks Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Utf8 Class Initialized
DEBUG - 2015-11-28 09:00:10 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 09:00:10 --> URI Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Router Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Output Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Security Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Input Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 09:00:10 --> Language Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Language Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Config Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Loader Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Helper loaded: url_helper
DEBUG - 2015-11-28 09:00:10 --> Helper loaded: form_helper
DEBUG - 2015-11-28 09:00:10 --> Database Driver Class Initialized
ERROR - 2015-11-28 09:00:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 09:00:10 --> Session Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Helper loaded: string_helper
DEBUG - 2015-11-28 09:00:10 --> Session routines successfully run
DEBUG - 2015-11-28 09:00:10 --> Form Validation Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Pagination Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Encrypt Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Email Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Controller Class Initialized
DEBUG - 2015-11-28 09:00:10 --> Individual MX_Controller Initialized
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 09:00:11 --> Model Class Initialized
DEBUG - 2015-11-28 09:00:11 --> Image Lib Class Initialized
DEBUG - 2015-11-28 09:00:11 --> DB Transaction Failure
ERROR - 2015-11-28 09:00:11 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-11-28 09:00:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-11-28 09:01:37 --> Config Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Hooks Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Utf8 Class Initialized
DEBUG - 2015-11-28 09:01:37 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 09:01:37 --> URI Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Router Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Output Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Security Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Input Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 09:01:37 --> Language Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Language Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Config Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Loader Class Initialized
DEBUG - 2015-11-28 09:01:37 --> Helper loaded: url_helper
DEBUG - 2015-11-28 09:01:37 --> Helper loaded: form_helper
DEBUG - 2015-11-28 09:01:38 --> Database Driver Class Initialized
ERROR - 2015-11-28 09:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 09:01:38 --> Session Class Initialized
DEBUG - 2015-11-28 09:01:38 --> Helper loaded: string_helper
DEBUG - 2015-11-28 09:01:38 --> Session routines successfully run
DEBUG - 2015-11-28 09:01:38 --> Form Validation Class Initialized
DEBUG - 2015-11-28 09:01:38 --> Pagination Class Initialized
DEBUG - 2015-11-28 09:01:38 --> Encrypt Class Initialized
DEBUG - 2015-11-28 09:01:38 --> Email Class Initialized
DEBUG - 2015-11-28 09:01:38 --> Controller Class Initialized
DEBUG - 2015-11-28 09:01:38 --> Individual MX_Controller Initialized
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 09:01:38 --> Model Class Initialized
DEBUG - 2015-11-28 09:01:38 --> Image Lib Class Initialized
DEBUG - 2015-11-28 09:01:38 --> DB Transaction Failure
ERROR - 2015-11-28 09:01:38 --> Query error: Table 'mfi.religion' doesn't exist
DEBUG - 2015-11-28 09:01:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-11-28 09:02:01 --> Config Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Hooks Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Utf8 Class Initialized
DEBUG - 2015-11-28 09:02:01 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 09:02:01 --> URI Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Router Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Output Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Security Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Input Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 09:02:01 --> Language Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Language Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Config Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Loader Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Helper loaded: url_helper
DEBUG - 2015-11-28 09:02:01 --> Helper loaded: form_helper
DEBUG - 2015-11-28 09:02:01 --> Database Driver Class Initialized
ERROR - 2015-11-28 09:02:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 09:02:01 --> Session Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Helper loaded: string_helper
DEBUG - 2015-11-28 09:02:01 --> Session routines successfully run
DEBUG - 2015-11-28 09:02:01 --> Form Validation Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Pagination Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Encrypt Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Email Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Controller Class Initialized
DEBUG - 2015-11-28 09:02:01 --> Individual MX_Controller Initialized
DEBUG - 2015-11-28 09:02:01 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 09:02:01 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 09:02:01 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 09:02:01 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 09:02:01 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 09:02:01 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 09:02:01 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 09:02:01 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 09:02:01 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 09:02:02 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 09:02:02 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 09:02:02 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:02 --> Image Lib Class Initialized
DEBUG - 2015-11-28 09:02:02 --> DB Transaction Failure
ERROR - 2015-11-28 09:02:02 --> Query error: Table 'mfi.civil_status' doesn't exist
DEBUG - 2015-11-28 09:02:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-11-28 09:02:11 --> Config Class Initialized
DEBUG - 2015-11-28 09:02:11 --> Hooks Class Initialized
DEBUG - 2015-11-28 09:02:11 --> Utf8 Class Initialized
DEBUG - 2015-11-28 09:02:11 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 09:02:11 --> URI Class Initialized
DEBUG - 2015-11-28 09:02:11 --> Router Class Initialized
DEBUG - 2015-11-28 09:02:11 --> Output Class Initialized
DEBUG - 2015-11-28 09:02:11 --> Security Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Input Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 09:02:12 --> Language Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Language Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Config Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Loader Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Helper loaded: url_helper
DEBUG - 2015-11-28 09:02:12 --> Helper loaded: form_helper
DEBUG - 2015-11-28 09:02:12 --> Database Driver Class Initialized
ERROR - 2015-11-28 09:02:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 09:02:12 --> Session Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Helper loaded: string_helper
DEBUG - 2015-11-28 09:02:12 --> Session routines successfully run
DEBUG - 2015-11-28 09:02:12 --> Form Validation Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Pagination Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Encrypt Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Email Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Controller Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Individual MX_Controller Initialized
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 09:02:12 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:12 --> Image Lib Class Initialized
DEBUG - 2015-11-28 09:02:12 --> DB Transaction Failure
ERROR - 2015-11-28 09:02:12 --> Query error: Table 'mfi.gender' doesn't exist
DEBUG - 2015-11-28 09:02:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-11-28 09:02:23 --> Config Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Hooks Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Utf8 Class Initialized
DEBUG - 2015-11-28 09:02:23 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 09:02:23 --> URI Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Router Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Output Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Security Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Input Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 09:02:23 --> Language Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Language Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Config Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Loader Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Helper loaded: url_helper
DEBUG - 2015-11-28 09:02:23 --> Helper loaded: form_helper
DEBUG - 2015-11-28 09:02:23 --> Database Driver Class Initialized
ERROR - 2015-11-28 09:02:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 09:02:23 --> Session Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Helper loaded: string_helper
DEBUG - 2015-11-28 09:02:23 --> Session routines successfully run
DEBUG - 2015-11-28 09:02:23 --> Form Validation Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Pagination Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Encrypt Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Email Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Controller Class Initialized
DEBUG - 2015-11-28 09:02:23 --> Individual MX_Controller Initialized
DEBUG - 2015-11-28 09:02:23 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 09:02:23 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 09:02:23 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 09:02:23 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 09:02:23 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 09:02:23 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 09:02:23 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 09:02:24 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 09:02:24 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 09:02:24 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 09:02:24 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 09:02:24 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:24 --> Image Lib Class Initialized
DEBUG - 2015-11-28 09:02:24 --> DB Transaction Failure
ERROR - 2015-11-28 09:02:24 --> Query error: Table 'mfi.job_title' doesn't exist
DEBUG - 2015-11-28 09:02:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-11-28 09:02:34 --> Config Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Hooks Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Utf8 Class Initialized
DEBUG - 2015-11-28 09:02:34 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 09:02:34 --> URI Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Router Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Output Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Security Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Input Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 09:02:34 --> Language Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Language Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Config Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Loader Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Helper loaded: url_helper
DEBUG - 2015-11-28 09:02:34 --> Helper loaded: form_helper
DEBUG - 2015-11-28 09:02:34 --> Database Driver Class Initialized
ERROR - 2015-11-28 09:02:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 09:02:34 --> Session Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Helper loaded: string_helper
DEBUG - 2015-11-28 09:02:34 --> Session routines successfully run
DEBUG - 2015-11-28 09:02:34 --> Form Validation Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Pagination Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Encrypt Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Email Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Controller Class Initialized
DEBUG - 2015-11-28 09:02:34 --> Individual MX_Controller Initialized
DEBUG - 2015-11-28 09:02:34 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 09:02:35 --> Model Class Initialized
DEBUG - 2015-11-28 09:02:35 --> Image Lib Class Initialized
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/microfinance/views/individual/add_individual.php
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 09:02:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 09:02:35 --> Final output sent to browser
DEBUG - 2015-11-28 09:02:35 --> Total execution time: 1.2077
DEBUG - 2015-11-28 11:15:15 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:15 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:15:15 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:15:15 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:15:15 --> URI Class Initialized
DEBUG - 2015-11-28 11:15:15 --> Router Class Initialized
DEBUG - 2015-11-28 11:15:15 --> Output Class Initialized
DEBUG - 2015-11-28 11:15:15 --> Security Class Initialized
DEBUG - 2015-11-28 11:15:15 --> Input Class Initialized
DEBUG - 2015-11-28 11:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:15:16 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:16 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:16 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:16 --> Loader Class Initialized
DEBUG - 2015-11-28 11:15:16 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:15:16 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:15:16 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:15:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:15:16 --> Session Class Initialized
DEBUG - 2015-11-28 11:15:16 --> Helper loaded: string_helper
ERROR - 2015-11-28 11:15:16 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-11-28 11:15:16 --> Session routines successfully run
DEBUG - 2015-11-28 11:15:16 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:15:16 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:15:17 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:15:17 --> Email Class Initialized
DEBUG - 2015-11-28 11:15:17 --> Controller Class Initialized
DEBUG - 2015-11-28 11:15:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 11:15:17 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:17 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:17 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:15:17 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:15:17 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:15:17 --> URI Class Initialized
DEBUG - 2015-11-28 11:15:17 --> Router Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Output Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Security Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Input Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:15:18 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Loader Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:15:18 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:15:18 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:15:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:15:18 --> Session Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Helper loaded: string_helper
DEBUG - 2015-11-28 11:15:18 --> Session routines successfully run
DEBUG - 2015-11-28 11:15:18 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Email Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Controller Class Initialized
DEBUG - 2015-11-28 11:15:18 --> Auth MX_Controller Initialized
DEBUG - 2015-11-28 11:15:18 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:15:18 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:15:18 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 11:15:18 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-11-28 11:15:18 --> Final output sent to browser
DEBUG - 2015-11-28 11:15:18 --> Total execution time: 0.9447
DEBUG - 2015-11-28 11:15:21 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:15:21 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:15:21 --> URI Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Router Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:15:21 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:15:21 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:15:21 --> URI Class Initialized
ERROR - 2015-11-28 11:15:21 --> 404 Page Not Found --> 
DEBUG - 2015-11-28 11:15:21 --> URI Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Router Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Router Class Initialized
ERROR - 2015-11-28 11:15:21 --> 404 Page Not Found --> 
DEBUG - 2015-11-28 11:15:21 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Utf8 Class Initialized
ERROR - 2015-11-28 11:15:21 --> 404 Page Not Found --> 
DEBUG - 2015-11-28 11:15:21 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:15:21 --> URI Class Initialized
DEBUG - 2015-11-28 11:15:21 --> Router Class Initialized
ERROR - 2015-11-28 11:15:21 --> 404 Page Not Found --> 
DEBUG - 2015-11-28 11:15:34 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:15:34 --> URI Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Router Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Output Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Security Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Input Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:15:34 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Loader Class Initialized
DEBUG - 2015-11-28 11:15:34 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:15:34 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:15:34 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:15:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:15:35 --> Session Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Helper loaded: string_helper
DEBUG - 2015-11-28 11:15:35 --> Session routines successfully run
DEBUG - 2015-11-28 11:15:35 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Email Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Controller Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Auth MX_Controller Initialized
DEBUG - 2015-11-28 11:15:35 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:15:35 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:15:35 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-11-28 11:15:35 --> XSS Filtering completed
DEBUG - 2015-11-28 11:15:35 --> Unable to find validation rule: exists
DEBUG - 2015-11-28 11:15:35 --> XSS Filtering completed
DEBUG - 2015-11-28 11:15:35 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:15:35 --> URI Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Router Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Output Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Security Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Input Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:15:35 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Loader Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:15:35 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:15:35 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:15:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:15:35 --> Session Class Initialized
DEBUG - 2015-11-28 11:15:35 --> Helper loaded: string_helper
DEBUG - 2015-11-28 11:15:35 --> Session routines successfully run
DEBUG - 2015-11-28 11:15:35 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:15:36 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:15:36 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:15:36 --> Email Class Initialized
DEBUG - 2015-11-28 11:15:36 --> Controller Class Initialized
DEBUG - 2015-11-28 11:15:36 --> Admin MX_Controller Initialized
DEBUG - 2015-11-28 11:15:36 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 11:15:36 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:15:36 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:15:36 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-11-28 11:15:36 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 11:15:36 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-11-28 11:15:36 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 11:15:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 11:15:36 --> Final output sent to browser
DEBUG - 2015-11-28 11:15:36 --> Total execution time: 1.2880
DEBUG - 2015-11-28 11:15:44 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:15:44 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:15:44 --> URI Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Router Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Output Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Security Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Input Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:15:44 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Language Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Config Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Loader Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:15:44 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:15:44 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:15:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:15:44 --> Session Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Helper loaded: string_helper
DEBUG - 2015-11-28 11:15:44 --> Session routines successfully run
DEBUG - 2015-11-28 11:15:44 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Email Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Controller Class Initialized
DEBUG - 2015-11-28 11:15:44 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-11-28 11:15:44 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:15:44 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 11:15:45 --> Model Class Initialized
DEBUG - 2015-11-28 11:15:45 --> DB Transaction Failure
ERROR - 2015-11-28 11:15:45 --> Query error: Table 'mfi.loans_plan' doesn't exist
DEBUG - 2015-11-28 11:15:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-11-28 11:17:15 --> Config Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:17:15 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:17:15 --> URI Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Router Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Output Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Security Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Input Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:17:15 --> Language Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Language Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Config Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Loader Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:17:15 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:17:15 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:17:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:17:15 --> Session Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Helper loaded: string_helper
DEBUG - 2015-11-28 11:17:15 --> Session routines successfully run
DEBUG - 2015-11-28 11:17:15 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Email Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Controller Class Initialized
DEBUG - 2015-11-28 11:17:15 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 11:17:15 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:16 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-11-28 11:17:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 11:17:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 11:17:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 11:17:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 11:17:16 --> Final output sent to browser
DEBUG - 2015-11-28 11:17:16 --> Total execution time: 1.2928
DEBUG - 2015-11-28 11:17:26 --> Config Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:17:26 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:17:26 --> URI Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Router Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Output Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Security Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Input Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:17:26 --> Language Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Language Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Config Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Loader Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:17:26 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:17:26 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:17:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:17:26 --> Session Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Helper loaded: string_helper
DEBUG - 2015-11-28 11:17:26 --> Session routines successfully run
DEBUG - 2015-11-28 11:17:26 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Email Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Controller Class Initialized
DEBUG - 2015-11-28 11:17:26 --> Microfinance MX_Controller Initialized
DEBUG - 2015-11-28 11:17:26 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:17:26 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:17:26 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 11:17:26 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 11:17:27 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 11:17:27 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 11:17:27 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 11:17:27 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 11:17:27 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 11:17:27 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 11:17:27 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:27 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 11:17:27 --> Model Class Initialized
ERROR - 2015-11-28 11:17:27 --> 404 Page Not Found --> microfinance/deposits
DEBUG - 2015-11-28 11:17:39 --> Config Class Initialized
DEBUG - 2015-11-28 11:17:39 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:17:39 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:17:40 --> URI Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Router Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Output Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Security Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Input Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:17:40 --> Language Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Language Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Config Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Loader Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:17:40 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:17:40 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:17:40 --> Session Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Helper loaded: string_helper
DEBUG - 2015-11-28 11:17:40 --> Session routines successfully run
DEBUG - 2015-11-28 11:17:40 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Email Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Controller Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Individual MX_Controller Initialized
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 11:17:40 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:40 --> Image Lib Class Initialized
DEBUG - 2015-11-28 11:17:41 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-11-28 11:17:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 11:17:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 11:17:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 11:17:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 11:17:41 --> Final output sent to browser
DEBUG - 2015-11-28 11:17:41 --> Total execution time: 1.3875
DEBUG - 2015-11-28 11:17:46 --> Config Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:17:46 --> URI Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Router Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Output Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Security Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Input Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:17:46 --> Language Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Language Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Config Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Loader Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:17:46 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:17:46 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:17:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:17:46 --> Session Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Helper loaded: string_helper
DEBUG - 2015-11-28 11:17:46 --> Session routines successfully run
DEBUG - 2015-11-28 11:17:46 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Email Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Controller Class Initialized
DEBUG - 2015-11-28 11:17:46 --> Individual MX_Controller Initialized
DEBUG - 2015-11-28 11:17:46 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:17:46 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:17:46 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 11:17:46 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 11:17:46 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 11:17:47 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 11:17:47 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 11:17:47 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 11:17:47 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 11:17:47 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 11:17:47 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 11:17:47 --> Model Class Initialized
DEBUG - 2015-11-28 11:17:47 --> Image Lib Class Initialized
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 11:17:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 11:17:48 --> Final output sent to browser
DEBUG - 2015-11-28 11:17:48 --> Total execution time: 2.2938
DEBUG - 2015-11-28 11:18:09 --> Config Class Initialized
DEBUG - 2015-11-28 11:18:09 --> Hooks Class Initialized
DEBUG - 2015-11-28 11:18:09 --> Utf8 Class Initialized
DEBUG - 2015-11-28 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2015-11-28 11:18:09 --> URI Class Initialized
DEBUG - 2015-11-28 11:18:09 --> Router Class Initialized
DEBUG - 2015-11-28 11:18:09 --> Output Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Security Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Input Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-28 11:18:10 --> Language Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Language Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Config Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Loader Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Helper loaded: url_helper
DEBUG - 2015-11-28 11:18:10 --> Helper loaded: form_helper
DEBUG - 2015-11-28 11:18:10 --> Database Driver Class Initialized
ERROR - 2015-11-28 11:18:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-11-28 11:18:10 --> Session Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Helper loaded: string_helper
DEBUG - 2015-11-28 11:18:10 --> Session routines successfully run
DEBUG - 2015-11-28 11:18:10 --> Form Validation Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Pagination Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Encrypt Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Email Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Controller Class Initialized
DEBUG - 2015-11-28 11:18:10 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-11-28 11:18:10 --> Model Class Initialized
DEBUG - 2015-11-28 11:18:11 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-11-28 11:18:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-11-28 11:18:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-11-28 11:18:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-11-28 11:18:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-11-28 11:18:11 --> Final output sent to browser
DEBUG - 2015-11-28 11:18:11 --> Total execution time: 1.5660
