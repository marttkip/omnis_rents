<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-11 00:00:29 --> Config Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:00:29 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:00:29 --> URI Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Router Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Output Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Security Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Input Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:00:29 --> Language Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Language Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Config Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Loader Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:00:29 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:00:29 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Session Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:00:29 --> Session routines successfully run
DEBUG - 2016-02-11 00:00:29 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Email Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Controller Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:00:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:29 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:00:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:00:29 --> Final output sent to browser
DEBUG - 2016-02-11 00:00:29 --> Total execution time: 0.2652
DEBUG - 2016-02-11 00:00:34 --> Config Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:00:34 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:00:34 --> URI Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Router Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Output Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Security Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Input Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:00:34 --> Language Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Language Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Config Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Loader Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:00:34 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:00:34 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Session Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:00:34 --> Session routines successfully run
DEBUG - 2016-02-11 00:00:34 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Email Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Controller Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:00:34 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:34 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:00:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:00:34 --> Final output sent to browser
DEBUG - 2016-02-11 00:00:34 --> Total execution time: 0.2705
DEBUG - 2016-02-11 00:00:38 --> Config Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:00:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:00:38 --> URI Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Router Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Output Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Security Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Input Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:00:38 --> Language Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Language Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Config Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Loader Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:00:38 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:00:38 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Session Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:00:38 --> Session routines successfully run
DEBUG - 2016-02-11 00:00:38 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Email Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Controller Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 00:00:38 --> Model Class Initialized
DEBUG - 2016-02-11 00:00:38 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:00:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:00:38 --> Final output sent to browser
DEBUG - 2016-02-11 00:00:38 --> Total execution time: 0.4323
DEBUG - 2016-02-11 00:00:48 --> Config Class Initialized
DEBUG - 2016-02-11 00:00:48 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:00:48 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:00:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:00:48 --> URI Class Initialized
DEBUG - 2016-02-11 00:00:48 --> Router Class Initialized
ERROR - 2016-02-11 00:00:48 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 00:01:42 --> Config Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:01:42 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:01:42 --> URI Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Router Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Output Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Security Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Input Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:01:42 --> Language Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Language Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Config Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Loader Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:01:42 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:01:42 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Session Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:01:42 --> Session routines successfully run
DEBUG - 2016-02-11 00:01:42 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Email Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Controller Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 00:01:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:01:42 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:01:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:01:42 --> Final output sent to browser
DEBUG - 2016-02-11 00:01:42 --> Total execution time: 0.3244
DEBUG - 2016-02-11 00:09:25 --> Config Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:09:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:09:25 --> URI Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Router Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Output Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Security Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Input Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:09:25 --> Language Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Language Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Config Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Loader Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:09:25 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:09:25 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Session Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:09:25 --> Session routines successfully run
DEBUG - 2016-02-11 00:09:25 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Email Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Controller Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 00:09:25 --> Model Class Initialized
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:09:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:09:25 --> Final output sent to browser
DEBUG - 2016-02-11 00:09:25 --> Total execution time: 0.3609
DEBUG - 2016-02-11 00:16:28 --> Config Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:16:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:16:28 --> URI Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Router Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Output Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Security Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Input Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:16:28 --> Language Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Language Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Config Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Loader Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:16:28 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:16:28 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Session Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:16:28 --> Session routines successfully run
DEBUG - 2016-02-11 00:16:28 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Email Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Controller Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 00:16:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:16:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:16:28 --> Final output sent to browser
DEBUG - 2016-02-11 00:16:28 --> Total execution time: 0.3373
DEBUG - 2016-02-11 00:16:42 --> Config Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:16:42 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:16:42 --> URI Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Router Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Output Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Security Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Input Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:16:42 --> Language Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Language Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Config Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Loader Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:16:42 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:16:42 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Session Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:16:42 --> Session routines successfully run
DEBUG - 2016-02-11 00:16:42 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Email Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Controller Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 00:16:42 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:16:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:16:42 --> Final output sent to browser
DEBUG - 2016-02-11 00:16:42 --> Total execution time: 0.2815
DEBUG - 2016-02-11 00:16:59 --> Config Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:16:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:16:59 --> URI Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Router Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Output Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Security Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Input Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:16:59 --> Language Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Language Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Config Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Loader Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:16:59 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:16:59 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Session Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:16:59 --> Session routines successfully run
DEBUG - 2016-02-11 00:16:59 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Email Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Controller Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 00:16:59 --> Model Class Initialized
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:16:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:16:59 --> Final output sent to browser
DEBUG - 2016-02-11 00:16:59 --> Total execution time: 0.2936
DEBUG - 2016-02-11 00:17:28 --> Config Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:17:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:17:28 --> URI Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Router Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Output Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Security Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Input Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:17:28 --> Language Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Language Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Config Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Loader Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:17:28 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:17:28 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Session Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:17:28 --> Session routines successfully run
DEBUG - 2016-02-11 00:17:28 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Email Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Controller Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 00:17:28 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 00:17:28 --> XSS Filtering completed
DEBUG - 2016-02-11 00:17:28 --> XSS Filtering completed
DEBUG - 2016-02-11 00:17:28 --> XSS Filtering completed
DEBUG - 2016-02-11 00:17:28 --> XSS Filtering completed
DEBUG - 2016-02-11 00:17:28 --> Config Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:17:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:17:28 --> URI Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Router Class Initialized
DEBUG - 2016-02-11 00:17:28 --> Output Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Security Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Input Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:17:29 --> Language Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Language Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Config Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Loader Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:17:29 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:17:29 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Session Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:17:29 --> Session routines successfully run
DEBUG - 2016-02-11 00:17:29 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Email Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Controller Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 00:17:29 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:17:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:17:29 --> Final output sent to browser
DEBUG - 2016-02-11 00:17:29 --> Total execution time: 0.2795
DEBUG - 2016-02-11 00:17:33 --> Config Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Hooks Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Utf8 Class Initialized
DEBUG - 2016-02-11 00:17:33 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 00:17:33 --> URI Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Router Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Output Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Security Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Input Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 00:17:33 --> Language Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Language Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Config Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Loader Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Helper loaded: url_helper
DEBUG - 2016-02-11 00:17:33 --> Helper loaded: form_helper
DEBUG - 2016-02-11 00:17:33 --> Database Driver Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Session Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Helper loaded: string_helper
DEBUG - 2016-02-11 00:17:33 --> Session routines successfully run
DEBUG - 2016-02-11 00:17:33 --> Form Validation Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Pagination Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Encrypt Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Email Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Controller Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> Image Lib Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 00:17:33 --> Model Class Initialized
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 00:17:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 00:17:33 --> Final output sent to browser
DEBUG - 2016-02-11 00:17:33 --> Total execution time: 0.3758
DEBUG - 2016-02-11 17:44:52 --> Config Class Initialized
DEBUG - 2016-02-11 17:44:53 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:44:53 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:44:53 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:44:53 --> URI Class Initialized
DEBUG - 2016-02-11 17:44:53 --> Router Class Initialized
DEBUG - 2016-02-11 17:44:56 --> Output Class Initialized
DEBUG - 2016-02-11 17:44:56 --> Security Class Initialized
DEBUG - 2016-02-11 17:44:56 --> Input Class Initialized
DEBUG - 2016-02-11 17:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:44:56 --> Language Class Initialized
DEBUG - 2016-02-11 17:44:57 --> Language Class Initialized
DEBUG - 2016-02-11 17:44:57 --> Config Class Initialized
DEBUG - 2016-02-11 17:44:57 --> Loader Class Initialized
DEBUG - 2016-02-11 17:44:58 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:44:58 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:44:58 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:45:05 --> Session Class Initialized
DEBUG - 2016-02-11 17:45:05 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:45:05 --> A session cookie was not found.
DEBUG - 2016-02-11 17:45:05 --> Session routines successfully run
DEBUG - 2016-02-11 17:45:05 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:45:06 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:45:06 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:45:06 --> Email Class Initialized
DEBUG - 2016-02-11 17:45:06 --> Controller Class Initialized
DEBUG - 2016-02-11 17:45:06 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 17:45:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:45:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:45:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:45:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:45:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:45:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:45:07 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:08 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:08 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:45:08 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:45:08 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:45:08 --> URI Class Initialized
DEBUG - 2016-02-11 17:45:08 --> Router Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Output Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Security Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Input Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:45:09 --> Language Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Language Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Loader Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:45:09 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:45:09 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Session Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:45:09 --> Session routines successfully run
DEBUG - 2016-02-11 17:45:09 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Email Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Controller Class Initialized
DEBUG - 2016-02-11 17:45:09 --> Auth MX_Controller Initialized
DEBUG - 2016-02-11 17:45:09 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:45:09 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:45:09 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:45:12 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-11 17:45:12 --> Final output sent to browser
DEBUG - 2016-02-11 17:45:12 --> Total execution time: 3.6014
DEBUG - 2016-02-11 17:45:27 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:27 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:45:27 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:45:27 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:45:27 --> URI Class Initialized
DEBUG - 2016-02-11 17:45:27 --> Router Class Initialized
ERROR - 2016-02-11 17:45:27 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 17:45:29 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:29 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:45:29 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:45:29 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:45:29 --> URI Class Initialized
DEBUG - 2016-02-11 17:45:29 --> Router Class Initialized
DEBUG - 2016-02-11 17:45:29 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:29 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:45:29 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:45:30 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:45:30 --> URI Class Initialized
DEBUG - 2016-02-11 17:45:30 --> Router Class Initialized
DEBUG - 2016-02-11 17:45:30 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:30 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:45:30 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:45:30 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:45:30 --> URI Class Initialized
DEBUG - 2016-02-11 17:45:30 --> Router Class Initialized
ERROR - 2016-02-11 17:45:31 --> 404 Page Not Found --> 
ERROR - 2016-02-11 17:45:31 --> 404 Page Not Found --> 
ERROR - 2016-02-11 17:45:32 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 17:45:38 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:45:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:45:38 --> URI Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Router Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Output Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Security Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Input Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:45:38 --> Language Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Language Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:38 --> Loader Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:45:39 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:45:39 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Session Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:45:39 --> Session routines successfully run
DEBUG - 2016-02-11 17:45:39 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Email Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Controller Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Auth MX_Controller Initialized
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:45:39 --> XSS Filtering completed
DEBUG - 2016-02-11 17:45:39 --> Unable to find validation rule: exists
DEBUG - 2016-02-11 17:45:39 --> XSS Filtering completed
DEBUG - 2016-02-11 17:45:39 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:45:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:45:39 --> URI Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Router Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Output Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Security Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Input Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:45:39 --> Language Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Language Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Config Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Loader Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:45:39 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:45:39 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Session Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:45:39 --> Session routines successfully run
DEBUG - 2016-02-11 17:45:39 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Email Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Controller Class Initialized
DEBUG - 2016-02-11 17:45:39 --> Admin MX_Controller Initialized
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:45:39 --> Model Class Initialized
DEBUG - 2016-02-11 17:45:39 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-02-11 17:45:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:45:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:45:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:45:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:45:40 --> Final output sent to browser
DEBUG - 2016-02-11 17:45:40 --> Total execution time: 0.9223
DEBUG - 2016-02-11 17:46:36 --> Config Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:46:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:46:36 --> URI Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Router Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Output Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Security Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Input Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:46:36 --> Language Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Language Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Config Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Loader Class Initialized
DEBUG - 2016-02-11 17:46:36 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:46:36 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:46:36 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:46:37 --> Session Class Initialized
DEBUG - 2016-02-11 17:46:37 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:46:37 --> Session routines successfully run
DEBUG - 2016-02-11 17:46:37 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:46:37 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:46:37 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:46:37 --> Email Class Initialized
DEBUG - 2016-02-11 17:46:37 --> Controller Class Initialized
DEBUG - 2016-02-11 17:46:37 --> Personnel MX_Controller Initialized
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:37 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-02-11 17:46:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:46:38 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2016-02-11 17:46:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:46:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:46:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:46:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:46:38 --> Final output sent to browser
DEBUG - 2016-02-11 17:46:38 --> Total execution time: 1.6191
DEBUG - 2016-02-11 17:47:14 --> Config Class Initialized
DEBUG - 2016-02-11 17:47:14 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:47:14 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:47:14 --> URI Class Initialized
DEBUG - 2016-02-11 17:47:14 --> Router Class Initialized
DEBUG - 2016-02-11 17:47:14 --> Output Class Initialized
DEBUG - 2016-02-11 17:47:14 --> Security Class Initialized
DEBUG - 2016-02-11 17:47:14 --> Input Class Initialized
DEBUG - 2016-02-11 17:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:47:14 --> Language Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Language Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Config Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Loader Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:47:15 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:47:15 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Session Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:47:15 --> Session routines successfully run
DEBUG - 2016-02-11 17:47:15 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Email Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Controller Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:47:15 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:15 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:47:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:47:15 --> Final output sent to browser
DEBUG - 2016-02-11 17:47:15 --> Total execution time: 0.8805
DEBUG - 2016-02-11 17:47:28 --> Config Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:47:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:47:28 --> URI Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Router Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Output Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Security Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Input Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:47:28 --> Language Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Language Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Config Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Loader Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:47:28 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:47:28 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Session Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:47:28 --> Session routines successfully run
DEBUG - 2016-02-11 17:47:28 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Email Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Controller Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:47:28 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:28 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:47:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:47:28 --> Final output sent to browser
DEBUG - 2016-02-11 17:47:28 --> Total execution time: 0.4177
DEBUG - 2016-02-11 17:47:54 --> Config Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:47:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:47:54 --> URI Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Router Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Output Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Security Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Input Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:47:54 --> Language Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Language Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Config Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Loader Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:47:54 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:47:54 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Session Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:47:54 --> Session routines successfully run
DEBUG - 2016-02-11 17:47:54 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Email Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Controller Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:47:54 --> XSS Filtering completed
DEBUG - 2016-02-11 17:47:54 --> XSS Filtering completed
DEBUG - 2016-02-11 17:47:54 --> XSS Filtering completed
DEBUG - 2016-02-11 17:47:54 --> XSS Filtering completed
DEBUG - 2016-02-11 17:47:54 --> XSS Filtering completed
DEBUG - 2016-02-11 17:47:54 --> XSS Filtering completed
DEBUG - 2016-02-11 17:47:54 --> Config Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:47:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:47:54 --> URI Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Router Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Output Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Security Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Input Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:47:54 --> Language Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Language Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Config Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Loader Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:47:54 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:47:54 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Session Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:47:54 --> Session routines successfully run
DEBUG - 2016-02-11 17:47:54 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Email Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Controller Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:47:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:47:54 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:47:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:47:54 --> Final output sent to browser
DEBUG - 2016-02-11 17:47:54 --> Total execution time: 0.3655
DEBUG - 2016-02-11 17:48:05 --> Config Class Initialized
DEBUG - 2016-02-11 17:48:05 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:48:05 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:48:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:48:05 --> URI Class Initialized
DEBUG - 2016-02-11 17:48:05 --> Router Class Initialized
DEBUG - 2016-02-11 17:48:05 --> Output Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Security Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Input Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:48:06 --> Language Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Language Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Config Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Loader Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:48:06 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:48:06 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Session Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:48:06 --> Session routines successfully run
DEBUG - 2016-02-11 17:48:06 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Email Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Controller Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:48:06 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:06 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:48:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:48:06 --> Final output sent to browser
DEBUG - 2016-02-11 17:48:06 --> Total execution time: 0.7075
DEBUG - 2016-02-11 17:48:20 --> Config Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:48:20 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:48:20 --> URI Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Router Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Output Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Security Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Input Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:48:20 --> Language Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Language Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Config Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Loader Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:48:20 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:48:20 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Session Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:48:20 --> Session routines successfully run
DEBUG - 2016-02-11 17:48:20 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Email Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Controller Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:48:20 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:20 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:48:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:48:20 --> Final output sent to browser
DEBUG - 2016-02-11 17:48:20 --> Total execution time: 0.5303
DEBUG - 2016-02-11 17:48:49 --> Config Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:48:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:48:49 --> URI Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Router Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Output Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Security Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Input Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:48:49 --> Language Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Language Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Config Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Loader Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:48:49 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:48:49 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Session Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:48:49 --> Session routines successfully run
DEBUG - 2016-02-11 17:48:49 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Email Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Controller Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:48:49 --> XSS Filtering completed
DEBUG - 2016-02-11 17:48:49 --> XSS Filtering completed
DEBUG - 2016-02-11 17:48:49 --> Config Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:48:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:48:49 --> URI Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Router Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Output Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Security Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Input Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:48:49 --> Language Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Language Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Config Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Loader Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:48:49 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:48:49 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Session Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:48:49 --> Session routines successfully run
DEBUG - 2016-02-11 17:48:49 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Email Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Controller Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:48:49 --> Model Class Initialized
DEBUG - 2016-02-11 17:48:49 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:48:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:48:49 --> Final output sent to browser
DEBUG - 2016-02-11 17:48:49 --> Total execution time: 0.2622
DEBUG - 2016-02-11 17:50:44 --> Config Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:50:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:50:44 --> URI Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Router Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Output Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Security Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Input Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:50:44 --> Language Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Language Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Config Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Loader Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:50:44 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:50:44 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Session Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:50:44 --> Session routines successfully run
DEBUG - 2016-02-11 17:50:44 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Email Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Controller Class Initialized
DEBUG - 2016-02-11 17:50:44 --> Auth MX_Controller Initialized
DEBUG - 2016-02-11 17:50:44 --> Model Class Initialized
DEBUG - 2016-02-11 17:50:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:50:44 --> Model Class Initialized
DEBUG - 2016-02-11 17:50:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:50:44 --> Model Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:50:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:50:45 --> URI Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Router Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Output Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Security Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Input Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:50:45 --> Language Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Language Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Loader Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:50:45 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:50:45 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Session Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:50:45 --> A session cookie was not found.
DEBUG - 2016-02-11 17:50:45 --> Session routines successfully run
DEBUG - 2016-02-11 17:50:45 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Email Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Controller Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Auth MX_Controller Initialized
DEBUG - 2016-02-11 17:50:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:50:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:50:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:50:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:50:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:50:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:50:45 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-11 17:50:45 --> Final output sent to browser
DEBUG - 2016-02-11 17:50:45 --> Total execution time: 0.1610
DEBUG - 2016-02-11 17:50:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:50:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:50:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:50:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:50:45 --> URI Class Initialized
DEBUG - 2016-02-11 17:50:45 --> URI Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:50:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:50:45 --> URI Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Router Class Initialized
ERROR - 2016-02-11 17:50:45 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 17:50:45 --> Router Class Initialized
ERROR - 2016-02-11 17:50:45 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 17:50:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Router Class Initialized
ERROR - 2016-02-11 17:50:45 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 17:50:45 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:50:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:50:45 --> URI Class Initialized
DEBUG - 2016-02-11 17:50:45 --> Router Class Initialized
ERROR - 2016-02-11 17:50:45 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 17:51:03 --> Config Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:51:03 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:51:03 --> URI Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Router Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Output Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Security Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Input Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:51:03 --> Language Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Language Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Config Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Loader Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:51:03 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:51:03 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Session Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:51:03 --> Session routines successfully run
DEBUG - 2016-02-11 17:51:03 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Email Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Controller Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Auth MX_Controller Initialized
DEBUG - 2016-02-11 17:51:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:51:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:51:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:51:03 --> XSS Filtering completed
DEBUG - 2016-02-11 17:51:03 --> Unable to find validation rule: exists
DEBUG - 2016-02-11 17:51:03 --> XSS Filtering completed
DEBUG - 2016-02-11 17:51:03 --> Config Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:51:03 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:51:03 --> URI Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Router Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Output Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Security Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Input Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:51:03 --> Language Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Language Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Config Class Initialized
DEBUG - 2016-02-11 17:51:03 --> Loader Class Initialized
DEBUG - 2016-02-11 17:51:04 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:51:04 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:51:04 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:51:04 --> Session Class Initialized
DEBUG - 2016-02-11 17:51:04 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:51:04 --> Session routines successfully run
DEBUG - 2016-02-11 17:51:04 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:51:04 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:51:04 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:51:04 --> Email Class Initialized
DEBUG - 2016-02-11 17:51:04 --> Controller Class Initialized
DEBUG - 2016-02-11 17:51:04 --> Admin MX_Controller Initialized
DEBUG - 2016-02-11 17:51:04 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:51:04 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:51:04 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:51:04 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:51:04 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:51:04 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:51:04 --> Model Class Initialized
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:51:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:51:04 --> Final output sent to browser
DEBUG - 2016-02-11 17:51:04 --> Total execution time: 0.2515
DEBUG - 2016-02-11 17:52:31 --> Config Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:52:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:52:31 --> URI Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Router Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Output Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Security Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Input Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:52:31 --> Language Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Language Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Config Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Loader Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:52:31 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:52:31 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Session Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:52:31 --> Session routines successfully run
DEBUG - 2016-02-11 17:52:31 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Email Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Controller Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:52:31 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:31 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:52:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:52:31 --> Final output sent to browser
DEBUG - 2016-02-11 17:52:31 --> Total execution time: 0.3364
DEBUG - 2016-02-11 17:52:35 --> Config Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:52:35 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:52:35 --> URI Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Router Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Output Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Security Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Input Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:52:35 --> Language Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Language Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Config Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Loader Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:52:35 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:52:35 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Session Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:52:35 --> Session routines successfully run
DEBUG - 2016-02-11 17:52:35 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Email Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Controller Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:52:35 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:35 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:52:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:52:35 --> Final output sent to browser
DEBUG - 2016-02-11 17:52:35 --> Total execution time: 0.2587
DEBUG - 2016-02-11 17:52:53 --> Config Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:52:53 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:52:53 --> URI Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Router Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Output Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Security Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Input Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:52:53 --> Language Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Language Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Config Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Loader Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:52:53 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:52:53 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Session Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:52:53 --> Session routines successfully run
DEBUG - 2016-02-11 17:52:53 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Email Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Controller Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:52:53 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:52:53 --> XSS Filtering completed
DEBUG - 2016-02-11 17:52:53 --> XSS Filtering completed
DEBUG - 2016-02-11 17:52:53 --> XSS Filtering completed
DEBUG - 2016-02-11 17:52:53 --> XSS Filtering completed
DEBUG - 2016-02-11 17:52:53 --> XSS Filtering completed
DEBUG - 2016-02-11 17:52:53 --> XSS Filtering completed
DEBUG - 2016-02-11 17:52:53 --> Config Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:52:53 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:52:53 --> URI Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Router Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Output Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Security Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Input Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:52:53 --> Language Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Language Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Config Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Loader Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:52:53 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:52:53 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Session Class Initialized
DEBUG - 2016-02-11 17:52:53 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:52:53 --> Session routines successfully run
DEBUG - 2016-02-11 17:52:54 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:52:54 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:52:54 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:52:54 --> Email Class Initialized
DEBUG - 2016-02-11 17:52:54 --> Controller Class Initialized
DEBUG - 2016-02-11 17:52:54 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:52:54 --> Model Class Initialized
DEBUG - 2016-02-11 17:52:54 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:52:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:52:54 --> Final output sent to browser
DEBUG - 2016-02-11 17:52:54 --> Total execution time: 0.2291
DEBUG - 2016-02-11 17:53:03 --> Config Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:53:03 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:53:03 --> URI Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Router Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Output Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Security Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Input Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:53:03 --> Language Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Language Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Config Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Loader Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:53:03 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:53:03 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Session Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:53:03 --> Session routines successfully run
DEBUG - 2016-02-11 17:53:03 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Email Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Controller Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:53:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:03 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:53:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:53:03 --> Final output sent to browser
DEBUG - 2016-02-11 17:53:03 --> Total execution time: 0.2389
DEBUG - 2016-02-11 17:53:34 --> Config Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:53:34 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:53:34 --> URI Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Router Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Output Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Security Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Input Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:53:34 --> Language Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Language Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Config Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Loader Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:53:34 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:53:34 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Session Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:53:34 --> Session routines successfully run
DEBUG - 2016-02-11 17:53:34 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Email Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Controller Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:53:34 --> XSS Filtering completed
DEBUG - 2016-02-11 17:53:34 --> XSS Filtering completed
DEBUG - 2016-02-11 17:53:34 --> XSS Filtering completed
DEBUG - 2016-02-11 17:53:34 --> XSS Filtering completed
DEBUG - 2016-02-11 17:53:34 --> XSS Filtering completed
DEBUG - 2016-02-11 17:53:34 --> XSS Filtering completed
DEBUG - 2016-02-11 17:53:34 --> Config Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:53:34 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:53:34 --> URI Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Router Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Output Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Security Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Input Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:53:34 --> Language Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Language Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Config Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Loader Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:53:34 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:53:34 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Session Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:53:34 --> Session routines successfully run
DEBUG - 2016-02-11 17:53:34 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Email Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Controller Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:53:34 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:34 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:53:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:53:34 --> Final output sent to browser
DEBUG - 2016-02-11 17:53:34 --> Total execution time: 0.2245
DEBUG - 2016-02-11 17:53:46 --> Config Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:53:46 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:53:46 --> URI Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Router Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Output Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Security Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Input Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:53:46 --> Language Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Language Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Config Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Loader Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:53:46 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:53:46 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Session Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:53:46 --> Session routines successfully run
DEBUG - 2016-02-11 17:53:46 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Email Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Controller Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:53:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:53:46 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:53:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:53:47 --> Final output sent to browser
DEBUG - 2016-02-11 17:53:47 --> Total execution time: 0.2777
DEBUG - 2016-02-11 17:54:46 --> Config Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:54:46 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:54:46 --> URI Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Router Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Output Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Security Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Input Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:54:46 --> Language Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Language Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Config Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Loader Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:54:46 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:54:46 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Session Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:54:46 --> Session routines successfully run
DEBUG - 2016-02-11 17:54:46 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Email Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Controller Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:54:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:54:46 --> XSS Filtering completed
DEBUG - 2016-02-11 17:54:46 --> XSS Filtering completed
DEBUG - 2016-02-11 17:54:46 --> XSS Filtering completed
DEBUG - 2016-02-11 17:54:46 --> XSS Filtering completed
DEBUG - 2016-02-11 17:54:46 --> XSS Filtering completed
DEBUG - 2016-02-11 17:54:46 --> XSS Filtering completed
DEBUG - 2016-02-11 17:54:46 --> Config Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:54:46 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:54:46 --> URI Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Router Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Output Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Security Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Input Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:54:46 --> Language Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Language Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Config Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Loader Class Initialized
DEBUG - 2016-02-11 17:54:46 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:54:46 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:54:46 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:54:47 --> Session Class Initialized
DEBUG - 2016-02-11 17:54:47 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:54:47 --> Session routines successfully run
DEBUG - 2016-02-11 17:54:47 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:54:47 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:54:47 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:54:47 --> Email Class Initialized
DEBUG - 2016-02-11 17:54:47 --> Controller Class Initialized
DEBUG - 2016-02-11 17:54:47 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:54:47 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:47 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:54:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:54:47 --> Final output sent to browser
DEBUG - 2016-02-11 17:54:47 --> Total execution time: 0.2316
DEBUG - 2016-02-11 17:54:51 --> Config Class Initialized
DEBUG - 2016-02-11 17:54:51 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:54:51 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:54:51 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:54:51 --> URI Class Initialized
DEBUG - 2016-02-11 17:54:51 --> Router Class Initialized
DEBUG - 2016-02-11 17:54:51 --> Output Class Initialized
DEBUG - 2016-02-11 17:54:51 --> Security Class Initialized
DEBUG - 2016-02-11 17:54:51 --> Input Class Initialized
DEBUG - 2016-02-11 17:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:54:51 --> Language Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Language Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Config Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Loader Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:54:52 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:54:52 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Session Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:54:52 --> Session routines successfully run
DEBUG - 2016-02-11 17:54:52 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Email Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Controller Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:54:52 --> Model Class Initialized
DEBUG - 2016-02-11 17:54:52 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:54:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:54:52 --> Final output sent to browser
DEBUG - 2016-02-11 17:54:52 --> Total execution time: 0.3272
DEBUG - 2016-02-11 17:55:37 --> Config Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:55:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:55:37 --> URI Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Router Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Output Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Security Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Input Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:55:37 --> Language Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Language Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Config Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Loader Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:55:37 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:55:37 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Session Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:55:37 --> Session routines successfully run
DEBUG - 2016-02-11 17:55:37 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Email Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Controller Class Initialized
DEBUG - 2016-02-11 17:55:37 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:55:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:55:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:55:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:55:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:55:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:55:37 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:55:38 --> XSS Filtering completed
DEBUG - 2016-02-11 17:55:38 --> XSS Filtering completed
DEBUG - 2016-02-11 17:55:38 --> XSS Filtering completed
DEBUG - 2016-02-11 17:55:38 --> XSS Filtering completed
DEBUG - 2016-02-11 17:55:38 --> XSS Filtering completed
DEBUG - 2016-02-11 17:55:38 --> XSS Filtering completed
DEBUG - 2016-02-11 17:55:38 --> Config Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:55:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:55:38 --> URI Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Router Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Output Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Security Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Input Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:55:38 --> Language Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Language Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Config Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Loader Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:55:38 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:55:38 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Session Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:55:38 --> Session routines successfully run
DEBUG - 2016-02-11 17:55:38 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Email Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Controller Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:55:38 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:38 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:55:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:55:38 --> Final output sent to browser
DEBUG - 2016-02-11 17:55:38 --> Total execution time: 0.3219
DEBUG - 2016-02-11 17:55:59 --> Config Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:55:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:55:59 --> URI Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Router Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Output Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Security Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Input Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:55:59 --> Language Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Language Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Config Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Loader Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:55:59 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:55:59 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Session Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:55:59 --> Session routines successfully run
DEBUG - 2016-02-11 17:55:59 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Email Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Controller Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:55:59 --> Model Class Initialized
DEBUG - 2016-02-11 17:55:59 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:55:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:55:59 --> Final output sent to browser
DEBUG - 2016-02-11 17:55:59 --> Total execution time: 0.2851
DEBUG - 2016-02-11 17:56:32 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:56:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:56:32 --> URI Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Router Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Output Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Security Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Input Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:56:32 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Loader Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:56:32 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:56:32 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Session Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:56:32 --> Session routines successfully run
DEBUG - 2016-02-11 17:56:32 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Email Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Controller Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:56:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:56:32 --> XSS Filtering completed
DEBUG - 2016-02-11 17:56:32 --> XSS Filtering completed
DEBUG - 2016-02-11 17:56:32 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:56:32 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:56:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:56:33 --> URI Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Router Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Output Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Security Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Input Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:56:33 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Loader Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:56:33 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:56:33 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Session Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:56:33 --> Session routines successfully run
DEBUG - 2016-02-11 17:56:33 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Email Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Controller Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:56:33 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:33 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:56:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:56:33 --> Final output sent to browser
DEBUG - 2016-02-11 17:56:33 --> Total execution time: 0.3592
DEBUG - 2016-02-11 17:56:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:56:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:56:45 --> URI Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Router Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Output Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Security Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Input Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:56:45 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Loader Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:56:45 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:56:45 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Session Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:56:45 --> Session routines successfully run
DEBUG - 2016-02-11 17:56:45 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Email Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Controller Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:56:45 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:56:45 --> XSS Filtering completed
DEBUG - 2016-02-11 17:56:45 --> XSS Filtering completed
DEBUG - 2016-02-11 17:56:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:56:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:56:45 --> URI Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Router Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Output Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Security Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Input Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:56:45 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Loader Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:56:45 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:56:45 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Session Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:56:45 --> Session routines successfully run
DEBUG - 2016-02-11 17:56:45 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Email Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Controller Class Initialized
DEBUG - 2016-02-11 17:56:45 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:56:46 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:46 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:56:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:56:46 --> Final output sent to browser
DEBUG - 2016-02-11 17:56:46 --> Total execution time: 0.3569
DEBUG - 2016-02-11 17:56:58 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:56:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:56:58 --> URI Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Router Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Output Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Security Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Input Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:56:58 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Loader Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:56:58 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:56:58 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Session Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:56:58 --> Session routines successfully run
DEBUG - 2016-02-11 17:56:58 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Email Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Controller Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:56:58 --> XSS Filtering completed
DEBUG - 2016-02-11 17:56:58 --> XSS Filtering completed
DEBUG - 2016-02-11 17:56:58 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:56:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:56:58 --> URI Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Router Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Output Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Security Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Input Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:56:58 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Language Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Config Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Loader Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:56:58 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:56:58 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Session Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:56:58 --> Session routines successfully run
DEBUG - 2016-02-11 17:56:58 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Email Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Controller Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:56:58 --> Model Class Initialized
DEBUG - 2016-02-11 17:56:58 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:56:58 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:56:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:56:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:56:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:56:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:56:59 --> Final output sent to browser
DEBUG - 2016-02-11 17:56:59 --> Total execution time: 0.2463
DEBUG - 2016-02-11 17:57:23 --> Config Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:57:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:57:23 --> URI Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Router Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Output Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Security Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Input Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:57:23 --> Language Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Language Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Config Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Loader Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:57:23 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:57:23 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Session Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:57:23 --> Session routines successfully run
DEBUG - 2016-02-11 17:57:23 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Email Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Controller Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:57:23 --> XSS Filtering completed
DEBUG - 2016-02-11 17:57:23 --> XSS Filtering completed
DEBUG - 2016-02-11 17:57:23 --> Config Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:57:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:57:23 --> URI Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Router Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Output Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Security Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Input Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:57:23 --> Language Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Language Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Config Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Loader Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:57:23 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:57:23 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Session Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:57:23 --> Session routines successfully run
DEBUG - 2016-02-11 17:57:23 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Email Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Controller Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:57:23 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:23 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:57:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:57:23 --> Final output sent to browser
DEBUG - 2016-02-11 17:57:23 --> Total execution time: 0.2359
DEBUG - 2016-02-11 17:57:31 --> Config Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:57:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:57:31 --> URI Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Router Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Output Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Security Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Input Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:57:31 --> Language Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Language Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Config Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Loader Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:57:31 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:57:31 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Session Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:57:31 --> Session routines successfully run
DEBUG - 2016-02-11 17:57:31 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:57:31 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Email Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Controller Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:57:32 --> XSS Filtering completed
DEBUG - 2016-02-11 17:57:32 --> XSS Filtering completed
DEBUG - 2016-02-11 17:57:32 --> Config Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:57:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:57:32 --> URI Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Router Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Output Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Security Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Input Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:57:32 --> Language Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Language Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Config Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Loader Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:57:32 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:57:32 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Session Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:57:32 --> Session routines successfully run
DEBUG - 2016-02-11 17:57:32 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Email Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Controller Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:57:32 --> Model Class Initialized
DEBUG - 2016-02-11 17:57:32 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:57:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:57:32 --> Final output sent to browser
DEBUG - 2016-02-11 17:57:32 --> Total execution time: 0.2771
DEBUG - 2016-02-11 17:58:02 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:58:02 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:58:02 --> URI Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Router Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Output Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Security Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Input Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:58:02 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Loader Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:58:02 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:58:02 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Session Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:58:02 --> Session routines successfully run
DEBUG - 2016-02-11 17:58:02 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Email Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Controller Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:58:02 --> XSS Filtering completed
DEBUG - 2016-02-11 17:58:02 --> XSS Filtering completed
DEBUG - 2016-02-11 17:58:02 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:58:02 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:58:02 --> URI Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Router Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Output Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Security Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Input Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:58:02 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Loader Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:58:02 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:58:02 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Session Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:58:02 --> Session routines successfully run
DEBUG - 2016-02-11 17:58:02 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Email Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Controller Class Initialized
DEBUG - 2016-02-11 17:58:02 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:58:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:58:03 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:03 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:58:03 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:58:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:58:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:58:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:58:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:58:03 --> Final output sent to browser
DEBUG - 2016-02-11 17:58:03 --> Total execution time: 0.2424
DEBUG - 2016-02-11 17:58:11 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:11 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:58:11 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:58:11 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:58:11 --> URI Class Initialized
DEBUG - 2016-02-11 17:58:11 --> Router Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Output Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Security Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Input Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:58:12 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Loader Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:58:12 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:58:12 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Session Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:58:12 --> Session routines successfully run
DEBUG - 2016-02-11 17:58:12 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Email Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Controller Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:58:12 --> XSS Filtering completed
DEBUG - 2016-02-11 17:58:12 --> XSS Filtering completed
DEBUG - 2016-02-11 17:58:12 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:58:12 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:58:12 --> URI Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Router Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Output Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Security Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Input Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:58:12 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Loader Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:58:12 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:58:12 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Session Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:58:12 --> Session routines successfully run
DEBUG - 2016-02-11 17:58:12 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Email Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Controller Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:58:12 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:12 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:58:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:58:12 --> Final output sent to browser
DEBUG - 2016-02-11 17:58:12 --> Total execution time: 0.2556
DEBUG - 2016-02-11 17:58:20 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:58:20 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:58:20 --> URI Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Router Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Output Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Security Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Input Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:58:20 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Loader Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:58:20 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:58:20 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:58:20 --> Session Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:58:21 --> Session routines successfully run
DEBUG - 2016-02-11 17:58:21 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Email Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Controller Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:58:21 --> XSS Filtering completed
DEBUG - 2016-02-11 17:58:21 --> XSS Filtering completed
DEBUG - 2016-02-11 17:58:21 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:58:21 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:58:21 --> URI Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Router Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Output Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Security Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Input Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:58:21 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Loader Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:58:21 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:58:21 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Session Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:58:21 --> Session routines successfully run
DEBUG - 2016-02-11 17:58:21 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Email Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Controller Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:58:21 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:21 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:58:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:58:21 --> Final output sent to browser
DEBUG - 2016-02-11 17:58:21 --> Total execution time: 0.2748
DEBUG - 2016-02-11 17:58:40 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:58:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:58:40 --> URI Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Router Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Output Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Security Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Input Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:58:40 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Loader Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:58:40 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:58:40 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Session Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:58:40 --> Session routines successfully run
DEBUG - 2016-02-11 17:58:40 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Email Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Controller Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:58:40 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:40 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:58:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 17:58:41 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:58:41 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 17:58:41 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:41 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 17:58:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:58:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:58:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:58:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:58:41 --> Final output sent to browser
DEBUG - 2016-02-11 17:58:41 --> Total execution time: 0.4800
DEBUG - 2016-02-11 17:58:56 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:56 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:58:56 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:58:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:58:57 --> URI Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Router Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Output Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Security Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Input Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:58:57 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Language Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Config Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Loader Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:58:57 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:58:57 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Session Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:58:57 --> Session routines successfully run
DEBUG - 2016-02-11 17:58:57 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Email Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Controller Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 17:58:57 --> Model Class Initialized
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:58:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:58:57 --> Final output sent to browser
DEBUG - 2016-02-11 17:58:57 --> Total execution time: 0.8408
DEBUG - 2016-02-11 17:59:42 --> Config Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:59:42 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:59:42 --> URI Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Router Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Output Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Security Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Input Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:59:42 --> Language Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Language Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Config Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Loader Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:59:42 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:59:42 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Session Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:59:42 --> Session routines successfully run
DEBUG - 2016-02-11 17:59:42 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Email Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Controller Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 17:59:42 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 17:59:42 --> XSS Filtering completed
DEBUG - 2016-02-11 17:59:42 --> XSS Filtering completed
DEBUG - 2016-02-11 17:59:42 --> XSS Filtering completed
DEBUG - 2016-02-11 17:59:42 --> XSS Filtering completed
DEBUG - 2016-02-11 17:59:42 --> Config Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:59:42 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:59:42 --> URI Class Initialized
DEBUG - 2016-02-11 17:59:42 --> Router Class Initialized
ERROR - 2016-02-11 17:59:42 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 17:59:50 --> Config Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Hooks Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Utf8 Class Initialized
DEBUG - 2016-02-11 17:59:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 17:59:50 --> URI Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Router Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Output Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Security Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Input Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 17:59:50 --> Language Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Language Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Config Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Loader Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Helper loaded: url_helper
DEBUG - 2016-02-11 17:59:50 --> Helper loaded: form_helper
DEBUG - 2016-02-11 17:59:50 --> Database Driver Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Session Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Helper loaded: string_helper
DEBUG - 2016-02-11 17:59:50 --> Session routines successfully run
DEBUG - 2016-02-11 17:59:50 --> Form Validation Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Pagination Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Encrypt Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Email Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Controller Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> Image Lib Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:50 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 17:59:50 --> Model Class Initialized
DEBUG - 2016-02-11 17:59:51 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 17:59:51 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 17:59:51 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 17:59:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 17:59:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 17:59:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 17:59:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 17:59:51 --> Final output sent to browser
DEBUG - 2016-02-11 17:59:51 --> Total execution time: 0.6660
DEBUG - 2016-02-11 18:00:01 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:00:01 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:00:01 --> URI Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Router Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Output Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Security Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Input Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:00:01 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Loader Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:00:01 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:00:01 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Session Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:00:01 --> Session routines successfully run
DEBUG - 2016-02-11 18:00:01 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Email Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Controller Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:00:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:01 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:00:01 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:00:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:00:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:00:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:00:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:00:02 --> Final output sent to browser
DEBUG - 2016-02-11 18:00:02 --> Total execution time: 0.3122
DEBUG - 2016-02-11 18:00:42 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:42 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:00:42 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:00:42 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:00:42 --> URI Class Initialized
DEBUG - 2016-02-11 18:00:42 --> Router Class Initialized
DEBUG - 2016-02-11 18:00:42 --> Output Class Initialized
DEBUG - 2016-02-11 18:00:42 --> Security Class Initialized
DEBUG - 2016-02-11 18:00:42 --> Input Class Initialized
DEBUG - 2016-02-11 18:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:00:42 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:42 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:42 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Loader Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:00:43 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:00:43 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Session Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:00:43 --> Session routines successfully run
DEBUG - 2016-02-11 18:00:43 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Email Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Controller Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:00:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:00:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:00:43 --> Final output sent to browser
DEBUG - 2016-02-11 18:00:43 --> Total execution time: 0.2503
DEBUG - 2016-02-11 18:00:51 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:00:51 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:00:51 --> URI Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Router Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Output Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Security Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Input Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:00:51 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Loader Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:00:51 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:00:51 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Session Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:00:51 --> Session routines successfully run
DEBUG - 2016-02-11 18:00:51 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Email Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Controller Class Initialized
DEBUG - 2016-02-11 18:00:51 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:00:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:00:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:00:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:00:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:00:52 --> XSS Filtering completed
DEBUG - 2016-02-11 18:00:52 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:00:52 --> URI Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Router Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Output Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Security Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Input Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:00:52 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Loader Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:00:52 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:00:52 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Session Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:00:52 --> Session routines successfully run
DEBUG - 2016-02-11 18:00:52 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Email Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Controller Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:00:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:00:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:00:52 --> Final output sent to browser
DEBUG - 2016-02-11 18:00:52 --> Total execution time: 0.3469
DEBUG - 2016-02-11 18:00:59 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:00:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:00:59 --> URI Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Router Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Output Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Security Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Input Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:00:59 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Language Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Config Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Loader Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:00:59 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:00:59 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Session Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:00:59 --> Session routines successfully run
DEBUG - 2016-02-11 18:00:59 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Email Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Controller Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:00:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:00:59 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:00:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:00:59 --> Final output sent to browser
DEBUG - 2016-02-11 18:00:59 --> Total execution time: 0.2590
DEBUG - 2016-02-11 18:01:08 --> Config Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:01:08 --> URI Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Router Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Output Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Security Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Input Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:01:08 --> Language Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Language Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Config Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Loader Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:01:08 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:01:08 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Session Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:01:08 --> Session routines successfully run
DEBUG - 2016-02-11 18:01:08 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Email Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Controller Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:01:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:01:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:01:08 --> Final output sent to browser
DEBUG - 2016-02-11 18:01:08 --> Total execution time: 0.2880
DEBUG - 2016-02-11 18:02:13 --> Config Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:02:13 --> URI Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Router Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Output Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Security Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Input Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:02:13 --> Language Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Language Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Config Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Loader Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:02:13 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:02:13 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Session Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:02:13 --> Session routines successfully run
DEBUG - 2016-02-11 18:02:13 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Email Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Controller Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:02:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:02:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:02:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:02:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:02:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:02:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:02:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:02:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:02:14 --> Final output sent to browser
DEBUG - 2016-02-11 18:02:14 --> Total execution time: 0.2880
DEBUG - 2016-02-11 18:03:48 --> Config Class Initialized
DEBUG - 2016-02-11 18:03:48 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:03:48 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:03:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:03:48 --> URI Class Initialized
DEBUG - 2016-02-11 18:03:48 --> Router Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Output Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Security Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Input Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:03:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Config Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Loader Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:03:49 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:03:49 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Session Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:03:49 --> Session routines successfully run
DEBUG - 2016-02-11 18:03:49 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Email Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Controller Class Initialized
DEBUG - 2016-02-11 18:03:49 --> leases MX_Controller Initialized
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:03:49 --> XSS Filtering completed
DEBUG - 2016-02-11 18:03:49 --> XSS Filtering completed
DEBUG - 2016-02-11 18:03:49 --> XSS Filtering completed
DEBUG - 2016-02-11 18:03:49 --> XSS Filtering completed
DEBUG - 2016-02-11 18:03:49 --> Config Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:03:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:03:49 --> URI Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Router Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Output Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Security Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Input Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:03:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Config Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Loader Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:03:49 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:03:49 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Session Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:03:49 --> Session routines successfully run
DEBUG - 2016-02-11 18:03:49 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Email Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Controller Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:03:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:03:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:03:49 --> Final output sent to browser
DEBUG - 2016-02-11 18:03:49 --> Total execution time: 0.2688
DEBUG - 2016-02-11 18:04:25 --> Config Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:04:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:04:25 --> URI Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Router Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Output Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Security Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Input Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:04:25 --> Language Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Language Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Config Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Loader Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:04:25 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:04:25 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Session Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:04:25 --> Session routines successfully run
DEBUG - 2016-02-11 18:04:25 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Email Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Controller Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:04:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:25 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:04:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:04:25 --> Final output sent to browser
DEBUG - 2016-02-11 18:04:25 --> Total execution time: 0.2395
DEBUG - 2016-02-11 18:04:29 --> Config Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:04:29 --> URI Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Router Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Output Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Security Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Input Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:04:29 --> Language Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Language Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Config Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Loader Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:04:29 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:04:29 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Session Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:04:29 --> Session routines successfully run
DEBUG - 2016-02-11 18:04:29 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Email Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Controller Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:04:29 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:04:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:04:29 --> Final output sent to browser
DEBUG - 2016-02-11 18:04:29 --> Total execution time: 0.3146
DEBUG - 2016-02-11 18:04:37 --> Config Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:04:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:04:37 --> URI Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Router Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Output Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Security Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Input Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:04:37 --> Language Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Language Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Config Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Loader Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:04:37 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:04:37 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:04:37 --> Session Class Initialized
DEBUG - 2016-02-11 18:04:38 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:04:38 --> Session routines successfully run
DEBUG - 2016-02-11 18:04:38 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:04:38 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:04:38 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:04:38 --> Email Class Initialized
DEBUG - 2016-02-11 18:04:38 --> Controller Class Initialized
DEBUG - 2016-02-11 18:04:38 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:04:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:04:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:04:38 --> Final output sent to browser
DEBUG - 2016-02-11 18:04:38 --> Total execution time: 0.5614
DEBUG - 2016-02-11 18:04:40 --> Config Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:04:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:04:40 --> URI Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Router Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Output Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Security Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Input Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:04:40 --> Language Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Language Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Config Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Loader Class Initialized
DEBUG - 2016-02-11 18:04:40 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:04:40 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:04:41 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:04:41 --> Session Class Initialized
DEBUG - 2016-02-11 18:04:41 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:04:41 --> Session routines successfully run
DEBUG - 2016-02-11 18:04:41 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:04:41 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:04:41 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:04:41 --> Email Class Initialized
DEBUG - 2016-02-11 18:04:41 --> Controller Class Initialized
DEBUG - 2016-02-11 18:04:41 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:04:41 --> Model Class Initialized
DEBUG - 2016-02-11 18:04:41 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:04:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:04:41 --> Final output sent to browser
DEBUG - 2016-02-11 18:04:41 --> Total execution time: 0.2774
DEBUG - 2016-02-11 18:05:09 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:05:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:05:09 --> URI Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Router Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Output Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Security Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Input Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:05:09 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Loader Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:05:09 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:05:09 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Session Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:05:09 --> Session routines successfully run
DEBUG - 2016-02-11 18:05:09 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Email Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Controller Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:05:09 --> XSS Filtering completed
DEBUG - 2016-02-11 18:05:09 --> XSS Filtering completed
DEBUG - 2016-02-11 18:05:09 --> XSS Filtering completed
DEBUG - 2016-02-11 18:05:09 --> XSS Filtering completed
DEBUG - 2016-02-11 18:05:09 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:05:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:05:09 --> URI Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Router Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Output Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Security Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Input Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:05:09 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Loader Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:05:09 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:05:09 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Session Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:05:09 --> Session routines successfully run
DEBUG - 2016-02-11 18:05:09 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Email Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Controller Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:05:09 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:05:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:05:09 --> Final output sent to browser
DEBUG - 2016-02-11 18:05:09 --> Total execution time: 0.2809
DEBUG - 2016-02-11 18:05:12 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:05:12 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:05:12 --> URI Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Router Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Output Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Security Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Input Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:05:12 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Loader Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:05:12 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:05:12 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Session Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:05:12 --> Session routines successfully run
DEBUG - 2016-02-11 18:05:12 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Email Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Controller Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:05:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:05:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:05:12 --> Final output sent to browser
DEBUG - 2016-02-11 18:05:12 --> Total execution time: 0.2704
DEBUG - 2016-02-11 18:05:27 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:05:27 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:05:27 --> URI Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Router Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Output Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Security Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Input Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:05:27 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Loader Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:05:27 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:05:27 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Session Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:05:27 --> Session routines successfully run
DEBUG - 2016-02-11 18:05:27 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Email Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Controller Class Initialized
DEBUG - 2016-02-11 18:05:27 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:05:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:05:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:05:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:05:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:05:28 --> XSS Filtering completed
DEBUG - 2016-02-11 18:05:28 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:05:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:05:28 --> URI Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Router Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Output Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Security Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Input Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:05:28 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Loader Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:05:28 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:05:28 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Session Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:05:28 --> Session routines successfully run
DEBUG - 2016-02-11 18:05:28 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Email Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Controller Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:05:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:05:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:05:28 --> Final output sent to browser
DEBUG - 2016-02-11 18:05:28 --> Total execution time: 0.2981
DEBUG - 2016-02-11 18:05:56 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:05:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:05:56 --> URI Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Router Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Output Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Security Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Input Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:05:56 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Loader Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:05:56 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:05:56 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Session Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:05:56 --> Session routines successfully run
DEBUG - 2016-02-11 18:05:56 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Email Class Initialized
DEBUG - 2016-02-11 18:05:56 --> Controller Class Initialized
DEBUG - 2016-02-11 18:05:56 --> leases MX_Controller Initialized
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:05:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:05:57 --> XSS Filtering completed
DEBUG - 2016-02-11 18:05:57 --> XSS Filtering completed
DEBUG - 2016-02-11 18:05:57 --> XSS Filtering completed
DEBUG - 2016-02-11 18:05:57 --> XSS Filtering completed
DEBUG - 2016-02-11 18:05:57 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:05:57 --> URI Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Router Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Output Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Security Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Input Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:05:57 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Language Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Config Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Loader Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:05:57 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:05:57 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Session Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:05:57 --> Session routines successfully run
DEBUG - 2016-02-11 18:05:57 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Email Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Controller Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:05:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:05:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:05:57 --> Final output sent to browser
DEBUG - 2016-02-11 18:05:57 --> Total execution time: 0.2678
DEBUG - 2016-02-11 18:06:02 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:06:02 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:06:02 --> URI Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Router Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Output Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Security Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Input Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:06:02 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Loader Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:06:02 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:06:02 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Session Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:06:02 --> Session routines successfully run
DEBUG - 2016-02-11 18:06:02 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Email Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Controller Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:06:02 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:02 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:06:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:06:02 --> Final output sent to browser
DEBUG - 2016-02-11 18:06:02 --> Total execution time: 0.3099
DEBUG - 2016-02-11 18:06:32 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:06:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:06:32 --> URI Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Router Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Output Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Security Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Input Class Initialized
DEBUG - 2016-02-11 18:06:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:06:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:06:32 --> URI Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Router Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Output Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Loader Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:06:32 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:06:32 --> Security Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Input Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:06:32 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Session Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:06:32 --> Session routines successfully run
DEBUG - 2016-02-11 18:06:32 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Loader Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:06:32 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:06:32 --> Email Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Controller Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Session Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:06:32 --> Session routines successfully run
DEBUG - 2016-02-11 18:06:32 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Email Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Controller Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:06:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:06:32 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:32 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:32 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:06:32 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:32 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:32 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:32 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:32 --> Final output sent to browser
DEBUG - 2016-02-11 18:06:32 --> Total execution time: 0.3392
DEBUG - 2016-02-11 18:06:36 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:06:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:06:36 --> URI Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Router Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Output Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Security Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Input Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:06:36 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Loader Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:06:36 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:06:36 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Session Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:06:36 --> Session routines successfully run
DEBUG - 2016-02-11 18:06:36 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Email Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Controller Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:06:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:06:36 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:36 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:36 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:36 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:36 --> Final output sent to browser
DEBUG - 2016-02-11 18:06:36 --> Total execution time: 0.2548
DEBUG - 2016-02-11 18:06:40 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:06:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:06:40 --> URI Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Router Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Output Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Security Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Input Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:06:40 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Loader Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:06:40 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:06:40 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Session Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:06:40 --> Session routines successfully run
DEBUG - 2016-02-11 18:06:40 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Email Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Controller Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:06:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:06:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:06:40 --> Final output sent to browser
DEBUG - 2016-02-11 18:06:40 --> Total execution time: 0.2904
DEBUG - 2016-02-11 18:06:48 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:06:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:06:48 --> URI Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Router Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Output Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Security Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Input Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:06:48 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Loader Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:06:48 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:06:48 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Session Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:06:48 --> Session routines successfully run
DEBUG - 2016-02-11 18:06:48 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Email Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Controller Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:06:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:06:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:06:48 --> Final output sent to browser
DEBUG - 2016-02-11 18:06:48 --> Total execution time: 0.2769
DEBUG - 2016-02-11 18:06:56 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:06:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:06:56 --> URI Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Router Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Output Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Security Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Input Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:06:56 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Loader Class Initialized
DEBUG - 2016-02-11 18:06:56 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:06:56 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:06:56 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Session Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:06:57 --> Session routines successfully run
DEBUG - 2016-02-11 18:06:57 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Email Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Controller Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:06:57 --> XSS Filtering completed
DEBUG - 2016-02-11 18:06:57 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:06:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:06:57 --> URI Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Router Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Output Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Security Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Input Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:06:57 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Language Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Config Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Loader Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:06:57 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:06:57 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Session Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:06:57 --> Session routines successfully run
DEBUG - 2016-02-11 18:06:57 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Email Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Controller Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:06:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:06:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:06:57 --> Final output sent to browser
DEBUG - 2016-02-11 18:06:57 --> Total execution time: 0.2620
DEBUG - 2016-02-11 18:07:23 --> Config Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:07:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:07:23 --> URI Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Router Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Output Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Security Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Input Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:07:23 --> Language Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Language Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Config Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Loader Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:07:23 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:07:23 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Session Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:07:23 --> Session routines successfully run
DEBUG - 2016-02-11 18:07:23 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Email Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Controller Class Initialized
DEBUG - 2016-02-11 18:07:23 --> leases MX_Controller Initialized
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:07:23 --> XSS Filtering completed
DEBUG - 2016-02-11 18:07:23 --> XSS Filtering completed
DEBUG - 2016-02-11 18:07:23 --> XSS Filtering completed
DEBUG - 2016-02-11 18:07:23 --> XSS Filtering completed
DEBUG - 2016-02-11 18:07:23 --> Config Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:07:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:07:23 --> URI Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Router Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Output Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Security Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Input Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:07:23 --> Language Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Language Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Config Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Loader Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:07:23 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:07:23 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Session Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:07:23 --> Session routines successfully run
DEBUG - 2016-02-11 18:07:23 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Email Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Controller Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:07:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:07:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:07:23 --> Final output sent to browser
DEBUG - 2016-02-11 18:07:23 --> Total execution time: 0.2814
DEBUG - 2016-02-11 18:07:25 --> Config Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:07:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:07:25 --> URI Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Router Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Output Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Security Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Input Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:07:25 --> Language Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Language Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Config Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Loader Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:07:25 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:07:25 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Session Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:07:25 --> Session routines successfully run
DEBUG - 2016-02-11 18:07:25 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Email Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Controller Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:07:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:07:25 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:07:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:07:25 --> Final output sent to browser
DEBUG - 2016-02-11 18:07:25 --> Total execution time: 0.2507
DEBUG - 2016-02-11 18:08:23 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:08:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:08:23 --> URI Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Router Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Output Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Security Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Input Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:08:23 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Loader Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:08:23 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:08:23 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Session Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:08:23 --> Session routines successfully run
DEBUG - 2016-02-11 18:08:23 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Email Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Controller Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:08:23 --> XSS Filtering completed
DEBUG - 2016-02-11 18:08:23 --> XSS Filtering completed
DEBUG - 2016-02-11 18:08:23 --> XSS Filtering completed
DEBUG - 2016-02-11 18:08:23 --> XSS Filtering completed
DEBUG - 2016-02-11 18:08:23 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:08:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:08:23 --> URI Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Router Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Output Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Security Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Input Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:08:23 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Loader Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:08:23 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:08:23 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Session Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:08:23 --> Session routines successfully run
DEBUG - 2016-02-11 18:08:23 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Email Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Controller Class Initialized
DEBUG - 2016-02-11 18:08:23 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:08:23 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:08:24 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:08:24 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:08:24 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:08:24 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:08:24 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:08:24 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:08:24 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:08:24 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:08:24 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:08:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:08:24 --> Final output sent to browser
DEBUG - 2016-02-11 18:08:24 --> Total execution time: 0.3139
DEBUG - 2016-02-11 18:08:36 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:08:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:08:36 --> URI Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Router Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Output Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Security Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Input Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:08:36 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Loader Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:08:36 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:08:36 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Session Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:08:36 --> Session routines successfully run
DEBUG - 2016-02-11 18:08:36 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Email Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Controller Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:08:36 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:08:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:08:36 --> Final output sent to browser
DEBUG - 2016-02-11 18:08:36 --> Total execution time: 0.2629
DEBUG - 2016-02-11 18:08:44 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:08:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:08:44 --> URI Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Router Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Output Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Security Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Input Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:08:44 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Loader Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:08:44 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:08:44 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Session Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:08:44 --> Session routines successfully run
DEBUG - 2016-02-11 18:08:44 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Email Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Controller Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:08:44 --> XSS Filtering completed
DEBUG - 2016-02-11 18:08:44 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:08:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:08:44 --> URI Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Router Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Output Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Security Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Input Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:08:44 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Language Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Config Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Loader Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:08:44 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:08:44 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Session Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:08:44 --> Session routines successfully run
DEBUG - 2016-02-11 18:08:44 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Email Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Controller Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:08:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:08:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:08:44 --> Final output sent to browser
DEBUG - 2016-02-11 18:08:44 --> Total execution time: 0.2664
DEBUG - 2016-02-11 18:09:12 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:09:12 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:09:12 --> URI Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Router Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Output Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Security Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Input Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:09:12 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Loader Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:09:12 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:09:12 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Session Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:09:12 --> Session routines successfully run
DEBUG - 2016-02-11 18:09:12 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Email Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Controller Class Initialized
DEBUG - 2016-02-11 18:09:12 --> leases MX_Controller Initialized
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:09:12 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:09:12 --> XSS Filtering completed
DEBUG - 2016-02-11 18:09:12 --> XSS Filtering completed
DEBUG - 2016-02-11 18:09:12 --> XSS Filtering completed
DEBUG - 2016-02-11 18:09:12 --> XSS Filtering completed
DEBUG - 2016-02-11 18:09:12 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:09:12 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:09:12 --> URI Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Router Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Output Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Security Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Input Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:09:12 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Loader Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:09:12 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:09:12 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Session Class Initialized
DEBUG - 2016-02-11 18:09:12 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:09:13 --> Session routines successfully run
DEBUG - 2016-02-11 18:09:13 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:09:13 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:09:13 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:09:13 --> Email Class Initialized
DEBUG - 2016-02-11 18:09:13 --> Controller Class Initialized
DEBUG - 2016-02-11 18:09:13 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:09:13 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:09:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:09:13 --> Final output sent to browser
DEBUG - 2016-02-11 18:09:13 --> Total execution time: 0.2670
DEBUG - 2016-02-11 18:09:19 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:09:19 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:09:19 --> URI Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Router Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Output Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Security Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Input Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:09:19 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:09:19 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:09:19 --> URI Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Loader Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Router Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:09:19 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:09:19 --> Output Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Security Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Input Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:09:19 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Session Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Loader Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:09:19 --> Session routines successfully run
DEBUG - 2016-02-11 18:09:19 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:09:19 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:09:19 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Email Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Controller Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Session Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:09:19 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:09:19 --> Session routines successfully run
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Email Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Controller Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:09:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:19 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:09:19 --> Final output sent to browser
DEBUG - 2016-02-11 18:09:19 --> Total execution time: 0.4578
DEBUG - 2016-02-11 18:09:19 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:09:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:09:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:09:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:09:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:09:20 --> Final output sent to browser
DEBUG - 2016-02-11 18:09:20 --> Total execution time: 0.3579
DEBUG - 2016-02-11 18:09:55 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:55 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:09:55 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:09:55 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:09:55 --> URI Class Initialized
DEBUG - 2016-02-11 18:09:55 --> Router Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Output Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Security Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Input Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:09:56 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Language Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Config Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Loader Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:09:56 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:09:56 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Session Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:09:56 --> Session routines successfully run
DEBUG - 2016-02-11 18:09:56 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Email Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Controller Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:09:56 --> Model Class Initialized
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:09:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:09:56 --> Final output sent to browser
DEBUG - 2016-02-11 18:09:56 --> Total execution time: 0.3318
DEBUG - 2016-02-11 18:10:26 --> Config Class Initialized
DEBUG - 2016-02-11 18:10:26 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:10:26 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:10:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:10:26 --> URI Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Router Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Output Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Security Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Input Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:10:27 --> Language Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Language Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Config Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Loader Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:10:27 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:10:27 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Session Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:10:27 --> Session routines successfully run
DEBUG - 2016-02-11 18:10:27 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Email Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Controller Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:10:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:10:27 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:10:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:10:27 --> Final output sent to browser
DEBUG - 2016-02-11 18:10:27 --> Total execution time: 0.2753
DEBUG - 2016-02-11 18:11:25 --> Config Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:11:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:11:25 --> URI Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Router Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Output Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Security Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Input Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:11:25 --> Language Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Language Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Config Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Loader Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:11:25 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:11:25 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Session Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:11:25 --> Session routines successfully run
DEBUG - 2016-02-11 18:11:25 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Email Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Controller Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:11:25 --> XSS Filtering completed
DEBUG - 2016-02-11 18:11:25 --> XSS Filtering completed
DEBUG - 2016-02-11 18:11:25 --> XSS Filtering completed
DEBUG - 2016-02-11 18:11:25 --> XSS Filtering completed
DEBUG - 2016-02-11 18:11:25 --> Config Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:11:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:11:25 --> URI Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Router Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Output Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Security Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Input Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:11:25 --> Language Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Language Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Config Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Loader Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:11:25 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:11:25 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Session Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:11:25 --> Session routines successfully run
DEBUG - 2016-02-11 18:11:25 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Email Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Controller Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:11:25 --> Model Class Initialized
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:11:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:11:25 --> Final output sent to browser
DEBUG - 2016-02-11 18:11:25 --> Total execution time: 0.3381
DEBUG - 2016-02-11 18:12:00 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:00 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:12:00 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:12:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:12:00 --> URI Class Initialized
DEBUG - 2016-02-11 18:12:00 --> Router Class Initialized
DEBUG - 2016-02-11 18:12:00 --> Output Class Initialized
DEBUG - 2016-02-11 18:12:00 --> Security Class Initialized
DEBUG - 2016-02-11 18:12:00 --> Input Class Initialized
DEBUG - 2016-02-11 18:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:12:00 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Loader Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:12:01 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:12:01 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Session Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:12:01 --> Session routines successfully run
DEBUG - 2016-02-11 18:12:01 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Email Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Controller Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:12:01 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:12:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:12:01 --> Final output sent to browser
DEBUG - 2016-02-11 18:12:01 --> Total execution time: 0.3032
DEBUG - 2016-02-11 18:12:27 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:12:27 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:12:27 --> URI Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Router Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Output Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Security Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Input Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:12:27 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Loader Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:12:27 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:12:27 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Session Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:12:27 --> Session routines successfully run
DEBUG - 2016-02-11 18:12:27 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Email Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Controller Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:12:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:27 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:12:28 --> XSS Filtering completed
DEBUG - 2016-02-11 18:12:28 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:12:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:12:28 --> URI Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Router Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Output Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Security Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Input Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:12:28 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Loader Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:12:28 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:12:28 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Session Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:12:28 --> Session routines successfully run
DEBUG - 2016-02-11 18:12:28 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Email Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Controller Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:12:28 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:12:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:12:28 --> Final output sent to browser
DEBUG - 2016-02-11 18:12:28 --> Total execution time: 0.2953
DEBUG - 2016-02-11 18:12:32 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:12:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:12:32 --> URI Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Router Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Output Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Security Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Input Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:12:32 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Loader Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:12:32 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:12:32 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Session Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:12:32 --> Session routines successfully run
DEBUG - 2016-02-11 18:12:32 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Email Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Controller Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:12:32 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:32 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:12:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:12:32 --> Final output sent to browser
DEBUG - 2016-02-11 18:12:32 --> Total execution time: 0.3393
DEBUG - 2016-02-11 18:12:45 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:12:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:12:45 --> URI Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Router Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Output Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Security Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Input Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:12:45 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Language Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Config Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Loader Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:12:45 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:12:45 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Session Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:12:45 --> Session routines successfully run
DEBUG - 2016-02-11 18:12:45 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Email Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Controller Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:12:45 --> Model Class Initialized
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:12:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:12:45 --> Final output sent to browser
DEBUG - 2016-02-11 18:12:45 --> Total execution time: 0.2673
DEBUG - 2016-02-11 18:13:05 --> Config Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:13:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:13:05 --> URI Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Router Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Output Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Security Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Input Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:13:05 --> Language Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Language Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Config Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Loader Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:13:05 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:13:05 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Session Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:13:05 --> Session routines successfully run
DEBUG - 2016-02-11 18:13:05 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Email Class Initialized
DEBUG - 2016-02-11 18:13:05 --> Controller Class Initialized
DEBUG - 2016-02-11 18:13:06 --> leases MX_Controller Initialized
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:13:06 --> XSS Filtering completed
DEBUG - 2016-02-11 18:13:06 --> XSS Filtering completed
DEBUG - 2016-02-11 18:13:06 --> XSS Filtering completed
DEBUG - 2016-02-11 18:13:06 --> XSS Filtering completed
DEBUG - 2016-02-11 18:13:06 --> Config Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:13:06 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:13:06 --> URI Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Router Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Output Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Security Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Input Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:13:06 --> Language Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Language Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Config Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Loader Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:13:06 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:13:06 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Session Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:13:06 --> Session routines successfully run
DEBUG - 2016-02-11 18:13:06 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Email Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Controller Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:13:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:13:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:13:06 --> Final output sent to browser
DEBUG - 2016-02-11 18:13:06 --> Total execution time: 0.2679
DEBUG - 2016-02-11 18:13:08 --> Config Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:13:08 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:13:08 --> URI Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Router Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Output Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Security Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Input Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:13:08 --> Language Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Language Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Config Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Loader Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:13:08 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:13:08 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Session Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:13:08 --> Session routines successfully run
DEBUG - 2016-02-11 18:13:08 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Email Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Controller Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:13:08 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:08 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:13:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:13:08 --> Final output sent to browser
DEBUG - 2016-02-11 18:13:08 --> Total execution time: 0.2387
DEBUG - 2016-02-11 18:13:37 --> Config Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:13:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:13:37 --> URI Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Router Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Output Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Security Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Input Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:13:37 --> Language Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Language Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Config Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Loader Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:13:37 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:13:37 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Session Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:13:37 --> Session routines successfully run
DEBUG - 2016-02-11 18:13:37 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Email Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Controller Class Initialized
DEBUG - 2016-02-11 18:13:37 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:13:37 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:13:37 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:13:37 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:37 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:13:37 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:13:37 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:13:37 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:13:37 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:38 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:13:38 --> Model Class Initialized
DEBUG - 2016-02-11 18:13:38 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-11 18:13:38 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-11 18:13:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:13:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:13:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:13:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:13:38 --> Final output sent to browser
DEBUG - 2016-02-11 18:13:38 --> Total execution time: 0.7016
DEBUG - 2016-02-11 18:15:31 --> Config Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:15:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:15:31 --> URI Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Router Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Output Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Security Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Input Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:15:31 --> Language Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Language Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Config Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Loader Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:15:31 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:15:31 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Session Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:15:31 --> Session routines successfully run
DEBUG - 2016-02-11 18:15:31 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Email Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Controller Class Initialized
DEBUG - 2016-02-11 18:15:31 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:15:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:15:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:15:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:15:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:15:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:15:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:15:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:15:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:15:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:15:31 --> Final output sent to browser
DEBUG - 2016-02-11 18:15:31 --> Total execution time: 0.2759
DEBUG - 2016-02-11 18:16:04 --> Config Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:16:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:16:04 --> URI Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Router Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Output Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Security Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Input Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:16:04 --> Language Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Language Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Config Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Loader Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:16:04 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:16:04 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Session Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:16:04 --> Session routines successfully run
DEBUG - 2016-02-11 18:16:04 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Email Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Controller Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:16:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:16:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:16:04 --> Final output sent to browser
DEBUG - 2016-02-11 18:16:04 --> Total execution time: 0.4643
DEBUG - 2016-02-11 18:17:27 --> Config Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:17:27 --> URI Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Router Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Output Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Security Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Input Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:17:27 --> Language Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Language Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Config Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Loader Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:17:27 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:17:27 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Session Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:17:27 --> Session routines successfully run
DEBUG - 2016-02-11 18:17:27 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Email Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Controller Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:17:27 --> Model Class Initialized
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:17:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:17:27 --> Final output sent to browser
DEBUG - 2016-02-11 18:17:27 --> Total execution time: 0.4476
DEBUG - 2016-02-11 18:22:21 --> Config Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:22:21 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:22:21 --> URI Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Router Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Output Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Security Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Input Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:22:21 --> Language Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Language Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Config Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Loader Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:22:21 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:22:21 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Session Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:22:21 --> Session routines successfully run
DEBUG - 2016-02-11 18:22:21 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Email Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Controller Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:22:21 --> XSS Filtering completed
DEBUG - 2016-02-11 18:22:21 --> XSS Filtering completed
DEBUG - 2016-02-11 18:22:21 --> XSS Filtering completed
DEBUG - 2016-02-11 18:22:21 --> XSS Filtering completed
DEBUG - 2016-02-11 18:22:21 --> Config Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:22:21 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:22:21 --> URI Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Router Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Output Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Security Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Input Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:22:21 --> Language Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Language Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Config Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Loader Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:22:21 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:22:21 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Session Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:22:21 --> Session routines successfully run
DEBUG - 2016-02-11 18:22:21 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Email Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Controller Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:22:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:22:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:22:21 --> Final output sent to browser
DEBUG - 2016-02-11 18:22:21 --> Total execution time: 0.2744
DEBUG - 2016-02-11 18:23:22 --> Config Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:23:22 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:23:22 --> URI Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Router Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Output Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Security Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Input Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:23:22 --> Language Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Language Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Config Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Loader Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:23:22 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:23:22 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Session Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:23:22 --> Session routines successfully run
DEBUG - 2016-02-11 18:23:22 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Email Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Controller Class Initialized
DEBUG - 2016-02-11 18:23:22 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:23:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:23:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:23:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:23:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:23:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:23:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:23:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:23:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:23:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:23:22 --> Final output sent to browser
DEBUG - 2016-02-11 18:23:22 --> Total execution time: 0.3280
DEBUG - 2016-02-11 18:24:50 --> Config Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:24:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:24:50 --> URI Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Router Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Output Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Security Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Input Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:24:50 --> Language Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Language Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Config Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Loader Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:24:50 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:24:50 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Session Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:24:50 --> Session routines successfully run
DEBUG - 2016-02-11 18:24:50 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Email Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Controller Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:24:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:24:50 --> XSS Filtering completed
DEBUG - 2016-02-11 18:24:50 --> XSS Filtering completed
DEBUG - 2016-02-11 18:24:50 --> XSS Filtering completed
DEBUG - 2016-02-11 18:24:50 --> XSS Filtering completed
DEBUG - 2016-02-11 18:24:50 --> Config Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:24:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:24:50 --> URI Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Router Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Output Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Security Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Input Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:24:50 --> Language Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Language Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Config Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Loader Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:24:50 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:24:50 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Session Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:24:50 --> Session routines successfully run
DEBUG - 2016-02-11 18:24:50 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:24:50 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:24:51 --> Email Class Initialized
DEBUG - 2016-02-11 18:24:51 --> Controller Class Initialized
DEBUG - 2016-02-11 18:24:51 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:24:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:24:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:24:51 --> Final output sent to browser
DEBUG - 2016-02-11 18:24:51 --> Total execution time: 0.2814
DEBUG - 2016-02-11 18:24:53 --> Config Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:24:53 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:24:53 --> URI Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Router Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Output Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Security Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Input Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:24:53 --> Language Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Language Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Config Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Loader Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:24:53 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:24:53 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Session Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:24:53 --> Session routines successfully run
DEBUG - 2016-02-11 18:24:53 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Email Class Initialized
DEBUG - 2016-02-11 18:24:53 --> Controller Class Initialized
DEBUG - 2016-02-11 18:24:54 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:24:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:24:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:24:54 --> Final output sent to browser
DEBUG - 2016-02-11 18:24:54 --> Total execution time: 0.3480
DEBUG - 2016-02-11 18:25:03 --> Config Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:25:03 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:25:03 --> URI Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Router Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Output Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Security Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Input Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:25:03 --> Language Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Language Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Config Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Loader Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:25:03 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:25:03 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Session Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:25:03 --> Session routines successfully run
DEBUG - 2016-02-11 18:25:03 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Email Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Controller Class Initialized
DEBUG - 2016-02-11 18:25:03 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:25:03 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:25:03 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:25:03 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:25:03 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:25:03 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:25:03 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:25:03 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:25:03 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:25:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:25:03 --> Final output sent to browser
DEBUG - 2016-02-11 18:25:03 --> Total execution time: 0.2591
DEBUG - 2016-02-11 18:25:21 --> Config Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:25:21 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:25:21 --> URI Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Router Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Output Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Security Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Input Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:25:21 --> Language Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Language Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Config Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Loader Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:25:21 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:25:21 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Session Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:25:21 --> Session routines successfully run
DEBUG - 2016-02-11 18:25:21 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Email Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Controller Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:25:21 --> Model Class Initialized
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:25:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:25:21 --> Final output sent to browser
DEBUG - 2016-02-11 18:25:21 --> Total execution time: 0.2862
DEBUG - 2016-02-11 18:26:26 --> Config Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:26:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:26:26 --> URI Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Router Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Output Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Security Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Input Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:26:26 --> Language Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Language Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Config Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Loader Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:26:26 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:26:26 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Session Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:26:26 --> Session routines successfully run
DEBUG - 2016-02-11 18:26:26 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Email Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Controller Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:26:26 --> XSS Filtering completed
DEBUG - 2016-02-11 18:26:26 --> XSS Filtering completed
DEBUG - 2016-02-11 18:26:26 --> XSS Filtering completed
DEBUG - 2016-02-11 18:26:26 --> XSS Filtering completed
DEBUG - 2016-02-11 18:26:26 --> Config Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:26:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:26:26 --> URI Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Router Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Output Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Security Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Input Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:26:26 --> Language Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Language Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Config Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Loader Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:26:26 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:26:26 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Session Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:26:26 --> Session routines successfully run
DEBUG - 2016-02-11 18:26:26 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Email Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Controller Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:26:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:26:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:26:27 --> Final output sent to browser
DEBUG - 2016-02-11 18:26:27 --> Total execution time: 0.2649
DEBUG - 2016-02-11 18:26:57 --> Config Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:26:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:26:57 --> URI Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Router Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Output Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Security Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Input Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:26:57 --> Language Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Language Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Config Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Loader Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:26:57 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:26:57 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Session Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:26:57 --> Session routines successfully run
DEBUG - 2016-02-11 18:26:57 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Email Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Controller Class Initialized
DEBUG - 2016-02-11 18:26:57 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:26:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:26:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:26:58 --> XSS Filtering completed
DEBUG - 2016-02-11 18:26:58 --> XSS Filtering completed
DEBUG - 2016-02-11 18:26:58 --> XSS Filtering completed
DEBUG - 2016-02-11 18:26:58 --> XSS Filtering completed
DEBUG - 2016-02-11 18:26:58 --> Config Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:26:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:26:58 --> URI Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Router Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Output Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Security Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Input Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:26:58 --> Language Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Language Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Config Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Loader Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:26:58 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:26:58 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Session Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:26:58 --> Session routines successfully run
DEBUG - 2016-02-11 18:26:58 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Email Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Controller Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:26:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:26:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:26:58 --> Final output sent to browser
DEBUG - 2016-02-11 18:26:58 --> Total execution time: 0.2713
DEBUG - 2016-02-11 18:27:31 --> Config Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:27:31 --> URI Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Router Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Output Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Security Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Input Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:27:31 --> Language Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Language Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Config Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Loader Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:27:31 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:27:31 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Session Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:27:31 --> Session routines successfully run
DEBUG - 2016-02-11 18:27:31 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Email Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Controller Class Initialized
DEBUG - 2016-02-11 18:27:31 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:27:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:27:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:27:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:27:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:27:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:27:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:27:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:27:31 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:27:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:27:31 --> Final output sent to browser
DEBUG - 2016-02-11 18:27:31 --> Total execution time: 0.2378
DEBUG - 2016-02-11 18:27:44 --> Config Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:27:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:27:44 --> URI Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Router Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Output Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Security Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Input Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:27:44 --> Language Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Language Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Config Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Loader Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:27:44 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:27:44 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Session Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:27:44 --> Session routines successfully run
DEBUG - 2016-02-11 18:27:44 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Email Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Controller Class Initialized
DEBUG - 2016-02-11 18:27:44 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:27:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:27:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:27:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:27:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:27:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:27:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:27:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:27:44 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:27:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:27:44 --> Final output sent to browser
DEBUG - 2016-02-11 18:27:44 --> Total execution time: 0.2646
DEBUG - 2016-02-11 18:27:51 --> Config Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:27:51 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:27:51 --> URI Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Router Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Output Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Security Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Input Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:27:51 --> Language Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Language Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Config Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Loader Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:27:51 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:27:51 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Session Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:27:51 --> Session routines successfully run
DEBUG - 2016-02-11 18:27:51 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Email Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Controller Class Initialized
DEBUG - 2016-02-11 18:27:51 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:27:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:27:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:27:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:27:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:27:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:27:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:27:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:27:51 --> Model Class Initialized
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:27:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:27:51 --> Final output sent to browser
DEBUG - 2016-02-11 18:27:51 --> Total execution time: 0.3591
DEBUG - 2016-02-11 18:28:19 --> Config Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:28:19 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:28:19 --> URI Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Router Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Output Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Security Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Input Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:28:19 --> Language Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Language Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Config Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Loader Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:28:19 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:28:19 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Session Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:28:19 --> Session routines successfully run
DEBUG - 2016-02-11 18:28:19 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Email Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Controller Class Initialized
DEBUG - 2016-02-11 18:28:19 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:28:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:28:19 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:28:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:28:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:28:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:28:19 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:28:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:28:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:28:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:28:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:28:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:28:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:28:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:28:19 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:28:19 --> Model Class Initialized
DEBUG - 2016-02-11 18:28:19 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-11 18:28:20 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-11 18:28:20 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-11 18:28:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:28:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:28:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:28:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:28:20 --> Final output sent to browser
DEBUG - 2016-02-11 18:28:20 --> Total execution time: 0.3739
DEBUG - 2016-02-11 18:33:31 --> Config Class Initialized
DEBUG - 2016-02-11 18:33:31 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:33:31 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:33:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:33:31 --> URI Class Initialized
DEBUG - 2016-02-11 18:33:31 --> Router Class Initialized
ERROR - 2016-02-11 18:33:31 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 18:33:43 --> Config Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:33:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:33:43 --> URI Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Router Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Output Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Security Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Input Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:33:43 --> Language Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Language Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Config Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Loader Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:33:43 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:33:43 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Session Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:33:43 --> Session routines successfully run
DEBUG - 2016-02-11 18:33:43 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Email Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Controller Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:33:43 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:33:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:33:43 --> Final output sent to browser
DEBUG - 2016-02-11 18:33:43 --> Total execution time: 0.3512
DEBUG - 2016-02-11 18:33:49 --> Config Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:33:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:33:49 --> URI Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Router Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Output Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Security Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Input Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:33:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Config Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Loader Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:33:49 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:33:49 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Session Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:33:49 --> Session routines successfully run
DEBUG - 2016-02-11 18:33:49 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Email Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Controller Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:33:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:33:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:33:49 --> Final output sent to browser
DEBUG - 2016-02-11 18:33:49 --> Total execution time: 0.2695
DEBUG - 2016-02-11 18:34:54 --> Config Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:34:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:34:54 --> URI Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Router Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Output Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Security Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Input Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:34:54 --> Language Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Language Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Config Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Loader Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:34:54 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:34:54 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Session Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:34:54 --> Session routines successfully run
DEBUG - 2016-02-11 18:34:54 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Email Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Controller Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:34:54 --> Model Class Initialized
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:34:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:34:54 --> Final output sent to browser
DEBUG - 2016-02-11 18:34:54 --> Total execution time: 0.3563
DEBUG - 2016-02-11 18:35:52 --> Config Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:35:52 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:35:52 --> URI Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Router Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Output Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Security Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Input Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:35:52 --> Language Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Language Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Config Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Loader Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:35:52 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:35:52 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Session Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:35:52 --> Session routines successfully run
DEBUG - 2016-02-11 18:35:52 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Email Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Controller Class Initialized
DEBUG - 2016-02-11 18:35:52 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:35:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:35:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:35:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:35:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:35:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:35:52 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:35:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:35:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:35:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:35:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:35:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:35:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:35:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:35:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:35:52 --> Model Class Initialized
DEBUG - 2016-02-11 18:35:53 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-11 18:35:53 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-11 18:35:53 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-11 18:35:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:35:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:35:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:35:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:35:53 --> Final output sent to browser
DEBUG - 2016-02-11 18:35:53 --> Total execution time: 0.2650
DEBUG - 2016-02-11 18:36:05 --> Config Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:36:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:36:05 --> URI Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Router Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Output Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Security Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Input Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:36:05 --> Language Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Language Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Config Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Loader Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:36:05 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:36:05 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Session Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:36:05 --> Session routines successfully run
DEBUG - 2016-02-11 18:36:05 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Email Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Controller Class Initialized
DEBUG - 2016-02-11 18:36:05 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:36:05 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:36:05 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:36:05 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:36:05 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:36:05 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:36:05 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:36:05 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:36:05 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:36:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:36:05 --> Final output sent to browser
DEBUG - 2016-02-11 18:36:05 --> Total execution time: 0.2578
DEBUG - 2016-02-11 18:36:40 --> Config Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:36:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:36:40 --> URI Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Router Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Output Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Security Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Input Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:36:40 --> Language Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Language Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Config Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Loader Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:36:40 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:36:40 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Session Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:36:40 --> Session routines successfully run
DEBUG - 2016-02-11 18:36:40 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Email Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Controller Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:36:40 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:40 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:36:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:36:40 --> Final output sent to browser
DEBUG - 2016-02-11 18:36:40 --> Total execution time: 0.2486
DEBUG - 2016-02-11 18:36:49 --> Config Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:36:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:36:49 --> URI Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Router Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Output Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Security Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Input Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:36:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Config Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Loader Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:36:49 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:36:49 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Session Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:36:49 --> Session routines successfully run
DEBUG - 2016-02-11 18:36:49 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Email Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Controller Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:36:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:36:49 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:36:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:36:49 --> Final output sent to browser
DEBUG - 2016-02-11 18:36:49 --> Total execution time: 0.2455
DEBUG - 2016-02-11 18:37:35 --> Config Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:37:35 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:37:35 --> URI Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Router Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Output Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Security Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Input Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:37:35 --> Language Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Language Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Config Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Loader Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:37:35 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:37:35 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Session Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:37:35 --> Session routines successfully run
DEBUG - 2016-02-11 18:37:35 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Email Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Controller Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-11 18:37:35 --> XSS Filtering completed
DEBUG - 2016-02-11 18:37:35 --> XSS Filtering completed
DEBUG - 2016-02-11 18:37:35 --> XSS Filtering completed
DEBUG - 2016-02-11 18:37:35 --> XSS Filtering completed
DEBUG - 2016-02-11 18:37:35 --> XSS Filtering completed
DEBUG - 2016-02-11 18:37:35 --> XSS Filtering completed
DEBUG - 2016-02-11 18:37:35 --> Config Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:37:35 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:37:35 --> URI Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Router Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Output Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Security Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Input Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:37:35 --> Language Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Language Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Config Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Loader Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:37:35 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:37:35 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Session Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:37:35 --> Session routines successfully run
DEBUG - 2016-02-11 18:37:35 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Email Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Controller Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Property MX_Controller Initialized
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:37:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:35 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:37:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:37:35 --> Final output sent to browser
DEBUG - 2016-02-11 18:37:35 --> Total execution time: 0.2299
DEBUG - 2016-02-11 18:37:39 --> Config Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:37:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:37:39 --> URI Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Router Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Output Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Security Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Input Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:37:39 --> Language Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Language Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Config Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Loader Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:37:39 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:37:39 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Session Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:37:39 --> Session routines successfully run
DEBUG - 2016-02-11 18:37:39 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Email Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Controller Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:37:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:39 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:37:40 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-02-11 18:37:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:37:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:37:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:37:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:37:40 --> Final output sent to browser
DEBUG - 2016-02-11 18:37:40 --> Total execution time: 0.2368
DEBUG - 2016-02-11 18:37:48 --> Config Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:37:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:37:48 --> URI Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Router Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Output Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Security Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Input Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:37:48 --> Language Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Language Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Config Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Loader Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:37:48 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:37:48 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Session Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:37:48 --> Session routines successfully run
DEBUG - 2016-02-11 18:37:48 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Email Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Controller Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:37:48 --> Model Class Initialized
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:37:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:37:49 --> Final output sent to browser
DEBUG - 2016-02-11 18:37:49 --> Total execution time: 0.3433
DEBUG - 2016-02-11 18:38:00 --> Config Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:38:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:38:00 --> URI Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Router Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Output Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Security Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Input Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:38:00 --> Language Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Language Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Config Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Loader Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:38:00 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:38:00 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Session Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:38:00 --> Session routines successfully run
DEBUG - 2016-02-11 18:38:00 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Email Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Controller Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:38:00 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:38:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:38:00 --> Final output sent to browser
DEBUG - 2016-02-11 18:38:00 --> Total execution time: 0.2745
DEBUG - 2016-02-11 18:38:26 --> Config Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:38:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:38:26 --> URI Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Router Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Output Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Security Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Input Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:38:26 --> Language Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Language Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Config Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Loader Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:38:26 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:38:26 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Session Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:38:26 --> Session routines successfully run
DEBUG - 2016-02-11 18:38:26 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Email Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Controller Class Initialized
DEBUG - 2016-02-11 18:38:26 --> Admin MX_Controller Initialized
DEBUG - 2016-02-11 18:38:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:38:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:38:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:38:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:38:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:38:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:38:26 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:38:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:38:26 --> Final output sent to browser
DEBUG - 2016-02-11 18:38:26 --> Total execution time: 0.2207
DEBUG - 2016-02-11 18:38:53 --> Config Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:38:53 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:38:53 --> URI Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Router Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Output Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Security Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Input Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:38:53 --> Language Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Language Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Config Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Loader Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:38:53 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:38:53 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Session Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:38:53 --> Session routines successfully run
DEBUG - 2016-02-11 18:38:53 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Email Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Controller Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:38:53 --> Model Class Initialized
DEBUG - 2016-02-11 18:38:53 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:38:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:38:53 --> Final output sent to browser
DEBUG - 2016-02-11 18:38:53 --> Total execution time: 0.2554
DEBUG - 2016-02-11 18:39:04 --> Config Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:39:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:39:04 --> URI Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Router Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Output Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Security Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Input Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:39:04 --> Language Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Language Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Config Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Loader Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:39:04 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:39:04 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Session Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:39:04 --> Session routines successfully run
DEBUG - 2016-02-11 18:39:04 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Email Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Controller Class Initialized
DEBUG - 2016-02-11 18:39:04 --> Water_management MX_Controller Initialized
DEBUG - 2016-02-11 18:39:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2016-02-11 18:39:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:39:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:39:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:39:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:39:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:39:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:39:04 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:39:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:39:04 --> Final output sent to browser
DEBUG - 2016-02-11 18:39:04 --> Total execution time: 0.5000
DEBUG - 2016-02-11 18:39:22 --> Config Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:39:22 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:39:22 --> URI Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Router Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Output Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Security Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Input Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:39:22 --> Language Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Language Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Config Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Loader Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:39:22 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:39:22 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Session Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:39:22 --> Session routines successfully run
DEBUG - 2016-02-11 18:39:22 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Email Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Controller Class Initialized
DEBUG - 2016-02-11 18:39:22 --> Water_management MX_Controller Initialized
DEBUG - 2016-02-11 18:39:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:22 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2016-02-11 18:39:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:39:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:39:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:39:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:39:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:39:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:22 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:39:22 --> Model Class Initialized
DEBUG - 2016-02-11 18:39:22 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2016-02-11 18:39:22 --> Final output sent to browser
DEBUG - 2016-02-11 18:39:22 --> Total execution time: 0.3228
DEBUG - 2016-02-11 18:40:16 --> Config Class Initialized
DEBUG - 2016-02-11 18:40:16 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:40:16 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:40:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:40:16 --> URI Class Initialized
DEBUG - 2016-02-11 18:40:16 --> Router Class Initialized
ERROR - 2016-02-11 18:40:16 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 18:40:39 --> Config Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:40:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:40:39 --> URI Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Router Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Output Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Security Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Input Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:40:39 --> Language Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Language Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Config Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Loader Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:40:39 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:40:39 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Session Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:40:39 --> Session routines successfully run
DEBUG - 2016-02-11 18:40:39 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Email Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Controller Class Initialized
DEBUG - 2016-02-11 18:40:39 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:40:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:40:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:40:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:40:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:40:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:40:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:40:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:40:39 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:40:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:40:39 --> Final output sent to browser
DEBUG - 2016-02-11 18:40:39 --> Total execution time: 0.2608
DEBUG - 2016-02-11 18:40:49 --> Config Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:40:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:40:49 --> URI Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Router Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Output Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Security Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Input Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:40:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Language Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Config Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Loader Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:40:49 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:40:49 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Session Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:40:49 --> Session routines successfully run
DEBUG - 2016-02-11 18:40:49 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Email Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Controller Class Initialized
DEBUG - 2016-02-11 18:40:49 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:40:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:40:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:40:49 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:49 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:40:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:40:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:40:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:40:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:40:50 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:40:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:40:50 --> Final output sent to browser
DEBUG - 2016-02-11 18:40:50 --> Total execution time: 0.2625
DEBUG - 2016-02-11 18:40:57 --> Config Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:40:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:40:57 --> URI Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Router Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Output Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Security Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Input Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:40:57 --> Language Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Language Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Config Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Loader Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:40:57 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:40:57 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Session Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:40:57 --> Session routines successfully run
DEBUG - 2016-02-11 18:40:57 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Email Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Controller Class Initialized
DEBUG - 2016-02-11 18:40:57 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:40:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:40:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:40:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:40:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:40:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:40:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:40:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:40:57 --> Model Class Initialized
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:40:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:40:57 --> Final output sent to browser
DEBUG - 2016-02-11 18:40:57 --> Total execution time: 0.2704
DEBUG - 2016-02-11 18:41:05 --> Config Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:41:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:41:05 --> URI Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Router Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Output Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Security Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Input Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:41:05 --> Language Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Language Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Config Class Initialized
DEBUG - 2016-02-11 18:41:05 --> Loader Class Initialized
DEBUG - 2016-02-11 18:41:06 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:41:06 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:41:06 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:41:06 --> Session Class Initialized
DEBUG - 2016-02-11 18:41:06 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:41:06 --> Session routines successfully run
DEBUG - 2016-02-11 18:41:06 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:41:06 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:41:06 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:41:06 --> Email Class Initialized
DEBUG - 2016-02-11 18:41:06 --> Controller Class Initialized
DEBUG - 2016-02-11 18:41:06 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:41:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:41:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:41:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:41:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:41:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:41:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:41:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:41:06 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:41:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:41:06 --> Final output sent to browser
DEBUG - 2016-02-11 18:41:06 --> Total execution time: 0.2751
DEBUG - 2016-02-11 18:41:10 --> Config Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:41:10 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:41:10 --> URI Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Router Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Output Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Security Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Input Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:41:10 --> Language Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Language Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Config Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Loader Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:41:10 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:41:10 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Session Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:41:10 --> Session routines successfully run
DEBUG - 2016-02-11 18:41:10 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Email Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Controller Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:41:10 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:10 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:41:10 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:41:10 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:10 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:41:10 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:41:10 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:41:10 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:41:10 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:10 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:41:10 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Config Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:41:10 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:41:10 --> URI Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Router Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Output Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Security Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Input Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:41:10 --> Language Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Language Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Config Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Loader Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:41:10 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:41:10 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Session Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:41:10 --> Session routines successfully run
DEBUG - 2016-02-11 18:41:10 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Email Class Initialized
DEBUG - 2016-02-11 18:41:10 --> Controller Class Initialized
DEBUG - 2016-02-11 18:41:11 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:41:11 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:41:11 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:41:11 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:41:11 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:41:11 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:41:11 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:41:11 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:41:11 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:41:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:41:11 --> Final output sent to browser
DEBUG - 2016-02-11 18:41:11 --> Total execution time: 0.3352
DEBUG - 2016-02-11 18:41:15 --> Config Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:41:15 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:41:15 --> URI Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Router Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Output Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Security Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Input Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:41:15 --> Language Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Language Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Config Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Loader Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:41:15 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:41:15 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Session Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:41:15 --> Session routines successfully run
DEBUG - 2016-02-11 18:41:15 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Email Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Controller Class Initialized
DEBUG - 2016-02-11 18:41:15 --> Reports MX_Controller Initialized
DEBUG - 2016-02-11 18:41:15 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:41:15 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:41:15 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-11 18:41:15 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:41:15 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:41:15 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:41:15 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:41:15 --> Model Class Initialized
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:41:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:41:15 --> Final output sent to browser
DEBUG - 2016-02-11 18:41:15 --> Total execution time: 0.2761
DEBUG - 2016-02-11 18:42:33 --> Config Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:42:33 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:42:33 --> URI Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Router Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Output Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Security Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Input Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:42:33 --> Language Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Language Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Config Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Loader Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:42:33 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:42:33 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Session Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:42:33 --> Session routines successfully run
DEBUG - 2016-02-11 18:42:33 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Email Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Controller Class Initialized
DEBUG - 2016-02-11 18:42:33 --> Personnel MX_Controller Initialized
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-02-11 18:42:33 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:42:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:42:33 --> Final output sent to browser
DEBUG - 2016-02-11 18:42:33 --> Total execution time: 0.2652
DEBUG - 2016-02-11 18:42:58 --> Config Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:42:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:42:58 --> URI Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Router Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Output Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Security Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Input Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:42:58 --> Language Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Language Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Config Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Loader Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:42:58 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:42:58 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Session Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:42:58 --> Session routines successfully run
DEBUG - 2016-02-11 18:42:58 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Email Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Controller Class Initialized
DEBUG - 2016-02-11 18:42:58 --> Branches MX_Controller Initialized
DEBUG - 2016-02-11 18:42:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:42:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:42:58 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:42:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:42:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:42:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:42:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:42:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-02-11 18:42:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-02-11 18:42:59 --> Model Class Initialized
DEBUG - 2016-02-11 18:42:59 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/admin/views/branches/all_branches.php
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:42:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:42:59 --> Final output sent to browser
DEBUG - 2016-02-11 18:42:59 --> Total execution time: 0.3204
DEBUG - 2016-02-11 18:42:59 --> Config Class Initialized
DEBUG - 2016-02-11 18:42:59 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:42:59 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:42:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:42:59 --> URI Class Initialized
DEBUG - 2016-02-11 18:42:59 --> Router Class Initialized
ERROR - 2016-02-11 18:42:59 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 18:42:59 --> Config Class Initialized
DEBUG - 2016-02-11 18:42:59 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:42:59 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:42:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:42:59 --> URI Class Initialized
DEBUG - 2016-02-11 18:42:59 --> Router Class Initialized
ERROR - 2016-02-11 18:42:59 --> 404 Page Not Found --> 
DEBUG - 2016-02-11 18:43:17 --> Config Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:43:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:43:17 --> URI Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Router Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Output Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Security Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Input Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:43:17 --> Language Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Language Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Config Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Loader Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:43:17 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:43:17 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Session Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:43:17 --> Session routines successfully run
DEBUG - 2016-02-11 18:43:17 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Email Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Controller Class Initialized
DEBUG - 2016-02-11 18:43:17 --> Admin MX_Controller Initialized
DEBUG - 2016-02-11 18:43:17 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:43:17 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:43:17 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:43:17 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:43:17 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:43:17 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:43:17 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/admin/views/configuration.php
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:43:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:43:17 --> Final output sent to browser
DEBUG - 2016-02-11 18:43:17 --> Total execution time: 0.4725
DEBUG - 2016-02-11 18:43:35 --> Config Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:43:35 --> URI Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Router Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Output Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Security Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Input Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:43:35 --> Language Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Language Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Config Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Loader Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:43:35 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:43:35 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Session Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:43:35 --> Session routines successfully run
DEBUG - 2016-02-11 18:43:35 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Email Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Controller Class Initialized
DEBUG - 2016-02-11 18:43:35 --> Sections MX_Controller Initialized
DEBUG - 2016-02-11 18:43:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:43:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:43:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:43:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:43:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:43:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:43:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:43:35 --> Model Class Initialized
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:43:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:43:35 --> Final output sent to browser
DEBUG - 2016-02-11 18:43:35 --> Total execution time: 0.3166
DEBUG - 2016-02-11 18:44:18 --> Config Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Hooks Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Utf8 Class Initialized
DEBUG - 2016-02-11 18:44:18 --> UTF-8 Support Enabled
DEBUG - 2016-02-11 18:44:18 --> URI Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Router Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Output Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Security Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Input Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-11 18:44:18 --> Language Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Language Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Config Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Loader Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Helper loaded: url_helper
DEBUG - 2016-02-11 18:44:18 --> Helper loaded: form_helper
DEBUG - 2016-02-11 18:44:18 --> Database Driver Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Session Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Helper loaded: string_helper
DEBUG - 2016-02-11 18:44:18 --> Session routines successfully run
DEBUG - 2016-02-11 18:44:18 --> Form Validation Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Pagination Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Encrypt Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Email Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Controller Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> Image Lib Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-11 18:44:18 --> Model Class Initialized
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-11 18:44:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-11 18:44:18 --> Final output sent to browser
DEBUG - 2016-02-11 18:44:18 --> Total execution time: 0.3282
