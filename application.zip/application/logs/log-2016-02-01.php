<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-01 16:36:38 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:36:38 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Router Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Output Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Security Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Input Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-01 16:36:38 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Loader Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Helper loaded: url_helper
DEBUG - 2016-02-01 16:36:38 --> Helper loaded: form_helper
DEBUG - 2016-02-01 16:36:38 --> Database Driver Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Session Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Helper loaded: string_helper
DEBUG - 2016-02-01 16:36:38 --> Session routines successfully run
DEBUG - 2016-02-01 16:36:38 --> Form Validation Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Pagination Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Encrypt Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Email Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Controller Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:36:38 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Router Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Output Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Security Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Input Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-01 16:36:38 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Loader Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Helper loaded: url_helper
DEBUG - 2016-02-01 16:36:38 --> Helper loaded: form_helper
DEBUG - 2016-02-01 16:36:38 --> Database Driver Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Session Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Helper loaded: string_helper
DEBUG - 2016-02-01 16:36:38 --> Session routines successfully run
DEBUG - 2016-02-01 16:36:38 --> Form Validation Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Pagination Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Encrypt Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Email Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Controller Class Initialized
DEBUG - 2016-02-01 16:36:38 --> Auth MX_Controller Initialized
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-01 16:36:38 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-01 16:36:38 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-01 16:36:38 --> Final output sent to browser
DEBUG - 2016-02-01 16:36:38 --> Total execution time: 0.1460
DEBUG - 2016-02-01 16:36:39 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:36:39 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Router Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Config Class Initialized
ERROR - 2016-02-01 16:36:39 --> 404 Page Not Found --> 
DEBUG - 2016-02-01 16:36:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:36:39 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Router Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:39 --> UTF-8 Support Enabled
ERROR - 2016-02-01 16:36:39 --> 404 Page Not Found --> 
DEBUG - 2016-02-01 16:36:39 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:36:39 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:39 --> Router Class Initialized
ERROR - 2016-02-01 16:36:39 --> 404 Page Not Found --> 
DEBUG - 2016-02-01 16:36:39 --> Router Class Initialized
ERROR - 2016-02-01 16:36:39 --> 404 Page Not Found --> 
DEBUG - 2016-02-01 16:36:41 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:41 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:36:41 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Router Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Output Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Security Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Input Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-01 16:36:41 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Loader Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Helper loaded: url_helper
DEBUG - 2016-02-01 16:36:41 --> Helper loaded: form_helper
DEBUG - 2016-02-01 16:36:41 --> Database Driver Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Session Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Helper loaded: string_helper
DEBUG - 2016-02-01 16:36:41 --> Session routines successfully run
DEBUG - 2016-02-01 16:36:41 --> Form Validation Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Pagination Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Encrypt Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Email Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Controller Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Auth MX_Controller Initialized
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-01 16:36:41 --> XSS Filtering completed
DEBUG - 2016-02-01 16:36:41 --> Unable to find validation rule: exists
DEBUG - 2016-02-01 16:36:41 --> XSS Filtering completed
DEBUG - 2016-02-01 16:36:41 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:41 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:36:41 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Router Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Output Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Security Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Input Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-01 16:36:41 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Loader Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Helper loaded: url_helper
DEBUG - 2016-02-01 16:36:41 --> Helper loaded: form_helper
DEBUG - 2016-02-01 16:36:41 --> Database Driver Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Session Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Helper loaded: string_helper
DEBUG - 2016-02-01 16:36:41 --> Session routines successfully run
DEBUG - 2016-02-01 16:36:41 --> Form Validation Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Pagination Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Encrypt Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Email Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Controller Class Initialized
DEBUG - 2016-02-01 16:36:41 --> Admin MX_Controller Initialized
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-01 16:36:41 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-01 16:36:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-01 16:36:41 --> Final output sent to browser
DEBUG - 2016-02-01 16:36:41 --> Total execution time: 0.1901
DEBUG - 2016-02-01 16:36:48 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:36:48 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Router Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Output Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Security Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Input Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-01 16:36:48 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Loader Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Helper loaded: url_helper
DEBUG - 2016-02-01 16:36:48 --> Helper loaded: form_helper
DEBUG - 2016-02-01 16:36:48 --> Database Driver Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Session Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Helper loaded: string_helper
DEBUG - 2016-02-01 16:36:48 --> Session routines successfully run
DEBUG - 2016-02-01 16:36:48 --> Form Validation Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Pagination Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Encrypt Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Email Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Controller Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> Image Lib Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-01 16:36:48 --> Model Class Initialized
ERROR - 2016-02-01 16:36:48 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-01 16:36:48 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-01 16:36:48 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-01 16:36:48 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-01 16:36:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-01 16:36:48 --> Final output sent to browser
DEBUG - 2016-02-01 16:36:48 --> Total execution time: 0.3479
DEBUG - 2016-02-01 16:36:56 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:36:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:36:56 --> URI Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Router Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Output Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Security Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Input Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-01 16:36:56 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Language Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Config Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Loader Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Helper loaded: url_helper
DEBUG - 2016-02-01 16:36:56 --> Helper loaded: form_helper
DEBUG - 2016-02-01 16:36:56 --> Database Driver Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Session Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Helper loaded: string_helper
DEBUG - 2016-02-01 16:36:56 --> Session routines successfully run
DEBUG - 2016-02-01 16:36:56 --> Form Validation Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Pagination Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Encrypt Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Email Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Controller Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> Image Lib Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-01 16:36:56 --> Model Class Initialized
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-01 16:36:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-01 16:36:56 --> Final output sent to browser
DEBUG - 2016-02-01 16:36:56 --> Total execution time: 0.3029
DEBUG - 2016-02-01 16:37:21 --> Config Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Hooks Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Utf8 Class Initialized
DEBUG - 2016-02-01 16:37:21 --> UTF-8 Support Enabled
DEBUG - 2016-02-01 16:37:21 --> URI Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Router Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Output Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Security Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Input Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-01 16:37:21 --> Language Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Language Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Config Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Loader Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Helper loaded: url_helper
DEBUG - 2016-02-01 16:37:21 --> Helper loaded: form_helper
DEBUG - 2016-02-01 16:37:21 --> Database Driver Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Session Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Helper loaded: string_helper
DEBUG - 2016-02-01 16:37:21 --> Session routines successfully run
DEBUG - 2016-02-01 16:37:21 --> Form Validation Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Pagination Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Encrypt Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Email Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Controller Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> Image Lib Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-01 16:37:21 --> Model Class Initialized
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-01 16:37:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-01 16:37:21 --> Final output sent to browser
DEBUG - 2016-02-01 16:37:21 --> Total execution time: 0.2660
