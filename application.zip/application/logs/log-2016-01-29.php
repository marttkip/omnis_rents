<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-29 16:09:26 --> Config Class Initialized
DEBUG - 2016-01-29 16:09:26 --> Hooks Class Initialized
DEBUG - 2016-01-29 16:09:26 --> Utf8 Class Initialized
DEBUG - 2016-01-29 16:09:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-29 16:09:26 --> URI Class Initialized
DEBUG - 2016-01-29 16:09:26 --> Router Class Initialized
DEBUG - 2016-01-29 16:09:27 --> No URI present. Default controller set.
DEBUG - 2016-01-29 16:09:27 --> Output Class Initialized
DEBUG - 2016-01-29 16:09:27 --> Security Class Initialized
DEBUG - 2016-01-29 16:09:27 --> Input Class Initialized
DEBUG - 2016-01-29 16:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-29 16:09:27 --> Language Class Initialized
DEBUG - 2016-01-29 16:09:27 --> Language Class Initialized
DEBUG - 2016-01-29 16:09:27 --> Config Class Initialized
DEBUG - 2016-01-29 16:09:27 --> Loader Class Initialized
DEBUG - 2016-01-29 16:09:27 --> Helper loaded: url_helper
DEBUG - 2016-01-29 16:09:28 --> Helper loaded: form_helper
DEBUG - 2016-01-29 16:09:28 --> Database Driver Class Initialized
DEBUG - 2016-01-29 16:09:29 --> Session Class Initialized
DEBUG - 2016-01-29 16:09:29 --> Helper loaded: string_helper
ERROR - 2016-01-29 16:09:30 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-01-29 16:09:30 --> Session routines successfully run
DEBUG - 2016-01-29 16:09:30 --> Form Validation Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Pagination Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Encrypt Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Email Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Controller Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Auth MX_Controller Initialized
DEBUG - 2016-01-29 16:09:30 --> Model Class Initialized
DEBUG - 2016-01-29 16:09:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-29 16:09:30 --> Model Class Initialized
DEBUG - 2016-01-29 16:09:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-29 16:09:30 --> Model Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Config Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Hooks Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Utf8 Class Initialized
DEBUG - 2016-01-29 16:09:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-29 16:09:30 --> URI Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Router Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Output Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Security Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Input Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-29 16:09:30 --> Language Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Language Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Config Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Loader Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Helper loaded: url_helper
DEBUG - 2016-01-29 16:09:30 --> Helper loaded: form_helper
DEBUG - 2016-01-29 16:09:30 --> Database Driver Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Session Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Helper loaded: string_helper
DEBUG - 2016-01-29 16:09:30 --> Session routines successfully run
DEBUG - 2016-01-29 16:09:30 --> Form Validation Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Pagination Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Encrypt Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Email Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Controller Class Initialized
DEBUG - 2016-01-29 16:09:30 --> Auth MX_Controller Initialized
DEBUG - 2016-01-29 16:09:30 --> Model Class Initialized
DEBUG - 2016-01-29 16:09:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-29 16:09:30 --> Model Class Initialized
DEBUG - 2016-01-29 16:09:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-29 16:09:30 --> Model Class Initialized
DEBUG - 2016-01-29 16:09:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-29 16:09:32 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-29 16:09:32 --> Final output sent to browser
DEBUG - 2016-01-29 16:09:32 --> Total execution time: 1.7660
DEBUG - 2016-01-29 16:09:36 --> Config Class Initialized
DEBUG - 2016-01-29 16:09:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 16:09:36 --> Utf8 Class Initialized
DEBUG - 2016-01-29 16:09:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-29 16:09:36 --> URI Class Initialized
DEBUG - 2016-01-29 16:09:36 --> Router Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Config Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Hooks Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Utf8 Class Initialized
DEBUG - 2016-01-29 16:09:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-29 16:09:37 --> URI Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Router Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Config Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Hooks Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Utf8 Class Initialized
DEBUG - 2016-01-29 16:09:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-29 16:09:37 --> Config Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Hooks Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Utf8 Class Initialized
DEBUG - 2016-01-29 16:09:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-29 16:09:37 --> URI Class Initialized
DEBUG - 2016-01-29 16:09:37 --> URI Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Router Class Initialized
DEBUG - 2016-01-29 16:09:37 --> Router Class Initialized
ERROR - 2016-01-29 16:09:37 --> 404 Page Not Found --> 
ERROR - 2016-01-29 16:09:37 --> 404 Page Not Found --> 
ERROR - 2016-01-29 16:09:37 --> 404 Page Not Found --> 
ERROR - 2016-01-29 16:09:37 --> 404 Page Not Found --> 
