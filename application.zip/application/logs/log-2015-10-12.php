<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-12 09:56:39 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:39 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Router Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Output Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Security Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Input Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 09:56:39 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Loader Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Helper loaded: url_helper
DEBUG - 2015-10-12 09:56:39 --> Helper loaded: form_helper
DEBUG - 2015-10-12 09:56:39 --> Database Driver Class Initialized
ERROR - 2015-10-12 09:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 09:56:39 --> Session Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Helper loaded: string_helper
DEBUG - 2015-10-12 09:56:39 --> A session cookie was not found.
DEBUG - 2015-10-12 09:56:39 --> Session routines successfully run
DEBUG - 2015-10-12 09:56:39 --> Form Validation Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Pagination Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Encrypt Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Email Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Controller Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:39 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Router Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Output Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Security Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Input Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 09:56:39 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Loader Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Helper loaded: url_helper
DEBUG - 2015-10-12 09:56:39 --> Helper loaded: form_helper
DEBUG - 2015-10-12 09:56:39 --> Database Driver Class Initialized
ERROR - 2015-10-12 09:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 09:56:39 --> Session Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Helper loaded: string_helper
DEBUG - 2015-10-12 09:56:39 --> Session routines successfully run
DEBUG - 2015-10-12 09:56:39 --> Form Validation Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Pagination Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Encrypt Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Email Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Controller Class Initialized
DEBUG - 2015-10-12 09:56:39 --> Auth MX_Controller Initialized
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 09:56:39 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 09:56:39 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-10-12 09:56:39 --> Final output sent to browser
DEBUG - 2015-10-12 09:56:39 --> Total execution time: 0.1141
DEBUG - 2015-10-12 09:56:40 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:40 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:40 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Router Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:40 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:40 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Router Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Router Class Initialized
DEBUG - 2015-10-12 09:56:40 --> Router Class Initialized
ERROR - 2015-10-12 09:56:40 --> 404 Page Not Found --> 
ERROR - 2015-10-12 09:56:40 --> 404 Page Not Found --> 
ERROR - 2015-10-12 09:56:40 --> 404 Page Not Found --> 
ERROR - 2015-10-12 09:56:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 09:56:45 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:45 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Router Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Output Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Security Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Input Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 09:56:45 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Loader Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Helper loaded: url_helper
DEBUG - 2015-10-12 09:56:45 --> Helper loaded: form_helper
DEBUG - 2015-10-12 09:56:45 --> Database Driver Class Initialized
ERROR - 2015-10-12 09:56:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 09:56:45 --> Session Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Helper loaded: string_helper
DEBUG - 2015-10-12 09:56:45 --> Session routines successfully run
DEBUG - 2015-10-12 09:56:45 --> Form Validation Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Pagination Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Encrypt Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Email Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Controller Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Auth MX_Controller Initialized
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 09:56:45 --> XSS Filtering completed
DEBUG - 2015-10-12 09:56:45 --> Unable to find validation rule: exists
DEBUG - 2015-10-12 09:56:45 --> XSS Filtering completed
DEBUG - 2015-10-12 09:56:45 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:45 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Router Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Output Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Security Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Input Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 09:56:45 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Loader Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Helper loaded: url_helper
DEBUG - 2015-10-12 09:56:45 --> Helper loaded: form_helper
DEBUG - 2015-10-12 09:56:45 --> Database Driver Class Initialized
ERROR - 2015-10-12 09:56:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 09:56:45 --> Session Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Helper loaded: string_helper
DEBUG - 2015-10-12 09:56:45 --> Session routines successfully run
DEBUG - 2015-10-12 09:56:45 --> Form Validation Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Pagination Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Encrypt Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Email Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Controller Class Initialized
DEBUG - 2015-10-12 09:56:45 --> Admin MX_Controller Initialized
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-12 09:56:45 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 09:56:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 09:56:45 --> Final output sent to browser
DEBUG - 2015-10-12 09:56:45 --> Total execution time: 0.1525
DEBUG - 2015-10-12 09:56:51 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:51 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Router Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Output Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Security Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Input Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 09:56:51 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Loader Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Helper loaded: url_helper
DEBUG - 2015-10-12 09:56:51 --> Helper loaded: form_helper
DEBUG - 2015-10-12 09:56:51 --> Database Driver Class Initialized
ERROR - 2015-10-12 09:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 09:56:51 --> Session Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Helper loaded: string_helper
DEBUG - 2015-10-12 09:56:51 --> Session routines successfully run
DEBUG - 2015-10-12 09:56:51 --> Form Validation Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Pagination Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Encrypt Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Email Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Controller Class Initialized
DEBUG - 2015-10-12 09:56:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 09:56:51 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 09:56:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 09:56:51 --> Final output sent to browser
DEBUG - 2015-10-12 09:56:51 --> Total execution time: 0.1670
DEBUG - 2015-10-12 09:56:58 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:56:58 --> URI Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Router Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Output Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Security Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Input Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 09:56:58 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Language Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Config Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Loader Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Helper loaded: url_helper
DEBUG - 2015-10-12 09:56:58 --> Helper loaded: form_helper
DEBUG - 2015-10-12 09:56:58 --> Database Driver Class Initialized
ERROR - 2015-10-12 09:56:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 09:56:58 --> Session Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Helper loaded: string_helper
DEBUG - 2015-10-12 09:56:58 --> Session routines successfully run
DEBUG - 2015-10-12 09:56:58 --> Form Validation Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Pagination Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Encrypt Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Email Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Controller Class Initialized
DEBUG - 2015-10-12 09:56:58 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 09:56:58 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:59 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 09:56:59 --> Model Class Initialized
DEBUG - 2015-10-12 09:56:59 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 09:56:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 09:56:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 09:56:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 09:56:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 09:56:59 --> Final output sent to browser
DEBUG - 2015-10-12 09:56:59 --> Total execution time: 0.1602
DEBUG - 2015-10-12 09:57:05 --> Config Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Hooks Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Utf8 Class Initialized
DEBUG - 2015-10-12 09:57:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 09:57:05 --> URI Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Router Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Output Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Security Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Input Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 09:57:05 --> Language Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Language Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Config Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Loader Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Helper loaded: url_helper
DEBUG - 2015-10-12 09:57:05 --> Helper loaded: form_helper
DEBUG - 2015-10-12 09:57:05 --> Database Driver Class Initialized
ERROR - 2015-10-12 09:57:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 09:57:05 --> Session Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Helper loaded: string_helper
DEBUG - 2015-10-12 09:57:05 --> Session routines successfully run
DEBUG - 2015-10-12 09:57:05 --> Form Validation Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Pagination Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Encrypt Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Email Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Controller Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 09:57:05 --> Model Class Initialized
DEBUG - 2015-10-12 09:57:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 09:57:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 09:57:05 --> Final output sent to browser
DEBUG - 2015-10-12 09:57:05 --> Total execution time: 0.1631
DEBUG - 2015-10-12 10:01:20 --> Config Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:01:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:01:20 --> URI Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Router Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Output Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Security Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Input Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:01:20 --> Language Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Language Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Config Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Loader Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:01:20 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:01:20 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:01:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:01:20 --> Session Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:01:20 --> Session routines successfully run
DEBUG - 2015-10-12 10:01:20 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Email Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Controller Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:01:20 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:01:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:01:20 --> Final output sent to browser
DEBUG - 2015-10-12 10:01:20 --> Total execution time: 0.1975
DEBUG - 2015-10-12 10:01:24 --> Config Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:01:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:01:24 --> URI Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Router Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Output Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Security Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Input Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:01:24 --> Language Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Language Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Config Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Loader Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:01:24 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:01:24 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:01:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:01:24 --> Session Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:01:24 --> Session routines successfully run
DEBUG - 2015-10-12 10:01:24 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Email Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Controller Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:01:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:01:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:01:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:01:24 --> Final output sent to browser
DEBUG - 2015-10-12 10:01:24 --> Total execution time: 0.1988
DEBUG - 2015-10-12 10:02:12 --> Config Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:02:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:02:12 --> URI Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Router Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Output Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Security Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Input Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:02:12 --> Language Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Language Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Config Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Loader Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:02:12 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:02:12 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:02:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:02:12 --> Session Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:02:12 --> Session routines successfully run
DEBUG - 2015-10-12 10:02:12 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Email Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Controller Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:02:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:02:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:02:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:02:12 --> Final output sent to browser
DEBUG - 2015-10-12 10:02:12 --> Total execution time: 0.1975
DEBUG - 2015-10-12 10:03:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:03:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:03:30 --> URI Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Router Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Output Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Security Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Input Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:03:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Loader Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:03:30 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:03:30 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:03:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:03:30 --> Session Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:03:30 --> Session routines successfully run
DEBUG - 2015-10-12 10:03:30 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Email Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Controller Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:03:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:03:30 --> Final output sent to browser
DEBUG - 2015-10-12 10:03:30 --> Total execution time: 0.1606
DEBUG - 2015-10-12 10:03:35 --> Config Class Initialized
DEBUG - 2015-10-12 10:03:35 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:03:35 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:03:35 --> URI Class Initialized
DEBUG - 2015-10-12 10:03:35 --> Router Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Output Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Security Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Input Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:03:36 --> Language Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Language Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Config Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Loader Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:03:36 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:03:36 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:03:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:03:36 --> Session Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:03:36 --> Session routines successfully run
DEBUG - 2015-10-12 10:03:36 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Email Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Controller Class Initialized
DEBUG - 2015-10-12 10:03:36 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:36 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:03:36 --> Model Class Initialized
ERROR - 2015-10-12 10:03:36 --> Severity: Notice  --> Undefined property: CI::$payment_model C:\wamp\www\mfi\application\libraries\MX\Controller.php 58
DEBUG - 2015-10-12 10:03:43 --> Config Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:03:43 --> URI Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Router Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Output Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Security Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Input Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:03:43 --> Language Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Language Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Config Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Loader Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:03:43 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:03:43 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:03:43 --> Session Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:03:43 --> Session routines successfully run
DEBUG - 2015-10-12 10:03:43 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Email Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Controller Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Config Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:03:43 --> URI Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Router Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Output Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Security Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Input Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:03:43 --> Language Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Language Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Config Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Loader Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:03:43 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:03:43 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:03:43 --> Session Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:03:43 --> Session routines successfully run
DEBUG - 2015-10-12 10:03:43 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Email Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Controller Class Initialized
DEBUG - 2015-10-12 10:03:43 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:03:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:03:43 --> Model Class Initialized
ERROR - 2015-10-12 10:03:43 --> 404 Page Not Found --> microfinance/edit_group_payment
DEBUG - 2015-10-12 10:04:06 --> Config Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:04:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:04:06 --> URI Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Router Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Output Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Security Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Input Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:04:06 --> Language Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Language Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Config Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Loader Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:04:06 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:04:06 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:04:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:04:06 --> Session Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:04:06 --> Session routines successfully run
DEBUG - 2015-10-12 10:04:06 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Email Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Controller Class Initialized
DEBUG - 2015-10-12 10:04:06 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:04:06 --> Model Class Initialized
ERROR - 2015-10-12 10:04:06 --> 404 Page Not Found --> microfinance/edit_group_payment
DEBUG - 2015-10-12 10:04:15 --> Config Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:04:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:04:15 --> URI Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Router Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Output Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Security Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Input Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:04:15 --> Language Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Language Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Config Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Loader Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:04:15 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:04:15 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:04:15 --> Session Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:04:15 --> Session routines successfully run
DEBUG - 2015-10-12 10:04:15 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Email Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Controller Class Initialized
DEBUG - 2015-10-12 10:04:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:04:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:04:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:04:15 --> Final output sent to browser
DEBUG - 2015-10-12 10:04:15 --> Total execution time: 0.1478
DEBUG - 2015-10-12 10:04:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:04:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:04:18 --> URI Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Router Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Output Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Security Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Input Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:04:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Loader Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:04:18 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:04:18 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:04:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:04:18 --> Session Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:04:18 --> Session routines successfully run
DEBUG - 2015-10-12 10:04:18 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Email Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Controller Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:04:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:04:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:04:18 --> Final output sent to browser
DEBUG - 2015-10-12 10:04:18 --> Total execution time: 0.1647
DEBUG - 2015-10-12 10:25:50 --> Config Class Initialized
DEBUG - 2015-10-12 10:25:50 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:25:50 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:25:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:25:50 --> URI Class Initialized
DEBUG - 2015-10-12 10:25:50 --> Router Class Initialized
DEBUG - 2015-10-12 10:25:50 --> Output Class Initialized
DEBUG - 2015-10-12 10:25:50 --> Security Class Initialized
DEBUG - 2015-10-12 10:25:50 --> Input Class Initialized
DEBUG - 2015-10-12 10:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:25:50 --> Language Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Config Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:26:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:26:35 --> URI Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Router Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Output Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Security Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Input Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:26:35 --> Language Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Language Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Config Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Loader Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:26:35 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:26:35 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:26:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:26:35 --> Session Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:26:35 --> Session routines successfully run
DEBUG - 2015-10-12 10:26:35 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Email Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Controller Class Initialized
DEBUG - 2015-10-12 10:26:35 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:26:35 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Config Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:26:51 --> URI Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Router Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Output Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Security Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Input Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:26:51 --> Language Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Language Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Config Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Loader Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:26:51 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:26:51 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:26:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:26:51 --> Session Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:26:51 --> Session routines successfully run
DEBUG - 2015-10-12 10:26:51 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Email Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Controller Class Initialized
DEBUG - 2015-10-12 10:26:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:26:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:26:51 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Config Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:27:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:27:10 --> URI Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Router Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Output Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Security Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Input Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:27:10 --> Language Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Language Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Config Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Loader Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:27:10 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:27:10 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:27:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:27:10 --> Session Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:27:10 --> Session routines successfully run
DEBUG - 2015-10-12 10:27:10 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Email Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Controller Class Initialized
DEBUG - 2015-10-12 10:27:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:27:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
ERROR - 2015-10-12 10:27:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 82
DEBUG - 2015-10-12 10:27:11 --> Config Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:27:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:27:11 --> URI Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Router Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Output Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Security Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Input Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:27:11 --> Language Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Language Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Config Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Loader Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:27:11 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:27:11 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:27:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:27:11 --> Session Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:27:11 --> Session routines successfully run
DEBUG - 2015-10-12 10:27:11 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Email Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Controller Class Initialized
DEBUG - 2015-10-12 10:27:11 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:27:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:27:11 --> Final output sent to browser
DEBUG - 2015-10-12 10:27:11 --> Total execution time: 0.1382
DEBUG - 2015-10-12 10:28:17 --> Config Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:28:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:28:17 --> URI Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Router Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Output Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Security Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Input Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:28:17 --> Language Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Language Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Config Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Loader Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:28:17 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:28:17 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:28:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:28:17 --> Session Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:28:17 --> Session routines successfully run
DEBUG - 2015-10-12 10:28:17 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Email Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Controller Class Initialized
DEBUG - 2015-10-12 10:28:17 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:28:17 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:28:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:28:17 --> Final output sent to browser
DEBUG - 2015-10-12 10:28:17 --> Total execution time: 0.1404
DEBUG - 2015-10-12 10:28:31 --> Config Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:28:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:28:31 --> URI Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Router Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Output Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Security Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Input Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:28:31 --> Language Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Language Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Config Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Loader Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:28:31 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:28:31 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:28:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:28:31 --> Session Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:28:31 --> Session routines successfully run
DEBUG - 2015-10-12 10:28:31 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Email Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Controller Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:28:31 --> Model Class Initialized
DEBUG - 2015-10-12 10:28:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:28:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:28:31 --> Final output sent to browser
DEBUG - 2015-10-12 10:28:31 --> Total execution time: 0.1500
DEBUG - 2015-10-12 10:29:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:29:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:29:18 --> URI Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Router Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Output Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Security Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Input Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:29:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Loader Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:29:18 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:29:18 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:29:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:29:18 --> Session Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:29:18 --> Session routines successfully run
DEBUG - 2015-10-12 10:29:18 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Email Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Controller Class Initialized
DEBUG - 2015-10-12 10:29:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:29:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:29:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:29:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:29:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:29:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:29:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:29:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:29:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:29:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:29:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:29:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:29:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:29:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:29:19 --> Final output sent to browser
DEBUG - 2015-10-12 10:29:19 --> Total execution time: 0.5310
DEBUG - 2015-10-12 10:29:25 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:29:25 --> URI Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Router Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Output Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Security Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Input Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:29:25 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Loader Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:29:25 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:29:25 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:29:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:29:25 --> Session Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:29:25 --> Session routines successfully run
DEBUG - 2015-10-12 10:29:25 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Email Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Controller Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:29:25 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:29:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:29:25 --> Final output sent to browser
DEBUG - 2015-10-12 10:29:25 --> Total execution time: 0.1453
DEBUG - 2015-10-12 10:29:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:29:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:29:30 --> URI Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Router Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Output Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Security Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Input Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:29:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Loader Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:29:30 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:29:30 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:29:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:29:30 --> Session Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:29:30 --> Session routines successfully run
DEBUG - 2015-10-12 10:29:30 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Email Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Controller Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
ERROR - 2015-10-12 10:29:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 82
DEBUG - 2015-10-12 10:29:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:29:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:29:30 --> URI Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Router Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Output Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Security Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Input Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:29:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Loader Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:29:30 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:29:30 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:29:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:29:30 --> Session Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:29:30 --> Session routines successfully run
DEBUG - 2015-10-12 10:29:30 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Email Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Controller Class Initialized
DEBUG - 2015-10-12 10:29:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:29:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:29:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:29:30 --> Final output sent to browser
DEBUG - 2015-10-12 10:29:30 --> Total execution time: 0.1634
DEBUG - 2015-10-12 10:29:40 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:29:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:29:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:29:40 --> URI Class Initialized
DEBUG - 2015-10-12 10:29:40 --> Router Class Initialized
ERROR - 2015-10-12 10:29:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:29:55 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:29:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:29:55 --> URI Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Router Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Output Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Security Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Input Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:29:55 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Language Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Loader Class Initialized
DEBUG - 2015-10-12 10:29:55 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:29:55 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:29:56 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:29:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:29:56 --> Session Class Initialized
DEBUG - 2015-10-12 10:29:56 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:29:56 --> Session routines successfully run
DEBUG - 2015-10-12 10:29:56 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:29:56 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:29:56 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:29:56 --> Email Class Initialized
DEBUG - 2015-10-12 10:29:56 --> Controller Class Initialized
DEBUG - 2015-10-12 10:29:56 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:29:56 --> Model Class Initialized
DEBUG - 2015-10-12 10:29:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:29:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:29:56 --> Final output sent to browser
DEBUG - 2015-10-12 10:29:56 --> Total execution time: 0.1519
DEBUG - 2015-10-12 10:29:57 --> Config Class Initialized
DEBUG - 2015-10-12 10:29:57 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:29:57 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:29:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:29:57 --> URI Class Initialized
DEBUG - 2015-10-12 10:29:57 --> Router Class Initialized
ERROR - 2015-10-12 10:29:57 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:30:44 --> Config Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:30:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:30:44 --> URI Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Router Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Output Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Security Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Input Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:30:44 --> Language Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Language Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Config Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Loader Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:30:44 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:30:44 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:30:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:30:44 --> Session Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:30:44 --> Session routines successfully run
DEBUG - 2015-10-12 10:30:44 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Email Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Controller Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
ERROR - 2015-10-12 10:30:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 82
ERROR - 2015-10-12 10:30:44 --> Severity: Notice  --> Undefined variable: group_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 203
DEBUG - 2015-10-12 10:30:44 --> Config Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:30:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:30:44 --> URI Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Router Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Output Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Security Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Input Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:30:44 --> Language Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Language Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Config Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Loader Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:30:44 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:30:44 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:30:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:30:44 --> Session Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:30:44 --> Session routines successfully run
DEBUG - 2015-10-12 10:30:44 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Email Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Controller Class Initialized
DEBUG - 2015-10-12 10:30:44 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
DEBUG - 2015-10-12 10:30:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:30:44 --> Model Class Initialized
ERROR - 2015-10-12 10:30:44 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 10:31:10 --> Config Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:31:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:31:10 --> URI Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Router Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Output Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Security Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Input Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:31:10 --> Language Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Language Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Config Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Loader Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:31:10 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:31:10 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:31:10 --> Session Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:31:10 --> Session routines successfully run
DEBUG - 2015-10-12 10:31:10 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Email Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Controller Class Initialized
DEBUG - 2015-10-12 10:31:10 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
DEBUG - 2015-10-12 10:31:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:31:10 --> Model Class Initialized
ERROR - 2015-10-12 10:31:10 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 10:32:54 --> Config Class Initialized
DEBUG - 2015-10-12 10:32:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:32:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:32:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:32:54 --> URI Class Initialized
DEBUG - 2015-10-12 10:32:54 --> Router Class Initialized
ERROR - 2015-10-12 10:32:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:32:58 --> Config Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:32:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:32:58 --> URI Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Router Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Output Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Security Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Input Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:32:58 --> Language Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Language Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Config Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Loader Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:32:58 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:32:58 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:32:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:32:58 --> Session Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:32:58 --> Session routines successfully run
DEBUG - 2015-10-12 10:32:58 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Email Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Controller Class Initialized
DEBUG - 2015-10-12 10:32:58 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:32:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:32:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:32:58 --> Final output sent to browser
DEBUG - 2015-10-12 10:32:58 --> Total execution time: 0.1337
DEBUG - 2015-10-12 10:32:59 --> Config Class Initialized
DEBUG - 2015-10-12 10:32:59 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:32:59 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:32:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:32:59 --> URI Class Initialized
DEBUG - 2015-10-12 10:32:59 --> Router Class Initialized
ERROR - 2015-10-12 10:32:59 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:33:02 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:33:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:33:02 --> URI Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Router Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Output Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Security Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Input Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:33:02 --> Language Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Language Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Loader Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:33:02 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:33:02 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:33:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:33:02 --> Session Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:33:02 --> Session routines successfully run
DEBUG - 2015-10-12 10:33:02 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Email Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Controller Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:33:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:33:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:33:02 --> Final output sent to browser
DEBUG - 2015-10-12 10:33:02 --> Total execution time: 0.1733
DEBUG - 2015-10-12 10:33:03 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:03 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:33:03 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:33:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:33:03 --> URI Class Initialized
DEBUG - 2015-10-12 10:33:03 --> Router Class Initialized
ERROR - 2015-10-12 10:33:03 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:33:21 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:33:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:33:21 --> URI Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Router Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Output Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Security Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Input Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:33:21 --> Language Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Language Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Loader Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:33:21 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:33:21 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:33:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:33:21 --> Session Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:33:21 --> Session routines successfully run
DEBUG - 2015-10-12 10:33:21 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Email Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Controller Class Initialized
DEBUG - 2015-10-12 10:33:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:33:21 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:33:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:33:21 --> Final output sent to browser
DEBUG - 2015-10-12 10:33:21 --> Total execution time: 0.1399
DEBUG - 2015-10-12 10:33:22 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:22 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:33:22 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:33:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:33:22 --> URI Class Initialized
DEBUG - 2015-10-12 10:33:22 --> Router Class Initialized
ERROR - 2015-10-12 10:33:22 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:33:54 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:33:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:33:54 --> URI Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Router Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Output Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Security Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Input Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:33:54 --> Language Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Language Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Loader Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:33:54 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:33:54 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:33:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:33:54 --> Session Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:33:54 --> Session routines successfully run
DEBUG - 2015-10-12 10:33:54 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Email Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Controller Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:33:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:33:54 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:33:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:33:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:33:55 --> URI Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Router Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Output Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Security Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Input Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:33:55 --> Language Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Language Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Loader Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:33:55 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:33:55 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:33:55 --> Session Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:33:55 --> Session routines successfully run
DEBUG - 2015-10-12 10:33:55 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Email Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Controller Class Initialized
DEBUG - 2015-10-12 10:33:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:33:55 --> Model Class Initialized
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:33:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:33:55 --> Final output sent to browser
DEBUG - 2015-10-12 10:33:55 --> Total execution time: 0.1384
DEBUG - 2015-10-12 10:33:56 --> Config Class Initialized
DEBUG - 2015-10-12 10:33:56 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:33:56 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:33:56 --> URI Class Initialized
DEBUG - 2015-10-12 10:33:56 --> Router Class Initialized
ERROR - 2015-10-12 10:33:56 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:34:24 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:34:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:34:24 --> URI Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Router Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Output Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Security Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Input Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:34:24 --> Language Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Language Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Loader Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:34:24 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:34:24 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:34:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:34:24 --> Session Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:34:24 --> Session routines successfully run
DEBUG - 2015-10-12 10:34:24 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Email Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Controller Class Initialized
DEBUG - 2015-10-12 10:34:24 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:34:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:34:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:34:24 --> Final output sent to browser
DEBUG - 2015-10-12 10:34:24 --> Total execution time: 0.1320
DEBUG - 2015-10-12 10:34:25 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:25 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:34:25 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:34:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:34:25 --> URI Class Initialized
DEBUG - 2015-10-12 10:34:25 --> Router Class Initialized
ERROR - 2015-10-12 10:34:25 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:34:29 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:34:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:34:29 --> URI Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Router Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Output Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Security Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Input Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:34:29 --> Language Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Language Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Loader Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:34:29 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:34:29 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:34:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:34:29 --> Session Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:34:29 --> Session routines successfully run
DEBUG - 2015-10-12 10:34:29 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Email Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Controller Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:34:29 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:34:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:34:29 --> Final output sent to browser
DEBUG - 2015-10-12 10:34:29 --> Total execution time: 0.1503
DEBUG - 2015-10-12 10:34:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:34:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:34:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:34:30 --> URI Class Initialized
DEBUG - 2015-10-12 10:34:30 --> Router Class Initialized
ERROR - 2015-10-12 10:34:30 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:34:42 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:34:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:34:42 --> URI Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Router Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Output Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Security Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Input Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:34:42 --> Language Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Language Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Loader Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:34:42 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:34:42 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:34:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:34:42 --> Session Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:34:42 --> Session routines successfully run
DEBUG - 2015-10-12 10:34:42 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Email Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Controller Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
ERROR - 2015-10-12 10:34:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 82
ERROR - 2015-10-12 10:34:42 --> Severity: Notice  --> Undefined variable: group_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 203
DEBUG - 2015-10-12 10:34:42 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:34:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:34:42 --> URI Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Router Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Output Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Security Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Input Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:34:42 --> Language Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Language Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Config Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Loader Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:34:42 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:34:42 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:34:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:34:42 --> Session Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:34:42 --> Session routines successfully run
DEBUG - 2015-10-12 10:34:42 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Email Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Controller Class Initialized
DEBUG - 2015-10-12 10:34:42 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
DEBUG - 2015-10-12 10:34:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:34:42 --> Model Class Initialized
ERROR - 2015-10-12 10:34:42 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 10:35:02 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:35:02 --> URI Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Router Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Output Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Security Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Input Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:35:02 --> Language Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Language Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Loader Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:35:02 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:35:02 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:35:02 --> Session Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:35:02 --> Session routines successfully run
DEBUG - 2015-10-12 10:35:02 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Email Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Controller Class Initialized
DEBUG - 2015-10-12 10:35:02 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:35:02 --> Model Class Initialized
ERROR - 2015-10-12 10:35:02 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 10:35:04 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:35:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:35:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:35:04 --> URI Class Initialized
DEBUG - 2015-10-12 10:35:04 --> Router Class Initialized
ERROR - 2015-10-12 10:35:04 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:35:09 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:35:09 --> URI Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Router Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Output Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Security Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Input Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:35:09 --> Language Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Language Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Loader Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:35:09 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:35:09 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:35:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:35:09 --> Session Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:35:09 --> Session routines successfully run
DEBUG - 2015-10-12 10:35:09 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Email Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Controller Class Initialized
DEBUG - 2015-10-12 10:35:09 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:35:09 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:35:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:35:09 --> Final output sent to browser
DEBUG - 2015-10-12 10:35:09 --> Total execution time: 0.1622
DEBUG - 2015-10-12 10:35:10 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:10 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:35:10 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:35:10 --> URI Class Initialized
DEBUG - 2015-10-12 10:35:10 --> Router Class Initialized
ERROR - 2015-10-12 10:35:10 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:35:13 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:35:13 --> URI Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Router Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Output Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Security Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Input Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:35:13 --> Language Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Language Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Loader Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:35:13 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:35:13 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:35:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:35:13 --> Session Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:35:13 --> Session routines successfully run
DEBUG - 2015-10-12 10:35:13 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Email Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Controller Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:35:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:35:13 --> Final output sent to browser
DEBUG - 2015-10-12 10:35:13 --> Total execution time: 0.1445
DEBUG - 2015-10-12 10:35:14 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:14 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:35:14 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:35:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:35:14 --> URI Class Initialized
DEBUG - 2015-10-12 10:35:14 --> Router Class Initialized
ERROR - 2015-10-12 10:35:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:35:33 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:35:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:35:33 --> URI Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Router Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Output Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Security Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Input Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:35:33 --> Language Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Language Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Loader Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:35:33 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:35:33 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:35:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:35:33 --> Session Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:35:33 --> Session routines successfully run
DEBUG - 2015-10-12 10:35:33 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Email Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Controller Class Initialized
DEBUG - 2015-10-12 10:35:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:35:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:35:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:35:33 --> Final output sent to browser
DEBUG - 2015-10-12 10:35:33 --> Total execution time: 0.1349
DEBUG - 2015-10-12 10:35:34 --> Config Class Initialized
DEBUG - 2015-10-12 10:35:34 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:35:34 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:35:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:35:34 --> URI Class Initialized
DEBUG - 2015-10-12 10:35:34 --> Router Class Initialized
ERROR - 2015-10-12 10:35:34 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:36:03 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:36:03 --> URI Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Router Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Output Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Security Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Input Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:36:03 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Loader Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:36:03 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:36:03 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:36:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:36:03 --> Session Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:36:03 --> Session routines successfully run
DEBUG - 2015-10-12 10:36:03 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Email Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Controller Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:36:03 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:36:03 --> URI Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Router Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Output Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Security Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Input Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:36:03 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Loader Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:36:03 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:36:03 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:36:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:36:03 --> Session Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:36:03 --> Session routines successfully run
DEBUG - 2015-10-12 10:36:03 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Email Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Controller Class Initialized
DEBUG - 2015-10-12 10:36:03 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:36:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:36:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:36:03 --> Final output sent to browser
DEBUG - 2015-10-12 10:36:03 --> Total execution time: 0.1299
DEBUG - 2015-10-12 10:36:05 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:05 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:36:05 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:36:05 --> URI Class Initialized
DEBUG - 2015-10-12 10:36:05 --> Router Class Initialized
ERROR - 2015-10-12 10:36:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:36:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:36:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:36:19 --> URI Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Router Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Output Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Security Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Input Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:36:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Loader Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:36:19 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:36:19 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:36:19 --> Session Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:36:19 --> Session routines successfully run
DEBUG - 2015-10-12 10:36:19 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Email Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Controller Class Initialized
DEBUG - 2015-10-12 10:36:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:36:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:36:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:36:19 --> Final output sent to browser
DEBUG - 2015-10-12 10:36:19 --> Total execution time: 0.1295
DEBUG - 2015-10-12 10:36:20 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:20 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:36:20 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:36:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:36:20 --> URI Class Initialized
DEBUG - 2015-10-12 10:36:20 --> Router Class Initialized
ERROR - 2015-10-12 10:36:20 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:36:23 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:36:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:36:23 --> URI Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Router Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Output Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Security Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Input Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:36:23 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Loader Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:36:23 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:36:23 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:36:23 --> Session Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:36:23 --> Session routines successfully run
DEBUG - 2015-10-12 10:36:23 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Email Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Controller Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:36:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:36:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:36:23 --> Final output sent to browser
DEBUG - 2015-10-12 10:36:23 --> Total execution time: 0.1690
DEBUG - 2015-10-12 10:36:24 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:24 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:36:24 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:36:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:36:24 --> URI Class Initialized
DEBUG - 2015-10-12 10:36:24 --> Router Class Initialized
ERROR - 2015-10-12 10:36:24 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:36:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:36:30 --> URI Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Router Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Output Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Security Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Input Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:36:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Loader Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:36:30 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:36:30 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:36:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:36:30 --> Session Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:36:30 --> Session routines successfully run
DEBUG - 2015-10-12 10:36:30 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Email Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Controller Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
ERROR - 2015-10-12 10:36:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 82
ERROR - 2015-10-12 10:36:30 --> Severity: Notice  --> Undefined variable: group_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 204
DEBUG - 2015-10-12 10:36:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:36:30 --> URI Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Router Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Output Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Security Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Input Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:36:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Language Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Config Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Loader Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:36:30 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:36:30 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:36:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:36:30 --> Session Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:36:30 --> Session routines successfully run
DEBUG - 2015-10-12 10:36:30 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Email Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Controller Class Initialized
DEBUG - 2015-10-12 10:36:30 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
DEBUG - 2015-10-12 10:36:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:36:30 --> Model Class Initialized
ERROR - 2015-10-12 10:36:30 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 10:37:05 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:05 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Router Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Output Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Security Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Input Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:37:05 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Loader Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:37:05 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:37:05 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:37:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:37:05 --> Session Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:37:05 --> Session routines successfully run
DEBUG - 2015-10-12 10:37:05 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Email Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Controller Class Initialized
DEBUG - 2015-10-12 10:37:05 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:37:05 --> Model Class Initialized
ERROR - 2015-10-12 10:37:05 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 10:37:07 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:07 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:07 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:07 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:07 --> Router Class Initialized
ERROR - 2015-10-12 10:37:07 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:37:11 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:11 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Router Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Output Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Security Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Input Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:37:11 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Loader Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:37:11 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:37:11 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:37:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:37:11 --> Session Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:37:11 --> Session routines successfully run
DEBUG - 2015-10-12 10:37:11 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Email Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Controller Class Initialized
DEBUG - 2015-10-12 10:37:11 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:37:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:37:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:37:11 --> Final output sent to browser
DEBUG - 2015-10-12 10:37:11 --> Total execution time: 0.1314
DEBUG - 2015-10-12 10:37:12 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:12 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:12 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:12 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:12 --> Router Class Initialized
ERROR - 2015-10-12 10:37:12 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:37:15 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:15 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Router Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Output Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Security Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Input Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:37:15 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Loader Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:37:15 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:37:15 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:37:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:37:15 --> Session Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:37:15 --> Session routines successfully run
DEBUG - 2015-10-12 10:37:15 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Email Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Controller Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:37:15 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:37:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:37:15 --> Final output sent to browser
DEBUG - 2015-10-12 10:37:15 --> Total execution time: 0.1701
DEBUG - 2015-10-12 10:37:16 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:16 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:16 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:16 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:16 --> Router Class Initialized
ERROR - 2015-10-12 10:37:16 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:37:23 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:23 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Router Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Output Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Security Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Input Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:37:23 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Loader Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:37:23 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:37:23 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:37:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:37:23 --> Session Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:37:23 --> Session routines successfully run
DEBUG - 2015-10-12 10:37:23 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Email Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Controller Class Initialized
DEBUG - 2015-10-12 10:37:23 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:37:23 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:37:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:37:23 --> Final output sent to browser
DEBUG - 2015-10-12 10:37:23 --> Total execution time: 0.1437
DEBUG - 2015-10-12 10:37:24 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:24 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:24 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:24 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:24 --> Router Class Initialized
ERROR - 2015-10-12 10:37:24 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:37:43 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:43 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Router Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Output Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Security Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Input Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:37:43 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Language Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Loader Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:37:43 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:37:43 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:37:43 --> Session Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:37:43 --> Session routines successfully run
DEBUG - 2015-10-12 10:37:43 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Email Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Controller Class Initialized
DEBUG - 2015-10-12 10:37:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:37:43 --> Model Class Initialized
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:37:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:37:43 --> Final output sent to browser
DEBUG - 2015-10-12 10:37:43 --> Total execution time: 0.1546
DEBUG - 2015-10-12 10:37:44 --> Config Class Initialized
DEBUG - 2015-10-12 10:37:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:37:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:37:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:37:44 --> URI Class Initialized
DEBUG - 2015-10-12 10:37:44 --> Router Class Initialized
ERROR - 2015-10-12 10:37:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:38:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:38:18 --> URI Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Router Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Output Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Security Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Input Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:38:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Loader Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:38:18 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:38:18 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:38:18 --> Session Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:38:18 --> Session routines successfully run
DEBUG - 2015-10-12 10:38:18 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Email Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Controller Class Initialized
DEBUG - 2015-10-12 10:38:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:38:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:38:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:38:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:38:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:38:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:38:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:38:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:38:19 --> URI Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Router Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Output Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Security Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Input Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:38:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Loader Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:38:19 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:38:19 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:38:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:38:19 --> Session Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:38:19 --> Session routines successfully run
DEBUG - 2015-10-12 10:38:19 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Email Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Controller Class Initialized
DEBUG - 2015-10-12 10:38:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:38:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:38:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:38:19 --> Final output sent to browser
DEBUG - 2015-10-12 10:38:19 --> Total execution time: 0.1312
DEBUG - 2015-10-12 10:38:20 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:20 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:38:20 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:38:20 --> URI Class Initialized
DEBUG - 2015-10-12 10:38:20 --> Router Class Initialized
ERROR - 2015-10-12 10:38:20 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:38:49 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:38:49 --> URI Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Router Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Output Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Security Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Input Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:38:49 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Loader Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:38:49 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:38:49 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:38:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:38:49 --> Session Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:38:49 --> Session routines successfully run
DEBUG - 2015-10-12 10:38:49 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Email Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Controller Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:38:49 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:38:49 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:38:49 --> URI Class Initialized
DEBUG - 2015-10-12 10:38:49 --> Router Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Output Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Security Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Input Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:38:50 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Loader Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:38:50 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:38:50 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:38:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:38:50 --> Session Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:38:50 --> Session routines successfully run
DEBUG - 2015-10-12 10:38:50 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Email Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Controller Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:38:50 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:38:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:38:50 --> Final output sent to browser
DEBUG - 2015-10-12 10:38:50 --> Total execution time: 0.1381
DEBUG - 2015-10-12 10:38:50 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:38:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:38:50 --> URI Class Initialized
DEBUG - 2015-10-12 10:38:50 --> Router Class Initialized
ERROR - 2015-10-12 10:38:50 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:38:58 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:38:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:38:58 --> URI Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Router Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Output Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Security Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Input Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:38:58 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Language Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Loader Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:38:58 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:38:58 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:38:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:38:58 --> Session Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:38:58 --> Session routines successfully run
DEBUG - 2015-10-12 10:38:58 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Email Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Controller Class Initialized
DEBUG - 2015-10-12 10:38:58 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:38:58 --> Model Class Initialized
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:38:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:38:58 --> Final output sent to browser
DEBUG - 2015-10-12 10:38:58 --> Total execution time: 0.1455
DEBUG - 2015-10-12 10:38:59 --> Config Class Initialized
DEBUG - 2015-10-12 10:38:59 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:38:59 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:38:59 --> URI Class Initialized
DEBUG - 2015-10-12 10:38:59 --> Router Class Initialized
ERROR - 2015-10-12 10:38:59 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:40:03 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:40:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:40:03 --> URI Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Router Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Output Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Security Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Input Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:40:03 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Loader Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:40:03 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:40:03 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:40:03 --> Session Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:40:03 --> Session routines successfully run
DEBUG - 2015-10-12 10:40:03 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Email Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Controller Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:40:03 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:40:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:40:03 --> URI Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Router Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Output Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Security Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Input Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:40:03 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Loader Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:40:03 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:40:03 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:40:03 --> Session Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:40:03 --> Session routines successfully run
DEBUG - 2015-10-12 10:40:03 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Email Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Controller Class Initialized
DEBUG - 2015-10-12 10:40:03 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:03 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:40:03 --> Model Class Initialized
ERROR - 2015-10-12 10:40:03 --> 404 Page Not Found --> microfinance/add-group-pyament
DEBUG - 2015-10-12 10:40:14 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:40:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:40:14 --> URI Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Router Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Output Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Security Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Input Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:40:14 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Loader Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:40:14 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:40:14 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:40:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:40:14 --> Session Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:40:14 --> Session routines successfully run
DEBUG - 2015-10-12 10:40:14 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Email Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Controller Class Initialized
DEBUG - 2015-10-12 10:40:14 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:40:14 --> Model Class Initialized
ERROR - 2015-10-12 10:40:14 --> 404 Page Not Found --> microfinance/add-group-pyament
DEBUG - 2015-10-12 10:40:23 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:40:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:40:23 --> URI Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Router Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Output Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Security Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Input Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:40:23 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Loader Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:40:23 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:40:23 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:40:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:40:23 --> Session Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:40:23 --> Session routines successfully run
DEBUG - 2015-10-12 10:40:23 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Email Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Controller Class Initialized
DEBUG - 2015-10-12 10:40:23 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:40:24 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:40:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:40:24 --> Final output sent to browser
DEBUG - 2015-10-12 10:40:24 --> Total execution time: 0.1330
DEBUG - 2015-10-12 10:40:24 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:24 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:40:24 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:40:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:40:24 --> URI Class Initialized
DEBUG - 2015-10-12 10:40:24 --> Router Class Initialized
ERROR - 2015-10-12 10:40:24 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:40:40 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:40:40 --> URI Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Router Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Output Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Security Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Input Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:40:40 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Language Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Config Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Loader Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:40:40 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:40:40 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:40:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:40:40 --> Session Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:40:40 --> Session routines successfully run
DEBUG - 2015-10-12 10:40:40 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Email Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Controller Class Initialized
DEBUG - 2015-10-12 10:40:40 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:40:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:40:40 --> Model Class Initialized
ERROR - 2015-10-12 10:40:40 --> 404 Page Not Found --> microfinance/list-group-payment
DEBUG - 2015-10-12 10:41:12 --> Config Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:41:12 --> URI Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Router Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Output Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Security Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Input Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:41:12 --> Language Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Language Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Config Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Loader Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:41:12 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:41:12 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:41:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:41:12 --> Session Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:41:12 --> Session routines successfully run
DEBUG - 2015-10-12 10:41:12 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Email Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Controller Class Initialized
DEBUG - 2015-10-12 10:41:12 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:41:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:41:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:41:12 --> Final output sent to browser
DEBUG - 2015-10-12 10:41:12 --> Total execution time: 0.1335
DEBUG - 2015-10-12 10:41:13 --> Config Class Initialized
DEBUG - 2015-10-12 10:41:13 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:41:13 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:41:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:41:13 --> URI Class Initialized
DEBUG - 2015-10-12 10:41:13 --> Router Class Initialized
ERROR - 2015-10-12 10:41:13 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:41:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:41:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:41:18 --> URI Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Router Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Output Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Security Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Input Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:41:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Loader Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:41:18 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:41:18 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:41:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:41:18 --> Session Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:41:18 --> Session routines successfully run
DEBUG - 2015-10-12 10:41:18 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Email Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Controller Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:41:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 10:41:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 10:41:18 --> Final output sent to browser
DEBUG - 2015-10-12 10:41:18 --> Total execution time: 0.1460
DEBUG - 2015-10-12 10:41:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:41:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:41:18 --> URI Class Initialized
DEBUG - 2015-10-12 10:41:18 --> Router Class Initialized
ERROR - 2015-10-12 10:41:18 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 10:41:34 --> Config Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:41:34 --> URI Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Router Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Output Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Security Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Input Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:41:34 --> Language Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Language Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Config Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Loader Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:41:34 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:41:34 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:41:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:41:34 --> Session Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:41:34 --> Session routines successfully run
DEBUG - 2015-10-12 10:41:34 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Email Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Controller Class Initialized
DEBUG - 2015-10-12 10:41:34 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
DEBUG - 2015-10-12 10:41:34 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:41:34 --> Model Class Initialized
ERROR - 2015-10-12 10:41:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 82
ERROR - 2015-10-12 10:41:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 82
DEBUG - 2015-10-12 10:41:34 --> Final output sent to browser
DEBUG - 2015-10-12 10:41:34 --> Total execution time: 0.1314
DEBUG - 2015-10-12 10:43:02 --> Config Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:43:02 --> URI Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Router Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Output Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Security Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Input Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:43:02 --> Language Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Language Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Config Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Loader Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:43:02 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:43:02 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:43:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:43:02 --> Session Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:43:02 --> Session routines successfully run
DEBUG - 2015-10-12 10:43:02 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Email Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Controller Class Initialized
DEBUG - 2015-10-12 10:43:02 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:43:02 --> Model Class Initialized
ERROR - 2015-10-12 10:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 82
ERROR - 2015-10-12 10:43:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 82
DEBUG - 2015-10-12 10:43:02 --> Final output sent to browser
DEBUG - 2015-10-12 10:43:02 --> Total execution time: 0.1972
DEBUG - 2015-10-12 10:43:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:43:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:43:19 --> URI Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Router Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Output Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Security Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Input Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:43:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Loader Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:43:19 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:43:19 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:43:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:43:19 --> Session Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:43:19 --> Session routines successfully run
DEBUG - 2015-10-12 10:43:19 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Email Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Controller Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:43:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:19 --> Final output sent to browser
DEBUG - 2015-10-12 10:43:19 --> Total execution time: 0.3345
DEBUG - 2015-10-12 10:43:33 --> Config Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:43:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:43:33 --> URI Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Router Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Output Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Security Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Input Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:43:33 --> Language Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Language Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Config Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Loader Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:43:33 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:43:33 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:43:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:43:33 --> Session Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:43:33 --> Session routines successfully run
DEBUG - 2015-10-12 10:43:33 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Email Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Controller Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:43:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:43:33 --> Final output sent to browser
DEBUG - 2015-10-12 10:43:33 --> Total execution time: 0.1857
DEBUG - 2015-10-12 10:44:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:44:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:44:19 --> URI Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Router Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Output Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Security Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Input Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:44:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Loader Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:44:19 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:44:19 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:44:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:44:19 --> Session Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:44:19 --> Session routines successfully run
DEBUG - 2015-10-12 10:44:19 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Email Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Controller Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:44:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:44:19 --> Final output sent to browser
DEBUG - 2015-10-12 10:44:19 --> Total execution time: 0.1425
DEBUG - 2015-10-12 10:45:40 --> Config Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:45:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:45:40 --> URI Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Router Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Output Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Security Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Input Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:45:40 --> Language Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Language Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Config Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Loader Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:45:40 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:45:40 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:45:40 --> Session Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:45:40 --> Session routines successfully run
DEBUG - 2015-10-12 10:45:40 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Email Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Controller Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:45:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:45:40 --> Final output sent to browser
DEBUG - 2015-10-12 10:45:40 --> Total execution time: 0.1196
DEBUG - 2015-10-12 10:46:48 --> Config Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:46:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:46:48 --> URI Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Router Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Output Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Security Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Input Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:46:48 --> Language Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Language Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Config Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Loader Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:46:48 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:46:48 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:46:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:46:48 --> Session Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:46:48 --> Session routines successfully run
DEBUG - 2015-10-12 10:46:48 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Email Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Controller Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:46:48 --> Model Class Initialized
DEBUG - 2015-10-12 10:46:48 --> Final output sent to browser
DEBUG - 2015-10-12 10:46:48 --> Total execution time: 0.1569
DEBUG - 2015-10-12 10:48:16 --> Config Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:48:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:48:16 --> URI Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Router Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Output Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Security Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Input Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:48:16 --> Language Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Language Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Config Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Loader Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:48:16 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:48:16 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:48:16 --> Session Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:48:16 --> Session routines successfully run
DEBUG - 2015-10-12 10:48:16 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Email Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Controller Class Initialized
DEBUG - 2015-10-12 10:48:16 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:48:16 --> Model Class Initialized
ERROR - 2015-10-12 10:48:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 84
DEBUG - 2015-10-12 10:48:16 --> Final output sent to browser
DEBUG - 2015-10-12 10:48:16 --> Total execution time: 0.1204
DEBUG - 2015-10-12 10:48:59 --> Config Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:48:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:48:59 --> URI Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Router Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Output Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Security Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Input Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:48:59 --> Language Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Language Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Config Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Loader Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:48:59 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:48:59 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:48:59 --> Session Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:48:59 --> Session routines successfully run
DEBUG - 2015-10-12 10:48:59 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Email Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Controller Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:48:59 --> Model Class Initialized
DEBUG - 2015-10-12 10:48:59 --> Final output sent to browser
DEBUG - 2015-10-12 10:48:59 --> Total execution time: 0.1177
DEBUG - 2015-10-12 10:49:04 --> Config Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:49:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:49:04 --> URI Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Router Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Output Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Security Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Input Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:49:04 --> Language Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Language Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Config Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Loader Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:49:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:49:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:49:04 --> Session Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:49:04 --> Session routines successfully run
DEBUG - 2015-10-12 10:49:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Email Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Controller Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:49:04 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:04 --> Final output sent to browser
DEBUG - 2015-10-12 10:49:04 --> Total execution time: 0.1212
DEBUG - 2015-10-12 10:49:22 --> Config Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:49:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:49:22 --> URI Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Router Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Output Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Security Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Input Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:49:22 --> Language Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Language Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Config Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Loader Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:49:22 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:49:22 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:49:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:49:22 --> Session Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:49:22 --> Session routines successfully run
DEBUG - 2015-10-12 10:49:22 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Email Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Controller Class Initialized
DEBUG - 2015-10-12 10:49:22 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
DEBUG - 2015-10-12 10:49:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:49:22 --> Model Class Initialized
ERROR - 2015-10-12 10:49:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 83
DEBUG - 2015-10-12 10:49:22 --> Final output sent to browser
DEBUG - 2015-10-12 10:49:22 --> Total execution time: 0.1238
DEBUG - 2015-10-12 10:53:16 --> Config Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:53:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:53:16 --> URI Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Router Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Output Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Security Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Input Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:53:16 --> Language Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Language Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Config Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Loader Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:53:16 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:53:16 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:53:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:53:16 --> Session Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:53:16 --> Session routines successfully run
DEBUG - 2015-10-12 10:53:16 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Email Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Controller Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:53:16 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:16 --> Final output sent to browser
DEBUG - 2015-10-12 10:53:16 --> Total execution time: 0.1241
DEBUG - 2015-10-12 10:53:33 --> Config Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:53:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:53:33 --> URI Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Router Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Output Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Security Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Input Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:53:33 --> Language Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Language Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Config Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Loader Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:53:33 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:53:33 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:53:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:53:33 --> Session Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:53:33 --> Session routines successfully run
DEBUG - 2015-10-12 10:53:33 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Email Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Controller Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:53:33 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:33 --> Final output sent to browser
DEBUG - 2015-10-12 10:53:33 --> Total execution time: 0.1259
DEBUG - 2015-10-12 10:53:54 --> Config Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:53:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:53:54 --> URI Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Router Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Output Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Security Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Input Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:53:54 --> Language Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Language Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Config Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Loader Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:53:54 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:53:54 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:53:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:53:54 --> Session Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:53:54 --> Session routines successfully run
DEBUG - 2015-10-12 10:53:54 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Email Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Controller Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:53:54 --> Model Class Initialized
DEBUG - 2015-10-12 10:53:54 --> Final output sent to browser
DEBUG - 2015-10-12 10:53:54 --> Total execution time: 0.2641
DEBUG - 2015-10-12 10:55:11 --> Config Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:55:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:55:11 --> URI Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Router Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Output Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Security Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Input Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:55:11 --> Language Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Language Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Config Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Loader Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:55:11 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:55:11 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:55:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:55:11 --> Session Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:55:11 --> Session routines successfully run
DEBUG - 2015-10-12 10:55:11 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Email Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Controller Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:55:11 --> Model Class Initialized
DEBUG - 2015-10-12 10:55:11 --> Final output sent to browser
DEBUG - 2015-10-12 10:55:11 --> Total execution time: 0.1212
DEBUG - 2015-10-12 10:58:05 --> Config Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:58:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:58:05 --> URI Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Router Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Output Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Security Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Input Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:58:05 --> Language Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Language Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Config Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Loader Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:58:05 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:58:05 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:58:05 --> Session Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:58:05 --> Session routines successfully run
DEBUG - 2015-10-12 10:58:05 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Email Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Controller Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:58:05 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:05 --> Final output sent to browser
DEBUG - 2015-10-12 10:58:05 --> Total execution time: 0.1165
DEBUG - 2015-10-12 10:58:12 --> Config Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:58:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:58:12 --> URI Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Router Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Output Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Security Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Input Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:58:12 --> Language Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Language Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Config Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Loader Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:58:12 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:58:12 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:58:12 --> Session Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:58:12 --> Session routines successfully run
DEBUG - 2015-10-12 10:58:12 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Email Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Controller Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:58:12 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:12 --> Final output sent to browser
DEBUG - 2015-10-12 10:58:12 --> Total execution time: 0.1181
DEBUG - 2015-10-12 10:58:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:58:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:58:19 --> URI Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Router Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Output Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Security Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Input Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:58:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Language Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Config Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Loader Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:58:19 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:58:19 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:58:19 --> Session Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:58:19 --> Session routines successfully run
DEBUG - 2015-10-12 10:58:19 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Email Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Controller Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:58:19 --> Model Class Initialized
DEBUG - 2015-10-12 10:58:19 --> Final output sent to browser
DEBUG - 2015-10-12 10:58:19 --> Total execution time: 0.1262
DEBUG - 2015-10-12 10:59:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:59:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:59:18 --> URI Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Router Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Output Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Security Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Input Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:59:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Language Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Config Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Loader Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:59:18 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:59:18 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:59:18 --> Session Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:59:18 --> Session routines successfully run
DEBUG - 2015-10-12 10:59:18 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Email Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Controller Class Initialized
DEBUG - 2015-10-12 10:59:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:59:18 --> Model Class Initialized
ERROR - 2015-10-12 10:59:18 --> Severity: Notice  --> Undefined index: group_id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 83
DEBUG - 2015-10-12 10:59:18 --> Final output sent to browser
DEBUG - 2015-10-12 10:59:18 --> Total execution time: 0.1259
DEBUG - 2015-10-12 10:59:40 --> Config Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 10:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 10:59:40 --> URI Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Router Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Output Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Security Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Input Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 10:59:40 --> Language Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Language Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Config Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Loader Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Helper loaded: url_helper
DEBUG - 2015-10-12 10:59:40 --> Helper loaded: form_helper
DEBUG - 2015-10-12 10:59:40 --> Database Driver Class Initialized
ERROR - 2015-10-12 10:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 10:59:40 --> Session Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Helper loaded: string_helper
DEBUG - 2015-10-12 10:59:40 --> Session routines successfully run
DEBUG - 2015-10-12 10:59:40 --> Form Validation Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Pagination Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Encrypt Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Email Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Controller Class Initialized
DEBUG - 2015-10-12 10:59:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
DEBUG - 2015-10-12 10:59:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 10:59:40 --> Model Class Initialized
ERROR - 2015-10-12 10:59:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 84
ERROR - 2015-10-12 10:59:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 84
DEBUG - 2015-10-12 10:59:40 --> Final output sent to browser
DEBUG - 2015-10-12 10:59:40 --> Total execution time: 0.1271
DEBUG - 2015-10-12 11:00:01 --> Config Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:00:01 --> URI Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Router Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Output Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Security Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Input Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:00:01 --> Language Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Language Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Config Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Loader Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:00:01 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:00:01 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:00:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:00:01 --> Session Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:00:01 --> Session routines successfully run
DEBUG - 2015-10-12 11:00:01 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Email Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Controller Class Initialized
DEBUG - 2015-10-12 11:00:01 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:00:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:00:01 --> Model Class Initialized
ERROR - 2015-10-12 11:00:01 --> Severity: Notice  --> Undefined index: group_id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 84
ERROR - 2015-10-12 11:00:01 --> Severity: Notice  --> Undefined index: group_id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 84
DEBUG - 2015-10-12 11:00:01 --> Final output sent to browser
DEBUG - 2015-10-12 11:00:01 --> Total execution time: 0.1965
DEBUG - 2015-10-12 11:01:19 --> Config Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:01:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:01:19 --> URI Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Router Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Output Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Security Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Input Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:01:19 --> Language Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Language Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Config Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Loader Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:01:19 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:01:19 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:01:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:01:19 --> Session Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:01:19 --> Session routines successfully run
DEBUG - 2015-10-12 11:01:19 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Email Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Controller Class Initialized
DEBUG - 2015-10-12 11:01:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:01:19 --> Model Class Initialized
ERROR - 2015-10-12 11:01:19 --> Severity: Notice  --> Undefined index: group_id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 84
DEBUG - 2015-10-12 11:01:19 --> Final output sent to browser
DEBUG - 2015-10-12 11:01:19 --> Total execution time: 0.1468
DEBUG - 2015-10-12 11:01:57 --> Config Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:01:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:01:57 --> URI Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Router Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Output Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Security Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Input Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:01:57 --> Language Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Language Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Config Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Loader Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:01:57 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:01:57 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:01:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:01:57 --> Session Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:01:57 --> Session routines successfully run
DEBUG - 2015-10-12 11:01:57 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Email Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Controller Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:01:57 --> Model Class Initialized
DEBUG - 2015-10-12 11:01:57 --> Final output sent to browser
DEBUG - 2015-10-12 11:01:57 --> Total execution time: 0.1307
DEBUG - 2015-10-12 11:02:17 --> Config Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:02:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:02:17 --> URI Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Router Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Output Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Security Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Input Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:02:17 --> Language Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Language Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Config Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Loader Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:02:17 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:02:17 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:02:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:02:17 --> Session Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:02:17 --> Session routines successfully run
DEBUG - 2015-10-12 11:02:17 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Email Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Controller Class Initialized
DEBUG - 2015-10-12 11:02:17 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:17 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:02:17 --> Model Class Initialized
ERROR - 2015-10-12 11:02:17 --> Severity: Notice  --> Array to string conversion C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 198
DEBUG - 2015-10-12 11:02:17 --> Final output sent to browser
DEBUG - 2015-10-12 11:02:17 --> Total execution time: 0.1242
DEBUG - 2015-10-12 11:02:36 --> Config Class Initialized
DEBUG - 2015-10-12 11:02:36 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:02:36 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:02:36 --> URI Class Initialized
DEBUG - 2015-10-12 11:02:36 --> Router Class Initialized
DEBUG - 2015-10-12 11:02:36 --> Output Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Security Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Input Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:02:37 --> Language Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Language Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Config Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Loader Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:02:37 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:02:37 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:02:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:02:37 --> Session Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:02:37 --> Session routines successfully run
DEBUG - 2015-10-12 11:02:37 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Email Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Controller Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:02:37 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:37 --> Final output sent to browser
DEBUG - 2015-10-12 11:02:37 --> Total execution time: 0.1986
DEBUG - 2015-10-12 11:02:40 --> Config Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:02:40 --> URI Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Router Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Output Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Security Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Input Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:02:40 --> Language Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Language Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Config Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Loader Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:02:40 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:02:40 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:02:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:02:40 --> Session Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:02:40 --> Session routines successfully run
DEBUG - 2015-10-12 11:02:40 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Email Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Controller Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:02:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:02:40 --> Final output sent to browser
DEBUG - 2015-10-12 11:02:40 --> Total execution time: 0.1187
DEBUG - 2015-10-12 11:03:06 --> Config Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:03:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:03:06 --> URI Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Router Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Output Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Security Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Input Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:03:06 --> Language Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Language Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Config Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Loader Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:03:06 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:03:06 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:03:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:03:06 --> Session Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:03:06 --> Session routines successfully run
DEBUG - 2015-10-12 11:03:06 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Email Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Controller Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:03:06 --> Model Class Initialized
DEBUG - 2015-10-12 11:03:06 --> Final output sent to browser
DEBUG - 2015-10-12 11:03:06 --> Total execution time: 0.1596
DEBUG - 2015-10-12 11:04:00 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:04:00 --> URI Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Router Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Output Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Security Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Input Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:04:00 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Loader Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:04:00 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:04:00 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:04:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:04:00 --> Session Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:04:00 --> Session routines successfully run
DEBUG - 2015-10-12 11:04:00 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Email Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Controller Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:04:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:00 --> Final output sent to browser
DEBUG - 2015-10-12 11:04:00 --> Total execution time: 0.1552
DEBUG - 2015-10-12 11:04:18 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:04:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:04:18 --> URI Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Router Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Output Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Security Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Input Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:04:18 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Loader Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:04:18 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:04:18 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:04:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:04:18 --> Session Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:04:18 --> Session routines successfully run
DEBUG - 2015-10-12 11:04:18 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Email Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Controller Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:04:18 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:18 --> Final output sent to browser
DEBUG - 2015-10-12 11:04:18 --> Total execution time: 0.1222
DEBUG - 2015-10-12 11:04:24 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:24 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:04:24 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:04:24 --> URI Class Initialized
DEBUG - 2015-10-12 11:04:24 --> Router Class Initialized
DEBUG - 2015-10-12 11:04:24 --> Output Class Initialized
DEBUG - 2015-10-12 11:04:24 --> Security Class Initialized
DEBUG - 2015-10-12 11:04:24 --> Input Class Initialized
DEBUG - 2015-10-12 11:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:04:24 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:24 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:24 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:25 --> Loader Class Initialized
DEBUG - 2015-10-12 11:04:25 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:04:25 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:04:25 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:04:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:04:25 --> Session Class Initialized
DEBUG - 2015-10-12 11:04:25 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:04:25 --> Session routines successfully run
DEBUG - 2015-10-12 11:04:25 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:04:25 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:04:25 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:04:25 --> Email Class Initialized
DEBUG - 2015-10-12 11:04:25 --> Controller Class Initialized
DEBUG - 2015-10-12 11:04:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:04:25 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:25 --> Final output sent to browser
DEBUG - 2015-10-12 11:04:25 --> Total execution time: 0.1190
DEBUG - 2015-10-12 11:04:49 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:04:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:04:49 --> URI Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Router Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Output Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Security Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Input Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:04:49 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Loader Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:04:49 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:04:49 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:04:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:04:49 --> Session Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:04:49 --> Session routines successfully run
DEBUG - 2015-10-12 11:04:49 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Email Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Controller Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
ERROR - 2015-10-12 11:04:49 --> Severity: Notice  --> Array to string conversion C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 204
DEBUG - 2015-10-12 11:04:49 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:04:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:04:49 --> URI Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Router Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Output Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Security Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Input Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:04:49 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Language Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Config Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Loader Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:04:49 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:04:49 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:04:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:04:49 --> Session Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:04:49 --> Session routines successfully run
DEBUG - 2015-10-12 11:04:49 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Email Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Controller Class Initialized
DEBUG - 2015-10-12 11:04:49 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
DEBUG - 2015-10-12 11:04:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:04:49 --> Model Class Initialized
ERROR - 2015-10-12 11:04:49 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 11:05:29 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:05:29 --> URI Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Router Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Output Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Security Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Input Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:05:29 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Loader Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:05:29 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:05:29 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:05:29 --> Session Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:05:29 --> Session routines successfully run
DEBUG - 2015-10-12 11:05:29 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Email Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Controller Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
ERROR - 2015-10-12 11:05:29 --> Severity: Notice  --> Undefined index: group_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 204
DEBUG - 2015-10-12 11:05:29 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:05:29 --> URI Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Router Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Output Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Security Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Input Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:05:29 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Loader Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:05:29 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:05:29 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:05:29 --> Session Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:05:29 --> Session routines successfully run
DEBUG - 2015-10-12 11:05:29 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Email Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Controller Class Initialized
DEBUG - 2015-10-12 11:05:29 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:05:29 --> Model Class Initialized
ERROR - 2015-10-12 11:05:29 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 11:05:45 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:05:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:05:45 --> URI Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Router Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Output Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Security Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Input Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:05:45 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Loader Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:05:45 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:05:45 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:05:45 --> Session Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:05:45 --> Session routines successfully run
DEBUG - 2015-10-12 11:05:45 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Email Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Controller Class Initialized
DEBUG - 2015-10-12 11:05:45 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:05:45 --> Model Class Initialized
ERROR - 2015-10-12 11:05:45 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 11:05:47 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:05:47 --> URI Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Router Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Output Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Security Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Input Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:05:47 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Loader Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:05:47 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:05:47 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:05:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:05:47 --> Session Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:05:47 --> Session routines successfully run
DEBUG - 2015-10-12 11:05:47 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Email Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Controller Class Initialized
DEBUG - 2015-10-12 11:05:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:05:47 --> Model Class Initialized
ERROR - 2015-10-12 11:05:47 --> Severity: Notice  --> Undefined index: group_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 204
DEBUG - 2015-10-12 11:05:48 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:05:48 --> URI Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Router Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Output Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Security Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Input Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:05:48 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Loader Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:05:48 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:05:48 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:05:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:05:48 --> Session Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:05:48 --> Session routines successfully run
DEBUG - 2015-10-12 11:05:48 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Email Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Controller Class Initialized
DEBUG - 2015-10-12 11:05:48 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:05:48 --> Model Class Initialized
ERROR - 2015-10-12 11:05:48 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 11:05:53 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:05:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:05:53 --> URI Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Router Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Output Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Security Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Input Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:05:53 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Loader Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:05:53 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:05:53 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:05:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:05:53 --> Session Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:05:53 --> Session routines successfully run
DEBUG - 2015-10-12 11:05:53 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Email Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Controller Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
ERROR - 2015-10-12 11:05:53 --> Severity: Notice  --> Undefined index: group_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 204
DEBUG - 2015-10-12 11:05:53 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:05:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:05:53 --> URI Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Router Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Output Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Security Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Input Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:05:53 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Language Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Config Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Loader Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:05:53 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:05:53 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:05:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:05:53 --> Session Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:05:53 --> Session routines successfully run
DEBUG - 2015-10-12 11:05:53 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Email Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Controller Class Initialized
DEBUG - 2015-10-12 11:05:53 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
DEBUG - 2015-10-12 11:05:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:05:53 --> Model Class Initialized
ERROR - 2015-10-12 11:05:53 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 11:06:49 --> Config Class Initialized
DEBUG - 2015-10-12 11:06:49 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:06:49 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:06:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:06:49 --> URI Class Initialized
DEBUG - 2015-10-12 11:06:49 --> Router Class Initialized
DEBUG - 2015-10-12 11:06:49 --> Output Class Initialized
DEBUG - 2015-10-12 11:06:49 --> Security Class Initialized
DEBUG - 2015-10-12 11:06:49 --> Input Class Initialized
DEBUG - 2015-10-12 11:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:06:49 --> Language Class Initialized
DEBUG - 2015-10-12 11:06:49 --> Language Class Initialized
DEBUG - 2015-10-12 11:06:49 --> Config Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Loader Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:06:50 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:06:50 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:06:50 --> Session Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:06:50 --> Session routines successfully run
DEBUG - 2015-10-12 11:06:50 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Email Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Controller Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Config Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:06:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:06:50 --> URI Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Router Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Output Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Security Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Input Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:06:50 --> Language Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Language Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Config Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Loader Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:06:50 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:06:50 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:06:50 --> Session Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:06:50 --> Session routines successfully run
DEBUG - 2015-10-12 11:06:50 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Email Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Controller Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:06:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:06:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:06:50 --> Final output sent to browser
DEBUG - 2015-10-12 11:06:50 --> Total execution time: 0.1343
DEBUG - 2015-10-12 11:06:50 --> Config Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:06:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:06:50 --> URI Class Initialized
DEBUG - 2015-10-12 11:06:50 --> Router Class Initialized
ERROR - 2015-10-12 11:06:50 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:09:04 --> Config Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:09:04 --> URI Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Router Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Output Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Security Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Input Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:09:04 --> Language Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Language Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Config Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Loader Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:09:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:09:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:09:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:09:04 --> Session Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:09:04 --> Session routines successfully run
DEBUG - 2015-10-12 11:09:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Email Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Controller Class Initialized
DEBUG - 2015-10-12 11:09:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:09:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:09:04 --> Final output sent to browser
DEBUG - 2015-10-12 11:09:04 --> Total execution time: 0.1351
DEBUG - 2015-10-12 11:09:05 --> Config Class Initialized
DEBUG - 2015-10-12 11:09:05 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:09:05 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:09:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:09:05 --> URI Class Initialized
DEBUG - 2015-10-12 11:09:05 --> Router Class Initialized
ERROR - 2015-10-12 11:09:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:09:32 --> Config Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:09:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:09:32 --> URI Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Router Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Output Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Security Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Input Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:09:32 --> Language Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Language Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Config Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Loader Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:09:32 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:09:32 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:09:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:09:32 --> Session Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:09:32 --> Session routines successfully run
DEBUG - 2015-10-12 11:09:32 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Email Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Controller Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:09:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:09:32 --> Final output sent to browser
DEBUG - 2015-10-12 11:09:32 --> Total execution time: 0.1408
DEBUG - 2015-10-12 11:10:31 --> Config Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:10:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:10:31 --> URI Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Router Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Output Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Security Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Input Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:10:31 --> Language Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Language Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Config Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Loader Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:10:31 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:10:31 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:10:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:10:31 --> Session Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:10:31 --> Session routines successfully run
DEBUG - 2015-10-12 11:10:31 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:10:31 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:10:32 --> Email Class Initialized
DEBUG - 2015-10-12 11:10:32 --> Controller Class Initialized
DEBUG - 2015-10-12 11:10:32 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:10:32 --> Model Class Initialized
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:10:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:10:32 --> Final output sent to browser
DEBUG - 2015-10-12 11:10:32 --> Total execution time: 0.3228
DEBUG - 2015-10-12 11:10:33 --> Config Class Initialized
DEBUG - 2015-10-12 11:10:33 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:10:33 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:10:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:10:33 --> URI Class Initialized
DEBUG - 2015-10-12 11:10:33 --> Router Class Initialized
ERROR - 2015-10-12 11:10:33 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:11:54 --> Config Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:11:54 --> URI Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Router Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Output Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Security Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Input Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:11:54 --> Language Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Language Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Config Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Loader Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:11:54 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:11:54 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:11:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:11:54 --> Session Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:11:54 --> Session routines successfully run
DEBUG - 2015-10-12 11:11:54 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Email Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Controller Class Initialized
DEBUG - 2015-10-12 11:11:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:11:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:11:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:11:54 --> Final output sent to browser
DEBUG - 2015-10-12 11:11:54 --> Total execution time: 0.1647
DEBUG - 2015-10-12 11:11:55 --> Config Class Initialized
DEBUG - 2015-10-12 11:11:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:11:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:11:55 --> URI Class Initialized
DEBUG - 2015-10-12 11:11:55 --> Router Class Initialized
ERROR - 2015-10-12 11:11:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:12:01 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:12:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:12:01 --> URI Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Router Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Output Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Security Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Input Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:12:01 --> Language Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Language Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Loader Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:12:01 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:12:01 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:12:01 --> Session Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:12:01 --> Session routines successfully run
DEBUG - 2015-10-12 11:12:01 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Email Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Controller Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:12:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:12:01 --> URI Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Router Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Output Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Security Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Input Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:12:01 --> Language Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Language Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Loader Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:12:01 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:12:01 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:12:01 --> Session Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:12:01 --> Session routines successfully run
DEBUG - 2015-10-12 11:12:01 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Email Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Controller Class Initialized
DEBUG - 2015-10-12 11:12:01 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:12:01 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:12:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:12:01 --> Final output sent to browser
DEBUG - 2015-10-12 11:12:01 --> Total execution time: 0.1363
DEBUG - 2015-10-12 11:12:02 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:12:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:12:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:12:02 --> URI Class Initialized
DEBUG - 2015-10-12 11:12:02 --> Router Class Initialized
ERROR - 2015-10-12 11:12:02 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:12:07 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:12:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:12:07 --> URI Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Router Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Output Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Security Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Input Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:12:07 --> Language Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Language Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Loader Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:12:07 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:12:07 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:12:07 --> Session Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:12:07 --> Session routines successfully run
DEBUG - 2015-10-12 11:12:07 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Email Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Controller Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:12:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:12:07 --> URI Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Router Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Output Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Security Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Input Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:12:07 --> Language Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Language Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Loader Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:12:07 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:12:07 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:12:07 --> Session Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:12:07 --> Session routines successfully run
DEBUG - 2015-10-12 11:12:07 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Email Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Controller Class Initialized
DEBUG - 2015-10-12 11:12:07 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:12:07 --> Model Class Initialized
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:12:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:12:07 --> Final output sent to browser
DEBUG - 2015-10-12 11:12:07 --> Total execution time: 0.1645
DEBUG - 2015-10-12 11:12:08 --> Config Class Initialized
DEBUG - 2015-10-12 11:12:08 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:12:08 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:12:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:12:08 --> URI Class Initialized
DEBUG - 2015-10-12 11:12:08 --> Router Class Initialized
ERROR - 2015-10-12 11:12:08 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:21:42 --> Config Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:21:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:21:42 --> URI Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Router Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Output Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Security Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Input Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:21:42 --> Language Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Language Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Config Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Loader Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:21:42 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:21:42 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:21:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:21:42 --> Session Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:21:42 --> Session routines successfully run
DEBUG - 2015-10-12 11:21:42 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Email Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Controller Class Initialized
DEBUG - 2015-10-12 11:21:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:21:42 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:21:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:21:42 --> Final output sent to browser
DEBUG - 2015-10-12 11:21:42 --> Total execution time: 0.1207
DEBUG - 2015-10-12 11:21:43 --> Config Class Initialized
DEBUG - 2015-10-12 11:21:43 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:21:43 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:21:43 --> URI Class Initialized
DEBUG - 2015-10-12 11:21:43 --> Router Class Initialized
ERROR - 2015-10-12 11:21:43 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:21:47 --> Config Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:21:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:21:47 --> URI Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Router Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Output Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Security Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Input Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:21:47 --> Language Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Language Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Config Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Loader Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:21:47 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:21:47 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:21:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:21:47 --> Session Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:21:47 --> Session routines successfully run
DEBUG - 2015-10-12 11:21:47 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Email Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Controller Class Initialized
DEBUG - 2015-10-12 11:21:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
DEBUG - 2015-10-12 11:21:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:21:47 --> Model Class Initialized
ERROR - 2015-10-12 11:21:47 --> 404 Page Not Found --> payments/show-group-payment
DEBUG - 2015-10-12 11:21:57 --> Config Class Initialized
DEBUG - 2015-10-12 11:21:57 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:21:57 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:21:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:21:57 --> URI Class Initialized
DEBUG - 2015-10-12 11:21:57 --> Router Class Initialized
ERROR - 2015-10-12 11:21:57 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:22:00 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:22:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:22:00 --> URI Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Router Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Output Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Security Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Input Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:22:00 --> Language Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Language Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Loader Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:22:00 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:22:00 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:22:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:22:00 --> Session Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:22:00 --> Session routines successfully run
DEBUG - 2015-10-12 11:22:00 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Email Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Controller Class Initialized
DEBUG - 2015-10-12 11:22:00 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:22:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:22:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:22:00 --> Final output sent to browser
DEBUG - 2015-10-12 11:22:00 --> Total execution time: 0.1307
DEBUG - 2015-10-12 11:22:01 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:01 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:22:01 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:22:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:22:01 --> URI Class Initialized
DEBUG - 2015-10-12 11:22:01 --> Router Class Initialized
ERROR - 2015-10-12 11:22:01 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:22:02 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:22:02 --> URI Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Router Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Output Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Security Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Input Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:22:02 --> Language Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Language Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Loader Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:22:02 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:22:02 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:22:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:22:02 --> Session Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:22:02 --> Session routines successfully run
DEBUG - 2015-10-12 11:22:02 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Email Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Controller Class Initialized
DEBUG - 2015-10-12 11:22:02 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:22:02 --> Model Class Initialized
ERROR - 2015-10-12 11:22:02 --> 404 Page Not Found --> microfinance/show-group-payment
DEBUG - 2015-10-12 11:22:24 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:22:24 --> URI Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Router Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Output Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Security Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Input Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:22:24 --> Language Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Language Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Loader Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:22:24 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:22:24 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:22:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:22:24 --> Session Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:22:24 --> Session routines successfully run
DEBUG - 2015-10-12 11:22:24 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Email Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Controller Class Initialized
DEBUG - 2015-10-12 11:22:24 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:22:24 --> Model Class Initialized
ERROR - 2015-10-12 11:22:24 --> 404 Page Not Found --> microfinance/show-group-payment
DEBUG - 2015-10-12 11:22:36 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:36 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:22:36 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:22:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:22:36 --> URI Class Initialized
DEBUG - 2015-10-12 11:22:36 --> Router Class Initialized
ERROR - 2015-10-12 11:22:36 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:22:55 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:22:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:22:55 --> URI Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Router Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Output Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Security Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Input Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:22:55 --> Language Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Language Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Loader Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:22:55 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:22:55 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:22:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:22:55 --> Session Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:22:55 --> Session routines successfully run
DEBUG - 2015-10-12 11:22:55 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Email Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Controller Class Initialized
DEBUG - 2015-10-12 11:22:55 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
DEBUG - 2015-10-12 11:22:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:22:55 --> Model Class Initialized
ERROR - 2015-10-12 11:22:55 --> 404 Page Not Found --> microfinance/show-group-payment
DEBUG - 2015-10-12 11:22:58 --> Config Class Initialized
DEBUG - 2015-10-12 11:22:58 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:22:58 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:22:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:22:58 --> URI Class Initialized
DEBUG - 2015-10-12 11:22:58 --> Router Class Initialized
ERROR - 2015-10-12 11:22:58 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:23:00 --> Config Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:23:00 --> URI Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Router Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Output Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Security Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Input Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:23:00 --> Language Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Language Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Config Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Loader Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:23:00 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:23:00 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:23:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:23:00 --> Session Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:23:00 --> Session routines successfully run
DEBUG - 2015-10-12 11:23:00 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Email Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Controller Class Initialized
DEBUG - 2015-10-12 11:23:00 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:23:00 --> Model Class Initialized
ERROR - 2015-10-12 11:23:00 --> 404 Page Not Found --> microfinance/show-group-payment
DEBUG - 2015-10-12 11:23:02 --> Config Class Initialized
DEBUG - 2015-10-12 11:23:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:23:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:23:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:23:02 --> URI Class Initialized
DEBUG - 2015-10-12 11:23:02 --> Router Class Initialized
ERROR - 2015-10-12 11:23:02 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:23:26 --> Config Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:23:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:23:26 --> URI Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Router Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Output Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Security Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Input Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:23:26 --> Language Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Language Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Config Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Loader Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:23:26 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:23:26 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:23:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:23:26 --> Session Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:23:26 --> Session routines successfully run
DEBUG - 2015-10-12 11:23:26 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Email Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Controller Class Initialized
DEBUG - 2015-10-12 11:23:26 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:23:26 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:23:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:23:26 --> Final output sent to browser
DEBUG - 2015-10-12 11:23:26 --> Total execution time: 0.3052
DEBUG - 2015-10-12 11:23:27 --> Config Class Initialized
DEBUG - 2015-10-12 11:23:27 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:23:27 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:23:27 --> URI Class Initialized
DEBUG - 2015-10-12 11:23:27 --> Router Class Initialized
ERROR - 2015-10-12 11:23:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:23:40 --> Config Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:23:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:23:40 --> URI Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Router Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Output Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Security Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Input Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:23:40 --> Language Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Language Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Config Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Loader Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:23:40 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:23:40 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:23:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:23:40 --> Session Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:23:40 --> Session routines successfully run
DEBUG - 2015-10-12 11:23:40 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Email Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Controller Class Initialized
DEBUG - 2015-10-12 11:23:40 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
DEBUG - 2015-10-12 11:23:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:23:40 --> Model Class Initialized
ERROR - 2015-10-12 11:23:40 --> 404 Page Not Found --> microfinance/show-group-payments
DEBUG - 2015-10-12 11:24:02 --> Config Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:24:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:24:02 --> URI Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Router Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Output Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Security Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Input Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:24:02 --> Language Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Language Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Config Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Loader Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:24:02 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:24:02 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:24:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:24:02 --> Session Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:24:02 --> Session routines successfully run
DEBUG - 2015-10-12 11:24:02 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Email Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Controller Class Initialized
DEBUG - 2015-10-12 11:24:02 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:24:02 --> Model Class Initialized
ERROR - 2015-10-12 11:24:02 --> 404 Page Not Found --> microfinance/show-group-payments
DEBUG - 2015-10-12 11:24:10 --> Config Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:24:10 --> URI Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Router Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Output Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Security Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Input Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:24:10 --> Language Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Language Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Config Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Loader Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:24:10 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:24:10 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:24:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:24:10 --> Session Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:24:10 --> Session routines successfully run
DEBUG - 2015-10-12 11:24:10 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Email Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Controller Class Initialized
DEBUG - 2015-10-12 11:24:10 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:24:10 --> Model Class Initialized
ERROR - 2015-10-12 11:24:10 --> 404 Page Not Found --> microfinance/show-group-payments
DEBUG - 2015-10-12 11:24:44 --> Config Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:24:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:24:44 --> URI Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Router Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Output Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Security Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Input Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:24:44 --> Language Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Language Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Config Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Loader Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:24:44 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:24:44 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:24:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:24:44 --> Session Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:24:44 --> Session routines successfully run
DEBUG - 2015-10-12 11:24:44 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Email Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Controller Class Initialized
DEBUG - 2015-10-12 11:24:44 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
DEBUG - 2015-10-12 11:24:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:24:44 --> Model Class Initialized
ERROR - 2015-10-12 11:24:44 --> 404 Page Not Found --> microfinance/show_group_payment
DEBUG - 2015-10-12 11:25:07 --> Config Class Initialized
DEBUG - 2015-10-12 11:25:07 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:25:07 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:25:07 --> URI Class Initialized
DEBUG - 2015-10-12 11:25:07 --> Router Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Output Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Security Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Input Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:25:08 --> Language Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Language Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Config Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Loader Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:25:08 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:25:08 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:25:08 --> Session Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:25:08 --> Session routines successfully run
DEBUG - 2015-10-12 11:25:08 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Email Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Controller Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:25:08 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:25:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:25:08 --> Final output sent to browser
DEBUG - 2015-10-12 11:25:08 --> Total execution time: 0.1220
DEBUG - 2015-10-12 11:25:08 --> Config Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:25:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:25:08 --> URI Class Initialized
DEBUG - 2015-10-12 11:25:08 --> Router Class Initialized
ERROR - 2015-10-12 11:25:08 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:25:16 --> Config Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:25:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:25:16 --> URI Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Router Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Output Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Security Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Input Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:25:16 --> Language Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Language Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Config Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Loader Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:25:16 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:25:16 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:25:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:25:16 --> Session Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:25:16 --> Session routines successfully run
DEBUG - 2015-10-12 11:25:16 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Email Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Controller Class Initialized
DEBUG - 2015-10-12 11:25:16 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
DEBUG - 2015-10-12 11:25:17 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:25:17 --> Model Class Initialized
ERROR - 2015-10-12 11:25:17 --> 404 Page Not Found --> microfinance/show-group-payments
DEBUG - 2015-10-12 11:27:51 --> Config Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:27:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:27:51 --> URI Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Router Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Output Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Security Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Input Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:27:51 --> Language Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Language Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Config Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Loader Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:27:51 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:27:51 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:27:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:27:51 --> Session Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:27:51 --> Session routines successfully run
DEBUG - 2015-10-12 11:27:51 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Email Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Controller Class Initialized
DEBUG - 2015-10-12 11:27:51 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:27:51 --> Model Class Initialized
ERROR - 2015-10-12 11:27:51 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 11:27:54 --> Config Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:27:54 --> URI Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Router Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Output Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Security Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Input Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:27:54 --> Language Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Language Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Config Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Loader Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:27:54 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:27:54 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:27:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:27:54 --> Session Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:27:54 --> Session routines successfully run
DEBUG - 2015-10-12 11:27:54 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Email Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Controller Class Initialized
DEBUG - 2015-10-12 11:27:54 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:27:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:27:54 --> Model Class Initialized
ERROR - 2015-10-12 11:27:54 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 11:28:10 --> Config Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:28:10 --> URI Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Router Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Output Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Security Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Input Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:28:10 --> Language Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Language Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Config Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Loader Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:28:10 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:28:10 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:28:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:28:10 --> Session Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:28:10 --> Session routines successfully run
DEBUG - 2015-10-12 11:28:10 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Email Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Controller Class Initialized
DEBUG - 2015-10-12 11:28:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:28:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:28:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:28:10 --> Final output sent to browser
DEBUG - 2015-10-12 11:28:10 --> Total execution time: 0.1164
DEBUG - 2015-10-12 11:28:11 --> Config Class Initialized
DEBUG - 2015-10-12 11:28:11 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:28:11 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:28:11 --> URI Class Initialized
DEBUG - 2015-10-12 11:28:11 --> Router Class Initialized
ERROR - 2015-10-12 11:28:11 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:28:59 --> Config Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:28:59 --> URI Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Router Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Output Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Security Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Input Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:28:59 --> Language Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Language Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Config Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Loader Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:28:59 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:28:59 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:28:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:28:59 --> Session Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:28:59 --> Session routines successfully run
DEBUG - 2015-10-12 11:28:59 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Email Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Controller Class Initialized
DEBUG - 2015-10-12 11:28:59 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:28:59 --> Model Class Initialized
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:28:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:28:59 --> Final output sent to browser
DEBUG - 2015-10-12 11:28:59 --> Total execution time: 0.1172
DEBUG - 2015-10-12 11:29:00 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:00 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:00 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:00 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:00 --> Router Class Initialized
ERROR - 2015-10-12 11:29:00 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:29:10 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:10 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Router Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Output Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Security Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Input Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:29:10 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Loader Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:29:10 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:29:10 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:29:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:29:10 --> Session Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:29:10 --> Session routines successfully run
DEBUG - 2015-10-12 11:29:10 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Email Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Controller Class Initialized
DEBUG - 2015-10-12 11:29:10 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:29:10 --> Model Class Initialized
ERROR - 2015-10-12 11:29:10 --> 404 Page Not Found --> microfinance/show-group-payments
DEBUG - 2015-10-12 11:29:33 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:33 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:33 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:33 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:33 --> Router Class Initialized
ERROR - 2015-10-12 11:29:33 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:29:34 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:34 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Router Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Output Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Security Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Input Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:29:34 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Loader Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:29:34 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:29:34 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:29:34 --> Session Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:29:34 --> Session routines successfully run
DEBUG - 2015-10-12 11:29:34 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Email Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Controller Class Initialized
DEBUG - 2015-10-12 11:29:34 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:34 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:29:34 --> Model Class Initialized
ERROR - 2015-10-12 11:29:34 --> 404 Page Not Found --> microfinance/show-group-payments
DEBUG - 2015-10-12 11:29:38 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:38 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Router Class Initialized
ERROR - 2015-10-12 11:29:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:29:38 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:38 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Router Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Output Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Security Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Input Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:29:38 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Loader Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:29:38 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:29:38 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:29:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:29:38 --> Session Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:29:38 --> Session routines successfully run
DEBUG - 2015-10-12 11:29:38 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Email Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Controller Class Initialized
DEBUG - 2015-10-12 11:29:38 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:29:38 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:29:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:29:38 --> Final output sent to browser
DEBUG - 2015-10-12 11:29:38 --> Total execution time: 0.1667
DEBUG - 2015-10-12 11:29:39 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:39 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:39 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:39 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:39 --> Router Class Initialized
ERROR - 2015-10-12 11:29:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:29:41 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:41 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Router Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Output Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Security Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Input Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:29:41 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Loader Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:29:41 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:29:41 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:29:41 --> Session Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:29:41 --> Session routines successfully run
DEBUG - 2015-10-12 11:29:41 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Email Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Controller Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:29:41 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:29:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:29:41 --> Final output sent to browser
DEBUG - 2015-10-12 11:29:41 --> Total execution time: 0.1223
DEBUG - 2015-10-12 11:29:42 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:42 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:42 --> Router Class Initialized
ERROR - 2015-10-12 11:29:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:29:46 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:46 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Router Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Output Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Security Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Input Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:29:46 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Loader Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:29:46 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:29:46 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:29:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:29:46 --> Session Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:29:46 --> Session routines successfully run
DEBUG - 2015-10-12 11:29:46 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Email Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Controller Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:29:46 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:29:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:29:46 --> Final output sent to browser
DEBUG - 2015-10-12 11:29:46 --> Total execution time: 0.1327
DEBUG - 2015-10-12 11:29:47 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:47 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:47 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:47 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:47 --> Router Class Initialized
ERROR - 2015-10-12 11:29:47 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:29:58 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:58 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Router Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Output Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Security Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Input Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:29:58 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Loader Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:29:58 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:29:58 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:29:58 --> Session Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:29:58 --> Session routines successfully run
DEBUG - 2015-10-12 11:29:58 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Email Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Controller Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:29:58 --> URI Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Router Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Output Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Security Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Input Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:29:58 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Language Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Config Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Loader Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:29:58 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:29:58 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:29:58 --> Session Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:29:58 --> Session routines successfully run
DEBUG - 2015-10-12 11:29:58 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Email Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Controller Class Initialized
DEBUG - 2015-10-12 11:29:58 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
DEBUG - 2015-10-12 11:29:58 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:29:58 --> Model Class Initialized
ERROR - 2015-10-12 11:29:58 --> 404 Page Not Found --> microfinance/show-group-payment
DEBUG - 2015-10-12 11:30:06 --> Config Class Initialized
DEBUG - 2015-10-12 11:30:06 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:30:06 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:30:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:30:06 --> URI Class Initialized
DEBUG - 2015-10-12 11:30:06 --> Router Class Initialized
ERROR - 2015-10-12 11:30:06 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:32:15 --> Config Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:32:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:32:15 --> URI Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Router Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Output Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Security Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Input Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:32:15 --> Language Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Language Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Config Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Loader Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:32:15 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:32:15 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:32:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:32:15 --> Session Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:32:15 --> Session routines successfully run
DEBUG - 2015-10-12 11:32:15 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Email Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Controller Class Initialized
DEBUG - 2015-10-12 11:32:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:32:15 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:32:15 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:32:16 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:32:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:32:16 --> Final output sent to browser
DEBUG - 2015-10-12 11:32:16 --> Total execution time: 0.1256
DEBUG - 2015-10-12 11:32:17 --> Config Class Initialized
DEBUG - 2015-10-12 11:32:17 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:32:17 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:32:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:32:17 --> URI Class Initialized
DEBUG - 2015-10-12 11:32:17 --> Router Class Initialized
ERROR - 2015-10-12 11:32:17 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:32:50 --> Config Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:32:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:32:50 --> URI Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Router Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Output Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Security Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Input Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:32:50 --> Language Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Language Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Config Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Loader Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:32:50 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:32:50 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:32:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:32:50 --> Session Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:32:50 --> Session routines successfully run
DEBUG - 2015-10-12 11:32:50 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Email Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Controller Class Initialized
DEBUG - 2015-10-12 11:32:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:32:50 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:32:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:32:50 --> Final output sent to browser
DEBUG - 2015-10-12 11:32:50 --> Total execution time: 0.1225
DEBUG - 2015-10-12 11:32:51 --> Config Class Initialized
DEBUG - 2015-10-12 11:32:51 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:32:51 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:32:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:32:51 --> URI Class Initialized
DEBUG - 2015-10-12 11:32:51 --> Router Class Initialized
ERROR - 2015-10-12 11:32:51 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:32:54 --> Config Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:32:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:32:54 --> URI Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Router Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Output Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Security Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Input Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:32:54 --> Language Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Language Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Config Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Loader Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:32:54 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:32:54 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:32:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:32:54 --> Session Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:32:54 --> Session routines successfully run
DEBUG - 2015-10-12 11:32:54 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Email Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Controller Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:32:54 --> Model Class Initialized
DEBUG - 2015-10-12 11:32:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:32:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:32:54 --> Final output sent to browser
DEBUG - 2015-10-12 11:32:54 --> Total execution time: 0.1268
DEBUG - 2015-10-12 11:32:55 --> Config Class Initialized
DEBUG - 2015-10-12 11:32:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:32:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:32:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:32:55 --> URI Class Initialized
DEBUG - 2015-10-12 11:32:55 --> Router Class Initialized
ERROR - 2015-10-12 11:32:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 11:33:03 --> Config Class Initialized
DEBUG - 2015-10-12 11:33:03 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:33:03 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:33:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:33:03 --> URI Class Initialized
DEBUG - 2015-10-12 11:33:03 --> Router Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Output Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Security Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Input Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:33:04 --> Language Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Language Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Config Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Loader Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:33:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:33:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:33:04 --> Session Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:33:04 --> Session routines successfully run
DEBUG - 2015-10-12 11:33:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Email Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Controller Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Config Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:33:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:33:04 --> URI Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Router Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Output Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Security Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Input Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 11:33:04 --> Language Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Language Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Config Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Loader Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 11:33:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 11:33:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 11:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 11:33:04 --> Session Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 11:33:04 --> Session routines successfully run
DEBUG - 2015-10-12 11:33:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Email Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Controller Class Initialized
DEBUG - 2015-10-12 11:33:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 11:33:04 --> Model Class Initialized
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 11:33:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 11:33:04 --> Final output sent to browser
DEBUG - 2015-10-12 11:33:04 --> Total execution time: 0.1290
DEBUG - 2015-10-12 11:33:05 --> Config Class Initialized
DEBUG - 2015-10-12 11:33:05 --> Hooks Class Initialized
DEBUG - 2015-10-12 11:33:05 --> Utf8 Class Initialized
DEBUG - 2015-10-12 11:33:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 11:33:05 --> URI Class Initialized
DEBUG - 2015-10-12 11:33:05 --> Router Class Initialized
ERROR - 2015-10-12 11:33:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:15:33 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:15:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:15:33 --> URI Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Router Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Output Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Security Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Input Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:15:33 --> Language Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Language Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Loader Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:15:33 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:15:33 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:15:33 --> Session Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:15:33 --> Session routines successfully run
DEBUG - 2015-10-12 12:15:33 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Email Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Controller Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:15:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:15:33 --> URI Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Router Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Output Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Security Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Input Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:15:33 --> Language Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Language Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Loader Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:15:33 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:15:33 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:15:33 --> Session Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:15:33 --> Session routines successfully run
DEBUG - 2015-10-12 12:15:33 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Email Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Controller Class Initialized
DEBUG - 2015-10-12 12:15:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:15:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:15:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:15:33 --> Final output sent to browser
DEBUG - 2015-10-12 12:15:33 --> Total execution time: 0.1456
DEBUG - 2015-10-12 12:15:34 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:34 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:15:34 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:15:34 --> URI Class Initialized
DEBUG - 2015-10-12 12:15:34 --> Router Class Initialized
ERROR - 2015-10-12 12:15:34 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:15:40 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:15:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:15:40 --> URI Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Router Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Output Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Security Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Input Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:15:40 --> Language Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Language Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Loader Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:15:40 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:15:40 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:15:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:15:40 --> Session Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:15:40 --> Session routines successfully run
DEBUG - 2015-10-12 12:15:40 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Email Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Controller Class Initialized
DEBUG - 2015-10-12 12:15:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:15:40 --> Model Class Initialized
ERROR - 2015-10-12 12:15:40 --> 404 Page Not Found --> payments/edit_group_payment
DEBUG - 2015-10-12 12:15:42 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:15:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:15:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:15:42 --> URI Class Initialized
DEBUG - 2015-10-12 12:15:42 --> Router Class Initialized
ERROR - 2015-10-12 12:15:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:15:47 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:15:47 --> URI Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Router Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Output Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Security Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Input Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:15:47 --> Language Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Language Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Loader Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:15:47 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:15:47 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:15:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:15:47 --> Session Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:15:47 --> Session routines successfully run
DEBUG - 2015-10-12 12:15:47 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Email Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Controller Class Initialized
DEBUG - 2015-10-12 12:15:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:15:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:15:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:15:47 --> Final output sent to browser
DEBUG - 2015-10-12 12:15:47 --> Total execution time: 0.1647
DEBUG - 2015-10-12 12:15:48 --> Config Class Initialized
DEBUG - 2015-10-12 12:15:48 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:15:48 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:15:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:15:48 --> URI Class Initialized
DEBUG - 2015-10-12 12:15:48 --> Router Class Initialized
ERROR - 2015-10-12 12:15:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:18:17 --> Config Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:18:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:18:17 --> URI Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Router Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Output Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Security Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Input Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:18:17 --> Language Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Language Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Config Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Loader Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:18:17 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:18:17 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:18:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:18:17 --> Session Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:18:17 --> Session routines successfully run
DEBUG - 2015-10-12 12:18:17 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Email Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Controller Class Initialized
DEBUG - 2015-10-12 12:18:17 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:18:17 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:18:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:18:17 --> Final output sent to browser
DEBUG - 2015-10-12 12:18:17 --> Total execution time: 0.1451
DEBUG - 2015-10-12 12:18:18 --> Config Class Initialized
DEBUG - 2015-10-12 12:18:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:18:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:18:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:18:18 --> URI Class Initialized
DEBUG - 2015-10-12 12:18:18 --> Router Class Initialized
ERROR - 2015-10-12 12:18:18 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:18:26 --> Config Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:18:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:18:26 --> URI Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Router Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Output Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Security Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Input Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:18:26 --> Language Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Language Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Config Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Loader Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:18:26 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:18:26 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:18:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:18:26 --> Session Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:18:26 --> Session routines successfully run
DEBUG - 2015-10-12 12:18:26 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Email Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Controller Class Initialized
DEBUG - 2015-10-12 12:18:26 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:18:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:18:26 --> Model Class Initialized
ERROR - 2015-10-12 12:18:26 --> 404 Page Not Found --> microfinance/edit-group-payment
DEBUG - 2015-10-12 12:18:32 --> Config Class Initialized
DEBUG - 2015-10-12 12:18:32 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:18:32 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:18:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:18:32 --> URI Class Initialized
DEBUG - 2015-10-12 12:18:32 --> Router Class Initialized
ERROR - 2015-10-12 12:18:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:28:35 --> Config Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:28:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:28:35 --> URI Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Router Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Output Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Security Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Input Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:28:35 --> Language Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Language Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Config Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Loader Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:28:35 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:28:35 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:28:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:28:35 --> Session Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:28:35 --> Session routines successfully run
DEBUG - 2015-10-12 12:28:35 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Email Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Controller Class Initialized
DEBUG - 2015-10-12 12:28:35 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:28:35 --> Model Class Initialized
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:28:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:28:35 --> Final output sent to browser
DEBUG - 2015-10-12 12:28:35 --> Total execution time: 0.1588
DEBUG - 2015-10-12 12:28:36 --> Config Class Initialized
DEBUG - 2015-10-12 12:28:36 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:28:36 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:28:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:28:36 --> URI Class Initialized
DEBUG - 2015-10-12 12:28:36 --> Router Class Initialized
ERROR - 2015-10-12 12:28:36 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:30:14 --> Config Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:30:14 --> URI Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Router Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Output Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Security Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Input Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:30:14 --> Language Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Language Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Config Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Loader Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:30:14 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:30:14 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:30:14 --> Session Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:30:14 --> Session routines successfully run
DEBUG - 2015-10-12 12:30:14 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Email Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Controller Class Initialized
DEBUG - 2015-10-12 12:30:14 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:30:14 --> Model Class Initialized
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Undefined variable: single C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 299
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 299
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Undefined variable: single C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 301
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 301
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Undefined variable: single C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 302
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 302
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Undefined variable: single C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 303
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 303
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Undefined variable: single C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 304
ERROR - 2015-10-12 12:30:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 304
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:30:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:30:14 --> Final output sent to browser
DEBUG - 2015-10-12 12:30:14 --> Total execution time: 0.1520
DEBUG - 2015-10-12 12:30:15 --> Config Class Initialized
DEBUG - 2015-10-12 12:30:15 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:30:15 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:30:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:30:15 --> URI Class Initialized
DEBUG - 2015-10-12 12:30:15 --> Router Class Initialized
ERROR - 2015-10-12 12:30:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:30:39 --> Config Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:30:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:30:39 --> URI Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Router Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Output Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Security Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Input Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:30:39 --> Language Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Language Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Config Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Loader Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:30:39 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:30:39 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:30:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:30:39 --> Session Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:30:39 --> Session routines successfully run
DEBUG - 2015-10-12 12:30:39 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Email Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Controller Class Initialized
DEBUG - 2015-10-12 12:30:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:30:39 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:30:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:30:39 --> Final output sent to browser
DEBUG - 2015-10-12 12:30:39 --> Total execution time: 0.1485
DEBUG - 2015-10-12 12:30:40 --> Config Class Initialized
DEBUG - 2015-10-12 12:30:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:30:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:30:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:30:40 --> URI Class Initialized
DEBUG - 2015-10-12 12:30:40 --> Router Class Initialized
ERROR - 2015-10-12 12:30:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:30:54 --> Config Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:30:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:30:54 --> URI Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Router Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Output Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Security Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Input Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:30:54 --> Language Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Language Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Config Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Loader Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:30:54 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:30:54 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:30:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:30:54 --> Session Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:30:54 --> Session routines successfully run
DEBUG - 2015-10-12 12:30:54 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Email Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Controller Class Initialized
DEBUG - 2015-10-12 12:30:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:30:54 --> Model Class Initialized
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:30:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:30:54 --> Final output sent to browser
DEBUG - 2015-10-12 12:30:54 --> Total execution time: 0.1415
DEBUG - 2015-10-12 12:30:55 --> Config Class Initialized
DEBUG - 2015-10-12 12:30:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:30:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:30:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:30:55 --> URI Class Initialized
DEBUG - 2015-10-12 12:30:55 --> Router Class Initialized
ERROR - 2015-10-12 12:30:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:32:23 --> Config Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:32:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:32:23 --> URI Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Router Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Output Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Security Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Input Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:32:23 --> Language Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Language Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Config Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Loader Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:32:23 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:32:23 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:32:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:32:23 --> Session Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:32:23 --> Session routines successfully run
DEBUG - 2015-10-12 12:32:23 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Email Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Controller Class Initialized
DEBUG - 2015-10-12 12:32:23 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:32:23 --> Model Class Initialized
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:32:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:32:23 --> Final output sent to browser
DEBUG - 2015-10-12 12:32:23 --> Total execution time: 0.1608
DEBUG - 2015-10-12 12:32:25 --> Config Class Initialized
DEBUG - 2015-10-12 12:32:25 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:32:25 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:32:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:32:25 --> URI Class Initialized
DEBUG - 2015-10-12 12:32:25 --> Router Class Initialized
ERROR - 2015-10-12 12:32:25 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:34:47 --> Config Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:34:47 --> URI Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Router Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Output Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Security Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Input Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:34:47 --> Language Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Language Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Config Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Loader Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:34:47 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:34:47 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:34:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:34:47 --> Session Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:34:47 --> Session routines successfully run
DEBUG - 2015-10-12 12:34:47 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Email Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Controller Class Initialized
DEBUG - 2015-10-12 12:34:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:34:47 --> Model Class Initialized
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:34:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:34:47 --> Final output sent to browser
DEBUG - 2015-10-12 12:34:47 --> Total execution time: 0.1363
DEBUG - 2015-10-12 12:34:48 --> Config Class Initialized
DEBUG - 2015-10-12 12:34:48 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:34:48 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:34:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:34:48 --> URI Class Initialized
DEBUG - 2015-10-12 12:34:48 --> Router Class Initialized
ERROR - 2015-10-12 12:34:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:35:13 --> Config Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:35:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:35:13 --> URI Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Router Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Output Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Security Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Input Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:35:13 --> Language Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Language Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Config Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Loader Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:35:13 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:35:13 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:35:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:35:13 --> Session Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:35:13 --> Session routines successfully run
DEBUG - 2015-10-12 12:35:13 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Email Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Controller Class Initialized
DEBUG - 2015-10-12 12:35:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:35:13 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Config Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:35:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:35:26 --> URI Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Router Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Output Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Security Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Input Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:35:26 --> Language Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Language Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Config Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Loader Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:35:26 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:35:26 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:35:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:35:26 --> Session Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:35:26 --> Session routines successfully run
DEBUG - 2015-10-12 12:35:26 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Email Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Controller Class Initialized
DEBUG - 2015-10-12 12:35:26 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:35:26 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Config Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:35:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:35:42 --> URI Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Router Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Output Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Security Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Input Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:35:42 --> Language Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Language Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Config Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Loader Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:35:42 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:35:42 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:35:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:35:42 --> Session Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:35:42 --> Session routines successfully run
DEBUG - 2015-10-12 12:35:42 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Email Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Controller Class Initialized
DEBUG - 2015-10-12 12:35:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:35:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:35:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:35:42 --> Final output sent to browser
DEBUG - 2015-10-12 12:35:42 --> Total execution time: 0.1434
DEBUG - 2015-10-12 12:35:43 --> Config Class Initialized
DEBUG - 2015-10-12 12:35:43 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:35:43 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:35:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:35:43 --> URI Class Initialized
DEBUG - 2015-10-12 12:35:43 --> Router Class Initialized
ERROR - 2015-10-12 12:35:43 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:36:11 --> Config Class Initialized
DEBUG - 2015-10-12 12:36:11 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:36:11 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:36:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:36:11 --> URI Class Initialized
DEBUG - 2015-10-12 12:36:11 --> Router Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Output Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Security Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Input Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:36:12 --> Language Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Language Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Config Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Loader Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:36:12 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:36:12 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:36:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:36:12 --> Session Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:36:12 --> Session routines successfully run
DEBUG - 2015-10-12 12:36:12 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Email Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Controller Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:36:12 --> Model Class Initialized
ERROR - 2015-10-12 12:36:12 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_single_group_payment.php 2
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:36:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:36:12 --> Final output sent to browser
DEBUG - 2015-10-12 12:36:12 --> Total execution time: 0.1349
DEBUG - 2015-10-12 12:36:12 --> Config Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:36:12 --> URI Class Initialized
DEBUG - 2015-10-12 12:36:12 --> Router Class Initialized
ERROR - 2015-10-12 12:36:13 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:36:50 --> Config Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:36:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:36:50 --> URI Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Router Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Output Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Security Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Input Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:36:50 --> Language Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Language Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Config Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Loader Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:36:50 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:36:50 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:36:50 --> Session Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:36:50 --> Session routines successfully run
DEBUG - 2015-10-12 12:36:50 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Email Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Controller Class Initialized
DEBUG - 2015-10-12 12:36:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:36:50 --> Model Class Initialized
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:36:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:36:50 --> Final output sent to browser
DEBUG - 2015-10-12 12:36:50 --> Total execution time: 0.1338
DEBUG - 2015-10-12 12:36:51 --> Config Class Initialized
DEBUG - 2015-10-12 12:36:51 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:36:51 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:36:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:36:51 --> URI Class Initialized
DEBUG - 2015-10-12 12:36:51 --> Router Class Initialized
ERROR - 2015-10-12 12:36:51 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:37:24 --> Config Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:37:24 --> URI Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Router Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Output Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Security Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Input Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:37:24 --> Language Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Language Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Config Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Loader Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:37:24 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:37:24 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:37:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:37:24 --> Session Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:37:24 --> Session routines successfully run
DEBUG - 2015-10-12 12:37:24 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Email Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Controller Class Initialized
DEBUG - 2015-10-12 12:37:24 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:37:24 --> Model Class Initialized
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:37:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:37:24 --> Final output sent to browser
DEBUG - 2015-10-12 12:37:24 --> Total execution time: 0.1402
DEBUG - 2015-10-12 12:37:25 --> Config Class Initialized
DEBUG - 2015-10-12 12:37:25 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:37:25 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:37:25 --> URI Class Initialized
DEBUG - 2015-10-12 12:37:25 --> Router Class Initialized
ERROR - 2015-10-12 12:37:25 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:42:04 --> Config Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:42:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:42:04 --> URI Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Router Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Output Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Security Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Input Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:42:04 --> Language Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Language Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Config Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Loader Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:42:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:42:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:42:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:42:04 --> Session Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:42:04 --> Session routines successfully run
DEBUG - 2015-10-12 12:42:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Email Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Controller Class Initialized
DEBUG - 2015-10-12 12:42:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:42:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Config Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:42:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:42:15 --> URI Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Router Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Output Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Security Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Input Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:42:15 --> Language Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Language Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Config Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Loader Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:42:15 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:42:15 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:42:15 --> Session Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:42:15 --> Session routines successfully run
DEBUG - 2015-10-12 12:42:15 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Email Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Controller Class Initialized
DEBUG - 2015-10-12 12:42:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:42:15 --> Model Class Initialized
ERROR - 2015-10-12 12:42:15 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_single_group_payment.php 109
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:42:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:42:15 --> Final output sent to browser
DEBUG - 2015-10-12 12:42:15 --> Total execution time: 0.1414
DEBUG - 2015-10-12 12:42:16 --> Config Class Initialized
DEBUG - 2015-10-12 12:42:16 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:42:16 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:42:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:42:16 --> URI Class Initialized
DEBUG - 2015-10-12 12:42:16 --> Router Class Initialized
ERROR - 2015-10-12 12:42:16 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:44:29 --> Config Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:44:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:44:29 --> URI Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Router Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Output Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Security Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Input Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:44:29 --> Language Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Language Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Config Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Loader Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:44:29 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:44:29 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:44:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:44:29 --> Session Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:44:29 --> Session routines successfully run
DEBUG - 2015-10-12 12:44:29 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Email Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Controller Class Initialized
DEBUG - 2015-10-12 12:44:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:44:29 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Config Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:44:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:44:38 --> URI Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Router Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Output Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Security Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Input Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:44:38 --> Language Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Language Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Config Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Loader Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:44:38 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:44:38 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:44:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:44:38 --> Session Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:44:38 --> Session routines successfully run
DEBUG - 2015-10-12 12:44:38 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Email Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Controller Class Initialized
DEBUG - 2015-10-12 12:44:38 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:44:38 --> Model Class Initialized
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:44:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:44:38 --> Final output sent to browser
DEBUG - 2015-10-12 12:44:38 --> Total execution time: 0.1564
DEBUG - 2015-10-12 12:44:39 --> Config Class Initialized
DEBUG - 2015-10-12 12:44:39 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:44:39 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:44:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:44:39 --> URI Class Initialized
DEBUG - 2015-10-12 12:44:39 --> Router Class Initialized
ERROR - 2015-10-12 12:44:39 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:45:01 --> Config Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:45:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:45:01 --> URI Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Router Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Output Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Security Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Input Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:45:01 --> Language Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Language Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Config Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Loader Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:45:01 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:45:01 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:45:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:45:01 --> Session Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:45:01 --> Session routines successfully run
DEBUG - 2015-10-12 12:45:01 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Email Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Controller Class Initialized
DEBUG - 2015-10-12 12:45:01 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:45:01 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:45:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:45:01 --> Final output sent to browser
DEBUG - 2015-10-12 12:45:01 --> Total execution time: 0.1404
DEBUG - 2015-10-12 12:45:02 --> Config Class Initialized
DEBUG - 2015-10-12 12:45:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:45:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:45:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:45:02 --> URI Class Initialized
DEBUG - 2015-10-12 12:45:02 --> Router Class Initialized
ERROR - 2015-10-12 12:45:03 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:45:09 --> Config Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:45:09 --> URI Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Router Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Output Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Security Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Input Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:45:09 --> Language Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Language Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Config Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Loader Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:45:09 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:45:09 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:45:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:45:09 --> Session Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:45:09 --> Session routines successfully run
DEBUG - 2015-10-12 12:45:09 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Email Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Controller Class Initialized
DEBUG - 2015-10-12 12:45:09 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:45:09 --> Model Class Initialized
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:45:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:45:09 --> Final output sent to browser
DEBUG - 2015-10-12 12:45:09 --> Total execution time: 0.1246
DEBUG - 2015-10-12 12:45:10 --> Config Class Initialized
DEBUG - 2015-10-12 12:45:10 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:45:10 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:45:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:45:10 --> URI Class Initialized
DEBUG - 2015-10-12 12:45:10 --> Router Class Initialized
ERROR - 2015-10-12 12:45:10 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:47:42 --> Config Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:47:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:47:42 --> URI Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Router Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Output Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Security Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Input Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:47:42 --> Language Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Language Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Config Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Loader Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:47:42 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:47:42 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:47:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:47:42 --> Session Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:47:42 --> Session routines successfully run
DEBUG - 2015-10-12 12:47:42 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Email Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Controller Class Initialized
DEBUG - 2015-10-12 12:47:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:47:42 --> Model Class Initialized
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:47:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:47:42 --> Final output sent to browser
DEBUG - 2015-10-12 12:47:42 --> Total execution time: 0.1577
DEBUG - 2015-10-12 12:47:44 --> Config Class Initialized
DEBUG - 2015-10-12 12:47:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:47:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:47:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:47:44 --> URI Class Initialized
DEBUG - 2015-10-12 12:47:44 --> Router Class Initialized
ERROR - 2015-10-12 12:47:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:48:33 --> Config Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:48:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:48:33 --> URI Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Router Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Output Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Security Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Input Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:48:33 --> Language Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Language Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Config Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Loader Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:48:33 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:48:33 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:48:33 --> Session Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:48:33 --> Session routines successfully run
DEBUG - 2015-10-12 12:48:33 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Email Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Controller Class Initialized
DEBUG - 2015-10-12 12:48:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:48:33 --> Model Class Initialized
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:48:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:48:33 --> Final output sent to browser
DEBUG - 2015-10-12 12:48:33 --> Total execution time: 0.1463
DEBUG - 2015-10-12 12:48:35 --> Config Class Initialized
DEBUG - 2015-10-12 12:48:35 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:48:35 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:48:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:48:35 --> URI Class Initialized
DEBUG - 2015-10-12 12:48:35 --> Router Class Initialized
ERROR - 2015-10-12 12:48:35 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:50:28 --> Config Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:50:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:50:28 --> URI Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Router Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Output Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Security Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Input Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:50:28 --> Language Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Language Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Config Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Loader Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:50:28 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:50:28 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:50:28 --> Session Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:50:28 --> Session routines successfully run
DEBUG - 2015-10-12 12:50:28 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Email Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Controller Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:50:28 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:50:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:50:28 --> Final output sent to browser
DEBUG - 2015-10-12 12:50:28 --> Total execution time: 0.1396
DEBUG - 2015-10-12 12:50:30 --> Config Class Initialized
DEBUG - 2015-10-12 12:50:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:50:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:50:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:50:30 --> URI Class Initialized
DEBUG - 2015-10-12 12:50:30 --> Router Class Initialized
ERROR - 2015-10-12 12:50:30 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:50:45 --> Config Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:50:45 --> URI Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Router Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Output Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Security Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Input Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:50:45 --> Language Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Language Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Config Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Loader Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:50:45 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:50:45 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:50:45 --> Session Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:50:45 --> Session routines successfully run
DEBUG - 2015-10-12 12:50:45 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Email Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Controller Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:50:45 --> Model Class Initialized
DEBUG - 2015-10-12 12:50:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:50:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:50:45 --> Final output sent to browser
DEBUG - 2015-10-12 12:50:45 --> Total execution time: 0.1296
DEBUG - 2015-10-12 12:50:46 --> Config Class Initialized
DEBUG - 2015-10-12 12:50:46 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:50:46 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:50:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:50:46 --> URI Class Initialized
DEBUG - 2015-10-12 12:50:46 --> Router Class Initialized
ERROR - 2015-10-12 12:50:46 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:51:18 --> Config Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:51:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:51:18 --> URI Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Router Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Output Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Security Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Input Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:51:18 --> Language Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Language Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Config Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Loader Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:51:18 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:51:18 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:51:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:51:18 --> Session Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:51:18 --> Session routines successfully run
DEBUG - 2015-10-12 12:51:18 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Email Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Controller Class Initialized
DEBUG - 2015-10-12 12:51:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:51:18 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:51:19 --> Model Class Initialized
DEBUG - 2015-10-12 12:51:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 12:51:19 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:51:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:51:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:51:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:51:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:51:19 --> Final output sent to browser
DEBUG - 2015-10-12 12:51:19 --> Total execution time: 0.1469
DEBUG - 2015-10-12 12:51:20 --> Config Class Initialized
DEBUG - 2015-10-12 12:51:20 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:51:20 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:51:20 --> URI Class Initialized
DEBUG - 2015-10-12 12:51:20 --> Router Class Initialized
ERROR - 2015-10-12 12:51:20 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:52:00 --> Config Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:52:00 --> URI Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Router Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Output Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Security Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Input Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:52:00 --> Language Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Language Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Config Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Loader Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:52:00 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:52:00 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:52:00 --> Session Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:52:00 --> Session routines successfully run
DEBUG - 2015-10-12 12:52:00 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Email Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Controller Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:52:00 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:52:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:52:00 --> Final output sent to browser
DEBUG - 2015-10-12 12:52:00 --> Total execution time: 0.1370
DEBUG - 2015-10-12 12:52:02 --> Config Class Initialized
DEBUG - 2015-10-12 12:52:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:52:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:52:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:52:02 --> URI Class Initialized
DEBUG - 2015-10-12 12:52:02 --> Router Class Initialized
ERROR - 2015-10-12 12:52:02 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:52:44 --> Config Class Initialized
DEBUG - 2015-10-12 12:52:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:52:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:52:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:52:44 --> URI Class Initialized
DEBUG - 2015-10-12 12:52:44 --> Router Class Initialized
ERROR - 2015-10-12 12:52:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:52:46 --> Config Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:52:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:52:46 --> URI Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Router Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Output Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Security Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Input Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:52:46 --> Language Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Language Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Config Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Loader Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:52:46 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:52:46 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:52:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:52:46 --> Session Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:52:46 --> Session routines successfully run
DEBUG - 2015-10-12 12:52:46 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Email Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Controller Class Initialized
DEBUG - 2015-10-12 12:52:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:52:46 --> Model Class Initialized
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:52:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:52:46 --> Final output sent to browser
DEBUG - 2015-10-12 12:52:46 --> Total execution time: 0.1336
DEBUG - 2015-10-12 12:52:47 --> Config Class Initialized
DEBUG - 2015-10-12 12:52:47 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:52:47 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:52:47 --> URI Class Initialized
DEBUG - 2015-10-12 12:52:47 --> Router Class Initialized
ERROR - 2015-10-12 12:52:47 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:53:02 --> Config Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:53:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:53:02 --> URI Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Router Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Output Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Security Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Input Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:53:02 --> Language Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Language Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Config Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Loader Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:53:02 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:53:02 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:53:02 --> Session Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:53:02 --> Session routines successfully run
DEBUG - 2015-10-12 12:53:02 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Email Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Controller Class Initialized
DEBUG - 2015-10-12 12:53:02 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:53:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:53:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:53:02 --> Final output sent to browser
DEBUG - 2015-10-12 12:53:02 --> Total execution time: 0.1418
DEBUG - 2015-10-12 12:53:03 --> Config Class Initialized
DEBUG - 2015-10-12 12:53:03 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:53:03 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:53:03 --> URI Class Initialized
DEBUG - 2015-10-12 12:53:03 --> Router Class Initialized
ERROR - 2015-10-12 12:53:03 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:53:06 --> Config Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:53:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:53:06 --> URI Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Router Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Output Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Security Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Input Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:53:06 --> Language Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Language Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Config Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Loader Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:53:06 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:53:06 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:53:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:53:06 --> Session Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:53:06 --> Session routines successfully run
DEBUG - 2015-10-12 12:53:06 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Email Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Controller Class Initialized
DEBUG - 2015-10-12 12:53:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
DEBUG - 2015-10-12 12:53:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:53:06 --> Model Class Initialized
ERROR - 2015-10-12 12:53:06 --> Severity: Warning  --> Missing argument 1 for Payments::edit_group_payment() C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 278
DEBUG - 2015-10-12 12:53:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 12:53:06 --> Severity: Notice  --> Undefined variable: group_payment_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 286
DEBUG - 2015-10-12 12:53:06 --> Final output sent to browser
DEBUG - 2015-10-12 12:53:06 --> Total execution time: 0.1153
DEBUG - 2015-10-12 12:54:04 --> Config Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:54:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:54:04 --> URI Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Router Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Output Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Security Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Input Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:54:04 --> Language Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Language Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Config Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Loader Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:54:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:54:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:54:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:54:04 --> Session Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:54:04 --> Session routines successfully run
DEBUG - 2015-10-12 12:54:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Email Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Controller Class Initialized
DEBUG - 2015-10-12 12:54:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
DEBUG - 2015-10-12 12:54:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:54:04 --> Model Class Initialized
ERROR - 2015-10-12 12:54:04 --> Severity: Warning  --> Missing argument 1 for Payments::edit_group_payment() C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 278
DEBUG - 2015-10-12 12:54:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 12:54:04 --> Severity: Notice  --> Undefined variable: group_payment_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 286
DEBUG - 2015-10-12 12:54:04 --> Final output sent to browser
DEBUG - 2015-10-12 12:54:04 --> Total execution time: 0.1192
DEBUG - 2015-10-12 12:54:38 --> Config Class Initialized
DEBUG - 2015-10-12 12:54:38 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:54:38 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:54:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:54:38 --> URI Class Initialized
DEBUG - 2015-10-12 12:54:38 --> Router Class Initialized
ERROR - 2015-10-12 12:54:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:55:02 --> Config Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:55:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:55:02 --> URI Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Router Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Output Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Security Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Input Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:55:02 --> Language Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Language Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Config Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Loader Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:55:02 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:55:02 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:55:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:55:02 --> Session Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:55:02 --> Session routines successfully run
DEBUG - 2015-10-12 12:55:02 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Email Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Controller Class Initialized
DEBUG - 2015-10-12 12:55:02 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:55:02 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Config Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:55:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:55:16 --> URI Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Router Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Output Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Security Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Input Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:55:16 --> Language Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Language Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Config Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Loader Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:55:16 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:55:16 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:55:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:55:16 --> Session Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:55:16 --> Session routines successfully run
DEBUG - 2015-10-12 12:55:16 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Email Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Controller Class Initialized
DEBUG - 2015-10-12 12:55:16 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:55:16 --> Model Class Initialized
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:55:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:55:16 --> Final output sent to browser
DEBUG - 2015-10-12 12:55:16 --> Total execution time: 0.1529
DEBUG - 2015-10-12 12:55:17 --> Config Class Initialized
DEBUG - 2015-10-12 12:55:17 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:55:17 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:55:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:55:17 --> URI Class Initialized
DEBUG - 2015-10-12 12:55:17 --> Router Class Initialized
ERROR - 2015-10-12 12:55:17 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 12:57:44 --> Config Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:57:44 --> URI Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Router Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Output Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Security Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Input Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 12:57:44 --> Language Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Language Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Config Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Loader Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Helper loaded: url_helper
DEBUG - 2015-10-12 12:57:44 --> Helper loaded: form_helper
DEBUG - 2015-10-12 12:57:44 --> Database Driver Class Initialized
ERROR - 2015-10-12 12:57:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 12:57:44 --> Session Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Helper loaded: string_helper
DEBUG - 2015-10-12 12:57:44 --> Session routines successfully run
DEBUG - 2015-10-12 12:57:44 --> Form Validation Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Pagination Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Encrypt Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Email Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Controller Class Initialized
DEBUG - 2015-10-12 12:57:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 12:57:44 --> Model Class Initialized
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 12:57:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 12:57:44 --> Final output sent to browser
DEBUG - 2015-10-12 12:57:44 --> Total execution time: 0.1309
DEBUG - 2015-10-12 12:57:45 --> Config Class Initialized
DEBUG - 2015-10-12 12:57:45 --> Hooks Class Initialized
DEBUG - 2015-10-12 12:57:45 --> Utf8 Class Initialized
DEBUG - 2015-10-12 12:57:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 12:57:45 --> URI Class Initialized
DEBUG - 2015-10-12 12:57:45 --> Router Class Initialized
ERROR - 2015-10-12 12:57:45 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:00:36 --> Config Class Initialized
DEBUG - 2015-10-12 13:00:36 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:00:36 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:00:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:00:36 --> URI Class Initialized
DEBUG - 2015-10-12 13:00:36 --> Router Class Initialized
DEBUG - 2015-10-12 13:00:36 --> Output Class Initialized
DEBUG - 2015-10-12 13:00:36 --> Security Class Initialized
DEBUG - 2015-10-12 13:00:36 --> Input Class Initialized
DEBUG - 2015-10-12 13:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:00:36 --> Language Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Config Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:00:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:00:43 --> URI Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Router Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Output Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Security Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Input Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:00:43 --> Language Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Language Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Config Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Loader Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:00:43 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:00:43 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:00:43 --> Session Class Initialized
DEBUG - 2015-10-12 13:00:43 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:00:43 --> Session routines successfully run
DEBUG - 2015-10-12 13:00:44 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:00:44 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:00:44 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:00:44 --> Email Class Initialized
DEBUG - 2015-10-12 13:00:44 --> Controller Class Initialized
DEBUG - 2015-10-12 13:00:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:00:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:00:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:00:44 --> Final output sent to browser
DEBUG - 2015-10-12 13:00:44 --> Total execution time: 0.1411
DEBUG - 2015-10-12 13:00:44 --> Config Class Initialized
DEBUG - 2015-10-12 13:00:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:00:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:00:44 --> URI Class Initialized
DEBUG - 2015-10-12 13:00:44 --> Router Class Initialized
ERROR - 2015-10-12 13:00:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:01:04 --> Config Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:01:04 --> URI Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Router Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Output Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Security Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Input Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:01:04 --> Language Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Language Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Config Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Loader Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:01:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:01:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:01:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:01:04 --> Session Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:01:04 --> Session routines successfully run
DEBUG - 2015-10-12 13:01:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Email Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Controller Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:01:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:01:04 --> Severity: Notice  --> Undefined variable: group_payment_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 289
DEBUG - 2015-10-12 13:01:04 --> Final output sent to browser
DEBUG - 2015-10-12 13:01:04 --> Total execution time: 0.1164
DEBUG - 2015-10-12 13:01:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:01:41 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:01:41 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:01:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:01:41 --> URI Class Initialized
DEBUG - 2015-10-12 13:01:41 --> Router Class Initialized
ERROR - 2015-10-12 13:01:41 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:01:56 --> Config Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:01:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:01:56 --> URI Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Router Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Output Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Security Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Input Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:01:56 --> Language Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Language Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Config Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Loader Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:01:56 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:01:56 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:01:56 --> Session Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:01:56 --> Session routines successfully run
DEBUG - 2015-10-12 13:01:56 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Email Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Controller Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:01:56 --> Model Class Initialized
DEBUG - 2015-10-12 13:01:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 13:01:56 --> DB Transaction Failure
ERROR - 2015-10-12 13:01:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
DEBUG - 2015-10-12 13:01:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-12 13:02:29 --> Config Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:02:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:02:29 --> URI Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Router Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Output Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Security Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Input Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:02:29 --> Language Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Language Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Config Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Loader Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:02:29 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:02:29 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:02:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:02:29 --> Session Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:02:29 --> Session routines successfully run
DEBUG - 2015-10-12 13:02:29 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Email Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Controller Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:02:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:02:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 13:02:29 --> DB Transaction Failure
ERROR - 2015-10-12 13:02:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
DEBUG - 2015-10-12 13:02:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-12 13:03:04 --> Config Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:03:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:03:04 --> URI Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Router Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Output Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Security Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Input Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:03:04 --> Language Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Language Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Config Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Loader Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:03:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:03:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:03:04 --> Session Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:03:04 --> Session routines successfully run
DEBUG - 2015-10-12 13:03:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Email Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Controller Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:03:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 13:03:04 --> DB Transaction Failure
ERROR - 2015-10-12 13:03:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
DEBUG - 2015-10-12 13:03:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-12 13:03:11 --> Config Class Initialized
DEBUG - 2015-10-12 13:03:11 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:03:11 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:03:11 --> URI Class Initialized
DEBUG - 2015-10-12 13:03:11 --> Router Class Initialized
ERROR - 2015-10-12 13:03:11 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:03:13 --> Config Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:03:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:03:13 --> URI Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Router Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Output Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Security Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Input Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:03:13 --> Language Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Language Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Config Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Loader Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:03:13 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:03:13 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:03:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:03:13 --> Session Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:03:13 --> Session routines successfully run
DEBUG - 2015-10-12 13:03:13 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Email Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Controller Class Initialized
DEBUG - 2015-10-12 13:03:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:03:13 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:03:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:03:13 --> Final output sent to browser
DEBUG - 2015-10-12 13:03:13 --> Total execution time: 0.1623
DEBUG - 2015-10-12 13:03:14 --> Config Class Initialized
DEBUG - 2015-10-12 13:03:14 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:03:14 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:03:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:03:14 --> URI Class Initialized
DEBUG - 2015-10-12 13:03:14 --> Router Class Initialized
ERROR - 2015-10-12 13:03:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:03:30 --> Config Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:03:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:03:30 --> URI Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Router Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Output Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Security Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Input Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:03:30 --> Language Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Language Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Config Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Loader Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:03:30 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:03:30 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:03:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:03:30 --> Session Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:03:30 --> Session routines successfully run
DEBUG - 2015-10-12 13:03:30 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Email Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Controller Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:03:30 --> Model Class Initialized
DEBUG - 2015-10-12 13:03:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:03:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:03:30 --> Final output sent to browser
DEBUG - 2015-10-12 13:03:30 --> Total execution time: 0.1310
DEBUG - 2015-10-12 13:03:32 --> Config Class Initialized
DEBUG - 2015-10-12 13:03:32 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:03:32 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:03:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:03:32 --> URI Class Initialized
DEBUG - 2015-10-12 13:03:32 --> Router Class Initialized
ERROR - 2015-10-12 13:03:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:11:28 --> Config Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:11:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:11:28 --> URI Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Router Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Output Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Security Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Input Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:11:28 --> Language Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Language Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Config Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Loader Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:11:28 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:11:28 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:11:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:11:28 --> Session Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:11:28 --> Session routines successfully run
DEBUG - 2015-10-12 13:11:28 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Email Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Controller Class Initialized
DEBUG - 2015-10-12 13:11:28 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:11:28 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:11:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:11:41 --> URI Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Router Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Output Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Security Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Input Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:11:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Loader Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:11:41 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:11:41 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:11:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:11:41 --> Session Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:11:41 --> Session routines successfully run
DEBUG - 2015-10-12 13:11:41 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Email Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Controller Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:11:41 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:11:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:11:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:11:41 --> URI Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Router Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Output Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Security Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Input Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:11:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Loader Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:11:41 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:11:41 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:11:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:11:41 --> Session Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:11:41 --> Session routines successfully run
DEBUG - 2015-10-12 13:11:41 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Email Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Controller Class Initialized
DEBUG - 2015-10-12 13:11:41 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:11:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:11:41 --> Model Class Initialized
ERROR - 2015-10-12 13:11:41 --> 404 Page Not Found --> microfinance/edit-group-payment0
DEBUG - 2015-10-12 13:12:47 --> Config Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:12:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:12:47 --> URI Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Router Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Output Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Security Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Input Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:12:47 --> Language Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Language Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Config Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Loader Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:12:47 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:12:47 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:12:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:12:47 --> Session Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:12:47 --> Session routines successfully run
DEBUG - 2015-10-12 13:12:47 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Email Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Controller Class Initialized
DEBUG - 2015-10-12 13:12:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:12:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:12:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:12:47 --> Final output sent to browser
DEBUG - 2015-10-12 13:12:47 --> Total execution time: 0.1287
DEBUG - 2015-10-12 13:12:48 --> Config Class Initialized
DEBUG - 2015-10-12 13:12:48 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:12:48 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:12:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:12:48 --> URI Class Initialized
DEBUG - 2015-10-12 13:12:48 --> Router Class Initialized
ERROR - 2015-10-12 13:12:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:12:55 --> Config Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:12:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:12:55 --> URI Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Router Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Output Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Security Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Input Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:12:55 --> Language Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Language Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Config Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Loader Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:12:55 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:12:55 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:12:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:12:55 --> Session Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:12:55 --> Session routines successfully run
DEBUG - 2015-10-12 13:12:55 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Email Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Controller Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:12:55 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:12:55 --> Config Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:12:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:12:55 --> URI Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Router Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Output Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Security Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Input Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:12:55 --> Language Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Language Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Config Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Loader Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:12:55 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:12:55 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:12:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:12:55 --> Session Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:12:55 --> Session routines successfully run
DEBUG - 2015-10-12 13:12:55 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Email Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Controller Class Initialized
DEBUG - 2015-10-12 13:12:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:12:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:12:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:12:55 --> Final output sent to browser
DEBUG - 2015-10-12 13:12:55 --> Total execution time: 0.1272
DEBUG - 2015-10-12 13:12:56 --> Config Class Initialized
DEBUG - 2015-10-12 13:12:56 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:12:56 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:12:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:12:56 --> URI Class Initialized
DEBUG - 2015-10-12 13:12:56 --> Router Class Initialized
ERROR - 2015-10-12 13:12:56 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:13:42 --> Config Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:13:42 --> URI Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Router Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Output Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Security Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Input Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:13:42 --> Language Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Language Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Config Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Loader Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:13:42 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:13:42 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:13:42 --> Session Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:13:42 --> Session routines successfully run
DEBUG - 2015-10-12 13:13:42 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Email Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Controller Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:13:42 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:13:42 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:13:43 --> Config Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:13:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:13:43 --> URI Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Router Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Output Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Security Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Input Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:13:43 --> Language Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Language Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Config Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Loader Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:13:43 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:13:43 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:13:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:13:43 --> Session Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:13:43 --> Session routines successfully run
DEBUG - 2015-10-12 13:13:43 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Email Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Controller Class Initialized
DEBUG - 2015-10-12 13:13:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:13:43 --> Model Class Initialized
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:13:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:13:43 --> Final output sent to browser
DEBUG - 2015-10-12 13:13:43 --> Total execution time: 0.1281
DEBUG - 2015-10-12 13:13:44 --> Config Class Initialized
DEBUG - 2015-10-12 13:13:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:13:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:13:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:13:44 --> URI Class Initialized
DEBUG - 2015-10-12 13:13:44 --> Router Class Initialized
ERROR - 2015-10-12 13:13:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:14:47 --> Config Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:14:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:14:47 --> URI Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Router Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Output Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Security Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Input Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:14:47 --> Language Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Language Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Config Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Loader Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:14:47 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:14:47 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:14:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:14:47 --> Session Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:14:47 --> Session routines successfully run
DEBUG - 2015-10-12 13:14:47 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Email Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Controller Class Initialized
DEBUG - 2015-10-12 13:14:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:14:47 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:14:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:14:47 --> Final output sent to browser
DEBUG - 2015-10-12 13:14:47 --> Total execution time: 0.1556
DEBUG - 2015-10-12 13:14:48 --> Config Class Initialized
DEBUG - 2015-10-12 13:14:48 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:14:48 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:14:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:14:48 --> URI Class Initialized
DEBUG - 2015-10-12 13:14:48 --> Router Class Initialized
ERROR - 2015-10-12 13:14:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:14:53 --> Config Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:14:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:14:53 --> URI Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Router Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Output Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Security Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Input Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:14:53 --> Language Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Language Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Config Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Loader Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:14:53 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:14:53 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:14:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:14:53 --> Session Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:14:53 --> Session routines successfully run
DEBUG - 2015-10-12 13:14:53 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Email Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Controller Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:14:53 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:14:53 --> Config Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:14:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:14:53 --> URI Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Router Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Output Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Security Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Input Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:14:53 --> Language Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Language Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Config Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Loader Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:14:53 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:14:53 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:14:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:14:53 --> Session Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:14:53 --> Session routines successfully run
DEBUG - 2015-10-12 13:14:53 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Email Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Controller Class Initialized
DEBUG - 2015-10-12 13:14:53 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:14:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:14:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:14:53 --> Final output sent to browser
DEBUG - 2015-10-12 13:14:53 --> Total execution time: 0.1421
DEBUG - 2015-10-12 13:14:54 --> Config Class Initialized
DEBUG - 2015-10-12 13:14:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:14:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:14:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:14:54 --> URI Class Initialized
DEBUG - 2015-10-12 13:14:54 --> Router Class Initialized
ERROR - 2015-10-12 13:14:54 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:16:05 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:16:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:16:05 --> URI Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Router Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Output Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Security Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Input Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:16:05 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Loader Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:16:05 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:16:05 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:16:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:16:05 --> Session Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:16:05 --> Session routines successfully run
DEBUG - 2015-10-12 13:16:05 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Email Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Controller Class Initialized
DEBUG - 2015-10-12 13:16:05 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:16:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:16:05 --> Final output sent to browser
DEBUG - 2015-10-12 13:16:05 --> Total execution time: 0.1446
DEBUG - 2015-10-12 13:16:07 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:07 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:16:07 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:16:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:16:07 --> URI Class Initialized
DEBUG - 2015-10-12 13:16:07 --> Router Class Initialized
ERROR - 2015-10-12 13:16:07 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:16:15 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:16:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:16:15 --> URI Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Router Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Output Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Security Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Input Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:16:15 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Loader Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:16:15 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:16:15 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:16:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:16:15 --> Session Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:16:15 --> Session routines successfully run
DEBUG - 2015-10-12 13:16:15 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Email Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Controller Class Initialized
DEBUG - 2015-10-12 13:16:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:16:15 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:16:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:16:15 --> Final output sent to browser
DEBUG - 2015-10-12 13:16:15 --> Total execution time: 0.1333
DEBUG - 2015-10-12 13:16:16 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:16 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:16:16 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:16:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:16:16 --> URI Class Initialized
DEBUG - 2015-10-12 13:16:16 --> Router Class Initialized
ERROR - 2015-10-12 13:16:16 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:16:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:16:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:16:41 --> URI Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Router Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Output Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Security Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Input Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:16:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Loader Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:16:41 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:16:41 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:16:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:16:41 --> Session Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:16:41 --> Session routines successfully run
DEBUG - 2015-10-12 13:16:41 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Email Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Controller Class Initialized
DEBUG - 2015-10-12 13:16:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:16:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:16:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:16:41 --> Final output sent to browser
DEBUG - 2015-10-12 13:16:41 --> Total execution time: 0.1528
DEBUG - 2015-10-12 13:16:42 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:16:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:16:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:16:42 --> URI Class Initialized
DEBUG - 2015-10-12 13:16:42 --> Router Class Initialized
ERROR - 2015-10-12 13:16:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:16:48 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:16:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:16:48 --> URI Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Router Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Output Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Security Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Input Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:16:48 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Loader Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:16:48 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:16:48 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:16:48 --> Session Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:16:48 --> Session routines successfully run
DEBUG - 2015-10-12 13:16:48 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Email Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Controller Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:16:48 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:16:48 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:16:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:16:48 --> URI Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Router Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Output Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Security Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Input Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:16:48 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Language Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Loader Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:16:48 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:16:48 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:16:48 --> Session Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:16:48 --> Session routines successfully run
DEBUG - 2015-10-12 13:16:48 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Email Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Controller Class Initialized
DEBUG - 2015-10-12 13:16:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:16:48 --> Model Class Initialized
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:16:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:16:48 --> Final output sent to browser
DEBUG - 2015-10-12 13:16:48 --> Total execution time: 0.1379
DEBUG - 2015-10-12 13:16:49 --> Config Class Initialized
DEBUG - 2015-10-12 13:16:49 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:16:49 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:16:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:16:49 --> URI Class Initialized
DEBUG - 2015-10-12 13:16:49 --> Router Class Initialized
ERROR - 2015-10-12 13:16:49 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:17:25 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:17:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:17:25 --> URI Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Router Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Output Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Security Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Input Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:17:25 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Loader Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:17:25 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:17:25 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:17:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:17:25 --> Session Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:17:25 --> Session routines successfully run
DEBUG - 2015-10-12 13:17:25 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Email Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Controller Class Initialized
DEBUG - 2015-10-12 13:17:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:17:25 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:17:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:17:25 --> Final output sent to browser
DEBUG - 2015-10-12 13:17:25 --> Total execution time: 0.1338
DEBUG - 2015-10-12 13:17:26 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:26 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:17:26 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:17:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:17:26 --> URI Class Initialized
DEBUG - 2015-10-12 13:17:26 --> Router Class Initialized
ERROR - 2015-10-12 13:17:26 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:17:29 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:17:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:17:29 --> URI Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Router Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Output Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Security Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Input Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:17:29 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Loader Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:17:29 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:17:29 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:17:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:17:29 --> Session Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:17:29 --> Session routines successfully run
DEBUG - 2015-10-12 13:17:29 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Email Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Controller Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:17:29 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:17:29 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:17:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:17:29 --> URI Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Router Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Output Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Security Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Input Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:17:29 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Loader Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:17:29 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:17:29 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:17:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:17:29 --> Session Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:17:29 --> Session routines successfully run
DEBUG - 2015-10-12 13:17:29 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Email Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Controller Class Initialized
DEBUG - 2015-10-12 13:17:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:17:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:17:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:17:29 --> Final output sent to browser
DEBUG - 2015-10-12 13:17:29 --> Total execution time: 0.1521
DEBUG - 2015-10-12 13:17:30 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:17:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:17:30 --> URI Class Initialized
DEBUG - 2015-10-12 13:17:30 --> Router Class Initialized
ERROR - 2015-10-12 13:17:30 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:17:37 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:17:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:17:37 --> URI Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Router Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Output Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Security Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Input Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:17:37 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Loader Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:17:37 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:17:37 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:17:37 --> Session Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:17:37 --> Session routines successfully run
DEBUG - 2015-10-12 13:17:37 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Email Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Controller Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:17:37 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:17:37 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:17:37 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:17:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:17:37 --> URI Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Router Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Output Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Security Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Input Class Initialized
DEBUG - 2015-10-12 13:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:17:37 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Language Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Loader Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:17:38 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:17:38 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:17:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:17:38 --> Session Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:17:38 --> Session routines successfully run
DEBUG - 2015-10-12 13:17:38 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Email Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Controller Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:17:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:17:38 --> Final output sent to browser
DEBUG - 2015-10-12 13:17:38 --> Total execution time: 0.1275
DEBUG - 2015-10-12 13:17:38 --> Config Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:17:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:17:38 --> URI Class Initialized
DEBUG - 2015-10-12 13:17:38 --> Router Class Initialized
ERROR - 2015-10-12 13:17:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:18:01 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:01 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Router Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Output Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Security Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Input Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:18:01 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Loader Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:18:01 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:18:01 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:18:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:18:01 --> Session Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:18:01 --> Session routines successfully run
DEBUG - 2015-10-12 13:18:01 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Email Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Controller Class Initialized
DEBUG - 2015-10-12 13:18:01 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:18:01 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:18:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:18:01 --> Final output sent to browser
DEBUG - 2015-10-12 13:18:01 --> Total execution time: 0.1482
DEBUG - 2015-10-12 13:18:02 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:02 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:02 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:02 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:02 --> Router Class Initialized
ERROR - 2015-10-12 13:18:02 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:18:04 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:04 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Router Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Output Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Security Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Input Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:18:04 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Loader Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:18:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:18:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:18:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:18:04 --> Session Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:18:04 --> Session routines successfully run
DEBUG - 2015-10-12 13:18:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Email Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Controller Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:18:04 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:18:04 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:04 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Router Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Output Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Security Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Input Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:18:04 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Loader Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:18:04 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:18:04 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:18:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:18:04 --> Session Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:18:04 --> Session routines successfully run
DEBUG - 2015-10-12 13:18:04 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Email Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Controller Class Initialized
DEBUG - 2015-10-12 13:18:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:18:04 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:18:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:18:04 --> Final output sent to browser
DEBUG - 2015-10-12 13:18:04 --> Total execution time: 0.1307
DEBUG - 2015-10-12 13:18:05 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:05 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:05 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:05 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:05 --> Router Class Initialized
ERROR - 2015-10-12 13:18:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:18:51 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:51 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Router Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Output Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Security Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Input Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:18:51 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Loader Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:18:51 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:18:51 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:18:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:18:51 --> Session Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:18:51 --> Session routines successfully run
DEBUG - 2015-10-12 13:18:51 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Email Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Controller Class Initialized
DEBUG - 2015-10-12 13:18:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:18:51 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:18:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:18:51 --> Final output sent to browser
DEBUG - 2015-10-12 13:18:51 --> Total execution time: 0.1316
DEBUG - 2015-10-12 13:18:52 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:52 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:52 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:52 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:52 --> Router Class Initialized
ERROR - 2015-10-12 13:18:52 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:18:55 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:55 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Router Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Output Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Security Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Input Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:18:55 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Loader Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:18:55 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:18:55 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:18:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:18:55 --> Session Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:18:55 --> Session routines successfully run
DEBUG - 2015-10-12 13:18:55 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Email Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Controller Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:18:55 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:18:55 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:55 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Router Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Output Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Security Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Input Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:18:55 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Language Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Loader Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:18:55 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:18:55 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:18:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:18:55 --> Session Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:18:55 --> Session routines successfully run
DEBUG - 2015-10-12 13:18:55 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Email Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Controller Class Initialized
DEBUG - 2015-10-12 13:18:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:18:55 --> Model Class Initialized
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:18:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:18:55 --> Final output sent to browser
DEBUG - 2015-10-12 13:18:55 --> Total execution time: 0.1285
DEBUG - 2015-10-12 13:18:56 --> Config Class Initialized
DEBUG - 2015-10-12 13:18:56 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:18:56 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:18:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:18:56 --> URI Class Initialized
DEBUG - 2015-10-12 13:18:56 --> Router Class Initialized
ERROR - 2015-10-12 13:18:56 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:19:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:19:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:19:41 --> URI Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Router Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Output Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Security Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Input Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:19:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Loader Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:19:41 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:19:41 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:19:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:19:41 --> Session Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:19:41 --> Session routines successfully run
DEBUG - 2015-10-12 13:19:41 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Email Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Controller Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:19:41 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:19:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:19:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:19:41 --> URI Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Router Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Output Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Security Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Input Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:19:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Loader Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:19:41 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:19:41 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:19:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:19:41 --> Session Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:19:41 --> Session routines successfully run
DEBUG - 2015-10-12 13:19:41 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Email Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Controller Class Initialized
DEBUG - 2015-10-12 13:19:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:19:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:19:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:19:41 --> Final output sent to browser
DEBUG - 2015-10-12 13:19:41 --> Total execution time: 0.1226
DEBUG - 2015-10-12 13:19:42 --> Config Class Initialized
DEBUG - 2015-10-12 13:19:42 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:19:42 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:19:42 --> URI Class Initialized
DEBUG - 2015-10-12 13:19:42 --> Router Class Initialized
ERROR - 2015-10-12 13:19:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:19:49 --> Config Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:19:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:19:49 --> URI Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Router Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Output Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Security Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Input Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:19:49 --> Language Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Language Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Config Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Loader Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:19:49 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:19:49 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:19:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:19:49 --> Session Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:19:49 --> Session routines successfully run
DEBUG - 2015-10-12 13:19:49 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Email Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Controller Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:19:49 --> Model Class Initialized
DEBUG - 2015-10-12 13:19:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:19:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:19:49 --> Final output sent to browser
DEBUG - 2015-10-12 13:19:49 --> Total execution time: 0.1329
DEBUG - 2015-10-12 13:19:50 --> Config Class Initialized
DEBUG - 2015-10-12 13:19:50 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:19:50 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:19:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:19:50 --> URI Class Initialized
DEBUG - 2015-10-12 13:19:50 --> Router Class Initialized
ERROR - 2015-10-12 13:19:50 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:21:17 --> Config Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:21:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:21:17 --> URI Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Router Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Output Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Security Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Input Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:21:17 --> Language Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Language Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Config Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Loader Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:21:17 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:21:17 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:21:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:21:17 --> Session Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:21:17 --> Session routines successfully run
DEBUG - 2015-10-12 13:21:17 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Email Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Controller Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:21:17 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:21:17 --> Config Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:21:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:21:17 --> URI Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Router Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Output Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Security Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Input Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:21:17 --> Language Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Language Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Config Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Loader Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:21:17 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:21:17 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:21:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:21:17 --> Session Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:21:17 --> Session routines successfully run
DEBUG - 2015-10-12 13:21:17 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Email Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Controller Class Initialized
DEBUG - 2015-10-12 13:21:17 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:21:17 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:21:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:21:17 --> Final output sent to browser
DEBUG - 2015-10-12 13:21:17 --> Total execution time: 0.1254
DEBUG - 2015-10-12 13:21:18 --> Config Class Initialized
DEBUG - 2015-10-12 13:21:18 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:21:18 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:21:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:21:18 --> URI Class Initialized
DEBUG - 2015-10-12 13:21:18 --> Router Class Initialized
ERROR - 2015-10-12 13:21:18 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:21:50 --> Config Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:21:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:21:50 --> URI Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Router Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Output Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Security Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Input Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:21:50 --> Language Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Language Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Config Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Loader Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:21:50 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:21:50 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:21:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:21:50 --> Session Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:21:50 --> Session routines successfully run
DEBUG - 2015-10-12 13:21:50 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Email Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Controller Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:21:50 --> Model Class Initialized
DEBUG - 2015-10-12 13:21:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-12 13:21:50 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\mfi\application\modules\microfinance\models\payments_model.php 97
DEBUG - 2015-10-12 13:21:50 --> Final output sent to browser
DEBUG - 2015-10-12 13:21:50 --> Total execution time: 0.1175
DEBUG - 2015-10-12 13:22:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:22:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:22:41 --> URI Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Router Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Output Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Security Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Input Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:22:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Language Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Config Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Loader Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:22:41 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:22:41 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:22:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:22:41 --> Session Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:22:41 --> Session routines successfully run
DEBUG - 2015-10-12 13:22:41 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Email Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Controller Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:22:41 --> Model Class Initialized
DEBUG - 2015-10-12 13:22:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 13:22:41 --> Final output sent to browser
DEBUG - 2015-10-12 13:22:41 --> Total execution time: 0.1237
DEBUG - 2015-10-12 13:22:55 --> Config Class Initialized
DEBUG - 2015-10-12 13:22:55 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:22:55 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:22:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:22:55 --> URI Class Initialized
DEBUG - 2015-10-12 13:22:55 --> Router Class Initialized
ERROR - 2015-10-12 13:22:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:23:06 --> Config Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:23:06 --> URI Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Router Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Output Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Security Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Input Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:23:06 --> Language Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Language Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Config Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Loader Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:23:06 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:23:06 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:23:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:23:06 --> Session Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:23:06 --> Session routines successfully run
DEBUG - 2015-10-12 13:23:06 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Email Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Controller Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:23:06 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 13:23:06 --> Final output sent to browser
DEBUG - 2015-10-12 13:23:06 --> Total execution time: 0.1185
DEBUG - 2015-10-12 13:23:14 --> Config Class Initialized
DEBUG - 2015-10-12 13:23:14 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:23:14 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:23:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:23:14 --> URI Class Initialized
DEBUG - 2015-10-12 13:23:14 --> Router Class Initialized
ERROR - 2015-10-12 13:23:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:23:35 --> Config Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:23:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:23:35 --> URI Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Router Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Output Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Security Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Input Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:23:35 --> Language Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Language Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Config Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Loader Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:23:35 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:23:35 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:23:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:23:35 --> Session Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:23:35 --> Session routines successfully run
DEBUG - 2015-10-12 13:23:35 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Email Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Controller Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 13:23:35 --> Config Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:23:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:23:35 --> URI Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Router Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Output Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Security Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Input Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:23:35 --> Language Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Language Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Config Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Loader Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:23:35 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:23:35 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:23:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:23:35 --> Session Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:23:35 --> Session routines successfully run
DEBUG - 2015-10-12 13:23:35 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Email Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Controller Class Initialized
DEBUG - 2015-10-12 13:23:35 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:23:35 --> Model Class Initialized
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/microfinance/views/payments/edit_single_group_payment.php
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:23:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:23:35 --> Final output sent to browser
DEBUG - 2015-10-12 13:23:35 --> Total execution time: 0.1251
DEBUG - 2015-10-12 13:23:36 --> Config Class Initialized
DEBUG - 2015-10-12 13:23:36 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:23:36 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:23:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:23:36 --> URI Class Initialized
DEBUG - 2015-10-12 13:23:36 --> Router Class Initialized
ERROR - 2015-10-12 13:23:36 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:24:19 --> Config Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:24:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:24:19 --> URI Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Router Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Output Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Security Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Input Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:24:19 --> Language Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Language Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Config Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Loader Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:24:19 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:24:19 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:24:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:24:19 --> Session Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:24:19 --> Session routines successfully run
DEBUG - 2015-10-12 13:24:19 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Email Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Controller Class Initialized
DEBUG - 2015-10-12 13:24:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:24:19 --> Model Class Initialized
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:24:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:24:19 --> Final output sent to browser
DEBUG - 2015-10-12 13:24:19 --> Total execution time: 0.1507
DEBUG - 2015-10-12 13:24:20 --> Config Class Initialized
DEBUG - 2015-10-12 13:24:20 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:24:20 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:24:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:24:20 --> URI Class Initialized
DEBUG - 2015-10-12 13:24:20 --> Router Class Initialized
ERROR - 2015-10-12 13:24:20 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:25:29 --> Config Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:25:29 --> URI Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Router Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Output Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Security Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Input Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:25:29 --> Language Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Language Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Config Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Loader Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:25:29 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:25:29 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:25:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:25:29 --> Session Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:25:29 --> Session routines successfully run
DEBUG - 2015-10-12 13:25:29 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Email Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Controller Class Initialized
DEBUG - 2015-10-12 13:25:29 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:25:29 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:25:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:25:29 --> Final output sent to browser
DEBUG - 2015-10-12 13:25:29 --> Total execution time: 0.1252
DEBUG - 2015-10-12 13:25:30 --> Config Class Initialized
DEBUG - 2015-10-12 13:25:30 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:25:30 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:25:30 --> URI Class Initialized
DEBUG - 2015-10-12 13:25:30 --> Router Class Initialized
ERROR - 2015-10-12 13:25:30 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:25:39 --> Config Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:25:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:25:39 --> URI Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Router Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Output Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Security Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Input Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:25:39 --> Language Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Language Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Config Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Loader Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:25:39 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:25:39 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:25:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:25:39 --> Session Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:25:39 --> Session routines successfully run
DEBUG - 2015-10-12 13:25:39 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Email Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Controller Class Initialized
DEBUG - 2015-10-12 13:25:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:25:39 --> Model Class Initialized
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:25:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:25:39 --> Final output sent to browser
DEBUG - 2015-10-12 13:25:39 --> Total execution time: 0.1456
DEBUG - 2015-10-12 13:25:40 --> Config Class Initialized
DEBUG - 2015-10-12 13:25:40 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:25:40 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:25:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:25:40 --> URI Class Initialized
DEBUG - 2015-10-12 13:25:40 --> Router Class Initialized
ERROR - 2015-10-12 13:25:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:26:44 --> Config Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:26:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:26:44 --> URI Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Router Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Output Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Security Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Input Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:26:44 --> Language Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Language Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Config Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Loader Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:26:44 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:26:44 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:26:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:26:44 --> Session Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:26:44 --> Session routines successfully run
DEBUG - 2015-10-12 13:26:44 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Email Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Controller Class Initialized
DEBUG - 2015-10-12 13:26:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:26:44 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:26:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:26:44 --> Final output sent to browser
DEBUG - 2015-10-12 13:26:44 --> Total execution time: 0.1354
DEBUG - 2015-10-12 13:26:45 --> Config Class Initialized
DEBUG - 2015-10-12 13:26:45 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:26:45 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:26:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:26:45 --> URI Class Initialized
DEBUG - 2015-10-12 13:26:45 --> Router Class Initialized
ERROR - 2015-10-12 13:26:45 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:26:53 --> Config Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:26:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:26:53 --> URI Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Router Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Output Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Security Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Input Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:26:53 --> Language Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Language Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Config Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Loader Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:26:53 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:26:53 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:26:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:26:53 --> Session Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:26:53 --> Session routines successfully run
DEBUG - 2015-10-12 13:26:53 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Email Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Controller Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:26:53 --> Model Class Initialized
DEBUG - 2015-10-12 13:26:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/microfinance/views/payments/show_group_payment.php
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:26:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:26:53 --> Final output sent to browser
DEBUG - 2015-10-12 13:26:53 --> Total execution time: 0.1254
DEBUG - 2015-10-12 13:26:54 --> Config Class Initialized
DEBUG - 2015-10-12 13:26:54 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:26:54 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:26:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:26:54 --> URI Class Initialized
DEBUG - 2015-10-12 13:26:54 --> Router Class Initialized
ERROR - 2015-10-12 13:26:54 --> 404 Page Not Found --> 
DEBUG - 2015-10-12 13:27:11 --> Config Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:27:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:27:11 --> URI Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Router Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Output Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Security Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Input Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-12 13:27:11 --> Language Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Language Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Config Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Loader Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Helper loaded: url_helper
DEBUG - 2015-10-12 13:27:11 --> Helper loaded: form_helper
DEBUG - 2015-10-12 13:27:11 --> Database Driver Class Initialized
ERROR - 2015-10-12 13:27:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-12 13:27:11 --> Session Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Helper loaded: string_helper
DEBUG - 2015-10-12 13:27:11 --> Session routines successfully run
DEBUG - 2015-10-12 13:27:11 --> Form Validation Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Pagination Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Encrypt Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Email Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Controller Class Initialized
DEBUG - 2015-10-12 13:27:11 --> Payments MX_Controller Initialized
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-12 13:27:11 --> Model Class Initialized
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-12 13:27:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-12 13:27:11 --> Final output sent to browser
DEBUG - 2015-10-12 13:27:11 --> Total execution time: 0.1288
DEBUG - 2015-10-12 13:27:12 --> Config Class Initialized
DEBUG - 2015-10-12 13:27:12 --> Hooks Class Initialized
DEBUG - 2015-10-12 13:27:12 --> Utf8 Class Initialized
DEBUG - 2015-10-12 13:27:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-12 13:27:12 --> URI Class Initialized
DEBUG - 2015-10-12 13:27:12 --> Router Class Initialized
ERROR - 2015-10-12 13:27:12 --> 404 Page Not Found --> 
