<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-22 19:55:04 --> Config Class Initialized
DEBUG - 2015-12-22 19:55:04 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:55:04 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:55:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:55:04 --> URI Class Initialized
DEBUG - 2015-12-22 19:55:05 --> Router Class Initialized
DEBUG - 2015-12-22 19:55:05 --> No URI present. Default controller set.
DEBUG - 2015-12-22 19:55:06 --> Output Class Initialized
DEBUG - 2015-12-22 19:55:06 --> Security Class Initialized
DEBUG - 2015-12-22 19:55:06 --> Input Class Initialized
DEBUG - 2015-12-22 19:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:55:06 --> Language Class Initialized
DEBUG - 2015-12-22 19:55:07 --> Language Class Initialized
DEBUG - 2015-12-22 19:55:07 --> Config Class Initialized
DEBUG - 2015-12-22 19:55:07 --> Loader Class Initialized
DEBUG - 2015-12-22 19:55:08 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:55:08 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:55:10 --> Database Driver Class Initialized
ERROR - 2015-12-22 19:55:12 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'localhost' (10061) C:\xampp\htdocs\rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 19:55:12 --> Unable to connect to the database
DEBUG - 2015-12-22 19:55:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-22 19:55:16 --> Config Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:55:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:55:16 --> URI Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Router Class Initialized
DEBUG - 2015-12-22 19:55:16 --> No URI present. Default controller set.
DEBUG - 2015-12-22 19:55:16 --> Output Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Security Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Input Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:55:16 --> Language Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Language Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Config Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Loader Class Initialized
DEBUG - 2015-12-22 19:55:16 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:55:16 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:55:16 --> Database Driver Class Initialized
ERROR - 2015-12-22 19:55:17 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'localhost' (10061) C:\xampp\htdocs\rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 19:55:17 --> Unable to connect to the database
DEBUG - 2015-12-22 19:55:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-22 19:55:20 --> Config Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:55:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:55:20 --> URI Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Router Class Initialized
DEBUG - 2015-12-22 19:55:20 --> No URI present. Default controller set.
DEBUG - 2015-12-22 19:55:20 --> Output Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Security Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Input Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:55:20 --> Language Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Language Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Config Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Loader Class Initialized
DEBUG - 2015-12-22 19:55:20 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:55:20 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:55:20 --> Database Driver Class Initialized
ERROR - 2015-12-22 19:55:21 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'localhost' (10061) C:\xampp\htdocs\rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 19:55:21 --> Unable to connect to the database
DEBUG - 2015-12-22 19:55:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-22 19:56:25 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:25 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:56:25 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:56:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:56:25 --> URI Class Initialized
DEBUG - 2015-12-22 19:56:25 --> Router Class Initialized
DEBUG - 2015-12-22 19:56:25 --> No URI present. Default controller set.
DEBUG - 2015-12-22 19:56:25 --> Output Class Initialized
DEBUG - 2015-12-22 19:56:26 --> Security Class Initialized
DEBUG - 2015-12-22 19:56:26 --> Input Class Initialized
DEBUG - 2015-12-22 19:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:56:26 --> Language Class Initialized
DEBUG - 2015-12-22 19:56:26 --> Language Class Initialized
DEBUG - 2015-12-22 19:56:26 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:26 --> Loader Class Initialized
DEBUG - 2015-12-22 19:56:26 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:56:26 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:56:26 --> Database Driver Class Initialized
DEBUG - 2015-12-22 19:56:30 --> Session Class Initialized
DEBUG - 2015-12-22 19:56:30 --> Helper loaded: string_helper
DEBUG - 2015-12-22 19:56:30 --> A session cookie was not found.
DEBUG - 2015-12-22 19:56:30 --> Session routines successfully run
DEBUG - 2015-12-22 19:56:30 --> Form Validation Class Initialized
DEBUG - 2015-12-22 19:56:30 --> Pagination Class Initialized
DEBUG - 2015-12-22 19:56:31 --> Encrypt Class Initialized
DEBUG - 2015-12-22 19:56:31 --> Email Class Initialized
DEBUG - 2015-12-22 19:56:31 --> Controller Class Initialized
DEBUG - 2015-12-22 19:56:31 --> Auth MX_Controller Initialized
DEBUG - 2015-12-22 19:56:31 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 19:56:31 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 19:56:32 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:56:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:56:32 --> URI Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Router Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Output Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Security Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Input Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:56:32 --> Language Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Language Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Loader Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:56:32 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:56:32 --> Database Driver Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Session Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Helper loaded: string_helper
DEBUG - 2015-12-22 19:56:32 --> Session routines successfully run
DEBUG - 2015-12-22 19:56:32 --> Form Validation Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Pagination Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Encrypt Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Email Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Controller Class Initialized
DEBUG - 2015-12-22 19:56:32 --> Auth MX_Controller Initialized
DEBUG - 2015-12-22 19:56:32 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 19:56:32 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 19:56:32 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 19:56:34 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-22 19:56:34 --> Final output sent to browser
DEBUG - 2015-12-22 19:56:34 --> Total execution time: 1.8881
DEBUG - 2015-12-22 19:56:51 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:56:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:56:51 --> URI Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Router Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:56:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:56:51 --> URI Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Router Class Initialized
ERROR - 2015-12-22 19:56:51 --> 404 Page Not Found --> 
ERROR - 2015-12-22 19:56:51 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 19:56:51 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:56:51 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:56:51 --> URI Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:56:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:56:51 --> URI Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Router Class Initialized
DEBUG - 2015-12-22 19:56:51 --> Router Class Initialized
ERROR - 2015-12-22 19:56:51 --> 404 Page Not Found --> 
ERROR - 2015-12-22 19:56:51 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 19:56:58 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:56:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:56:58 --> URI Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Router Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Output Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Security Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Input Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:56:58 --> Language Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Language Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Loader Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:56:58 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:56:58 --> Database Driver Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Session Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Helper loaded: string_helper
DEBUG - 2015-12-22 19:56:58 --> Session routines successfully run
DEBUG - 2015-12-22 19:56:58 --> Form Validation Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Pagination Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Encrypt Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Email Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Controller Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Auth MX_Controller Initialized
DEBUG - 2015-12-22 19:56:58 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 19:56:58 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 19:56:58 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 19:56:58 --> XSS Filtering completed
DEBUG - 2015-12-22 19:56:58 --> Unable to find validation rule: exists
DEBUG - 2015-12-22 19:56:58 --> XSS Filtering completed
DEBUG - 2015-12-22 19:56:58 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:56:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:56:58 --> URI Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Router Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Output Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Security Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Input Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:56:58 --> Language Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Language Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Config Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Loader Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:56:58 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:56:58 --> Database Driver Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Session Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Helper loaded: string_helper
DEBUG - 2015-12-22 19:56:58 --> Session routines successfully run
DEBUG - 2015-12-22 19:56:58 --> Form Validation Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Pagination Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Encrypt Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Email Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Controller Class Initialized
DEBUG - 2015-12-22 19:56:58 --> Admin MX_Controller Initialized
DEBUG - 2015-12-22 19:56:58 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 19:56:58 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 19:56:58 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 19:56:58 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 19:56:59 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 19:56:59 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 19:56:59 --> Model Class Initialized
DEBUG - 2015-12-22 19:56:59 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-22 19:56:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 19:56:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 19:56:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 19:56:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 19:56:59 --> Final output sent to browser
DEBUG - 2015-12-22 19:56:59 --> Total execution time: 1.3880
DEBUG - 2015-12-22 19:57:19 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:57:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:57:19 --> URI Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Router Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Output Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Security Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Input Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:57:19 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Loader Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:57:19 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:57:19 --> Database Driver Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Session Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Helper loaded: string_helper
DEBUG - 2015-12-22 19:57:19 --> Session routines successfully run
DEBUG - 2015-12-22 19:57:19 --> Form Validation Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Pagination Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Encrypt Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Email Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Controller Class Initialized
DEBUG - 2015-12-22 19:57:19 --> Sections MX_Controller Initialized
DEBUG - 2015-12-22 19:57:19 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 19:57:19 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 19:57:19 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 19:57:19 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 19:57:19 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 19:57:19 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 19:57:19 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 19:57:19 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:21 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-22 19:57:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 19:57:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 19:57:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 19:57:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 19:57:21 --> Final output sent to browser
DEBUG - 2015-12-22 19:57:21 --> Total execution time: 1.9235
DEBUG - 2015-12-22 19:57:23 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:57:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:57:23 --> URI Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Router Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:57:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:57:23 --> Output Class Initialized
DEBUG - 2015-12-22 19:57:23 --> URI Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Security Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Input Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Router Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:57:23 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Output Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Security Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Input Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:57:23 --> Loader Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:57:23 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:57:23 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Loader Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Database Driver Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:57:23 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:57:23 --> Session Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Helper loaded: string_helper
DEBUG - 2015-12-22 19:57:23 --> Session routines successfully run
DEBUG - 2015-12-22 19:57:23 --> Database Driver Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Form Validation Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Pagination Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Encrypt Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Session Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Helper loaded: string_helper
DEBUG - 2015-12-22 19:57:23 --> Session routines successfully run
DEBUG - 2015-12-22 19:57:23 --> Email Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Controller Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Sections MX_Controller Initialized
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Form Validation Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Pagination Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Encrypt Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Email Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Controller Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 19:57:23 --> Sections MX_Controller Initialized
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 19:57:23 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 19:57:24 --> Final output sent to browser
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 19:57:24 --> Total execution time: 0.3373
DEBUG - 2015-12-22 19:57:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 19:57:24 --> Final output sent to browser
DEBUG - 2015-12-22 19:57:24 --> Total execution time: 0.3156
DEBUG - 2015-12-22 19:57:55 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:57:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:57:55 --> URI Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Router Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Output Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Security Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Input Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:57:55 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Loader Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:57:55 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:57:55 --> Database Driver Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Session Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Helper loaded: string_helper
DEBUG - 2015-12-22 19:57:55 --> Session routines successfully run
DEBUG - 2015-12-22 19:57:55 --> Form Validation Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Pagination Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Encrypt Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Email Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Controller Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Sections MX_Controller Initialized
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 19:57:55 --> XSS Filtering completed
DEBUG - 2015-12-22 19:57:55 --> XSS Filtering completed
DEBUG - 2015-12-22 19:57:55 --> XSS Filtering completed
DEBUG - 2015-12-22 19:57:55 --> XSS Filtering completed
DEBUG - 2015-12-22 19:57:55 --> XSS Filtering completed
DEBUG - 2015-12-22 19:57:55 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:57:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:57:55 --> URI Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Router Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Output Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Security Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Input Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:57:55 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Language Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Config Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Loader Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Helper loaded: url_helper
DEBUG - 2015-12-22 19:57:55 --> Helper loaded: form_helper
DEBUG - 2015-12-22 19:57:55 --> Database Driver Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Session Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Helper loaded: string_helper
DEBUG - 2015-12-22 19:57:55 --> Session routines successfully run
DEBUG - 2015-12-22 19:57:55 --> Form Validation Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Pagination Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Encrypt Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Email Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Controller Class Initialized
DEBUG - 2015-12-22 19:57:55 --> Sections MX_Controller Initialized
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 19:57:55 --> Model Class Initialized
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 19:57:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 19:57:55 --> Final output sent to browser
DEBUG - 2015-12-22 19:57:55 --> Total execution time: 0.2134
DEBUG - 2015-12-22 19:58:18 --> Config Class Initialized
DEBUG - 2015-12-22 19:58:18 --> Hooks Class Initialized
DEBUG - 2015-12-22 19:58:18 --> Utf8 Class Initialized
DEBUG - 2015-12-22 19:58:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 19:58:18 --> URI Class Initialized
DEBUG - 2015-12-22 19:58:18 --> Router Class Initialized
DEBUG - 2015-12-22 19:58:19 --> Output Class Initialized
DEBUG - 2015-12-22 19:58:19 --> Security Class Initialized
DEBUG - 2015-12-22 19:58:19 --> Input Class Initialized
DEBUG - 2015-12-22 19:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 19:58:19 --> Language Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Config Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:01:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:01:54 --> URI Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Router Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Output Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Security Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Input Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:01:54 --> Language Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Language Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Config Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Loader Class Initialized
DEBUG - 2015-12-22 20:01:54 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:01:54 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:01:55 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:01:55 --> Session Class Initialized
DEBUG - 2015-12-22 20:01:55 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:01:55 --> Session routines successfully run
DEBUG - 2015-12-22 20:01:55 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:01:55 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:01:55 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:01:55 --> Email Class Initialized
DEBUG - 2015-12-22 20:01:55 --> Controller Class Initialized
DEBUG - 2015-12-22 20:01:55 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:01:55 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:01:55 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:01:55 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:01:55 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:01:55 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:01:55 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:01:55 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:01:55 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:01:55 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:55 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:01:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:01:55 --> Final output sent to browser
DEBUG - 2015-12-22 20:01:55 --> Total execution time: 1.4201
DEBUG - 2015-12-22 20:01:58 --> Config Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:01:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:01:58 --> URI Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Router Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Output Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Security Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Input Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:01:58 --> Language Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Language Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Config Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Loader Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:01:58 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:01:58 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Session Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:01:58 --> Session routines successfully run
DEBUG - 2015-12-22 20:01:58 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Email Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Controller Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:01:58 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:01:58 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:01:58 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:01:58 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:01:58 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:01:58 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:01:58 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:01:58 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:01:58 --> Model Class Initialized
DEBUG - 2015-12-22 20:01:58 --> Image Lib Class Initialized
ERROR - 2015-12-22 20:01:58 --> Severity: Notice  --> Undefined property: CI::$property_owners C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2015-12-22 20:02:16 --> Config Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:02:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:02:16 --> URI Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Router Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Output Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Security Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Input Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:02:16 --> Language Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Language Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Config Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Loader Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:02:16 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:02:16 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Session Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:02:16 --> Session routines successfully run
DEBUG - 2015-12-22 20:02:16 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Email Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Controller Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:02:16 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:02:16 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:02:16 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:02:16 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:02:16 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:02:16 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:02:16 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:02:16 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:02:16 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:16 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:02:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:02:16 --> Final output sent to browser
DEBUG - 2015-12-22 20:02:16 --> Total execution time: 0.2400
DEBUG - 2015-12-22 20:02:18 --> Config Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:02:18 --> URI Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Router Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Output Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Security Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Input Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:02:18 --> Language Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Language Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Config Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Loader Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:02:18 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:02:18 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Session Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:02:18 --> Session routines successfully run
DEBUG - 2015-12-22 20:02:18 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Email Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Controller Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:02:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:02:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:02:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:02:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:02:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:02:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:02:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:02:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:02:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:18 --> Image Lib Class Initialized
ERROR - 2015-12-22 20:02:18 --> Severity: Notice  --> Undefined property: CI::$property_owners_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2015-12-22 20:02:53 --> Config Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:02:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:02:53 --> URI Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Router Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Output Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Security Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Input Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:02:53 --> Language Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Language Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Config Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Loader Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:02:53 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:02:53 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Session Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:02:53 --> Session routines successfully run
DEBUG - 2015-12-22 20:02:53 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Email Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Controller Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:02:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:02:53 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:02:53 --> DB Transaction Failure
ERROR - 2015-12-22 20:02:53 --> Query error: Unknown column 'property_owner_level_id' in 'where clause'
DEBUG - 2015-12-22 20:02:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-22 20:03:18 --> Config Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:03:18 --> URI Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Router Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Output Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Security Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Input Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:03:18 --> Language Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Language Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Config Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Loader Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:03:18 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:03:18 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Session Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:03:18 --> Session routines successfully run
DEBUG - 2015-12-22 20:03:18 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Email Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Controller Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:03:18 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:18 --> Image Lib Class Initialized
ERROR - 2015-12-22 20:03:19 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\add_property.php 8
DEBUG - 2015-12-22 20:03:19 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2015-12-22 20:03:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:03:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:03:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:03:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:03:19 --> Final output sent to browser
DEBUG - 2015-12-22 20:03:19 --> Total execution time: 0.3426
DEBUG - 2015-12-22 20:03:50 --> Config Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:03:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:03:50 --> URI Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Router Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Output Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Security Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Input Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:03:50 --> Language Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Language Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Config Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Loader Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:03:50 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:03:50 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Session Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:03:50 --> Session routines successfully run
DEBUG - 2015-12-22 20:03:50 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Email Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Controller Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:03:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:50 --> Image Lib Class Initialized
ERROR - 2015-12-22 20:03:50 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\add_property.php 8
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:03:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:03:50 --> Final output sent to browser
DEBUG - 2015-12-22 20:03:50 --> Total execution time: 0.3153
DEBUG - 2015-12-22 20:03:52 --> Config Class Initialized
DEBUG - 2015-12-22 20:03:52 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:03:52 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:03:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:03:52 --> URI Class Initialized
DEBUG - 2015-12-22 20:03:52 --> Router Class Initialized
DEBUG - 2015-12-22 20:03:52 --> Output Class Initialized
DEBUG - 2015-12-22 20:03:52 --> Security Class Initialized
DEBUG - 2015-12-22 20:03:52 --> Input Class Initialized
DEBUG - 2015-12-22 20:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:03:52 --> Language Class Initialized
DEBUG - 2015-12-22 20:03:52 --> Language Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Config Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Loader Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:03:53 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:03:53 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Session Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:03:53 --> Session routines successfully run
DEBUG - 2015-12-22 20:03:53 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Email Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Controller Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:03:53 --> Model Class Initialized
DEBUG - 2015-12-22 20:03:53 --> Image Lib Class Initialized
ERROR - 2015-12-22 20:03:53 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\add_property.php 8
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:03:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:03:53 --> Final output sent to browser
DEBUG - 2015-12-22 20:03:53 --> Total execution time: 0.2781
DEBUG - 2015-12-22 20:04:05 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:04:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:04:05 --> URI Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Router Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Output Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Security Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Input Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:04:05 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Loader Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:04:05 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:04:05 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Session Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:04:05 --> Session routines successfully run
DEBUG - 2015-12-22 20:04:05 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Email Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Controller Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:04:05 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:05 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:04:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:04:05 --> Final output sent to browser
DEBUG - 2015-12-22 20:04:05 --> Total execution time: 0.2484
DEBUG - 2015-12-22 20:04:30 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:04:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:04:30 --> URI Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Router Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Output Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Security Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Input Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:04:30 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Loader Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:04:30 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:04:30 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Session Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:04:30 --> Session routines successfully run
DEBUG - 2015-12-22 20:04:30 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Email Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Controller Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 20:04:30 --> XSS Filtering completed
DEBUG - 2015-12-22 20:04:30 --> XSS Filtering completed
DEBUG - 2015-12-22 20:04:30 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:04:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:04:30 --> URI Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Router Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Output Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Security Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Input Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:04:30 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Loader Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:04:30 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:04:30 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Session Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:04:30 --> Session routines successfully run
DEBUG - 2015-12-22 20:04:30 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Email Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Controller Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:04:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:30 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:04:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:04:30 --> Final output sent to browser
DEBUG - 2015-12-22 20:04:30 --> Total execution time: 0.2293
DEBUG - 2015-12-22 20:04:37 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:37 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:04:37 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:04:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:04:37 --> URI Class Initialized
DEBUG - 2015-12-22 20:04:37 --> Router Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Output Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Security Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Input Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:04:38 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Loader Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:04:38 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:04:38 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Session Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:04:38 --> Session routines successfully run
DEBUG - 2015-12-22 20:04:38 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Email Class Initialized
DEBUG - 2015-12-22 20:04:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:04:38 --> Controller Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:04:38 --> URI Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Router Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Output Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Security Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Input Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:04:38 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:04:38 --> Loader Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:04:38 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:04:38 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Session Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2015-12-22 20:04:38 --> Session routines successfully run
DEBUG - 2015-12-22 20:04:38 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:04:38 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:04:38 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:04:38 --> Final output sent to browser
DEBUG - 2015-12-22 20:04:38 --> Email Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Total execution time: 0.3704
DEBUG - 2015-12-22 20:04:38 --> Controller Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:04:38 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:38 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:04:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:04:38 --> Final output sent to browser
DEBUG - 2015-12-22 20:04:38 --> Total execution time: 0.2783
DEBUG - 2015-12-22 20:04:41 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:04:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:04:41 --> URI Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Router Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Output Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Security Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Input Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:04:41 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Loader Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:04:41 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:04:41 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Session Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:04:41 --> Session routines successfully run
DEBUG - 2015-12-22 20:04:41 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Email Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Controller Class Initialized
DEBUG - 2015-12-22 20:04:41 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-22 20:04:41 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:04:41 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:04:41 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:04:41 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:04:41 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:04:41 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:04:41 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:04:41 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:04:41 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:42 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-22 20:04:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:04:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:04:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:04:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:04:42 --> Final output sent to browser
DEBUG - 2015-12-22 20:04:42 --> Total execution time: 0.4117
DEBUG - 2015-12-22 20:04:47 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:04:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:04:47 --> URI Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Router Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Output Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Security Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Input Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:04:47 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Language Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Config Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Loader Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:04:47 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:04:47 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Session Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:04:47 --> Session routines successfully run
DEBUG - 2015-12-22 20:04:47 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Email Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Controller Class Initialized
DEBUG - 2015-12-22 20:04:47 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-22 20:04:47 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:04:47 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:04:47 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:04:47 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:04:47 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:04:47 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:04:47 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:04:47 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:04:47 --> Model Class Initialized
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:04:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:04:47 --> Final output sent to browser
DEBUG - 2015-12-22 20:04:47 --> Total execution time: 0.2346
DEBUG - 2015-12-22 20:05:25 --> Config Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:05:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:05:25 --> URI Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Router Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Output Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Security Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Input Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:05:25 --> Language Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Language Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Config Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Loader Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:05:25 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:05:25 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Session Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:05:25 --> Session routines successfully run
DEBUG - 2015-12-22 20:05:25 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Email Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Controller Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:05:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:25 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:05:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:05:25 --> Final output sent to browser
DEBUG - 2015-12-22 20:05:25 --> Total execution time: 0.2398
DEBUG - 2015-12-22 20:05:49 --> Config Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:05:49 --> URI Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Router Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Output Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Security Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Input Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:05:49 --> Language Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Language Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Config Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Loader Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:05:49 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:05:49 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Session Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:05:49 --> Session routines successfully run
DEBUG - 2015-12-22 20:05:49 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Email Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Controller Class Initialized
DEBUG - 2015-12-22 20:05:49 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:05:49 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:05:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:05:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:05:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:05:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:05:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:05:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:05:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:05:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:05:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:05:50 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:05:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:05:50 --> Final output sent to browser
DEBUG - 2015-12-22 20:05:50 --> Total execution time: 0.2502
DEBUG - 2015-12-22 20:07:07 --> Config Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:07:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:07:07 --> URI Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Router Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Output Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Security Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Input Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:07:07 --> Language Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Language Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Config Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Loader Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:07:07 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:07:07 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Session Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:07:07 --> Session routines successfully run
DEBUG - 2015-12-22 20:07:07 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Email Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Controller Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:07:07 --> Model Class Initialized
DEBUG - 2015-12-22 20:07:07 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:07:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:07:07 --> Final output sent to browser
DEBUG - 2015-12-22 20:07:07 --> Total execution time: 0.2412
DEBUG - 2015-12-22 20:20:08 --> Config Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:20:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:20:08 --> URI Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Router Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Output Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Security Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Input Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:20:08 --> Language Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Language Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Config Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Loader Class Initialized
DEBUG - 2015-12-22 20:20:08 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:20:08 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:20:08 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:20:09 --> Session Class Initialized
DEBUG - 2015-12-22 20:20:09 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:20:09 --> Session routines successfully run
DEBUG - 2015-12-22 20:20:09 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:20:09 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:20:09 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:20:09 --> Email Class Initialized
DEBUG - 2015-12-22 20:20:09 --> Controller Class Initialized
DEBUG - 2015-12-22 20:20:09 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 20:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:20:09 --> Image Lib Class Initialized
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:20:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:20:09 --> Final output sent to browser
DEBUG - 2015-12-22 20:20:09 --> Total execution time: 0.3413
DEBUG - 2015-12-22 20:21:08 --> Config Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:21:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:21:08 --> URI Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Router Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Output Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Security Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Input Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:21:08 --> Language Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Language Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Config Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Loader Class Initialized
DEBUG - 2015-12-22 20:21:08 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:21:08 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:21:08 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:21:09 --> Session Class Initialized
DEBUG - 2015-12-22 20:21:09 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:21:09 --> Session routines successfully run
DEBUG - 2015-12-22 20:21:09 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:21:09 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:21:09 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:21:09 --> Email Class Initialized
DEBUG - 2015-12-22 20:21:09 --> Controller Class Initialized
DEBUG - 2015-12-22 20:21:09 --> Sections MX_Controller Initialized
DEBUG - 2015-12-22 20:21:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:21:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:21:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:21:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:21:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:21:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:21:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:21:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:21:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:21:09 --> Final output sent to browser
DEBUG - 2015-12-22 20:21:09 --> Total execution time: 0.2658
DEBUG - 2015-12-22 20:21:11 --> Config Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:21:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:21:11 --> URI Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Router Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Output Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Security Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Input Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:21:11 --> Language Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Language Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Config Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Loader Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:21:11 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:21:11 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Session Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:21:11 --> Session routines successfully run
DEBUG - 2015-12-22 20:21:11 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Email Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Controller Class Initialized
DEBUG - 2015-12-22 20:21:11 --> Sections MX_Controller Initialized
DEBUG - 2015-12-22 20:21:11 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:21:11 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:21:11 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:21:11 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:21:11 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:21:11 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:21:11 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:21:11 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:21:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:21:11 --> Final output sent to browser
DEBUG - 2015-12-22 20:21:11 --> Total execution time: 0.2206
DEBUG - 2015-12-22 20:21:59 --> Config Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:21:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:21:59 --> URI Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Router Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Output Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Security Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Input Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:21:59 --> Language Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Language Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Config Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Loader Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:21:59 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:21:59 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Session Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:21:59 --> Session routines successfully run
DEBUG - 2015-12-22 20:21:59 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Email Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Controller Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Sections MX_Controller Initialized
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 20:21:59 --> XSS Filtering completed
DEBUG - 2015-12-22 20:21:59 --> XSS Filtering completed
DEBUG - 2015-12-22 20:21:59 --> XSS Filtering completed
DEBUG - 2015-12-22 20:21:59 --> XSS Filtering completed
DEBUG - 2015-12-22 20:21:59 --> XSS Filtering completed
DEBUG - 2015-12-22 20:21:59 --> Config Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:21:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:21:59 --> URI Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Router Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Output Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Security Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Input Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:21:59 --> Language Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Language Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Config Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Loader Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:21:59 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:21:59 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Session Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:21:59 --> Session routines successfully run
DEBUG - 2015-12-22 20:21:59 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Email Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Controller Class Initialized
DEBUG - 2015-12-22 20:21:59 --> Sections MX_Controller Initialized
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:21:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:21:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:21:59 --> Final output sent to browser
DEBUG - 2015-12-22 20:21:59 --> Total execution time: 0.2785
DEBUG - 2015-12-22 20:45:50 --> Config Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:45:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:45:50 --> URI Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Router Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Output Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Security Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Input Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:45:50 --> Language Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Language Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Config Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Loader Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:45:50 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:45:50 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Session Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:45:50 --> Session routines successfully run
DEBUG - 2015-12-22 20:45:50 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Email Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Controller Class Initialized
DEBUG - 2015-12-22 20:45:50 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-22 20:45:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-22 20:45:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:45:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:45:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:45:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:45:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:45:50 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/messaging/views/sms/sent_messages.php
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:45:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:45:50 --> Final output sent to browser
DEBUG - 2015-12-22 20:45:50 --> Total execution time: 0.4772
DEBUG - 2015-12-22 20:45:53 --> Config Class Initialized
DEBUG - 2015-12-22 20:45:53 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:45:53 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:45:53 --> URI Class Initialized
DEBUG - 2015-12-22 20:45:53 --> Router Class Initialized
ERROR - 2015-12-22 20:45:53 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 20:45:59 --> Config Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:45:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:45:59 --> URI Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Router Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Output Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Security Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Input Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:45:59 --> Language Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Language Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Config Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Loader Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:45:59 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:45:59 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Session Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:45:59 --> Session routines successfully run
DEBUG - 2015-12-22 20:45:59 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Email Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Controller Class Initialized
DEBUG - 2015-12-22 20:45:59 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-22 20:45:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-22 20:45:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:45:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:45:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:45:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:45:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:45:59 --> Model Class Initialized
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:45:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:45:59 --> Final output sent to browser
DEBUG - 2015-12-22 20:45:59 --> Total execution time: 0.2324
DEBUG - 2015-12-22 20:49:26 --> Config Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:49:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:49:26 --> URI Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Router Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Output Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Security Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Input Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:49:26 --> Language Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Language Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Config Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Loader Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:49:26 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:49:26 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Session Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:49:26 --> Session routines successfully run
DEBUG - 2015-12-22 20:49:26 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Email Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Controller Class Initialized
DEBUG - 2015-12-22 20:49:26 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-22 20:49:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-22 20:49:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:49:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:49:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:49:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:49:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:49:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:49:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:49:26 --> Final output sent to browser
DEBUG - 2015-12-22 20:49:26 --> Total execution time: 0.2526
DEBUG - 2015-12-22 20:49:30 --> Config Class Initialized
DEBUG - 2015-12-22 20:49:30 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:49:30 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:49:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:49:30 --> URI Class Initialized
DEBUG - 2015-12-22 20:49:30 --> Router Class Initialized
ERROR - 2015-12-22 20:49:30 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 20:50:01 --> Config Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:50:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:50:01 --> URI Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Router Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Output Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Security Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Input Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:50:01 --> Language Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Language Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Config Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Loader Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:50:01 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:50:01 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Session Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:50:01 --> Session routines successfully run
DEBUG - 2015-12-22 20:50:01 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Email Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Controller Class Initialized
DEBUG - 2015-12-22 20:50:01 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-22 20:50:01 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-22 20:50:01 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:50:01 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:50:01 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:50:01 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:50:01 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:50:01 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:50:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:50:01 --> Final output sent to browser
DEBUG - 2015-12-22 20:50:01 --> Total execution time: 0.2434
DEBUG - 2015-12-22 20:50:06 --> Config Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:50:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:50:06 --> URI Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Router Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Output Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Security Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Input Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:50:06 --> Language Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Language Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Config Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Loader Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:50:06 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:50:06 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Session Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:50:06 --> Session routines successfully run
DEBUG - 2015-12-22 20:50:06 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Email Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Controller Class Initialized
DEBUG - 2015-12-22 20:50:06 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:50:06 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:06 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:50:30 --> Config Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:50:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:50:30 --> URI Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Router Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Output Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Security Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Input Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:50:30 --> Language Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Language Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Config Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Loader Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:50:30 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:50:30 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Session Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:50:30 --> Session routines successfully run
DEBUG - 2015-12-22 20:50:30 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Email Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Controller Class Initialized
DEBUG - 2015-12-22 20:50:30 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:50:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:30 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:50:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:50:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:50:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:50:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:50:30 --> Model Class Initialized
DEBUG - 2015-12-22 20:50:30 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:50:30 --> Model Class Initialized
ERROR - 2015-12-22 20:50:30 --> Severity: Notice  --> Undefined property: CI::$messaging_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2015-12-22 20:51:08 --> Config Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:51:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:51:08 --> URI Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Router Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Output Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Security Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Input Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:51:08 --> Language Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Language Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Config Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Loader Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:51:08 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:51:08 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Session Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:51:08 --> Session routines successfully run
DEBUG - 2015-12-22 20:51:08 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Email Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Controller Class Initialized
DEBUG - 2015-12-22 20:51:08 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:51:08 --> Model Class Initialized
DEBUG - 2015-12-22 20:51:08 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:51:08 --> Model Class Initialized
DEBUG - 2015-12-22 20:51:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:51:08 --> Model Class Initialized
DEBUG - 2015-12-22 20:51:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:51:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:51:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:51:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:51:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:51:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:51:09 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:51:09 --> Model Class Initialized
ERROR - 2015-12-22 20:51:09 --> Severity: Notice  --> Undefined property: CI::$water_management C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2015-12-22 20:52:46 --> Config Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:52:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:52:46 --> URI Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Router Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Output Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Security Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Input Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:52:46 --> Language Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Language Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Config Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Loader Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:52:46 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:52:46 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Session Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:52:46 --> Session routines successfully run
DEBUG - 2015-12-22 20:52:46 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Email Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Controller Class Initialized
DEBUG - 2015-12-22 20:52:46 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:52:46 --> Model Class Initialized
DEBUG - 2015-12-22 20:52:46 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:52:46 --> Model Class Initialized
DEBUG - 2015-12-22 20:52:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:52:46 --> Model Class Initialized
DEBUG - 2015-12-22 20:52:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:52:46 --> Model Class Initialized
DEBUG - 2015-12-22 20:52:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:52:46 --> Model Class Initialized
DEBUG - 2015-12-22 20:52:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:52:46 --> Model Class Initialized
DEBUG - 2015-12-22 20:52:46 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:52:46 --> Model Class Initialized
ERROR - 2015-12-22 20:52:46 --> Severity: Notice  --> Undefined property: CI::$water_management C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2015-12-22 20:53:12 --> Config Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:53:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:53:12 --> URI Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Router Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Output Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Security Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Input Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:53:12 --> Language Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Language Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Config Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Loader Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:53:12 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:53:12 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Session Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:53:12 --> Session routines successfully run
DEBUG - 2015-12-22 20:53:12 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Email Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Controller Class Initialized
DEBUG - 2015-12-22 20:53:12 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:53:12 --> Model Class Initialized
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:53:12 --> Model Class Initialized
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:53:12 --> Model Class Initialized
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:53:12 --> Model Class Initialized
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:53:12 --> Model Class Initialized
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:53:12 --> Model Class Initialized
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:53:12 --> Model Class Initialized
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:53:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:53:12 --> Final output sent to browser
DEBUG - 2015-12-22 20:53:12 --> Total execution time: 0.2604
DEBUG - 2015-12-22 20:54:57 --> Config Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:54:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:54:57 --> URI Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Router Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Output Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Security Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Input Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:54:57 --> Language Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Language Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Config Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Loader Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:54:57 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:54:57 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Session Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:54:57 --> Session routines successfully run
DEBUG - 2015-12-22 20:54:57 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Email Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Controller Class Initialized
DEBUG - 2015-12-22 20:54:57 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:54:57 --> Model Class Initialized
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:54:57 --> Model Class Initialized
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:54:57 --> Model Class Initialized
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:54:57 --> Model Class Initialized
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:54:57 --> Model Class Initialized
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:54:57 --> Model Class Initialized
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:54:57 --> Model Class Initialized
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:54:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:54:57 --> Final output sent to browser
DEBUG - 2015-12-22 20:54:57 --> Total execution time: 0.2160
DEBUG - 2015-12-22 20:55:25 --> Config Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:55:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:55:25 --> URI Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Router Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Output Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Security Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Input Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:55:25 --> Language Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Language Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Config Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Loader Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:55:25 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:55:25 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Session Class Initialized
DEBUG - 2015-12-22 20:55:25 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:55:25 --> Session routines successfully run
DEBUG - 2015-12-22 20:55:26 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:55:26 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:55:26 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:55:26 --> Email Class Initialized
DEBUG - 2015-12-22 20:55:26 --> Controller Class Initialized
DEBUG - 2015-12-22 20:55:26 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:55:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:55:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:55:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:55:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:55:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:55:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:55:26 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:55:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:55:26 --> Final output sent to browser
DEBUG - 2015-12-22 20:55:26 --> Total execution time: 0.2408
DEBUG - 2015-12-22 20:55:52 --> Config Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:55:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:55:52 --> URI Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Router Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Output Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Security Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Input Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:55:52 --> Language Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Language Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Config Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Loader Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:55:52 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:55:52 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Session Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:55:52 --> Session routines successfully run
DEBUG - 2015-12-22 20:55:52 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Email Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Controller Class Initialized
DEBUG - 2015-12-22 20:55:52 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:55:52 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:55:52 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:55:52 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:55:52 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:55:52 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:55:52 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:55:52 --> Model Class Initialized
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:55:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:55:52 --> Final output sent to browser
DEBUG - 2015-12-22 20:55:52 --> Total execution time: 0.2248
DEBUG - 2015-12-22 20:56:24 --> Config Class Initialized
DEBUG - 2015-12-22 20:56:24 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:56:24 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:56:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:56:24 --> URI Class Initialized
DEBUG - 2015-12-22 20:56:24 --> Router Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Output Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Security Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Input Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:56:25 --> Language Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Language Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Config Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Loader Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:56:25 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:56:25 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Session Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:56:25 --> Session routines successfully run
DEBUG - 2015-12-22 20:56:25 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Email Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Controller Class Initialized
DEBUG - 2015-12-22 20:56:25 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:56:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:56:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:56:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:56:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:56:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:56:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:56:25 --> Model Class Initialized
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:56:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:56:25 --> Final output sent to browser
DEBUG - 2015-12-22 20:56:25 --> Total execution time: 0.3511
DEBUG - 2015-12-22 20:57:09 --> Config Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:57:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:57:09 --> URI Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Router Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Output Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Security Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Input Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:57:09 --> Language Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Language Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Config Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Loader Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:57:09 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:57:09 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Session Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:57:09 --> Session routines successfully run
DEBUG - 2015-12-22 20:57:09 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Email Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Controller Class Initialized
DEBUG - 2015-12-22 20:57:09 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:57:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:57:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:57:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:57:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:57:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:57:09 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:57:09 --> Model Class Initialized
ERROR - 2015-12-22 20:57:09 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\water_management\views\water_records.php 154
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:57:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:57:09 --> Final output sent to browser
DEBUG - 2015-12-22 20:57:09 --> Total execution time: 0.3088
DEBUG - 2015-12-22 20:57:20 --> Config Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:57:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:57:20 --> URI Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Router Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Output Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Security Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Input Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:57:20 --> Language Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Language Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Config Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Loader Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:57:20 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:57:20 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Session Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:57:20 --> Session routines successfully run
DEBUG - 2015-12-22 20:57:20 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Email Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Controller Class Initialized
DEBUG - 2015-12-22 20:57:20 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:57:20 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:57:20 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:57:20 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:57:20 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:57:20 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:57:20 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:57:20 --> Model Class Initialized
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:57:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:57:20 --> Final output sent to browser
DEBUG - 2015-12-22 20:57:20 --> Total execution time: 0.2011
DEBUG - 2015-12-22 20:58:37 --> Config Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:58:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:58:37 --> URI Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Router Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Output Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Security Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Input Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:58:37 --> Language Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Language Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Config Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Loader Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:58:37 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:58:37 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Session Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:58:37 --> Session routines successfully run
DEBUG - 2015-12-22 20:58:37 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Email Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Controller Class Initialized
DEBUG - 2015-12-22 20:58:37 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:58:37 --> Model Class Initialized
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:58:37 --> Model Class Initialized
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:58:37 --> Model Class Initialized
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:58:37 --> Model Class Initialized
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:58:37 --> Model Class Initialized
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:58:37 --> Model Class Initialized
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:58:37 --> Model Class Initialized
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:58:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:58:37 --> Final output sent to browser
DEBUG - 2015-12-22 20:58:37 --> Total execution time: 0.2120
DEBUG - 2015-12-22 20:59:00 --> Config Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:59:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:59:00 --> URI Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Router Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Output Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Security Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Input Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:59:00 --> Language Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Language Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Config Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Loader Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:59:00 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:59:00 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Session Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:59:00 --> Session routines successfully run
DEBUG - 2015-12-22 20:59:00 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Email Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Controller Class Initialized
DEBUG - 2015-12-22 20:59:00 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:59:00 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:59:00 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:59:00 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:59:00 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:59:00 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:59:00 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:59:00 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:59:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:59:00 --> Final output sent to browser
DEBUG - 2015-12-22 20:59:00 --> Total execution time: 0.2535
DEBUG - 2015-12-22 20:59:33 --> Config Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Hooks Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Utf8 Class Initialized
DEBUG - 2015-12-22 20:59:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 20:59:34 --> URI Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Router Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Output Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Security Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Input Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 20:59:34 --> Language Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Language Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Config Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Loader Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Helper loaded: url_helper
DEBUG - 2015-12-22 20:59:34 --> Helper loaded: form_helper
DEBUG - 2015-12-22 20:59:34 --> Database Driver Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Session Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Helper loaded: string_helper
DEBUG - 2015-12-22 20:59:34 --> Session routines successfully run
DEBUG - 2015-12-22 20:59:34 --> Form Validation Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Pagination Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Encrypt Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Email Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Controller Class Initialized
DEBUG - 2015-12-22 20:59:34 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 20:59:34 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 20:59:34 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 20:59:34 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 20:59:34 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 20:59:34 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 20:59:34 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 20:59:34 --> Model Class Initialized
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 20:59:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 20:59:34 --> Final output sent to browser
DEBUG - 2015-12-22 20:59:34 --> Total execution time: 0.2174
DEBUG - 2015-12-22 21:00:00 --> Config Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:00:00 --> URI Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Router Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Output Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Security Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Input Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:00:00 --> Language Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Language Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Config Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Loader Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:00:00 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:00:00 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Session Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:00:00 --> Session routines successfully run
DEBUG - 2015-12-22 21:00:00 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Email Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Controller Class Initialized
DEBUG - 2015-12-22 21:00:00 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:00:00 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:00:00 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:00:00 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:00:00 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:00:00 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:00:00 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:00:00 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:00:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:00:00 --> Final output sent to browser
DEBUG - 2015-12-22 21:00:00 --> Total execution time: 0.2318
DEBUG - 2015-12-22 21:00:55 --> Config Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:00:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:00:55 --> URI Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Router Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Output Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Security Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Input Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:00:55 --> Language Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Language Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Config Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Loader Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:00:55 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:00:55 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Session Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:00:55 --> Session routines successfully run
DEBUG - 2015-12-22 21:00:55 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Email Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Controller Class Initialized
DEBUG - 2015-12-22 21:00:55 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:00:55 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:55 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:00:55 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:00:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:00:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:00:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:00:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:56 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:00:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:00:56 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:00:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:00:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:00:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:00:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:00:56 --> Final output sent to browser
DEBUG - 2015-12-22 21:00:56 --> Total execution time: 0.2208
DEBUG - 2015-12-22 21:23:21 --> Config Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:23:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:23:22 --> URI Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Router Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Output Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Security Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Input Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:23:22 --> Language Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Language Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Config Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Loader Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:23:22 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:23:22 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Session Class Initialized
DEBUG - 2015-12-22 21:23:22 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:23:22 --> Session routines successfully run
DEBUG - 2015-12-22 21:23:23 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:23:23 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:23:23 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:23:23 --> Email Class Initialized
DEBUG - 2015-12-22 21:23:23 --> Controller Class Initialized
DEBUG - 2015-12-22 21:23:23 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:23:23 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:23:23 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:23:23 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:23:23 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:23:23 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:23:23 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:23:23 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:23:23 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:23:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:23:23 --> Final output sent to browser
DEBUG - 2015-12-22 21:23:23 --> Total execution time: 1.8059
DEBUG - 2015-12-22 21:23:54 --> Config Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:23:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:23:54 --> URI Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Router Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Output Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Security Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Input Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:23:54 --> Language Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Language Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Config Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Loader Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:23:54 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:23:54 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Session Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:23:54 --> Session routines successfully run
DEBUG - 2015-12-22 21:23:54 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Email Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Controller Class Initialized
DEBUG - 2015-12-22 21:23:54 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:23:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:23:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:23:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:23:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:23:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:23:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:23:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:23:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:23:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:23:54 --> Final output sent to browser
DEBUG - 2015-12-22 21:23:54 --> Total execution time: 0.2487
DEBUG - 2015-12-22 21:27:14 --> Config Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:27:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:27:14 --> URI Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Router Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Output Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Security Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Input Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:27:14 --> Language Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Language Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Config Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Loader Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:27:14 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:27:14 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Session Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:27:14 --> Session routines successfully run
DEBUG - 2015-12-22 21:27:14 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Email Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Controller Class Initialized
DEBUG - 2015-12-22 21:27:14 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:27:14 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:27:14 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:27:14 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:27:14 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:27:14 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:27:14 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:27:14 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:27:14 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:27:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:27:14 --> Final output sent to browser
DEBUG - 2015-12-22 21:27:14 --> Total execution time: 0.2448
DEBUG - 2015-12-22 21:27:26 --> Config Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:27:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:27:26 --> URI Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Router Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Output Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Security Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Input Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:27:26 --> Language Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Language Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Config Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Loader Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:27:26 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:27:26 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Session Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:27:26 --> Session routines successfully run
DEBUG - 2015-12-22 21:27:26 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Email Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Controller Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-22 21:27:26 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:26 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-22 21:27:26 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:27:26 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:27:26 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:27:26 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:27:26 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:27:26 --> Model Class Initialized
DEBUG - 2015-12-22 21:27:26 --> Final output sent to browser
DEBUG - 2015-12-22 21:27:26 --> Total execution time: 0.2854
DEBUG - 2015-12-22 21:28:36 --> Config Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:28:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:28:36 --> URI Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Router Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Output Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Security Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Input Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:28:36 --> Language Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Language Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Config Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Loader Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:28:36 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:28:36 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Session Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:28:36 --> Session routines successfully run
DEBUG - 2015-12-22 21:28:36 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Email Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Controller Class Initialized
DEBUG - 2015-12-22 21:28:36 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:28:36 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:28:36 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:28:36 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:28:36 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:28:36 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:28:36 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:28:36 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:28:36 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:28:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:28:36 --> Final output sent to browser
DEBUG - 2015-12-22 21:28:36 --> Total execution time: 0.2265
DEBUG - 2015-12-22 21:28:39 --> Config Class Initialized
DEBUG - 2015-12-22 21:28:39 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:28:39 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:28:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:28:39 --> URI Class Initialized
DEBUG - 2015-12-22 21:28:39 --> Router Class Initialized
DEBUG - 2015-12-22 21:28:39 --> Output Class Initialized
DEBUG - 2015-12-22 21:28:39 --> Security Class Initialized
DEBUG - 2015-12-22 21:28:39 --> Input Class Initialized
DEBUG - 2015-12-22 21:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:28:39 --> Language Class Initialized
DEBUG - 2015-12-22 21:28:39 --> Language Class Initialized
DEBUG - 2015-12-22 21:28:39 --> Config Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Loader Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:28:40 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:28:40 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Session Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:28:40 --> Session routines successfully run
DEBUG - 2015-12-22 21:28:40 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Email Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Controller Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:28:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:40 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:28:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:28:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:28:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:28:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:28:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:28:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:40 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:28:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:28:40 --> Final output sent to browser
DEBUG - 2015-12-22 21:28:40 --> Total execution time: 0.2238
DEBUG - 2015-12-22 21:30:43 --> Config Class Initialized
DEBUG - 2015-12-22 21:30:43 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:30:43 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:30:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:30:43 --> URI Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Router Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Output Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Security Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Input Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:30:44 --> Language Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Language Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Config Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Loader Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:30:44 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:30:44 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Session Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:30:44 --> Session routines successfully run
DEBUG - 2015-12-22 21:30:44 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Email Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Controller Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Upload Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Config Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:30:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:30:44 --> URI Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Router Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Output Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Security Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Input Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:30:44 --> Language Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Language Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Config Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Loader Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:30:44 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:30:44 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Session Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:30:44 --> Session routines successfully run
DEBUG - 2015-12-22 21:30:44 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Email Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Controller Class Initialized
DEBUG - 2015-12-22 21:30:44 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:30:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:30:44 --> Final output sent to browser
DEBUG - 2015-12-22 21:30:44 --> Total execution time: 0.2901
DEBUG - 2015-12-22 21:30:54 --> Config Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:30:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:30:54 --> URI Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Router Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Output Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Security Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Input Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:30:54 --> Language Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Language Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Config Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Loader Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:30:54 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:30:54 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Session Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:30:54 --> Session routines successfully run
DEBUG - 2015-12-22 21:30:54 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Email Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Controller Class Initialized
DEBUG - 2015-12-22 21:30:54 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:30:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:30:54 --> Final output sent to browser
DEBUG - 2015-12-22 21:30:54 --> Total execution time: 0.2290
DEBUG - 2015-12-22 21:31:46 --> Config Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:31:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:31:46 --> URI Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Router Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Output Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Security Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Input Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:31:46 --> Language Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Language Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Config Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Loader Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:31:46 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:31:46 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Session Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:31:46 --> Session routines successfully run
DEBUG - 2015-12-22 21:31:46 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:31:46 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:31:47 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:31:47 --> Email Class Initialized
DEBUG - 2015-12-22 21:31:47 --> Controller Class Initialized
DEBUG - 2015-12-22 21:31:47 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:31:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:31:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:31:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:31:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:31:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:31:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:31:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:31:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:31:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:31:47 --> Final output sent to browser
DEBUG - 2015-12-22 21:31:47 --> Total execution time: 0.2294
DEBUG - 2015-12-22 21:31:52 --> Config Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:31:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:31:52 --> URI Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Router Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Output Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Security Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Input Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:31:52 --> Language Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Language Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Config Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Loader Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:31:52 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:31:52 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Session Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:31:52 --> Session routines successfully run
DEBUG - 2015-12-22 21:31:52 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Email Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Controller Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Upload Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Config Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:31:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:31:52 --> URI Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Router Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Output Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Security Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Input Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:31:52 --> Language Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Language Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Config Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Loader Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:31:52 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:31:52 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Session Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:31:52 --> Session routines successfully run
DEBUG - 2015-12-22 21:31:52 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Email Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Controller Class Initialized
DEBUG - 2015-12-22 21:31:52 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:31:52 --> Model Class Initialized
ERROR - 2015-12-22 21:31:52 --> Severity: Notice  --> Undefined property: stdClass::$sent_status C:\xampp\htdocs\rents\application\modules\water_management\views\water_records.php 34
ERROR - 2015-12-22 21:31:52 --> Severity: Notice  --> Undefined variable: document_number C:\xampp\htdocs\rents\application\modules\water_management\views\water_records.php 41
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:31:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:31:52 --> Final output sent to browser
DEBUG - 2015-12-22 21:31:52 --> Total execution time: 0.2790
DEBUG - 2015-12-22 21:33:29 --> Config Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:33:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:33:29 --> URI Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Router Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Output Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Security Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Input Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:33:29 --> Language Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Language Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Config Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Loader Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:33:29 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:33:29 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Session Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:33:29 --> Session routines successfully run
DEBUG - 2015-12-22 21:33:29 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Email Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Controller Class Initialized
DEBUG - 2015-12-22 21:33:29 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:33:29 --> Model Class Initialized
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:33:29 --> Model Class Initialized
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:33:29 --> Model Class Initialized
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:33:29 --> Model Class Initialized
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:33:29 --> Model Class Initialized
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:33:29 --> Model Class Initialized
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:33:29 --> Model Class Initialized
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:33:29 --> Model Class Initialized
ERROR - 2015-12-22 21:33:29 --> Severity: Notice  --> Undefined property: stdClass::$sent_status C:\xampp\htdocs\rents\application\modules\water_management\views\water_records.php 35
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:33:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:33:29 --> Final output sent to browser
DEBUG - 2015-12-22 21:33:29 --> Total execution time: 0.2858
DEBUG - 2015-12-22 21:34:20 --> Config Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:34:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:34:20 --> URI Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Router Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Output Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Security Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Input Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:34:20 --> Language Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Language Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Config Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Loader Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:34:20 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:34:20 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Session Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:34:20 --> Session routines successfully run
DEBUG - 2015-12-22 21:34:20 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Email Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Controller Class Initialized
DEBUG - 2015-12-22 21:34:20 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:34:20 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:34:20 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:34:20 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:34:20 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:34:20 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:34:20 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:34:20 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:34:20 --> Model Class Initialized
ERROR - 2015-12-22 21:34:20 --> Severity: Notice  --> Undefined property: stdClass::$sent_status C:\xampp\htdocs\rents\application\modules\water_management\views\water_records.php 35
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:34:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:34:20 --> Final output sent to browser
DEBUG - 2015-12-22 21:34:20 --> Total execution time: 0.2131
DEBUG - 2015-12-22 21:34:37 --> Config Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:34:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:34:37 --> URI Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Router Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Output Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Security Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Input Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:34:37 --> Language Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Language Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Config Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Loader Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:34:37 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:34:37 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Session Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:34:37 --> Session routines successfully run
DEBUG - 2015-12-22 21:34:37 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Email Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Controller Class Initialized
DEBUG - 2015-12-22 21:34:37 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:34:37 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:34:37 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:34:37 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:34:37 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:34:37 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:34:37 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:34:37 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:34:37 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:34:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:34:37 --> Final output sent to browser
DEBUG - 2015-12-22 21:34:37 --> Total execution time: 0.2066
DEBUG - 2015-12-22 21:34:55 --> Config Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:34:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:34:55 --> URI Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Router Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Output Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Security Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Input Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:34:55 --> Language Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Language Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Config Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Loader Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:34:55 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:34:55 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Session Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:34:55 --> Session routines successfully run
DEBUG - 2015-12-22 21:34:55 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:34:55 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:34:56 --> Email Class Initialized
DEBUG - 2015-12-22 21:34:56 --> Controller Class Initialized
DEBUG - 2015-12-22 21:34:56 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:34:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:34:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:34:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:34:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:34:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:34:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:34:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:34:56 --> Model Class Initialized
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:34:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:34:56 --> Final output sent to browser
DEBUG - 2015-12-22 21:34:56 --> Total execution time: 0.2499
DEBUG - 2015-12-22 21:35:17 --> Config Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:35:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:35:17 --> URI Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Router Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Output Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Security Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Input Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:35:17 --> Language Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Language Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Config Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Loader Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:35:17 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:35:17 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Session Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:35:17 --> Session routines successfully run
DEBUG - 2015-12-22 21:35:17 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Email Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Controller Class Initialized
DEBUG - 2015-12-22 21:35:17 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:35:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:35:17 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:35:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:35:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:35:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:35:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:35:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:35:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:35:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:35:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:35:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:35:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:35:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:35:17 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:35:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:35:18 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:35:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:35:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:35:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:35:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:35:18 --> Final output sent to browser
DEBUG - 2015-12-22 21:35:18 --> Total execution time: 0.2380
DEBUG - 2015-12-22 21:45:38 --> Config Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:45:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:45:38 --> URI Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Router Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Output Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Security Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Input Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:45:38 --> Language Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Language Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Config Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Loader Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:45:38 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:45:38 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Session Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:45:38 --> Session routines successfully run
DEBUG - 2015-12-22 21:45:38 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Email Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Controller Class Initialized
DEBUG - 2015-12-22 21:45:38 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:45:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:45:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:45:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:45:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:45:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:45:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:45:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:45:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:45:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:45:39 --> Final output sent to browser
DEBUG - 2015-12-22 21:45:39 --> Total execution time: 0.2349
DEBUG - 2015-12-22 21:45:42 --> Config Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:45:42 --> URI Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Router Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Output Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Security Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Input Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:45:42 --> Language Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Language Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Config Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Loader Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:45:42 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:45:42 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Session Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:45:42 --> Session routines successfully run
DEBUG - 2015-12-22 21:45:42 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Email Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Controller Class Initialized
DEBUG - 2015-12-22 21:45:42 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:45:42 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:42 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:45:42 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:45:42 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:45:42 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:45:42 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:45:42 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:45:42 --> Model Class Initialized
DEBUG - 2015-12-22 21:45:42 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:45:42 --> Model Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Config Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:46:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:46:38 --> URI Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Router Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Output Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Security Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Input Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:46:38 --> Language Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Language Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Config Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Loader Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:46:38 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:46:38 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Session Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:46:38 --> Session routines successfully run
DEBUG - 2015-12-22 21:46:38 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Email Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Controller Class Initialized
DEBUG - 2015-12-22 21:46:38 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:46:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:46:38 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:46:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:46:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:46:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:46:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:46:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:46:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:46:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:46:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:46:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:46:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:46:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:46:38 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:46:38 --> Model Class Initialized
DEBUG - 2015-12-22 21:46:39 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:46:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:46:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:46:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:46:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:46:39 --> Final output sent to browser
DEBUG - 2015-12-22 21:46:39 --> Total execution time: 0.2176
DEBUG - 2015-12-22 21:46:41 --> Config Class Initialized
DEBUG - 2015-12-22 21:46:41 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:46:41 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:46:41 --> URI Class Initialized
DEBUG - 2015-12-22 21:46:41 --> Router Class Initialized
ERROR - 2015-12-22 21:46:41 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 21:47:29 --> Config Class Initialized
DEBUG - 2015-12-22 21:47:29 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:47:29 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:47:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:47:29 --> URI Class Initialized
DEBUG - 2015-12-22 21:47:29 --> Router Class Initialized
ERROR - 2015-12-22 21:47:29 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 21:47:31 --> Config Class Initialized
DEBUG - 2015-12-22 21:47:31 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:47:31 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:47:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:47:31 --> URI Class Initialized
DEBUG - 2015-12-22 21:47:31 --> Router Class Initialized
ERROR - 2015-12-22 21:47:31 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 21:47:59 --> Config Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:47:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:47:59 --> URI Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Router Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Output Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Security Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Input Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:47:59 --> Language Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Language Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Config Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Loader Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:47:59 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:47:59 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Session Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:47:59 --> Session routines successfully run
DEBUG - 2015-12-22 21:47:59 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Email Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Controller Class Initialized
DEBUG - 2015-12-22 21:47:59 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:47:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:47:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:47:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:47:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:47:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:47:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:47:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:47:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 21:47:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 21:47:59 --> Final output sent to browser
DEBUG - 2015-12-22 21:47:59 --> Total execution time: 0.2121
DEBUG - 2015-12-22 21:48:02 --> Config Class Initialized
DEBUG - 2015-12-22 21:48:02 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:48:02 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:48:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:48:02 --> URI Class Initialized
DEBUG - 2015-12-22 21:48:02 --> Router Class Initialized
ERROR - 2015-12-22 21:48:02 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 21:48:31 --> Config Class Initialized
DEBUG - 2015-12-22 21:48:31 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:48:31 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:48:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:48:31 --> URI Class Initialized
DEBUG - 2015-12-22 21:48:31 --> Router Class Initialized
ERROR - 2015-12-22 21:48:31 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 21:48:45 --> Config Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:48:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:48:45 --> URI Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Router Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Output Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Security Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Input Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:48:45 --> Language Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Language Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Config Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Loader Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:48:45 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:48:45 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Session Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:48:45 --> Session routines successfully run
DEBUG - 2015-12-22 21:48:45 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Email Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Controller Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:48:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:45 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:48:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:48:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:48:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:48:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:48:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:48:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:45 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:48:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:45 --> Final output sent to browser
DEBUG - 2015-12-22 21:48:45 --> Total execution time: 0.1814
DEBUG - 2015-12-22 21:48:46 --> Config Class Initialized
DEBUG - 2015-12-22 21:48:46 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:48:46 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:48:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:48:46 --> URI Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Router Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Output Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Security Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Input Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:48:47 --> Language Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Language Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Config Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Loader Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:48:47 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:48:47 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Session Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:48:47 --> Session routines successfully run
DEBUG - 2015-12-22 21:48:47 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Email Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Controller Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:48:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:47 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:48:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:48:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:48:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:48:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:48:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:48:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:48:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:47 --> Final output sent to browser
DEBUG - 2015-12-22 21:48:47 --> Total execution time: 0.2017
DEBUG - 2015-12-22 21:48:55 --> Config Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:48:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:48:55 --> URI Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Router Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Output Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Security Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Input Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:48:55 --> Language Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Language Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Config Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Loader Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:48:55 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:48:55 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Session Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:48:55 --> Session routines successfully run
DEBUG - 2015-12-22 21:48:55 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Email Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Controller Class Initialized
DEBUG - 2015-12-22 21:48:55 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:48:55 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:55 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:48:55 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:48:55 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:48:55 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:48:55 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:48:55 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:48:55 --> Model Class Initialized
DEBUG - 2015-12-22 21:48:55 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:48:55 --> Model Class Initialized
ERROR - 2015-12-22 21:48:55 --> Severity: Notice  --> Undefined variable: served_by C:\xampp\htdocs\rents\application\modules\water_management\views\reading_reports.php 86
DEBUG - 2015-12-22 21:48:55 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:48:55 --> Final output sent to browser
DEBUG - 2015-12-22 21:48:55 --> Total execution time: 0.2396
DEBUG - 2015-12-22 21:52:28 --> Config Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:52:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:52:28 --> URI Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Router Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Output Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Security Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Input Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:52:28 --> Language Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Language Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Config Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Loader Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:52:28 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:52:28 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Session Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:52:28 --> Session routines successfully run
DEBUG - 2015-12-22 21:52:28 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Email Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Controller Class Initialized
DEBUG - 2015-12-22 21:52:28 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:52:28 --> Model Class Initialized
DEBUG - 2015-12-22 21:52:28 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:52:28 --> Model Class Initialized
DEBUG - 2015-12-22 21:52:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:52:28 --> Model Class Initialized
DEBUG - 2015-12-22 21:52:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:52:28 --> Model Class Initialized
DEBUG - 2015-12-22 21:52:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:52:28 --> Model Class Initialized
DEBUG - 2015-12-22 21:52:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:52:28 --> Model Class Initialized
DEBUG - 2015-12-22 21:52:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:52:28 --> Model Class Initialized
DEBUG - 2015-12-22 21:52:28 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:52:28 --> Model Class Initialized
DEBUG - 2015-12-22 21:52:28 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:52:28 --> Final output sent to browser
DEBUG - 2015-12-22 21:52:28 --> Total execution time: 0.1873
DEBUG - 2015-12-22 21:54:40 --> Config Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:54:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:54:40 --> URI Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Router Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Output Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Security Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Input Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:54:40 --> Language Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Language Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Config Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Loader Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:54:40 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:54:40 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Session Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:54:40 --> Session routines successfully run
DEBUG - 2015-12-22 21:54:40 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Email Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Controller Class Initialized
DEBUG - 2015-12-22 21:54:40 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:54:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:54:40 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:54:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:54:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:54:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:54:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:54:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:54:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:54:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:54:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:54:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:54:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:54:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:54:40 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:54:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:54:40 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:54:40 --> Final output sent to browser
DEBUG - 2015-12-22 21:54:40 --> Total execution time: 0.1986
DEBUG - 2015-12-22 21:55:40 --> Config Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:55:40 --> URI Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Router Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Output Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Security Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Input Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:55:40 --> Language Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Language Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Config Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Loader Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:55:40 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:55:40 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Session Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:55:40 --> Session routines successfully run
DEBUG - 2015-12-22 21:55:40 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Email Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Controller Class Initialized
DEBUG - 2015-12-22 21:55:40 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:55:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:40 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:55:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:55:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:55:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:55:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:55:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:55:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:40 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:55:40 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:40 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:55:40 --> Final output sent to browser
DEBUG - 2015-12-22 21:55:40 --> Total execution time: 0.2010
DEBUG - 2015-12-22 21:55:57 --> Config Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:55:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:55:57 --> URI Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Router Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Output Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Security Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Input Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:55:57 --> Language Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Language Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Config Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Loader Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:55:57 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:55:57 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Session Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:55:57 --> Session routines successfully run
DEBUG - 2015-12-22 21:55:57 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Email Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Controller Class Initialized
DEBUG - 2015-12-22 21:55:57 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:55:57 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:57 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:55:57 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:55:57 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:55:57 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:55:57 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:55:57 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:55:57 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:57 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:55:57 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:57 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:55:57 --> Final output sent to browser
DEBUG - 2015-12-22 21:55:57 --> Total execution time: 0.1931
DEBUG - 2015-12-22 21:55:58 --> Config Class Initialized
DEBUG - 2015-12-22 21:55:58 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:55:58 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:55:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:55:58 --> URI Class Initialized
DEBUG - 2015-12-22 21:55:58 --> Router Class Initialized
DEBUG - 2015-12-22 21:55:58 --> Output Class Initialized
DEBUG - 2015-12-22 21:55:58 --> Security Class Initialized
DEBUG - 2015-12-22 21:55:58 --> Input Class Initialized
DEBUG - 2015-12-22 21:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:55:58 --> Language Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Language Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Config Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Loader Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:55:59 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:55:59 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Session Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:55:59 --> Session routines successfully run
DEBUG - 2015-12-22 21:55:59 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Email Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Controller Class Initialized
DEBUG - 2015-12-22 21:55:59 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:55:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:59 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:55:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:55:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:55:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:55:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:55:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:55:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:59 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:55:59 --> Model Class Initialized
DEBUG - 2015-12-22 21:55:59 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:55:59 --> Final output sent to browser
DEBUG - 2015-12-22 21:55:59 --> Total execution time: 0.1827
DEBUG - 2015-12-22 21:56:05 --> Config Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:56:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:56:05 --> URI Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Router Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Output Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Security Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Input Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:56:05 --> Language Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Language Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Config Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Loader Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:56:05 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:56:05 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Session Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:56:05 --> Session routines successfully run
DEBUG - 2015-12-22 21:56:05 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Email Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Controller Class Initialized
DEBUG - 2015-12-22 21:56:05 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:56:05 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:05 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:56:05 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:56:05 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:56:05 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:56:05 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:56:05 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:56:05 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:56:05 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:05 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:56:05 --> Final output sent to browser
DEBUG - 2015-12-22 21:56:05 --> Total execution time: 0.2042
DEBUG - 2015-12-22 21:56:19 --> Config Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:56:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:56:19 --> URI Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Router Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Output Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Security Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Input Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:56:19 --> Language Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Language Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Config Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Loader Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:56:19 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:56:19 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Session Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:56:19 --> Session routines successfully run
DEBUG - 2015-12-22 21:56:19 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Email Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Controller Class Initialized
DEBUG - 2015-12-22 21:56:19 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:56:19 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:19 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:56:19 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:56:19 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:56:19 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:56:19 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:56:19 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:56:19 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:19 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:56:19 --> Model Class Initialized
DEBUG - 2015-12-22 21:56:19 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:56:19 --> Final output sent to browser
DEBUG - 2015-12-22 21:56:19 --> Total execution time: 0.2440
DEBUG - 2015-12-22 21:57:03 --> Config Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:57:03 --> URI Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Router Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Output Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Security Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Input Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:57:03 --> Language Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Language Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Config Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Loader Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:57:03 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:57:03 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Session Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:57:03 --> Session routines successfully run
DEBUG - 2015-12-22 21:57:03 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Email Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Controller Class Initialized
DEBUG - 2015-12-22 21:57:03 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:57:03 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:03 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:57:03 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:57:03 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:57:04 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:57:04 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:57:04 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:57:04 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:04 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:57:04 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:04 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:57:04 --> Final output sent to browser
DEBUG - 2015-12-22 21:57:04 --> Total execution time: 0.2319
DEBUG - 2015-12-22 21:57:17 --> Config Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:57:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:57:17 --> URI Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Router Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Output Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Security Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Input Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:57:17 --> Language Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Language Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Config Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Loader Class Initialized
DEBUG - 2015-12-22 21:57:17 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:57:17 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:57:18 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:57:18 --> Session Class Initialized
DEBUG - 2015-12-22 21:57:18 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:57:18 --> Session routines successfully run
DEBUG - 2015-12-22 21:57:18 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:57:18 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:57:18 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:57:18 --> Email Class Initialized
DEBUG - 2015-12-22 21:57:18 --> Controller Class Initialized
DEBUG - 2015-12-22 21:57:18 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:57:18 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:18 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:57:18 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:57:18 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:57:18 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:57:18 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:57:18 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:57:18 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:18 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:57:18 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:18 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:57:18 --> Final output sent to browser
DEBUG - 2015-12-22 21:57:18 --> Total execution time: 0.1978
DEBUG - 2015-12-22 21:57:44 --> Config Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:57:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:57:44 --> URI Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Router Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Output Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Security Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Input Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:57:44 --> Language Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Language Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Config Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Loader Class Initialized
DEBUG - 2015-12-22 21:57:44 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:57:44 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:57:44 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:57:45 --> Session Class Initialized
DEBUG - 2015-12-22 21:57:45 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:57:45 --> Session routines successfully run
DEBUG - 2015-12-22 21:57:45 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:57:45 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:57:45 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:57:45 --> Email Class Initialized
DEBUG - 2015-12-22 21:57:45 --> Controller Class Initialized
DEBUG - 2015-12-22 21:57:45 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:57:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:45 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:57:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:57:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:57:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:57:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:57:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:57:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:45 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:57:45 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:45 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:57:45 --> Final output sent to browser
DEBUG - 2015-12-22 21:57:45 --> Total execution time: 0.2642
DEBUG - 2015-12-22 21:57:47 --> Config Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:57:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:57:47 --> URI Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Router Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Output Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Security Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Input Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:57:47 --> Language Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Language Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Config Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Loader Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:57:47 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:57:47 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Session Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:57:47 --> Session routines successfully run
DEBUG - 2015-12-22 21:57:47 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Email Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Controller Class Initialized
DEBUG - 2015-12-22 21:57:47 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:57:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:47 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:57:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:57:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:57:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:57:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:57:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:57:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:57:47 --> Model Class Initialized
DEBUG - 2015-12-22 21:57:47 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:57:47 --> Final output sent to browser
DEBUG - 2015-12-22 21:57:47 --> Total execution time: 0.1988
DEBUG - 2015-12-22 21:58:17 --> Config Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:58:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:58:17 --> URI Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Router Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Output Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Security Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Input Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:58:17 --> Language Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Language Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Config Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Loader Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:58:17 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:58:17 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Session Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:58:17 --> Session routines successfully run
DEBUG - 2015-12-22 21:58:17 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Email Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Controller Class Initialized
DEBUG - 2015-12-22 21:58:17 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:58:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:58:17 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:58:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:58:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:58:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:58:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:58:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:58:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:58:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:58:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:58:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:58:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:58:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:58:17 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:58:17 --> Model Class Initialized
DEBUG - 2015-12-22 21:58:17 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:58:17 --> Final output sent to browser
DEBUG - 2015-12-22 21:58:17 --> Total execution time: 0.2118
DEBUG - 2015-12-22 21:59:01 --> Config Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Hooks Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Utf8 Class Initialized
DEBUG - 2015-12-22 21:59:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 21:59:01 --> URI Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Router Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Output Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Security Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Input Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 21:59:01 --> Language Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Language Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Config Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Loader Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Helper loaded: url_helper
DEBUG - 2015-12-22 21:59:01 --> Helper loaded: form_helper
DEBUG - 2015-12-22 21:59:01 --> Database Driver Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Session Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Helper loaded: string_helper
DEBUG - 2015-12-22 21:59:01 --> Session routines successfully run
DEBUG - 2015-12-22 21:59:01 --> Form Validation Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Pagination Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Encrypt Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Email Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Controller Class Initialized
DEBUG - 2015-12-22 21:59:01 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 21:59:01 --> Model Class Initialized
DEBUG - 2015-12-22 21:59:01 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 21:59:01 --> Model Class Initialized
DEBUG - 2015-12-22 21:59:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 21:59:01 --> Model Class Initialized
DEBUG - 2015-12-22 21:59:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 21:59:01 --> Model Class Initialized
DEBUG - 2015-12-22 21:59:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 21:59:01 --> Model Class Initialized
DEBUG - 2015-12-22 21:59:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 21:59:01 --> Model Class Initialized
DEBUG - 2015-12-22 21:59:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 21:59:01 --> Model Class Initialized
DEBUG - 2015-12-22 21:59:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 21:59:01 --> Model Class Initialized
DEBUG - 2015-12-22 21:59:01 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 21:59:01 --> Final output sent to browser
DEBUG - 2015-12-22 21:59:01 --> Total execution time: 0.1954
DEBUG - 2015-12-22 22:01:59 --> Config Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:01:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:01:59 --> URI Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Router Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Output Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Security Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Input Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:01:59 --> Language Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Language Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Config Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Loader Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:01:59 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:01:59 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Session Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:01:59 --> Session routines successfully run
DEBUG - 2015-12-22 22:01:59 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Email Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Controller Class Initialized
DEBUG - 2015-12-22 22:01:59 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:01:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:01:59 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:01:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:01:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:01:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:01:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:01:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:01:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:01:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:01:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:01:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:01:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:01:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:01:59 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:01:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:01:59 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:01:59 --> Final output sent to browser
DEBUG - 2015-12-22 22:01:59 --> Total execution time: 0.2043
DEBUG - 2015-12-22 22:05:27 --> Config Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:05:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:05:27 --> URI Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Router Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Output Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Security Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Input Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:05:27 --> Language Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Language Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Config Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Loader Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:05:27 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:05:27 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Session Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:05:27 --> Session routines successfully run
DEBUG - 2015-12-22 22:05:27 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Email Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Controller Class Initialized
DEBUG - 2015-12-22 22:05:27 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:05:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:05:27 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:05:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:05:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:05:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:05:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:05:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:05:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:05:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:05:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:05:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:05:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:05:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:05:27 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:05:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:05:27 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:05:27 --> Final output sent to browser
DEBUG - 2015-12-22 22:05:27 --> Total execution time: 0.1899
DEBUG - 2015-12-22 22:06:04 --> Config Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:06:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:06:04 --> URI Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Router Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Output Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Security Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Input Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:06:04 --> Language Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Language Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Config Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Loader Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:06:04 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:06:04 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Session Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:06:04 --> Session routines successfully run
DEBUG - 2015-12-22 22:06:04 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Email Class Initialized
DEBUG - 2015-12-22 22:06:04 --> Controller Class Initialized
DEBUG - 2015-12-22 22:06:05 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:06:05 --> Model Class Initialized
DEBUG - 2015-12-22 22:06:05 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:06:05 --> Model Class Initialized
DEBUG - 2015-12-22 22:06:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:06:05 --> Model Class Initialized
DEBUG - 2015-12-22 22:06:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:06:05 --> Model Class Initialized
DEBUG - 2015-12-22 22:06:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:06:05 --> Model Class Initialized
DEBUG - 2015-12-22 22:06:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:06:05 --> Model Class Initialized
DEBUG - 2015-12-22 22:06:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:06:05 --> Model Class Initialized
DEBUG - 2015-12-22 22:06:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:06:05 --> Model Class Initialized
DEBUG - 2015-12-22 22:06:05 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:06:05 --> Final output sent to browser
DEBUG - 2015-12-22 22:06:05 --> Total execution time: 0.1966
DEBUG - 2015-12-22 22:07:15 --> Config Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:07:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:07:15 --> URI Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Router Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Output Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Security Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Input Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:07:15 --> Language Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Language Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Config Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Loader Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:07:15 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:07:15 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Session Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:07:15 --> Session routines successfully run
DEBUG - 2015-12-22 22:07:15 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Email Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Controller Class Initialized
DEBUG - 2015-12-22 22:07:15 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:07:15 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:15 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:07:15 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:07:15 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:07:15 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:07:15 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:07:15 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:07:15 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:15 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:07:15 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:15 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:07:15 --> Final output sent to browser
DEBUG - 2015-12-22 22:07:15 --> Total execution time: 0.2855
DEBUG - 2015-12-22 22:07:35 --> Config Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:07:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:07:35 --> URI Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Router Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Output Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Security Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Input Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:07:35 --> Language Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Language Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Config Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Loader Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:07:35 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:07:35 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Session Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:07:35 --> Session routines successfully run
DEBUG - 2015-12-22 22:07:35 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Email Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Controller Class Initialized
DEBUG - 2015-12-22 22:07:35 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:07:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:35 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:07:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:07:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:07:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:07:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:07:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:07:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:35 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:07:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:07:35 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:07:35 --> Final output sent to browser
DEBUG - 2015-12-22 22:07:35 --> Total execution time: 0.1950
DEBUG - 2015-12-22 22:08:06 --> Config Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:08:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:08:06 --> URI Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Router Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Output Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Security Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Input Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:08:06 --> Language Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Language Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Config Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Loader Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:08:06 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:08:06 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Session Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:08:06 --> Session routines successfully run
DEBUG - 2015-12-22 22:08:06 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Email Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Controller Class Initialized
DEBUG - 2015-12-22 22:08:06 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:06 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:06 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:06 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:08:06 --> Final output sent to browser
DEBUG - 2015-12-22 22:08:06 --> Total execution time: 0.1956
DEBUG - 2015-12-22 22:08:37 --> Config Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:08:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:08:37 --> URI Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Router Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Output Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Security Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Input Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:08:37 --> Language Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Language Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Config Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Loader Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:08:37 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:08:37 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Session Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:08:37 --> Session routines successfully run
DEBUG - 2015-12-22 22:08:37 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Email Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Controller Class Initialized
DEBUG - 2015-12-22 22:08:37 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:08:37 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:37 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:08:37 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:08:37 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:08:37 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:08:37 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:08:37 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:08:37 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:37 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:08:37 --> Model Class Initialized
DEBUG - 2015-12-22 22:08:37 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:08:37 --> Final output sent to browser
DEBUG - 2015-12-22 22:08:37 --> Total execution time: 0.1864
DEBUG - 2015-12-22 22:09:07 --> Config Class Initialized
DEBUG - 2015-12-22 22:09:07 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:09:07 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:09:07 --> URI Class Initialized
DEBUG - 2015-12-22 22:09:07 --> Router Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Output Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Security Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Input Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:09:08 --> Language Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Language Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Config Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Loader Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:09:08 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:09:08 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Session Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:09:08 --> Session routines successfully run
DEBUG - 2015-12-22 22:09:08 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Email Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Controller Class Initialized
DEBUG - 2015-12-22 22:09:08 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:09:08 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:08 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:09:08 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:09:08 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:09:08 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:09:08 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:09:08 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:09:08 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:08 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:09:08 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:08 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:09:08 --> Final output sent to browser
DEBUG - 2015-12-22 22:09:08 --> Total execution time: 0.2180
DEBUG - 2015-12-22 22:09:27 --> Config Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:09:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:09:27 --> URI Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Router Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Output Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Security Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Input Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:09:27 --> Language Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Language Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Config Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Loader Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:09:27 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:09:27 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Session Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:09:27 --> Session routines successfully run
DEBUG - 2015-12-22 22:09:27 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Email Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Controller Class Initialized
DEBUG - 2015-12-22 22:09:27 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:09:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:27 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:09:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:09:27 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:09:28 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:09:28 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:09:28 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:09:28 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:28 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:09:28 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:28 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:09:28 --> Final output sent to browser
DEBUG - 2015-12-22 22:09:28 --> Total execution time: 0.1955
DEBUG - 2015-12-22 22:09:50 --> Config Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:09:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:09:50 --> URI Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Router Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Output Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Security Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Input Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:09:50 --> Language Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Language Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Config Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Loader Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:09:50 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:09:50 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Session Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:09:50 --> Session routines successfully run
DEBUG - 2015-12-22 22:09:50 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Email Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Controller Class Initialized
DEBUG - 2015-12-22 22:09:50 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:09:50 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:50 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:09:50 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:09:50 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:09:50 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:09:50 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:09:50 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:09:50 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:50 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:09:50 --> Model Class Initialized
DEBUG - 2015-12-22 22:09:50 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:09:50 --> Final output sent to browser
DEBUG - 2015-12-22 22:09:50 --> Total execution time: 0.2122
DEBUG - 2015-12-22 22:10:21 --> Config Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:10:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:10:21 --> URI Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Router Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Output Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Security Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Input Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:10:21 --> Language Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Language Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Config Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Loader Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:10:21 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:10:21 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Session Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:10:21 --> Session routines successfully run
DEBUG - 2015-12-22 22:10:21 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Email Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Controller Class Initialized
DEBUG - 2015-12-22 22:10:21 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:10:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:10:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:10:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:10:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:10:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:10:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:10:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:10:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:10:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:10:21 --> Final output sent to browser
DEBUG - 2015-12-22 22:10:21 --> Total execution time: 0.2526
DEBUG - 2015-12-22 22:10:24 --> Config Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:10:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:10:24 --> URI Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Router Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Output Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Security Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Input Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:10:24 --> Language Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Language Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Config Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Loader Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:10:24 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:10:24 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Session Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:10:24 --> Session routines successfully run
DEBUG - 2015-12-22 22:10:24 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Email Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Controller Class Initialized
DEBUG - 2015-12-22 22:10:24 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:10:24 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:24 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:10:24 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:10:24 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:10:24 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:10:24 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:10:24 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:10:24 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:24 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:10:24 --> Model Class Initialized
DEBUG - 2015-12-22 22:10:24 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:10:24 --> Final output sent to browser
DEBUG - 2015-12-22 22:10:24 --> Total execution time: 0.2577
DEBUG - 2015-12-22 22:11:46 --> Config Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:11:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:11:46 --> URI Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Router Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Output Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Security Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Input Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:11:46 --> Language Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Language Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Config Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Loader Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:11:46 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:11:46 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Session Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:11:46 --> Session routines successfully run
DEBUG - 2015-12-22 22:11:46 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Email Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Controller Class Initialized
DEBUG - 2015-12-22 22:11:46 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:11:46 --> Model Class Initialized
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:11:46 --> Model Class Initialized
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:11:46 --> Model Class Initialized
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:11:46 --> Model Class Initialized
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:11:46 --> Model Class Initialized
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:11:46 --> Model Class Initialized
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:11:46 --> Model Class Initialized
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:11:46 --> Model Class Initialized
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:11:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:11:46 --> Final output sent to browser
DEBUG - 2015-12-22 22:11:46 --> Total execution time: 0.2211
DEBUG - 2015-12-22 22:12:16 --> Config Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:12:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:12:16 --> URI Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Router Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Output Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Security Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Input Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:12:16 --> Language Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Language Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Config Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Loader Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:12:16 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:12:16 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Session Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:12:16 --> Session routines successfully run
DEBUG - 2015-12-22 22:12:16 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Email Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Controller Class Initialized
DEBUG - 2015-12-22 22:12:16 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:12:16 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:16 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:12:16 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:12:16 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:12:17 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:12:17 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:12:17 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:12:17 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:12:17 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:12:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:12:17 --> Final output sent to browser
DEBUG - 2015-12-22 22:12:17 --> Total execution time: 0.2300
DEBUG - 2015-12-22 22:12:20 --> Config Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:12:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:12:20 --> URI Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Router Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Output Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Security Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Input Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:12:20 --> Language Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Language Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Config Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Loader Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:12:20 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:12:20 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Session Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:12:20 --> Session routines successfully run
DEBUG - 2015-12-22 22:12:20 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Email Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Controller Class Initialized
DEBUG - 2015-12-22 22:12:20 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:12:20 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:12:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:12:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:12:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:12:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:12:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:12:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:12:21 --> Model Class Initialized
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:12:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:12:21 --> Final output sent to browser
DEBUG - 2015-12-22 22:12:21 --> Total execution time: 0.2370
DEBUG - 2015-12-22 22:15:19 --> Config Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:15:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:15:19 --> URI Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Router Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Output Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Security Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Input Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:15:19 --> Language Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Language Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Config Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Loader Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:15:19 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:15:19 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Session Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:15:19 --> Session routines successfully run
DEBUG - 2015-12-22 22:15:19 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Email Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Controller Class Initialized
DEBUG - 2015-12-22 22:15:19 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:15:19 --> Model Class Initialized
DEBUG - 2015-12-22 22:15:19 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:15:19 --> Model Class Initialized
DEBUG - 2015-12-22 22:15:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:15:19 --> Model Class Initialized
DEBUG - 2015-12-22 22:15:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:15:19 --> Model Class Initialized
DEBUG - 2015-12-22 22:15:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:15:19 --> Model Class Initialized
DEBUG - 2015-12-22 22:15:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:15:19 --> Model Class Initialized
DEBUG - 2015-12-22 22:15:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:15:19 --> Model Class Initialized
DEBUG - 2015-12-22 22:15:19 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:15:19 --> Model Class Initialized
DEBUG - 2015-12-22 22:15:19 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:15:19 --> Final output sent to browser
DEBUG - 2015-12-22 22:15:19 --> Total execution time: 0.2235
DEBUG - 2015-12-22 22:22:58 --> Config Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:22:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:22:58 --> URI Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Router Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Output Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Security Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Input Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:22:58 --> Language Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Language Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Config Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Loader Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:22:58 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:22:58 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Session Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:22:58 --> Session routines successfully run
DEBUG - 2015-12-22 22:22:58 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Email Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Controller Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:22:58 --> Model Class Initialized
DEBUG - 2015-12-22 22:22:58 --> Image Lib Class Initialized
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:22:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:22:58 --> Final output sent to browser
DEBUG - 2015-12-22 22:22:58 --> Total execution time: 0.3750
DEBUG - 2015-12-22 22:23:01 --> Config Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:23:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:23:01 --> URI Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Router Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Output Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Security Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Input Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:23:01 --> Language Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Language Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Config Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Loader Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:23:01 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:23:01 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Session Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:23:01 --> Session routines successfully run
DEBUG - 2015-12-22 22:23:01 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Email Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Controller Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:23:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:01 --> Image Lib Class Initialized
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:23:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:23:01 --> Final output sent to browser
DEBUG - 2015-12-22 22:23:01 --> Total execution time: 0.3150
DEBUG - 2015-12-22 22:23:07 --> Config Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:23:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:23:07 --> URI Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Router Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Output Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Security Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Input Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:23:07 --> Language Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Language Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Config Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Loader Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:23:07 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:23:07 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Session Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:23:07 --> Session routines successfully run
DEBUG - 2015-12-22 22:23:07 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Email Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Controller Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Property MX_Controller Initialized
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:23:07 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:07 --> Image Lib Class Initialized
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:23:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:23:08 --> Final output sent to browser
DEBUG - 2015-12-22 22:23:08 --> Total execution time: 0.2618
DEBUG - 2015-12-22 22:23:12 --> Config Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:23:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:23:12 --> URI Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Router Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Output Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Security Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Input Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:23:12 --> Language Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Language Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Config Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Loader Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:23:12 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:23:12 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Session Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:23:12 --> Session routines successfully run
DEBUG - 2015-12-22 22:23:12 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Email Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Controller Class Initialized
DEBUG - 2015-12-22 22:23:12 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:23:12 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:23:12 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:23:12 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:23:12 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:23:12 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:23:12 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:23:12 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:23:12 --> Model Class Initialized
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:23:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:23:12 --> Final output sent to browser
DEBUG - 2015-12-22 22:23:12 --> Total execution time: 0.2368
DEBUG - 2015-12-22 22:24:36 --> Config Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:24:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:24:36 --> URI Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Router Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Output Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Security Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Input Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:24:36 --> Language Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Language Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Config Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Loader Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:24:36 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:24:36 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Session Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:24:36 --> Session routines successfully run
DEBUG - 2015-12-22 22:24:36 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Email Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Controller Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Auth MX_Controller Initialized
DEBUG - 2015-12-22 22:24:36 --> Model Class Initialized
DEBUG - 2015-12-22 22:24:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 22:24:36 --> Model Class Initialized
DEBUG - 2015-12-22 22:24:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:24:36 --> Model Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Config Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:24:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:24:36 --> URI Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Router Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Output Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Security Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Input Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:24:36 --> Language Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Language Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Config Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Loader Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:24:36 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:24:36 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Session Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:24:36 --> A session cookie was not found.
DEBUG - 2015-12-22 22:24:36 --> Session routines successfully run
DEBUG - 2015-12-22 22:24:36 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Email Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Controller Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Auth MX_Controller Initialized
DEBUG - 2015-12-22 22:24:36 --> Model Class Initialized
DEBUG - 2015-12-22 22:24:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 22:24:36 --> Model Class Initialized
DEBUG - 2015-12-22 22:24:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:24:36 --> Model Class Initialized
DEBUG - 2015-12-22 22:24:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:24:36 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-22 22:24:36 --> Final output sent to browser
DEBUG - 2015-12-22 22:24:36 --> Total execution time: 0.2078
DEBUG - 2015-12-22 22:24:36 --> Config Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:24:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:24:36 --> URI Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Router Class Initialized
ERROR - 2015-12-22 22:24:36 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 22:24:36 --> Config Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:24:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:24:36 --> URI Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Router Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Config Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:24:36 --> UTF-8 Support Enabled
ERROR - 2015-12-22 22:24:36 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 22:24:36 --> URI Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Router Class Initialized
ERROR - 2015-12-22 22:24:36 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 22:24:36 --> Config Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:24:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:24:36 --> URI Class Initialized
DEBUG - 2015-12-22 22:24:36 --> Router Class Initialized
ERROR - 2015-12-22 22:24:37 --> 404 Page Not Found --> 
DEBUG - 2015-12-22 22:25:18 --> Config Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:25:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:25:18 --> URI Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Router Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Output Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Security Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Input Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:25:18 --> Language Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Language Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Config Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Loader Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:25:18 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:25:18 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Session Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:25:18 --> Session routines successfully run
DEBUG - 2015-12-22 22:25:18 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Email Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Controller Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Auth MX_Controller Initialized
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 22:25:18 --> XSS Filtering completed
DEBUG - 2015-12-22 22:25:18 --> Unable to find validation rule: exists
DEBUG - 2015-12-22 22:25:18 --> XSS Filtering completed
DEBUG - 2015-12-22 22:25:18 --> Config Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:25:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:25:18 --> URI Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Router Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Output Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Security Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Input Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:25:18 --> Language Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Language Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Config Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Loader Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:25:18 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:25:18 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Session Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:25:18 --> Session routines successfully run
DEBUG - 2015-12-22 22:25:18 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Email Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Controller Class Initialized
DEBUG - 2015-12-22 22:25:18 --> Admin MX_Controller Initialized
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-22 22:25:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:25:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:25:18 --> Final output sent to browser
DEBUG - 2015-12-22 22:25:18 --> Total execution time: 0.2702
DEBUG - 2015-12-22 22:25:23 --> Config Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:25:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:25:23 --> URI Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Router Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Output Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Security Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Input Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:25:23 --> Language Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Language Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Config Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Loader Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:25:23 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:25:23 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Session Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:25:23 --> Session routines successfully run
DEBUG - 2015-12-22 22:25:23 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Email Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Controller Class Initialized
DEBUG - 2015-12-22 22:25:23 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:25:23 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:25:23 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:25:23 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:25:23 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:25:23 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:25:23 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:25:23 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:25:23 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-22 22:25:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-22 22:25:24 --> Final output sent to browser
DEBUG - 2015-12-22 22:25:24 --> Total execution time: 0.2779
DEBUG - 2015-12-22 22:25:25 --> Config Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:25:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:25:25 --> URI Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Router Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Output Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Security Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Input Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:25:25 --> Language Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Language Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Config Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Loader Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:25:25 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:25:25 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Session Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:25:25 --> Session routines successfully run
DEBUG - 2015-12-22 22:25:25 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Email Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Controller Class Initialized
DEBUG - 2015-12-22 22:25:25 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:25:25 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:25 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:25:25 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:25:25 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:25:25 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:25:25 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:25:25 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:25:25 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:25 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:25:25 --> Model Class Initialized
DEBUG - 2015-12-22 22:25:25 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:25:25 --> Final output sent to browser
DEBUG - 2015-12-22 22:25:25 --> Total execution time: 0.2567
DEBUG - 2015-12-22 22:26:35 --> Config Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:26:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:26:35 --> URI Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Router Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Output Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Security Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Input Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:26:35 --> Language Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Language Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Config Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Loader Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:26:35 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:26:35 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Session Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:26:35 --> Session routines successfully run
DEBUG - 2015-12-22 22:26:35 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Email Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Controller Class Initialized
DEBUG - 2015-12-22 22:26:35 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:26:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:35 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:26:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:26:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:26:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:26:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:26:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:26:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:35 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:26:35 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:35 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:26:35 --> Final output sent to browser
DEBUG - 2015-12-22 22:26:35 --> Total execution time: 0.2549
DEBUG - 2015-12-22 22:26:59 --> Config Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:26:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:26:59 --> URI Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Router Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Output Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Security Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Input Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:26:59 --> Language Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Language Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Config Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Loader Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:26:59 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:26:59 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Session Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:26:59 --> Session routines successfully run
DEBUG - 2015-12-22 22:26:59 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Email Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Controller Class Initialized
DEBUG - 2015-12-22 22:26:59 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:26:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:59 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:26:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:26:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:26:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:26:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:26:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:26:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:59 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:26:59 --> Model Class Initialized
DEBUG - 2015-12-22 22:26:59 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:26:59 --> Final output sent to browser
DEBUG - 2015-12-22 22:26:59 --> Total execution time: 0.2018
DEBUG - 2015-12-22 22:28:22 --> Config Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:28:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:28:22 --> URI Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Router Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Output Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Security Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Input Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:28:22 --> Language Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Language Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Config Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Loader Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:28:22 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:28:22 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Session Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:28:22 --> Session routines successfully run
DEBUG - 2015-12-22 22:28:22 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Email Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Controller Class Initialized
DEBUG - 2015-12-22 22:28:22 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:28:22 --> Model Class Initialized
DEBUG - 2015-12-22 22:28:22 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:28:22 --> Model Class Initialized
DEBUG - 2015-12-22 22:28:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:28:22 --> Model Class Initialized
DEBUG - 2015-12-22 22:28:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:28:22 --> Model Class Initialized
DEBUG - 2015-12-22 22:28:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:28:22 --> Model Class Initialized
DEBUG - 2015-12-22 22:28:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:28:22 --> Model Class Initialized
DEBUG - 2015-12-22 22:28:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:28:22 --> Model Class Initialized
DEBUG - 2015-12-22 22:28:22 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:28:22 --> Model Class Initialized
DEBUG - 2015-12-22 22:28:22 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:28:22 --> Final output sent to browser
DEBUG - 2015-12-22 22:28:22 --> Total execution time: 0.1950
DEBUG - 2015-12-22 22:29:43 --> Config Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:29:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:29:43 --> URI Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Router Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Output Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Security Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Input Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:29:43 --> Language Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Language Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Config Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Loader Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:29:43 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:29:43 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Session Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:29:43 --> Session routines successfully run
DEBUG - 2015-12-22 22:29:43 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Email Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Controller Class Initialized
DEBUG - 2015-12-22 22:29:43 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:29:43 --> Model Class Initialized
DEBUG - 2015-12-22 22:29:43 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:29:43 --> Model Class Initialized
DEBUG - 2015-12-22 22:29:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:29:43 --> Model Class Initialized
DEBUG - 2015-12-22 22:29:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:29:43 --> Model Class Initialized
DEBUG - 2015-12-22 22:29:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:29:43 --> Model Class Initialized
DEBUG - 2015-12-22 22:29:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:29:43 --> Model Class Initialized
DEBUG - 2015-12-22 22:29:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:29:43 --> Model Class Initialized
DEBUG - 2015-12-22 22:29:43 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:29:43 --> Model Class Initialized
DEBUG - 2015-12-22 22:29:43 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:29:43 --> Final output sent to browser
DEBUG - 2015-12-22 22:29:43 --> Total execution time: 0.1904
DEBUG - 2015-12-22 22:30:00 --> Config Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:30:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:30:00 --> URI Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Router Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Output Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Security Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Input Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:30:00 --> Language Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Language Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Config Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Loader Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:30:00 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:30:00 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Session Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:30:00 --> Session routines successfully run
DEBUG - 2015-12-22 22:30:00 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Email Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Controller Class Initialized
DEBUG - 2015-12-22 22:30:00 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:30:00 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:00 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:30:00 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:30:00 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:30:00 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:30:00 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:30:00 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:30:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:30:01 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:01 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:30:01 --> Final output sent to browser
DEBUG - 2015-12-22 22:30:01 --> Total execution time: 0.2112
DEBUG - 2015-12-22 22:30:18 --> Config Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:30:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:30:18 --> URI Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Router Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Output Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Security Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Input Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:30:18 --> Language Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Language Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Config Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Loader Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:30:18 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:30:18 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Session Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:30:18 --> Session routines successfully run
DEBUG - 2015-12-22 22:30:18 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Email Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Controller Class Initialized
DEBUG - 2015-12-22 22:30:18 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:30:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:18 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:30:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:30:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:30:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:30:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:30:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:30:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:18 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:30:18 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:18 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:30:18 --> Final output sent to browser
DEBUG - 2015-12-22 22:30:18 --> Total execution time: 0.2392
DEBUG - 2015-12-22 22:30:43 --> Config Class Initialized
DEBUG - 2015-12-22 22:30:43 --> Hooks Class Initialized
DEBUG - 2015-12-22 22:30:43 --> Utf8 Class Initialized
DEBUG - 2015-12-22 22:30:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 22:30:43 --> URI Class Initialized
DEBUG - 2015-12-22 22:30:43 --> Router Class Initialized
DEBUG - 2015-12-22 22:30:43 --> Output Class Initialized
DEBUG - 2015-12-22 22:30:43 --> Security Class Initialized
DEBUG - 2015-12-22 22:30:43 --> Input Class Initialized
DEBUG - 2015-12-22 22:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 22:30:43 --> Language Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Language Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Config Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Loader Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Helper loaded: url_helper
DEBUG - 2015-12-22 22:30:44 --> Helper loaded: form_helper
DEBUG - 2015-12-22 22:30:44 --> Database Driver Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Session Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Helper loaded: string_helper
DEBUG - 2015-12-22 22:30:44 --> Session routines successfully run
DEBUG - 2015-12-22 22:30:44 --> Form Validation Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Pagination Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Encrypt Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Email Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Controller Class Initialized
DEBUG - 2015-12-22 22:30:44 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-22 22:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:44 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-22 22:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-22 22:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-22 22:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-22 22:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-22 22:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-22 22:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:44 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-22 22:30:44 --> Model Class Initialized
DEBUG - 2015-12-22 22:30:44 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-22 22:30:44 --> Final output sent to browser
DEBUG - 2015-12-22 22:30:44 --> Total execution time: 0.1993
