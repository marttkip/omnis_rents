<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-04-19 11:52:56 --> Config Class Initialized
DEBUG - 2016-04-19 11:52:56 --> Hooks Class Initialized
DEBUG - 2016-04-19 11:52:56 --> Utf8 Class Initialized
DEBUG - 2016-04-19 11:52:56 --> UTF-8 Support Enabled
DEBUG - 2016-04-19 11:52:56 --> URI Class Initialized
DEBUG - 2016-04-19 11:52:56 --> Router Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Output Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Security Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Input Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-19 11:52:57 --> Language Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Language Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Config Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Loader Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Helper loaded: url_helper
DEBUG - 2016-04-19 11:52:57 --> Helper loaded: form_helper
DEBUG - 2016-04-19 11:52:57 --> Database Driver Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Session Class Initialized
DEBUG - 2016-04-19 11:52:57 --> Helper loaded: string_helper
DEBUG - 2016-04-19 11:52:57 --> Session routines successfully run
DEBUG - 2016-04-19 11:52:58 --> Form Validation Class Initialized
DEBUG - 2016-04-19 11:52:58 --> Pagination Class Initialized
DEBUG - 2016-04-19 11:52:58 --> Encrypt Class Initialized
DEBUG - 2016-04-19 11:52:58 --> Email Class Initialized
DEBUG - 2016-04-19 11:52:58 --> Controller Class Initialized
DEBUG - 2016-04-19 11:52:58 --> Auth MX_Controller Initialized
DEBUG - 2016-04-19 11:52:58 --> Model Class Initialized
DEBUG - 2016-04-19 11:52:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-19 11:52:58 --> Model Class Initialized
DEBUG - 2016-04-19 11:52:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-19 11:52:58 --> Model Class Initialized
DEBUG - 2016-04-19 11:52:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-19 11:52:58 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-04-19 11:52:58 --> Final output sent to browser
DEBUG - 2016-04-19 11:52:58 --> Total execution time: 1.6635
DEBUG - 2016-04-19 11:53:02 --> Config Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Hooks Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Utf8 Class Initialized
DEBUG - 2016-04-19 11:53:02 --> UTF-8 Support Enabled
DEBUG - 2016-04-19 11:53:02 --> URI Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Router Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Config Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Hooks Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Utf8 Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Config Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Hooks Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Utf8 Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Config Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Hooks Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Utf8 Class Initialized
DEBUG - 2016-04-19 11:53:02 --> UTF-8 Support Enabled
DEBUG - 2016-04-19 11:53:02 --> URI Class Initialized
DEBUG - 2016-04-19 11:53:02 --> UTF-8 Support Enabled
DEBUG - 2016-04-19 11:53:02 --> URI Class Initialized
DEBUG - 2016-04-19 11:53:02 --> UTF-8 Support Enabled
DEBUG - 2016-04-19 11:53:02 --> URI Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Router Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Router Class Initialized
DEBUG - 2016-04-19 11:53:02 --> Router Class Initialized
ERROR - 2016-04-19 11:53:03 --> 404 Page Not Found --> 
ERROR - 2016-04-19 11:53:03 --> 404 Page Not Found --> 
ERROR - 2016-04-19 11:53:03 --> 404 Page Not Found --> 
ERROR - 2016-04-19 11:53:03 --> 404 Page Not Found --> 
DEBUG - 2016-04-19 11:53:52 --> Config Class Initialized
DEBUG - 2016-04-19 11:53:52 --> Hooks Class Initialized
DEBUG - 2016-04-19 11:53:52 --> Utf8 Class Initialized
DEBUG - 2016-04-19 11:53:52 --> UTF-8 Support Enabled
DEBUG - 2016-04-19 11:53:52 --> URI Class Initialized
DEBUG - 2016-04-19 11:53:52 --> Router Class Initialized
ERROR - 2016-04-19 11:53:52 --> 404 Page Not Found --> 
DEBUG - 2016-04-19 11:53:56 --> Config Class Initialized
DEBUG - 2016-04-19 11:53:56 --> Hooks Class Initialized
DEBUG - 2016-04-19 11:53:56 --> Utf8 Class Initialized
DEBUG - 2016-04-19 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2016-04-19 11:53:56 --> URI Class Initialized
DEBUG - 2016-04-19 11:53:56 --> Router Class Initialized
ERROR - 2016-04-19 11:53:56 --> 404 Page Not Found --> 
