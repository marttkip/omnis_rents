<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-05 13:07:54 --> Config Class Initialized
DEBUG - 2015-12-05 13:07:55 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:07:55 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:07:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:07:55 --> URI Class Initialized
DEBUG - 2015-12-05 13:07:56 --> Router Class Initialized
DEBUG - 2015-12-05 13:07:56 --> Output Class Initialized
DEBUG - 2015-12-05 13:07:56 --> Security Class Initialized
DEBUG - 2015-12-05 13:07:56 --> Input Class Initialized
DEBUG - 2015-12-05 13:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:07:56 --> Language Class Initialized
DEBUG - 2015-12-05 13:07:56 --> Language Class Initialized
DEBUG - 2015-12-05 13:07:56 --> Config Class Initialized
DEBUG - 2015-12-05 13:07:57 --> Loader Class Initialized
DEBUG - 2015-12-05 13:07:57 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:07:57 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:07:57 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:08:03 --> Session Class Initialized
DEBUG - 2015-12-05 13:08:03 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:08:03 --> A session cookie was not found.
DEBUG - 2015-12-05 13:08:03 --> Session routines successfully run
DEBUG - 2015-12-05 13:08:03 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:08:03 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:08:03 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:08:03 --> Email Class Initialized
DEBUG - 2015-12-05 13:08:03 --> Controller Class Initialized
DEBUG - 2015-12-05 13:08:03 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:08:03 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:08:03 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:08:03 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:08:03 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:08:03 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:08:03 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:08:04 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:08:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:04 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Router Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Output Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Security Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Input Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:08:04 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Loader Class Initialized
DEBUG - 2015-12-05 13:08:04 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:08:04 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:08:04 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:08:05 --> Session Class Initialized
DEBUG - 2015-12-05 13:08:05 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:08:05 --> Session routines successfully run
DEBUG - 2015-12-05 13:08:05 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:08:05 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:08:05 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:08:05 --> Email Class Initialized
DEBUG - 2015-12-05 13:08:05 --> Controller Class Initialized
DEBUG - 2015-12-05 13:08:05 --> Auth MX_Controller Initialized
DEBUG - 2015-12-05 13:08:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:08:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:08:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:08:06 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-05 13:08:06 --> Final output sent to browser
DEBUG - 2015-12-05 13:08:06 --> Total execution time: 1.3348
DEBUG - 2015-12-05 13:08:08 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:08 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:08 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:08:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:08 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:08 --> Router Class Initialized
DEBUG - 2015-12-05 13:08:10 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:10 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:10 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:08:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:10 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:10 --> Router Class Initialized
DEBUG - 2015-12-05 13:08:11 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:11 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:11 --> Utf8 Class Initialized
ERROR - 2015-12-05 13:08:11 --> 404 Page Not Found --> 
DEBUG - 2015-12-05 13:08:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:11 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:11 --> Router Class Initialized
DEBUG - 2015-12-05 13:08:11 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:11 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:11 --> Utf8 Class Initialized
ERROR - 2015-12-05 13:08:11 --> 404 Page Not Found --> 
DEBUG - 2015-12-05 13:08:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:11 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:12 --> Router Class Initialized
ERROR - 2015-12-05 13:08:12 --> 404 Page Not Found --> 
ERROR - 2015-12-05 13:08:12 --> 404 Page Not Found --> 
DEBUG - 2015-12-05 13:08:17 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:08:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:17 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Router Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Output Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Security Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Input Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:08:17 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Loader Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:08:17 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:08:17 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Session Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:08:17 --> Session routines successfully run
DEBUG - 2015-12-05 13:08:17 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Email Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Controller Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Auth MX_Controller Initialized
DEBUG - 2015-12-05 13:08:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:08:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:08:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:08:17 --> XSS Filtering completed
DEBUG - 2015-12-05 13:08:17 --> Unable to find validation rule: exists
DEBUG - 2015-12-05 13:08:17 --> XSS Filtering completed
DEBUG - 2015-12-05 13:08:18 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:08:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:18 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Router Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Output Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Security Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Input Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:08:18 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Loader Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:08:18 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:08:18 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Session Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:08:18 --> Session routines successfully run
DEBUG - 2015-12-05 13:08:18 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Email Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Controller Class Initialized
DEBUG - 2015-12-05 13:08:18 --> Admin MX_Controller Initialized
DEBUG - 2015-12-05 13:08:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:08:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:08:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:08:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:08:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:08:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:08:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:08:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:08:18 --> Final output sent to browser
DEBUG - 2015-12-05 13:08:18 --> Total execution time: 0.8011
DEBUG - 2015-12-05 13:08:29 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:29 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Router Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Output Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Security Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Input Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:08:29 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Loader Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:08:29 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:08:29 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Session Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:08:29 --> Session routines successfully run
DEBUG - 2015-12-05 13:08:29 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Email Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Controller Class Initialized
DEBUG - 2015-12-05 13:08:29 --> Admin MX_Controller Initialized
DEBUG - 2015-12-05 13:08:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:08:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:08:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:08:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:08:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:08:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:08:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:30 --> File loaded: application/modules/admin/views/configuration.php
DEBUG - 2015-12-05 13:08:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:08:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:08:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:08:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:08:30 --> Final output sent to browser
DEBUG - 2015-12-05 13:08:30 --> Total execution time: 1.0691
DEBUG - 2015-12-05 13:08:38 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:38 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Router Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Output Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Security Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Input Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:08:38 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Loader Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:08:38 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:08:38 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Session Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:08:38 --> Session routines successfully run
DEBUG - 2015-12-05 13:08:38 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Email Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Controller Class Initialized
DEBUG - 2015-12-05 13:08:38 --> Admin MX_Controller Initialized
DEBUG - 2015-12-05 13:08:38 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:08:38 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:08:38 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:08:38 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:08:38 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:08:38 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:08:38 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/admin/views/configuration.php
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:08:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:08:38 --> Final output sent to browser
DEBUG - 2015-12-05 13:08:38 --> Total execution time: 0.2842
DEBUG - 2015-12-05 13:08:47 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:08:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:08:47 --> URI Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Router Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Output Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Security Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Input Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:08:47 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Language Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Config Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Loader Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:08:47 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:08:47 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Session Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:08:47 --> Session routines successfully run
DEBUG - 2015-12-05 13:08:47 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Email Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Controller Class Initialized
DEBUG - 2015-12-05 13:08:47 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:08:47 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:08:47 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:08:47 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:08:47 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:08:47 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:08:47 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:08:47 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:08:47 --> Model Class Initialized
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:08:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:08:47 --> Final output sent to browser
DEBUG - 2015-12-05 13:08:47 --> Total execution time: 0.4458
DEBUG - 2015-12-05 13:09:07 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:07 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Router Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Output Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Security Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Input Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:09:07 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Loader Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:09:07 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:09:07 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Session Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:09:07 --> Session routines successfully run
DEBUG - 2015-12-05 13:09:07 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Email Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Controller Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:09:07 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:09:07 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:09:07 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:09:07 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:09:07 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:09:07 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:09:07 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:09:07 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:09:08 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:08 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:08 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:08 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:08 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:08 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:08 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Router Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Output Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Security Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Input Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:09:08 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Loader Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:09:08 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:09:08 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Session Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:09:08 --> Session routines successfully run
DEBUG - 2015-12-05 13:09:08 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Email Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Controller Class Initialized
DEBUG - 2015-12-05 13:09:08 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:09:08 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:09:08 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:09:08 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:09:08 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:09:08 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:09:08 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:09:08 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:09:08 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:09:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:09:08 --> Final output sent to browser
DEBUG - 2015-12-05 13:09:08 --> Total execution time: 0.3765
DEBUG - 2015-12-05 13:09:13 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:13 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Router Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Output Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Security Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Input Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:09:13 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Loader Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:09:13 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:09:13 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Session Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:09:13 --> Session routines successfully run
DEBUG - 2015-12-05 13:09:13 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Email Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Controller Class Initialized
DEBUG - 2015-12-05 13:09:13 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:09:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:09:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:09:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:09:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:09:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:09:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:09:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:09:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:09:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:09:13 --> Final output sent to browser
DEBUG - 2015-12-05 13:09:13 --> Total execution time: 0.2721
DEBUG - 2015-12-05 13:09:16 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:16 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Router Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Output Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Security Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Input Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:09:16 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Loader Class Initialized
DEBUG - 2015-12-05 13:09:16 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:09:16 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:09:17 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:09:17 --> Session Class Initialized
DEBUG - 2015-12-05 13:09:17 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:09:17 --> Session routines successfully run
DEBUG - 2015-12-05 13:09:17 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:09:17 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:09:17 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:09:17 --> Email Class Initialized
DEBUG - 2015-12-05 13:09:17 --> Controller Class Initialized
DEBUG - 2015-12-05 13:09:17 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:09:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:09:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:09:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:09:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:09:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:09:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:09:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:09:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:09:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:09:17 --> Final output sent to browser
DEBUG - 2015-12-05 13:09:17 --> Total execution time: 0.2285
DEBUG - 2015-12-05 13:09:35 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:35 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Router Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Output Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Security Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Input Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:09:35 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Loader Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:09:35 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:09:35 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Session Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:09:35 --> Session routines successfully run
DEBUG - 2015-12-05 13:09:35 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Email Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Controller Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:09:35 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:35 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:35 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:35 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:35 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:35 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:35 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Router Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Output Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Security Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Input Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:09:35 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Loader Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:09:35 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:09:35 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Session Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:09:35 --> Session routines successfully run
DEBUG - 2015-12-05 13:09:35 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Email Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Controller Class Initialized
DEBUG - 2015-12-05 13:09:35 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:09:35 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:09:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:09:35 --> Final output sent to browser
DEBUG - 2015-12-05 13:09:35 --> Total execution time: 0.2265
DEBUG - 2015-12-05 13:09:38 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:38 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:38 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:38 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:38 --> Router Class Initialized
ERROR - 2015-12-05 13:09:38 --> 404 Page Not Found --> 
DEBUG - 2015-12-05 13:09:49 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:49 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Router Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Output Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Security Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Input Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:09:49 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Loader Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:09:49 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:09:49 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Session Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:09:49 --> Session routines successfully run
DEBUG - 2015-12-05 13:09:49 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Email Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Controller Class Initialized
DEBUG - 2015-12-05 13:09:49 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:09:49 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:09:49 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:09:49 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:09:49 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:09:49 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:09:49 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:09:49 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:09:49 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:09:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:09:49 --> Final output sent to browser
DEBUG - 2015-12-05 13:09:49 --> Total execution time: 0.3025
DEBUG - 2015-12-05 13:09:58 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:58 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Router Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Output Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Security Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Input Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:09:58 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Loader Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:09:58 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:09:58 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Session Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:09:58 --> Session routines successfully run
DEBUG - 2015-12-05 13:09:58 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Email Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Controller Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:09:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:09:58 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:09:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:09:58 --> URI Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Router Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Output Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Security Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Input Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:09:58 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Language Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Config Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Loader Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:09:58 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:09:58 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Session Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:09:58 --> Session routines successfully run
DEBUG - 2015-12-05 13:09:58 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Email Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Controller Class Initialized
DEBUG - 2015-12-05 13:09:58 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:09:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:09:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:09:58 --> Final output sent to browser
DEBUG - 2015-12-05 13:09:58 --> Total execution time: 0.2477
DEBUG - 2015-12-05 13:10:02 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:10:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:10:02 --> URI Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Router Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Output Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Security Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Input Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:10:02 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Loader Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:10:02 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:10:02 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Session Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:10:02 --> Session routines successfully run
DEBUG - 2015-12-05 13:10:02 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Email Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Controller Class Initialized
DEBUG - 2015-12-05 13:10:02 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:10:02 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:10:02 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:10:02 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:10:02 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:10:02 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:10:02 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:10:02 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:10:02 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:10:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:10:02 --> Final output sent to browser
DEBUG - 2015-12-05 13:10:02 --> Total execution time: 0.2166
DEBUG - 2015-12-05 13:10:05 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:10:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:10:05 --> URI Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Router Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Output Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Security Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Input Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:10:05 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Loader Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:10:05 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:10:05 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Session Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:10:05 --> Session routines successfully run
DEBUG - 2015-12-05 13:10:05 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Email Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Controller Class Initialized
DEBUG - 2015-12-05 13:10:05 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:10:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:10:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:10:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:10:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:10:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:10:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:10:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:10:05 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:10:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:10:05 --> Final output sent to browser
DEBUG - 2015-12-05 13:10:05 --> Total execution time: 0.2537
DEBUG - 2015-12-05 13:10:18 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:10:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:10:18 --> URI Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Router Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Output Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Security Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Input Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:10:18 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Loader Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:10:18 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:10:18 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Session Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:10:18 --> Session routines successfully run
DEBUG - 2015-12-05 13:10:18 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Email Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Controller Class Initialized
DEBUG - 2015-12-05 13:10:18 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:10:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:10:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:10:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:10:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:10:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:10:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:10:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:10:18 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:10:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:10:18 --> Final output sent to browser
DEBUG - 2015-12-05 13:10:18 --> Total execution time: 0.2608
DEBUG - 2015-12-05 13:10:29 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:10:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:10:29 --> URI Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Router Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Output Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Security Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Input Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:10:29 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Loader Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:10:29 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:10:29 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Session Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:10:29 --> Session routines successfully run
DEBUG - 2015-12-05 13:10:29 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Email Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Controller Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:10:29 --> XSS Filtering completed
DEBUG - 2015-12-05 13:10:29 --> XSS Filtering completed
DEBUG - 2015-12-05 13:10:29 --> XSS Filtering completed
DEBUG - 2015-12-05 13:10:29 --> XSS Filtering completed
DEBUG - 2015-12-05 13:10:29 --> XSS Filtering completed
DEBUG - 2015-12-05 13:10:29 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:10:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:10:29 --> URI Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Router Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Output Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Security Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Input Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:10:29 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Loader Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:10:29 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:10:29 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Session Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:10:29 --> Session routines successfully run
DEBUG - 2015-12-05 13:10:29 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Email Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Controller Class Initialized
DEBUG - 2015-12-05 13:10:29 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:10:29 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:10:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:10:29 --> Final output sent to browser
DEBUG - 2015-12-05 13:10:29 --> Total execution time: 0.2528
DEBUG - 2015-12-05 13:10:31 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:10:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:10:31 --> URI Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Router Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Output Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Security Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Input Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:10:31 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Language Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Config Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Loader Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:10:31 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:10:31 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Session Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:10:31 --> Session routines successfully run
DEBUG - 2015-12-05 13:10:31 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Email Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Controller Class Initialized
DEBUG - 2015-12-05 13:10:31 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:10:31 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:10:31 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:10:31 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:10:31 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:10:31 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:10:31 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:10:31 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:10:31 --> Model Class Initialized
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:10:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:10:31 --> Final output sent to browser
DEBUG - 2015-12-05 13:10:31 --> Total execution time: 0.2777
DEBUG - 2015-12-05 13:12:58 --> Config Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:12:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:12:58 --> URI Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Router Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Output Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Security Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Input Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:12:58 --> Language Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Language Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Config Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Loader Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:12:58 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:12:58 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Session Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:12:58 --> Session routines successfully run
DEBUG - 2015-12-05 13:12:58 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Email Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Controller Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:12:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:12:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:12:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:12:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:12:58 --> XSS Filtering completed
DEBUG - 2015-12-05 13:12:58 --> Config Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:12:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:12:58 --> URI Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Router Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Output Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Security Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Input Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:12:58 --> Language Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Language Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Config Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Loader Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:12:58 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:12:58 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Session Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:12:58 --> Session routines successfully run
DEBUG - 2015-12-05 13:12:58 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Email Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Controller Class Initialized
DEBUG - 2015-12-05 13:12:58 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:12:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:12:58 --> Final output sent to browser
DEBUG - 2015-12-05 13:12:58 --> Total execution time: 0.2211
DEBUG - 2015-12-05 13:29:39 --> Config Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:29:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:29:39 --> URI Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Router Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Output Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Security Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Input Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:29:39 --> Language Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Language Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Config Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Loader Class Initialized
DEBUG - 2015-12-05 13:29:39 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:29:39 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:29:39 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:29:40 --> Session Class Initialized
DEBUG - 2015-12-05 13:29:40 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:29:40 --> Session routines successfully run
DEBUG - 2015-12-05 13:29:40 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:29:40 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:29:40 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:29:40 --> Email Class Initialized
DEBUG - 2015-12-05 13:29:40 --> Controller Class Initialized
DEBUG - 2015-12-05 13:29:40 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:29:40 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:29:40 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:29:40 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:29:40 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:29:40 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:29:40 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:29:40 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:29:40 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:29:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:29:40 --> Final output sent to browser
DEBUG - 2015-12-05 13:29:40 --> Total execution time: 0.2626
DEBUG - 2015-12-05 13:29:54 --> Config Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:29:54 --> URI Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Router Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Output Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Security Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Input Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:29:54 --> Language Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Language Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Config Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Loader Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:29:54 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:29:54 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Session Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:29:54 --> Session routines successfully run
DEBUG - 2015-12-05 13:29:54 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Email Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Controller Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:29:54 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:29:54 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:29:54 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:29:54 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:29:54 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:29:54 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:29:54 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:29:54 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:29:54 --> XSS Filtering completed
DEBUG - 2015-12-05 13:29:54 --> XSS Filtering completed
DEBUG - 2015-12-05 13:29:54 --> XSS Filtering completed
DEBUG - 2015-12-05 13:29:54 --> XSS Filtering completed
DEBUG - 2015-12-05 13:29:54 --> XSS Filtering completed
DEBUG - 2015-12-05 13:29:54 --> Config Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:29:54 --> URI Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Router Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Output Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Security Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Input Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:29:54 --> Language Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Language Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Config Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Loader Class Initialized
DEBUG - 2015-12-05 13:29:54 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:29:55 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:29:55 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:29:55 --> Session Class Initialized
DEBUG - 2015-12-05 13:29:55 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:29:55 --> Session routines successfully run
DEBUG - 2015-12-05 13:29:55 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:29:55 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:29:55 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:29:55 --> Email Class Initialized
DEBUG - 2015-12-05 13:29:55 --> Controller Class Initialized
DEBUG - 2015-12-05 13:29:55 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:29:55 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:29:55 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:29:55 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:29:55 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:29:55 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:29:55 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:29:55 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:29:55 --> Model Class Initialized
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:29:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:29:55 --> Final output sent to browser
DEBUG - 2015-12-05 13:29:55 --> Total execution time: 0.2194
DEBUG - 2015-12-05 13:30:00 --> Config Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:30:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:30:00 --> URI Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Router Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Output Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Security Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Input Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:30:00 --> Language Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Language Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Config Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Loader Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:30:00 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:30:00 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Session Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:30:00 --> Session routines successfully run
DEBUG - 2015-12-05 13:30:00 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Email Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Controller Class Initialized
DEBUG - 2015-12-05 13:30:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:30:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:30:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:30:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:30:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:30:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:30:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:30:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:30:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:30:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:30:00 --> Final output sent to browser
DEBUG - 2015-12-05 13:30:00 --> Total execution time: 0.2623
DEBUG - 2015-12-05 13:30:22 --> Config Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:30:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:30:22 --> URI Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Router Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Output Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Security Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Input Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:30:22 --> Language Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Language Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Config Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Loader Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:30:22 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:30:22 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Session Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:30:22 --> Session routines successfully run
DEBUG - 2015-12-05 13:30:22 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Email Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Controller Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:30:22 --> XSS Filtering completed
DEBUG - 2015-12-05 13:30:22 --> XSS Filtering completed
DEBUG - 2015-12-05 13:30:22 --> XSS Filtering completed
DEBUG - 2015-12-05 13:30:22 --> XSS Filtering completed
DEBUG - 2015-12-05 13:30:22 --> XSS Filtering completed
DEBUG - 2015-12-05 13:30:22 --> Config Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:30:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:30:22 --> URI Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Router Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Output Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Security Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Input Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:30:22 --> Language Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Language Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Config Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Loader Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:30:22 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:30:22 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Session Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:30:22 --> Session routines successfully run
DEBUG - 2015-12-05 13:30:22 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Email Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Controller Class Initialized
DEBUG - 2015-12-05 13:30:22 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:30:22 --> Model Class Initialized
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:30:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:30:22 --> Final output sent to browser
DEBUG - 2015-12-05 13:30:22 --> Total execution time: 0.2306
DEBUG - 2015-12-05 13:34:35 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:35 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:34:35 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:34:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:34:35 --> URI Class Initialized
DEBUG - 2015-12-05 13:34:35 --> Router Class Initialized
DEBUG - 2015-12-05 13:34:35 --> Output Class Initialized
DEBUG - 2015-12-05 13:34:35 --> Security Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Input Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:34:36 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Loader Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:34:36 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:34:36 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Session Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:34:36 --> Session routines successfully run
DEBUG - 2015-12-05 13:34:36 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Email Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Controller Class Initialized
DEBUG - 2015-12-05 13:34:36 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:34:36 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:34:36 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:34:36 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:34:36 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:34:36 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:34:36 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:34:36 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:34:36 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:34:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:34:36 --> Final output sent to browser
DEBUG - 2015-12-05 13:34:36 --> Total execution time: 0.2522
DEBUG - 2015-12-05 13:34:43 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:34:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:34:43 --> URI Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Router Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Output Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Security Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Input Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:34:43 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Loader Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:34:43 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:34:43 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Session Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:34:43 --> Session routines successfully run
DEBUG - 2015-12-05 13:34:43 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Email Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Controller Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:34:43 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:43 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:43 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:43 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:43 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:43 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:34:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:34:43 --> URI Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Router Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Output Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Security Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Input Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:34:43 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Loader Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:34:43 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:34:43 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Session Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:34:43 --> Session routines successfully run
DEBUG - 2015-12-05 13:34:43 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Email Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Controller Class Initialized
DEBUG - 2015-12-05 13:34:43 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:34:43 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:34:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:34:43 --> Final output sent to browser
DEBUG - 2015-12-05 13:34:43 --> Total execution time: 0.2197
DEBUG - 2015-12-05 13:34:48 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:34:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:34:48 --> URI Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Router Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Output Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Security Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Input Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:34:48 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Loader Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:34:48 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:34:48 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Session Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:34:48 --> Session routines successfully run
DEBUG - 2015-12-05 13:34:48 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Email Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Controller Class Initialized
DEBUG - 2015-12-05 13:34:48 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:34:48 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:34:48 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:34:48 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:34:48 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:34:48 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:34:48 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:34:48 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:34:48 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:34:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:34:48 --> Final output sent to browser
DEBUG - 2015-12-05 13:34:48 --> Total execution time: 0.2655
DEBUG - 2015-12-05 13:34:56 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:34:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:34:56 --> URI Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Router Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Output Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Security Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Input Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:34:56 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Loader Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:34:56 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:34:56 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Session Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:34:56 --> Session routines successfully run
DEBUG - 2015-12-05 13:34:56 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Email Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Controller Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:34:56 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:56 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:56 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:56 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:56 --> XSS Filtering completed
DEBUG - 2015-12-05 13:34:56 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:34:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:34:56 --> URI Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Router Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Output Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Security Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Input Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:34:56 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Language Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Config Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Loader Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:34:56 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:34:56 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Session Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:34:56 --> Session routines successfully run
DEBUG - 2015-12-05 13:34:56 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Email Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Controller Class Initialized
DEBUG - 2015-12-05 13:34:56 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:34:56 --> Model Class Initialized
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:34:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:34:56 --> Final output sent to browser
DEBUG - 2015-12-05 13:34:56 --> Total execution time: 0.2577
DEBUG - 2015-12-05 13:35:00 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:35:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:35:00 --> URI Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Router Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Output Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Security Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Input Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:35:00 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Loader Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:35:00 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:35:00 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Session Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:35:00 --> Session routines successfully run
DEBUG - 2015-12-05 13:35:00 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Email Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Controller Class Initialized
DEBUG - 2015-12-05 13:35:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:35:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:35:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:35:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:35:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:35:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:35:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:35:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:35:00 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:35:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:35:00 --> Final output sent to browser
DEBUG - 2015-12-05 13:35:00 --> Total execution time: 0.2533
DEBUG - 2015-12-05 13:35:12 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:35:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:35:12 --> URI Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Router Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Output Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Security Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Input Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:35:12 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Loader Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:35:12 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:35:12 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Session Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:35:12 --> Session routines successfully run
DEBUG - 2015-12-05 13:35:12 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Email Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Controller Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:35:12 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:35:12 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:35:12 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:35:12 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:35:12 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:35:12 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:35:12 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:35:12 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:35:12 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:12 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:12 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:12 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:12 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:13 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:35:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:35:13 --> URI Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Router Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Output Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Security Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Input Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:35:13 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Loader Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:35:13 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:35:13 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Session Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:35:13 --> Session routines successfully run
DEBUG - 2015-12-05 13:35:13 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Email Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Controller Class Initialized
DEBUG - 2015-12-05 13:35:13 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:35:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:35:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:35:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:35:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:35:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:35:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:35:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:35:13 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:35:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:35:13 --> Final output sent to browser
DEBUG - 2015-12-05 13:35:13 --> Total execution time: 0.2797
DEBUG - 2015-12-05 13:35:17 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:35:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:35:17 --> URI Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Router Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Output Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Security Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Input Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:35:17 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Loader Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:35:17 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:35:17 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Session Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:35:17 --> Session routines successfully run
DEBUG - 2015-12-05 13:35:17 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Email Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Controller Class Initialized
DEBUG - 2015-12-05 13:35:17 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:35:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:35:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:35:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:35:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:35:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:35:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:35:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:35:17 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:35:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:35:17 --> Final output sent to browser
DEBUG - 2015-12-05 13:35:17 --> Total execution time: 0.2422
DEBUG - 2015-12-05 13:35:33 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:33 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:35:33 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:35:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:35:33 --> URI Class Initialized
DEBUG - 2015-12-05 13:35:33 --> Router Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Output Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Security Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Input Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:35:34 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Loader Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:35:34 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:35:34 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Session Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:35:34 --> Session routines successfully run
DEBUG - 2015-12-05 13:35:34 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Email Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Controller Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-05 13:35:34 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:34 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:34 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:34 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:34 --> XSS Filtering completed
DEBUG - 2015-12-05 13:35:34 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Hooks Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Utf8 Class Initialized
DEBUG - 2015-12-05 13:35:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-05 13:35:34 --> URI Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Router Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Output Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Security Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Input Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-05 13:35:34 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Language Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Config Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Loader Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Helper loaded: url_helper
DEBUG - 2015-12-05 13:35:34 --> Helper loaded: form_helper
DEBUG - 2015-12-05 13:35:34 --> Database Driver Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Session Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Helper loaded: string_helper
DEBUG - 2015-12-05 13:35:34 --> Session routines successfully run
DEBUG - 2015-12-05 13:35:34 --> Form Validation Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Pagination Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Encrypt Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Email Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Controller Class Initialized
DEBUG - 2015-12-05 13:35:34 --> Sections MX_Controller Initialized
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-05 13:35:34 --> Model Class Initialized
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-05 13:35:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-05 13:35:34 --> Final output sent to browser
DEBUG - 2015-12-05 13:35:34 --> Total execution time: 0.2211
