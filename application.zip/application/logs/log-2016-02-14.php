<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-14 08:01:13 --> Config Class Initialized
DEBUG - 2016-02-14 08:01:13 --> Hooks Class Initialized
DEBUG - 2016-02-14 08:01:13 --> Utf8 Class Initialized
DEBUG - 2016-02-14 08:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-02-14 08:01:13 --> URI Class Initialized
DEBUG - 2016-02-14 08:01:14 --> Router Class Initialized
DEBUG - 2016-02-14 08:01:17 --> No URI present. Default controller set.
DEBUG - 2016-02-14 08:01:17 --> Output Class Initialized
DEBUG - 2016-02-14 08:01:17 --> Security Class Initialized
DEBUG - 2016-02-14 08:01:18 --> Input Class Initialized
DEBUG - 2016-02-14 08:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-14 08:01:18 --> Language Class Initialized
DEBUG - 2016-02-14 08:01:19 --> Language Class Initialized
DEBUG - 2016-02-14 08:01:19 --> Config Class Initialized
DEBUG - 2016-02-14 08:01:19 --> Loader Class Initialized
DEBUG - 2016-02-14 08:01:20 --> Helper loaded: url_helper
DEBUG - 2016-02-14 08:01:20 --> Helper loaded: form_helper
DEBUG - 2016-02-14 08:01:23 --> Database Driver Class Initialized
DEBUG - 2016-02-14 08:01:27 --> Session Class Initialized
DEBUG - 2016-02-14 08:01:27 --> Helper loaded: string_helper
DEBUG - 2016-02-14 08:01:27 --> A session cookie was not found.
DEBUG - 2016-02-14 08:01:27 --> Session routines successfully run
DEBUG - 2016-02-14 08:01:27 --> Form Validation Class Initialized
DEBUG - 2016-02-14 08:01:27 --> Pagination Class Initialized
DEBUG - 2016-02-14 08:01:28 --> Encrypt Class Initialized
DEBUG - 2016-02-14 08:01:28 --> Email Class Initialized
DEBUG - 2016-02-14 08:01:28 --> Controller Class Initialized
DEBUG - 2016-02-14 08:01:28 --> Auth MX_Controller Initialized
DEBUG - 2016-02-14 08:01:29 --> Model Class Initialized
DEBUG - 2016-02-14 08:01:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-14 08:01:29 --> Model Class Initialized
DEBUG - 2016-02-14 08:01:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-14 08:01:29 --> Model Class Initialized
