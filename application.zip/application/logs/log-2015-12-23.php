<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-23 07:34:26 --> Config Class Initialized
DEBUG - 2015-12-23 07:34:26 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:34:26 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:34:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:34:26 --> URI Class Initialized
DEBUG - 2015-12-23 07:34:26 --> Router Class Initialized
ERROR - 2015-12-23 07:34:26 --> 404 Page Not Found --> 
DEBUG - 2015-12-23 07:36:34 --> Config Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:36:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:36:34 --> URI Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Router Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Output Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Security Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Input Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:36:34 --> Language Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Language Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Config Class Initialized
DEBUG - 2015-12-23 07:36:34 --> Loader Class Initialized
DEBUG - 2015-12-23 07:36:35 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:36:35 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:36:35 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:36:35 --> Session Class Initialized
DEBUG - 2015-12-23 07:36:35 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:36:35 --> A session cookie was not found.
DEBUG - 2015-12-23 07:36:35 --> Session routines successfully run
DEBUG - 2015-12-23 07:36:35 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:36:35 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:36:35 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:36:35 --> Email Class Initialized
DEBUG - 2015-12-23 07:36:35 --> Controller Class Initialized
DEBUG - 2015-12-23 07:36:35 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:36:35 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:36:35 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:36:35 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:36:35 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:36:35 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:36:35 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:36:35 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:36:35 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 07:36:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 07:36:35 --> Final output sent to browser
DEBUG - 2015-12-23 07:36:35 --> Total execution time: 0.9010
DEBUG - 2015-12-23 07:36:38 --> Config Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:36:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:36:38 --> URI Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Router Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Output Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Security Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Input Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:36:38 --> Language Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Language Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Config Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Loader Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:36:38 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:36:38 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Session Class Initialized
DEBUG - 2015-12-23 07:36:38 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:36:38 --> Session routines successfully run
DEBUG - 2015-12-23 07:36:39 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:36:39 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:36:39 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:36:39 --> Email Class Initialized
DEBUG - 2015-12-23 07:36:39 --> Controller Class Initialized
DEBUG - 2015-12-23 07:36:39 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:36:39 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:39 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:36:39 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:36:39 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:36:39 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:36:39 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:36:39 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:36:39 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:39 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:36:39 --> Model Class Initialized
DEBUG - 2015-12-23 07:36:39 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:36:39 --> Final output sent to browser
DEBUG - 2015-12-23 07:36:39 --> Total execution time: 0.2645
DEBUG - 2015-12-23 07:38:10 --> Config Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:38:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:38:10 --> URI Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Router Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Output Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Security Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Input Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:38:10 --> Language Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Language Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Config Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Loader Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:38:10 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:38:10 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Session Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:38:10 --> Session routines successfully run
DEBUG - 2015-12-23 07:38:10 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Email Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Controller Class Initialized
DEBUG - 2015-12-23 07:38:10 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:38:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:10 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:38:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:38:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:38:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:38:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:38:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:38:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:10 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:38:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:10 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:38:10 --> Final output sent to browser
DEBUG - 2015-12-23 07:38:10 --> Total execution time: 0.1961
DEBUG - 2015-12-23 07:38:12 --> Config Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:38:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:38:12 --> URI Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Router Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Output Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Security Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Input Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:38:12 --> Language Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Language Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Config Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Loader Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:38:12 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:38:12 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Session Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:38:12 --> Session routines successfully run
DEBUG - 2015-12-23 07:38:12 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Email Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Controller Class Initialized
DEBUG - 2015-12-23 07:38:12 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:38:12 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:12 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:38:12 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:38:12 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:38:12 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:38:12 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:38:12 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:38:12 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:12 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:38:12 --> Model Class Initialized
DEBUG - 2015-12-23 07:38:12 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:38:12 --> Final output sent to browser
DEBUG - 2015-12-23 07:38:12 --> Total execution time: 0.2433
DEBUG - 2015-12-23 07:39:44 --> Config Class Initialized
DEBUG - 2015-12-23 07:39:44 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:39:44 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:39:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:39:45 --> URI Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Router Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Output Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Security Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Input Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:39:45 --> Language Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Language Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Config Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Loader Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:39:45 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:39:45 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Session Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:39:45 --> Session routines successfully run
DEBUG - 2015-12-23 07:39:45 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Email Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Controller Class Initialized
DEBUG - 2015-12-23 07:39:45 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:39:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:39:45 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:39:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:39:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:39:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:39:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:39:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:39:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:39:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:39:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:39:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:39:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:39:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:39:45 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:39:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:39:45 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:39:45 --> Final output sent to browser
DEBUG - 2015-12-23 07:39:45 --> Total execution time: 0.2170
DEBUG - 2015-12-23 07:40:42 --> Config Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:40:42 --> URI Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Router Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Output Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Security Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Input Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:40:42 --> Language Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Language Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Config Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Loader Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:40:42 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:40:42 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Session Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:40:42 --> Session routines successfully run
DEBUG - 2015-12-23 07:40:42 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Email Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Controller Class Initialized
DEBUG - 2015-12-23 07:40:42 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:40:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:42 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:40:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:40:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:40:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:40:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:40:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:40:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:42 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:40:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:42 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:40:42 --> Final output sent to browser
DEBUG - 2015-12-23 07:40:42 --> Total execution time: 0.3426
DEBUG - 2015-12-23 07:40:44 --> Config Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:40:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:40:44 --> URI Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Router Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Output Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Security Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Input Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:40:44 --> Language Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Language Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Config Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Loader Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:40:44 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:40:44 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Session Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:40:44 --> Session routines successfully run
DEBUG - 2015-12-23 07:40:44 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Email Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Controller Class Initialized
DEBUG - 2015-12-23 07:40:44 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:40:44 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:44 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:40:44 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:40:44 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:40:44 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:40:44 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:40:44 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:40:44 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:44 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:40:44 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:44 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:40:44 --> Final output sent to browser
DEBUG - 2015-12-23 07:40:44 --> Total execution time: 0.1839
DEBUG - 2015-12-23 07:40:45 --> Config Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:40:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:40:45 --> URI Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Router Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Output Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Security Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Input Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:40:45 --> Language Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Language Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Config Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Loader Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:40:45 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:40:45 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Session Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:40:45 --> Session routines successfully run
DEBUG - 2015-12-23 07:40:45 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Email Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Controller Class Initialized
DEBUG - 2015-12-23 07:40:45 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:40:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:45 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:40:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:40:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:40:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:40:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:40:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:40:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:45 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:40:45 --> Model Class Initialized
DEBUG - 2015-12-23 07:40:45 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:40:45 --> Final output sent to browser
DEBUG - 2015-12-23 07:40:45 --> Total execution time: 0.2641
DEBUG - 2015-12-23 07:41:22 --> Config Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:41:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:41:22 --> URI Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Router Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Output Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Security Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Input Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:41:22 --> Language Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Language Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Config Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Loader Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:41:22 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:41:22 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Session Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:41:22 --> Session routines successfully run
DEBUG - 2015-12-23 07:41:22 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Email Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Controller Class Initialized
DEBUG - 2015-12-23 07:41:22 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:41:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:41:22 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:41:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:41:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:41:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:41:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:41:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:41:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:41:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:41:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:41:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:41:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:41:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:41:22 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:41:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:41:22 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:41:22 --> Final output sent to browser
DEBUG - 2015-12-23 07:41:22 --> Total execution time: 0.2121
DEBUG - 2015-12-23 07:42:16 --> Config Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:42:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:42:16 --> URI Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Router Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Output Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Security Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Input Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:42:16 --> Language Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Language Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Config Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Loader Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:42:16 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:42:16 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Session Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:42:16 --> Session routines successfully run
DEBUG - 2015-12-23 07:42:16 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Email Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Controller Class Initialized
DEBUG - 2015-12-23 07:42:16 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:42:16 --> Model Class Initialized
DEBUG - 2015-12-23 07:42:16 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:42:16 --> Model Class Initialized
DEBUG - 2015-12-23 07:42:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:42:16 --> Model Class Initialized
DEBUG - 2015-12-23 07:42:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:42:16 --> Model Class Initialized
DEBUG - 2015-12-23 07:42:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:42:16 --> Model Class Initialized
DEBUG - 2015-12-23 07:42:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:42:16 --> Model Class Initialized
DEBUG - 2015-12-23 07:42:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:42:16 --> Model Class Initialized
DEBUG - 2015-12-23 07:42:16 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:42:16 --> Model Class Initialized
DEBUG - 2015-12-23 07:42:16 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:42:16 --> Final output sent to browser
DEBUG - 2015-12-23 07:42:16 --> Total execution time: 0.2325
DEBUG - 2015-12-23 07:43:10 --> Config Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:43:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:43:10 --> URI Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Router Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Output Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Security Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Input Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:43:10 --> Language Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Language Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Config Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Loader Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:43:10 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:43:10 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Session Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:43:10 --> Session routines successfully run
DEBUG - 2015-12-23 07:43:10 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Email Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Controller Class Initialized
DEBUG - 2015-12-23 07:43:10 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:43:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:10 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:43:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:43:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:43:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:43:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:43:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:43:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:10 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:43:10 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:10 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:43:10 --> Final output sent to browser
DEBUG - 2015-12-23 07:43:10 --> Total execution time: 0.1931
DEBUG - 2015-12-23 07:43:22 --> Config Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:43:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:43:22 --> URI Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Router Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Output Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Security Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Input Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:43:22 --> Language Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Language Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Config Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Loader Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:43:22 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:43:22 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Session Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:43:22 --> Session routines successfully run
DEBUG - 2015-12-23 07:43:22 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Email Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Controller Class Initialized
DEBUG - 2015-12-23 07:43:22 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:43:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:22 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:43:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:43:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:43:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:43:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:43:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:43:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:22 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:43:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:22 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:43:22 --> Final output sent to browser
DEBUG - 2015-12-23 07:43:22 --> Total execution time: 0.1911
DEBUG - 2015-12-23 07:43:36 --> Config Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:43:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:43:36 --> URI Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Router Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Output Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Security Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Input Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:43:36 --> Language Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Language Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Config Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Loader Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:43:36 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:43:36 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Session Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:43:36 --> Session routines successfully run
DEBUG - 2015-12-23 07:43:36 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Email Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Controller Class Initialized
DEBUG - 2015-12-23 07:43:36 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:43:36 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:36 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:43:36 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:43:36 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:43:36 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:43:36 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:43:36 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:43:36 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:36 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:43:36 --> Model Class Initialized
DEBUG - 2015-12-23 07:43:36 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:43:36 --> Final output sent to browser
DEBUG - 2015-12-23 07:43:36 --> Total execution time: 0.2251
DEBUG - 2015-12-23 07:45:30 --> Config Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:45:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:45:30 --> URI Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Router Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Output Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Security Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Input Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:45:30 --> Language Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Language Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Config Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Loader Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:45:30 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:45:30 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Session Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:45:30 --> Session routines successfully run
DEBUG - 2015-12-23 07:45:30 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Email Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Controller Class Initialized
DEBUG - 2015-12-23 07:45:30 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:45:30 --> Model Class Initialized
DEBUG - 2015-12-23 07:45:30 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:45:30 --> Model Class Initialized
DEBUG - 2015-12-23 07:45:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:45:30 --> Model Class Initialized
DEBUG - 2015-12-23 07:45:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:45:30 --> Model Class Initialized
DEBUG - 2015-12-23 07:45:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:45:30 --> Model Class Initialized
DEBUG - 2015-12-23 07:45:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:45:30 --> Model Class Initialized
DEBUG - 2015-12-23 07:45:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:45:30 --> Model Class Initialized
DEBUG - 2015-12-23 07:45:30 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:45:30 --> Model Class Initialized
DEBUG - 2015-12-23 07:45:30 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:45:30 --> Final output sent to browser
DEBUG - 2015-12-23 07:45:30 --> Total execution time: 0.1913
DEBUG - 2015-12-23 07:46:19 --> Config Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:46:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:46:19 --> URI Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Router Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Output Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Security Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Input Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:46:19 --> Language Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Language Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Config Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Loader Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:46:19 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:46:19 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Session Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:46:19 --> Session routines successfully run
DEBUG - 2015-12-23 07:46:19 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Email Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Controller Class Initialized
DEBUG - 2015-12-23 07:46:19 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:46:20 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:20 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:46:20 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:46:20 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:46:20 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:46:20 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:46:20 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:46:20 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:20 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:46:20 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:20 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:46:20 --> Final output sent to browser
DEBUG - 2015-12-23 07:46:20 --> Total execution time: 0.2401
DEBUG - 2015-12-23 07:46:21 --> Config Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:46:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:46:21 --> URI Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Router Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Output Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Security Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Input Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:46:21 --> Language Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Language Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Config Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Loader Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:46:21 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:46:21 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Session Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:46:21 --> Session routines successfully run
DEBUG - 2015-12-23 07:46:21 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Email Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Controller Class Initialized
DEBUG - 2015-12-23 07:46:21 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:46:21 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:21 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:46:21 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:46:21 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:46:21 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:46:21 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:46:21 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:46:21 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:21 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:46:21 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:21 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:46:21 --> Final output sent to browser
DEBUG - 2015-12-23 07:46:21 --> Total execution time: 0.2532
DEBUG - 2015-12-23 07:46:22 --> Config Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:46:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:46:22 --> URI Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Router Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Output Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Security Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Input Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:46:22 --> Language Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Language Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Config Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Loader Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:46:22 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:46:22 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Session Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:46:22 --> Session routines successfully run
DEBUG - 2015-12-23 07:46:22 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Email Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Controller Class Initialized
DEBUG - 2015-12-23 07:46:22 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:46:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:22 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:46:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:46:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:46:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:46:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:46:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:46:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:22 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:46:22 --> Model Class Initialized
DEBUG - 2015-12-23 07:46:22 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:46:22 --> Final output sent to browser
DEBUG - 2015-12-23 07:46:22 --> Total execution time: 0.1876
DEBUG - 2015-12-23 07:47:09 --> Config Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:47:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:47:09 --> URI Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Router Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Output Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Security Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Input Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:47:09 --> Language Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Language Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Config Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Loader Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:47:09 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:47:09 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Session Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:47:09 --> Session routines successfully run
DEBUG - 2015-12-23 07:47:09 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Email Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Controller Class Initialized
DEBUG - 2015-12-23 07:47:09 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:47:09 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:09 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:47:09 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:47:09 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:47:09 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:47:09 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:47:09 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:47:09 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:09 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:47:09 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:09 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:47:09 --> Final output sent to browser
DEBUG - 2015-12-23 07:47:09 --> Total execution time: 0.1863
DEBUG - 2015-12-23 07:47:33 --> Config Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:47:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:47:33 --> URI Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Router Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Output Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Security Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Input Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:47:33 --> Language Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Language Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Config Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Loader Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:47:33 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:47:33 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Session Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:47:33 --> Session routines successfully run
DEBUG - 2015-12-23 07:47:33 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Email Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Controller Class Initialized
DEBUG - 2015-12-23 07:47:33 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:47:33 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:33 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:47:33 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:47:33 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:47:33 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:47:33 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:47:33 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:47:33 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:33 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:47:33 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:33 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:47:33 --> Final output sent to browser
DEBUG - 2015-12-23 07:47:33 --> Total execution time: 0.2008
DEBUG - 2015-12-23 07:47:42 --> Config Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:47:42 --> URI Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Router Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Output Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Security Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Input Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:47:42 --> Language Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Language Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Config Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Loader Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:47:42 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:47:42 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Session Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:47:42 --> Session routines successfully run
DEBUG - 2015-12-23 07:47:42 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Email Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Controller Class Initialized
DEBUG - 2015-12-23 07:47:42 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:47:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:42 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:47:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:47:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:47:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:47:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:47:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:47:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:42 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:47:42 --> Model Class Initialized
DEBUG - 2015-12-23 07:47:42 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:47:42 --> Final output sent to browser
DEBUG - 2015-12-23 07:47:42 --> Total execution time: 0.2298
DEBUG - 2015-12-23 07:59:58 --> Config Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Hooks Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Utf8 Class Initialized
DEBUG - 2015-12-23 07:59:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 07:59:58 --> URI Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Router Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Output Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Security Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Input Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 07:59:58 --> Language Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Language Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Config Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Loader Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Helper loaded: url_helper
DEBUG - 2015-12-23 07:59:58 --> Helper loaded: form_helper
DEBUG - 2015-12-23 07:59:58 --> Database Driver Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Session Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Helper loaded: string_helper
DEBUG - 2015-12-23 07:59:58 --> Session routines successfully run
DEBUG - 2015-12-23 07:59:58 --> Form Validation Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Pagination Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Encrypt Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Email Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Controller Class Initialized
DEBUG - 2015-12-23 07:59:58 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 07:59:58 --> Model Class Initialized
DEBUG - 2015-12-23 07:59:58 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 07:59:58 --> Model Class Initialized
DEBUG - 2015-12-23 07:59:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 07:59:58 --> Model Class Initialized
DEBUG - 2015-12-23 07:59:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 07:59:58 --> Model Class Initialized
DEBUG - 2015-12-23 07:59:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 07:59:58 --> Model Class Initialized
DEBUG - 2015-12-23 07:59:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 07:59:58 --> Model Class Initialized
DEBUG - 2015-12-23 07:59:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 07:59:58 --> Model Class Initialized
DEBUG - 2015-12-23 07:59:58 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 07:59:58 --> Model Class Initialized
DEBUG - 2015-12-23 07:59:58 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 07:59:58 --> Final output sent to browser
DEBUG - 2015-12-23 07:59:58 --> Total execution time: 0.2807
DEBUG - 2015-12-23 08:00:41 --> Config Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:00:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:00:41 --> URI Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Router Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Output Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Security Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Input Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:00:41 --> Language Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Language Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Config Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Loader Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:00:41 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:00:41 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Session Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:00:41 --> Session routines successfully run
DEBUG - 2015-12-23 08:00:41 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Email Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Controller Class Initialized
DEBUG - 2015-12-23 08:00:41 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:00:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:00:41 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:00:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:00:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:00:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:00:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:00:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:00:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:00:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:00:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:00:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:00:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:00:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:00:41 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:00:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:00:41 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 08:00:41 --> Final output sent to browser
DEBUG - 2015-12-23 08:00:41 --> Total execution time: 0.2553
DEBUG - 2015-12-23 08:20:55 --> Config Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:20:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:20:56 --> URI Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Router Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Output Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Security Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Input Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:20:56 --> Language Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Language Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Config Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Loader Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:20:56 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:20:56 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Session Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:20:56 --> Session routines successfully run
DEBUG - 2015-12-23 08:20:56 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Email Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Controller Class Initialized
DEBUG - 2015-12-23 08:20:56 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:20:56 --> Model Class Initialized
DEBUG - 2015-12-23 08:20:56 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:20:56 --> Model Class Initialized
DEBUG - 2015-12-23 08:20:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:20:56 --> Model Class Initialized
DEBUG - 2015-12-23 08:20:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:20:56 --> Model Class Initialized
DEBUG - 2015-12-23 08:20:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:20:56 --> Model Class Initialized
DEBUG - 2015-12-23 08:20:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:20:56 --> Model Class Initialized
DEBUG - 2015-12-23 08:20:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:20:56 --> Model Class Initialized
DEBUG - 2015-12-23 08:20:56 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:20:56 --> Model Class Initialized
ERROR - 2015-12-23 08:20:57 --> Severity: Notice  --> Undefined property: stdClass::$receipt_number C:\xampp\htdocs\rents\application\modules\water_management\views\reading_reports.php 733
ERROR - 2015-12-23 08:20:57 --> Severity: Notice  --> Undefined property: stdClass::$receipt_number C:\xampp\htdocs\rents\application\modules\water_management\views\reading_reports.php 733
DEBUG - 2015-12-23 08:20:57 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 08:20:57 --> Final output sent to browser
DEBUG - 2015-12-23 08:20:57 --> Total execution time: 1.1106
DEBUG - 2015-12-23 08:21:07 --> Config Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:21:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:21:07 --> URI Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Router Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Output Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Security Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Input Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:21:07 --> Language Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Language Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Config Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Loader Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:21:07 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:21:07 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Session Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:21:07 --> Session routines successfully run
DEBUG - 2015-12-23 08:21:07 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Email Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Controller Class Initialized
DEBUG - 2015-12-23 08:21:07 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:21:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:07 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:21:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:21:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:21:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:21:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:21:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:21:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:07 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:21:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:07 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 08:21:07 --> Final output sent to browser
DEBUG - 2015-12-23 08:21:07 --> Total execution time: 0.2098
DEBUG - 2015-12-23 08:21:41 --> Config Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:21:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:21:41 --> URI Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Router Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Output Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Security Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Input Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:21:41 --> Language Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Language Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Config Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Loader Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:21:41 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:21:41 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Session Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:21:41 --> Session routines successfully run
DEBUG - 2015-12-23 08:21:41 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Email Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Controller Class Initialized
DEBUG - 2015-12-23 08:21:41 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:21:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:41 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:21:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:21:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:21:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:21:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:21:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:21:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:41 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:21:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:21:41 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 08:21:41 --> Final output sent to browser
DEBUG - 2015-12-23 08:21:41 --> Total execution time: 0.2170
DEBUG - 2015-12-23 08:24:24 --> Config Class Initialized
DEBUG - 2015-12-23 08:24:24 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:24:24 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:24:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:24:24 --> URI Class Initialized
DEBUG - 2015-12-23 08:24:24 --> Router Class Initialized
DEBUG - 2015-12-23 08:24:24 --> Output Class Initialized
DEBUG - 2015-12-23 08:24:24 --> Security Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Input Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:24:25 --> Language Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Language Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Config Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Loader Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:24:25 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:24:25 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Session Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:24:25 --> Session routines successfully run
DEBUG - 2015-12-23 08:24:25 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Email Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Controller Class Initialized
DEBUG - 2015-12-23 08:24:25 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:24:25 --> Model Class Initialized
DEBUG - 2015-12-23 08:24:25 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:24:25 --> Model Class Initialized
DEBUG - 2015-12-23 08:24:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:24:25 --> Model Class Initialized
DEBUG - 2015-12-23 08:24:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:24:25 --> Model Class Initialized
DEBUG - 2015-12-23 08:24:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:24:25 --> Model Class Initialized
DEBUG - 2015-12-23 08:24:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:24:25 --> Model Class Initialized
DEBUG - 2015-12-23 08:24:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:24:25 --> Model Class Initialized
DEBUG - 2015-12-23 08:24:25 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:24:25 --> Model Class Initialized
DEBUG - 2015-12-23 08:24:25 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 08:24:25 --> Final output sent to browser
DEBUG - 2015-12-23 08:24:25 --> Total execution time: 0.2044
DEBUG - 2015-12-23 08:26:55 --> Config Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:26:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:26:55 --> URI Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Router Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Output Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Security Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Input Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:26:55 --> Language Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Language Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Config Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Loader Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:26:55 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:26:55 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Session Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:26:55 --> Session routines successfully run
DEBUG - 2015-12-23 08:26:55 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Email Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Controller Class Initialized
DEBUG - 2015-12-23 08:26:55 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:26:55 --> Model Class Initialized
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:26:55 --> Model Class Initialized
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:26:55 --> Model Class Initialized
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:26:55 --> Model Class Initialized
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:26:55 --> Model Class Initialized
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:26:55 --> Model Class Initialized
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:26:55 --> Model Class Initialized
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:26:55 --> Model Class Initialized
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:26:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:26:55 --> Final output sent to browser
DEBUG - 2015-12-23 08:26:55 --> Total execution time: 0.3554
DEBUG - 2015-12-23 08:27:09 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:09 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:09 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:09 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:09 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:09 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:10 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:10 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:10 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:10 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:10 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:10 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:10 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:10 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:10 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:27:10 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:10 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:27:10 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:10 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:27:10 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:27:10 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:27:10 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:27:10 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:10 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:27:10 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-23 08:27:10 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:10 --> Upload Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:11 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:11 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:11 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:11 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:11 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:11 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:11 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:27:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:27:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:27:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:27:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:27:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:27:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:27:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:27:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:27:11 --> Final output sent to browser
DEBUG - 2015-12-23 08:27:11 --> Total execution time: 0.2115
DEBUG - 2015-12-23 08:27:29 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:29 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:29 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:29 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:30 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:30 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:30 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:30 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Auth MX_Controller Initialized
DEBUG - 2015-12-23 08:27:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:27:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:30 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:30 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:30 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:30 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:30 --> A session cookie was not found.
DEBUG - 2015-12-23 08:27:30 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:30 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Auth MX_Controller Initialized
DEBUG - 2015-12-23 08:27:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:27:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:27:30 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-23 08:27:30 --> Final output sent to browser
DEBUG - 2015-12-23 08:27:30 --> Total execution time: 0.2091
DEBUG - 2015-12-23 08:27:30 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:30 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:30 --> UTF-8 Support Enabled
ERROR - 2015-12-23 08:27:30 --> 404 Page Not Found --> 
DEBUG - 2015-12-23 08:27:30 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Router Class Initialized
ERROR - 2015-12-23 08:27:30 --> 404 Page Not Found --> 
DEBUG - 2015-12-23 08:27:30 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:30 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:30 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:30 --> Router Class Initialized
ERROR - 2015-12-23 08:27:30 --> 404 Page Not Found --> 
ERROR - 2015-12-23 08:27:30 --> 404 Page Not Found --> 
DEBUG - 2015-12-23 08:27:32 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:32 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:32 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:32 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:32 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:32 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:32 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Auth MX_Controller Initialized
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-23 08:27:32 --> XSS Filtering completed
DEBUG - 2015-12-23 08:27:32 --> Unable to find validation rule: exists
DEBUG - 2015-12-23 08:27:32 --> XSS Filtering completed
DEBUG - 2015-12-23 08:27:32 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:32 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:32 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:32 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:32 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:32 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:32 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:32 --> Admin MX_Controller Initialized
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-23 08:27:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:33 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-23 08:27:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:27:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:27:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:27:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:27:33 --> Final output sent to browser
DEBUG - 2015-12-23 08:27:33 --> Total execution time: 0.3979
DEBUG - 2015-12-23 08:27:40 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:40 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:40 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:40 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:40 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:40 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:40 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:40 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:27:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:27:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:27:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:27:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:27:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:27:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:27:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:27:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:27:40 --> Final output sent to browser
DEBUG - 2015-12-23 08:27:40 --> Total execution time: 0.2749
DEBUG - 2015-12-23 08:27:46 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:46 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:46 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:46 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:46 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:46 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:46 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:27:46 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:46 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:27:46 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:46 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:27:46 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:27:46 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:27:46 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:27:46 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:46 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:27:46 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-23 08:27:46 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Upload Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:46 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:46 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:46 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:46 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:46 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:46 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:46 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:47 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:47 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:47 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:47 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:47 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:27:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:27:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:27:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:27:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:27:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:27:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:27:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:27:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:27:47 --> Final output sent to browser
DEBUG - 2015-12-23 08:27:47 --> Total execution time: 0.2313
DEBUG - 2015-12-23 08:27:49 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:49 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:27:49 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:27:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:27:49 --> URI Class Initialized
DEBUG - 2015-12-23 08:27:49 --> Router Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Output Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Security Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Input Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:27:50 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Language Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Config Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Loader Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:27:50 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:27:50 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Session Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:27:50 --> Session routines successfully run
DEBUG - 2015-12-23 08:27:50 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Email Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Controller Class Initialized
DEBUG - 2015-12-23 08:27:50 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:27:50 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:50 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:27:50 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:27:50 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:27:50 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:27:50 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:27:50 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:27:50 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:50 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:27:50 --> Model Class Initialized
DEBUG - 2015-12-23 08:27:50 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 08:27:50 --> Final output sent to browser
DEBUG - 2015-12-23 08:27:50 --> Total execution time: 0.3377
DEBUG - 2015-12-23 08:29:30 --> Config Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:29:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:29:30 --> URI Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Router Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Output Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Security Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Input Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:29:30 --> Language Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Language Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Config Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Loader Class Initialized
DEBUG - 2015-12-23 08:29:30 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:29:30 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:29:31 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:29:31 --> Session Class Initialized
DEBUG - 2015-12-23 08:29:31 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:29:31 --> Session routines successfully run
DEBUG - 2015-12-23 08:29:31 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:29:31 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:29:31 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:29:31 --> Email Class Initialized
DEBUG - 2015-12-23 08:29:31 --> Controller Class Initialized
DEBUG - 2015-12-23 08:29:31 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:29:31 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:29:31 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:29:31 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:29:31 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:29:31 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:29:31 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:29:31 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:29:31 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:29:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:29:31 --> Final output sent to browser
DEBUG - 2015-12-23 08:29:31 --> Total execution time: 0.3573
DEBUG - 2015-12-23 08:29:36 --> Config Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:29:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:29:36 --> URI Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Router Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Output Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Security Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Input Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:29:36 --> Language Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Language Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Config Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Loader Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:29:36 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:29:36 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Session Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:29:36 --> Session routines successfully run
DEBUG - 2015-12-23 08:29:36 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Email Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Controller Class Initialized
DEBUG - 2015-12-23 08:29:36 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:29:36 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:29:36 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:29:36 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:29:36 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:29:36 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:29:36 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:29:36 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:29:36 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:29:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:29:36 --> Final output sent to browser
DEBUG - 2015-12-23 08:29:36 --> Total execution time: 0.2351
DEBUG - 2015-12-23 08:29:41 --> Config Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:29:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:29:41 --> URI Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Router Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Output Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Security Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Input Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:29:41 --> Language Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Language Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Config Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Loader Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:29:41 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:29:41 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Session Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:29:41 --> Session routines successfully run
DEBUG - 2015-12-23 08:29:41 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Email Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Controller Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Property MX_Controller Initialized
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:29:41 --> Model Class Initialized
DEBUG - 2015-12-23 08:29:41 --> Image Lib Class Initialized
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:29:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:29:41 --> Final output sent to browser
DEBUG - 2015-12-23 08:29:41 --> Total execution time: 0.3450
DEBUG - 2015-12-23 08:30:04 --> Config Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:30:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:30:04 --> URI Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Router Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Output Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Security Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Input Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:30:04 --> Language Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Language Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Config Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Loader Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:30:04 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:30:04 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Session Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:30:04 --> Session routines successfully run
DEBUG - 2015-12-23 08:30:04 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Email Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Controller Class Initialized
DEBUG - 2015-12-23 08:30:04 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:30:04 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:30:04 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:30:04 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:30:04 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:30:04 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:30:04 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:30:04 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:30:04 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:30:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:30:04 --> Final output sent to browser
DEBUG - 2015-12-23 08:30:04 --> Total execution time: 0.2649
DEBUG - 2015-12-23 08:30:29 --> Config Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:30:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:30:29 --> URI Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Router Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Output Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Security Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Input Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:30:29 --> Language Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Language Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Config Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Loader Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:30:29 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:30:29 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Session Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:30:29 --> Session routines successfully run
DEBUG - 2015-12-23 08:30:29 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:30:29 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:30:30 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:30:30 --> Email Class Initialized
DEBUG - 2015-12-23 08:30:30 --> Controller Class Initialized
DEBUG - 2015-12-23 08:30:30 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:30:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:30:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:30:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:30:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:30:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:30:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:30:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:30:30 --> Model Class Initialized
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:30:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:30:30 --> Final output sent to browser
DEBUG - 2015-12-23 08:30:30 --> Total execution time: 0.2284
DEBUG - 2015-12-23 08:31:02 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:31:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:31:02 --> URI Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Router Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Output Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Security Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Input Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:31:02 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Loader Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:31:02 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:31:02 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Session Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:31:02 --> Session routines successfully run
DEBUG - 2015-12-23 08:31:02 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Email Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Controller Class Initialized
DEBUG - 2015-12-23 08:31:02 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:31:02 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:31:02 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:31:02 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:31:02 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:31:02 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:31:02 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:31:02 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:31:02 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:31:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:31:02 --> Final output sent to browser
DEBUG - 2015-12-23 08:31:02 --> Total execution time: 0.3559
DEBUG - 2015-12-23 08:31:07 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:31:07 --> URI Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Router Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Output Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Security Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Input Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:31:07 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Loader Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:31:07 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:31:07 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Session Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:31:07 --> Session routines successfully run
DEBUG - 2015-12-23 08:31:07 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Email Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Controller Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Property MX_Controller Initialized
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:31:07 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:07 --> Image Lib Class Initialized
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:31:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:31:07 --> Final output sent to browser
DEBUG - 2015-12-23 08:31:07 --> Total execution time: 0.2501
DEBUG - 2015-12-23 08:31:11 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:31:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:31:11 --> URI Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Router Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Output Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Security Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Input Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:31:11 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Loader Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:31:11 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:31:11 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Session Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:31:11 --> Session routines successfully run
DEBUG - 2015-12-23 08:31:11 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Email Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Controller Class Initialized
DEBUG - 2015-12-23 08:31:11 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-23 08:31:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-23 08:31:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:31:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:31:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:31:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:31:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:31:11 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:31:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:31:11 --> Final output sent to browser
DEBUG - 2015-12-23 08:31:11 --> Total execution time: 0.4463
DEBUG - 2015-12-23 08:31:14 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:31:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:31:14 --> URI Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Router Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Output Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Security Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Input Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:31:14 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Loader Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:31:14 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:31:14 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Session Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:31:14 --> Session routines successfully run
DEBUG - 2015-12-23 08:31:14 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Email Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Controller Class Initialized
DEBUG - 2015-12-23 08:31:14 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:14 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-23 08:31:14 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:15 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-23 08:31:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:31:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:31:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:31:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:31:15 --> Final output sent to browser
DEBUG - 2015-12-23 08:31:15 --> Total execution time: 0.9651
DEBUG - 2015-12-23 08:31:17 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:17 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:31:17 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:31:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:31:17 --> URI Class Initialized
DEBUG - 2015-12-23 08:31:17 --> Router Class Initialized
DEBUG - 2015-12-23 08:31:17 --> Output Class Initialized
DEBUG - 2015-12-23 08:31:17 --> Security Class Initialized
DEBUG - 2015-12-23 08:31:17 --> Input Class Initialized
DEBUG - 2015-12-23 08:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:31:17 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Loader Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:31:18 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:31:18 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Session Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:31:18 --> Session routines successfully run
DEBUG - 2015-12-23 08:31:18 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Email Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Controller Class Initialized
DEBUG - 2015-12-23 08:31:18 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-23 08:31:18 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:31:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:31:18 --> Final output sent to browser
DEBUG - 2015-12-23 08:31:18 --> Total execution time: 0.9531
DEBUG - 2015-12-23 08:31:32 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:31:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:31:32 --> URI Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Router Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Output Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Security Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Input Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:31:32 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Loader Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:31:32 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:31:32 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Session Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:31:32 --> Session routines successfully run
DEBUG - 2015-12-23 08:31:32 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Email Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Controller Class Initialized
DEBUG - 2015-12-23 08:31:32 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-23 08:31:32 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:31:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:31:32 --> Final output sent to browser
DEBUG - 2015-12-23 08:31:32 --> Total execution time: 0.4208
DEBUG - 2015-12-23 08:31:46 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:31:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:31:46 --> URI Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Router Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Output Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Security Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Input Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:31:46 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Language Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Config Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Loader Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:31:46 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:31:46 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Session Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:31:46 --> Session routines successfully run
DEBUG - 2015-12-23 08:31:46 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:31:46 --> Email Class Initialized
DEBUG - 2015-12-23 08:31:47 --> Controller Class Initialized
DEBUG - 2015-12-23 08:31:47 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-23 08:31:47 --> Model Class Initialized
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:31:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:31:47 --> Final output sent to browser
DEBUG - 2015-12-23 08:31:47 --> Total execution time: 0.3863
DEBUG - 2015-12-23 08:32:33 --> Config Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:32:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:32:33 --> URI Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Router Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Output Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Security Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Input Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:32:33 --> Language Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Language Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Config Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Loader Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:32:33 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:32:33 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Session Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:32:33 --> Session routines successfully run
DEBUG - 2015-12-23 08:32:33 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Email Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Controller Class Initialized
DEBUG - 2015-12-23 08:32:33 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-23 08:32:33 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:32:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:32:33 --> Final output sent to browser
DEBUG - 2015-12-23 08:32:33 --> Total execution time: 0.2696
DEBUG - 2015-12-23 08:32:40 --> Config Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Hooks Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Utf8 Class Initialized
DEBUG - 2015-12-23 08:32:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 08:32:40 --> URI Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Router Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Output Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Security Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Input Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 08:32:40 --> Language Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Language Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Config Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Loader Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Helper loaded: url_helper
DEBUG - 2015-12-23 08:32:40 --> Helper loaded: form_helper
DEBUG - 2015-12-23 08:32:40 --> Database Driver Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Session Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Helper loaded: string_helper
DEBUG - 2015-12-23 08:32:40 --> Session routines successfully run
DEBUG - 2015-12-23 08:32:40 --> Form Validation Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Pagination Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Encrypt Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Email Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Controller Class Initialized
DEBUG - 2015-12-23 08:32:40 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 08:32:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 08:32:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 08:32:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 08:32:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 08:32:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 08:32:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 08:32:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 08:32:40 --> Model Class Initialized
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 08:32:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 08:32:40 --> Final output sent to browser
DEBUG - 2015-12-23 08:32:40 --> Total execution time: 0.3963
DEBUG - 2015-12-23 18:10:44 --> Config Class Initialized
DEBUG - 2015-12-23 18:10:44 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:10:45 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:10:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:10:45 --> URI Class Initialized
DEBUG - 2015-12-23 18:10:45 --> Router Class Initialized
DEBUG - 2015-12-23 18:10:46 --> Output Class Initialized
DEBUG - 2015-12-23 18:10:46 --> Security Class Initialized
DEBUG - 2015-12-23 18:10:46 --> Config Class Initialized
DEBUG - 2015-12-23 18:10:46 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:10:46 --> Input Class Initialized
DEBUG - 2015-12-23 18:10:46 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:10:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:10:46 --> URI Class Initialized
DEBUG - 2015-12-23 18:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 18:10:46 --> Router Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Language Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Output Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Security Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Input Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 18:10:47 --> Language Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Language Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Language Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Config Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Config Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Loader Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Loader Class Initialized
DEBUG - 2015-12-23 18:10:47 --> Helper loaded: url_helper
DEBUG - 2015-12-23 18:10:47 --> Helper loaded: url_helper
DEBUG - 2015-12-23 18:10:47 --> Helper loaded: form_helper
DEBUG - 2015-12-23 18:10:47 --> Helper loaded: form_helper
DEBUG - 2015-12-23 18:10:48 --> Database Driver Class Initialized
DEBUG - 2015-12-23 18:10:48 --> Database Driver Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Session Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Session Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Helper loaded: string_helper
DEBUG - 2015-12-23 18:10:49 --> A session cookie was not found.
DEBUG - 2015-12-23 18:10:49 --> Helper loaded: string_helper
DEBUG - 2015-12-23 18:10:49 --> A session cookie was not found.
DEBUG - 2015-12-23 18:10:49 --> Session routines successfully run
DEBUG - 2015-12-23 18:10:49 --> Session routines successfully run
DEBUG - 2015-12-23 18:10:49 --> Form Validation Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Form Validation Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Pagination Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Pagination Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Encrypt Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Encrypt Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Email Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Controller Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Email Class Initialized
DEBUG - 2015-12-23 18:10:49 --> Controller Class Initialized
DEBUG - 2015-12-23 18:10:50 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 18:10:50 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> Model Class Initialized
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 18:10:50 --> Final output sent to browser
DEBUG - 2015-12-23 18:10:50 --> Total execution time: 7.6213
DEBUG - 2015-12-23 18:10:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 18:10:50 --> Final output sent to browser
DEBUG - 2015-12-23 18:10:50 --> Total execution time: 4.3738
DEBUG - 2015-12-23 18:11:00 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:00 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:00 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:01 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Router Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Output Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Security Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Input Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 18:11:01 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Loader Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Helper loaded: url_helper
DEBUG - 2015-12-23 18:11:01 --> Helper loaded: form_helper
DEBUG - 2015-12-23 18:11:01 --> Database Driver Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Session Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Helper loaded: string_helper
DEBUG - 2015-12-23 18:11:01 --> Session routines successfully run
DEBUG - 2015-12-23 18:11:01 --> Form Validation Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Pagination Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Encrypt Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Email Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Controller Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Auth MX_Controller Initialized
DEBUG - 2015-12-23 18:11:01 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 18:11:01 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 18:11:01 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:01 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Router Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Output Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Security Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Input Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 18:11:01 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Loader Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Helper loaded: url_helper
DEBUG - 2015-12-23 18:11:01 --> Helper loaded: form_helper
DEBUG - 2015-12-23 18:11:01 --> Database Driver Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Session Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Helper loaded: string_helper
DEBUG - 2015-12-23 18:11:01 --> A session cookie was not found.
DEBUG - 2015-12-23 18:11:01 --> Session routines successfully run
DEBUG - 2015-12-23 18:11:01 --> Form Validation Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Pagination Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Encrypt Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Email Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Controller Class Initialized
DEBUG - 2015-12-23 18:11:01 --> Auth MX_Controller Initialized
DEBUG - 2015-12-23 18:11:01 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 18:11:01 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 18:11:01 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 18:11:01 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-23 18:11:01 --> Final output sent to browser
DEBUG - 2015-12-23 18:11:01 --> Total execution time: 0.2191
DEBUG - 2015-12-23 18:11:02 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:02 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Router Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:02 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Router Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:02 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:02 --> Router Class Initialized
DEBUG - 2015-12-23 18:11:03 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:03 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:03 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:03 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:03 --> Router Class Initialized
ERROR - 2015-12-23 18:11:03 --> 404 Page Not Found --> 
ERROR - 2015-12-23 18:11:03 --> 404 Page Not Found --> 
ERROR - 2015-12-23 18:11:03 --> 404 Page Not Found --> 
ERROR - 2015-12-23 18:11:03 --> 404 Page Not Found --> 
DEBUG - 2015-12-23 18:11:05 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:05 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Router Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Output Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Security Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Input Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 18:11:05 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Loader Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Helper loaded: url_helper
DEBUG - 2015-12-23 18:11:05 --> Helper loaded: form_helper
DEBUG - 2015-12-23 18:11:05 --> Database Driver Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Session Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Helper loaded: string_helper
DEBUG - 2015-12-23 18:11:05 --> Session routines successfully run
DEBUG - 2015-12-23 18:11:05 --> Form Validation Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Pagination Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Encrypt Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Email Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Controller Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Auth MX_Controller Initialized
DEBUG - 2015-12-23 18:11:05 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 18:11:05 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 18:11:05 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-23 18:11:05 --> XSS Filtering completed
DEBUG - 2015-12-23 18:11:05 --> Unable to find validation rule: exists
DEBUG - 2015-12-23 18:11:05 --> XSS Filtering completed
DEBUG - 2015-12-23 18:11:06 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:06 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Router Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Output Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Security Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Input Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 18:11:06 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Loader Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Helper loaded: url_helper
DEBUG - 2015-12-23 18:11:06 --> Helper loaded: form_helper
DEBUG - 2015-12-23 18:11:06 --> Database Driver Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Session Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Helper loaded: string_helper
DEBUG - 2015-12-23 18:11:06 --> Session routines successfully run
DEBUG - 2015-12-23 18:11:06 --> Form Validation Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Pagination Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Encrypt Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Email Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Controller Class Initialized
DEBUG - 2015-12-23 18:11:06 --> Admin MX_Controller Initialized
DEBUG - 2015-12-23 18:11:06 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 18:11:06 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-23 18:11:06 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 18:11:06 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-23 18:11:06 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 18:11:06 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-23 18:11:06 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 18:11:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 18:11:06 --> Final output sent to browser
DEBUG - 2015-12-23 18:11:06 --> Total execution time: 0.3684
DEBUG - 2015-12-23 18:11:10 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:10 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Router Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Output Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Security Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Input Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 18:11:10 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Loader Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Helper loaded: url_helper
DEBUG - 2015-12-23 18:11:10 --> Helper loaded: form_helper
DEBUG - 2015-12-23 18:11:10 --> Database Driver Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Session Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Helper loaded: string_helper
DEBUG - 2015-12-23 18:11:10 --> Session routines successfully run
DEBUG - 2015-12-23 18:11:10 --> Form Validation Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Pagination Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Encrypt Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Email Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Controller Class Initialized
DEBUG - 2015-12-23 18:11:10 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 18:11:10 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 18:11:10 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 18:11:10 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 18:11:10 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 18:11:10 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 18:11:10 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 18:11:10 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 18:11:10 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-23 18:11:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-23 18:11:10 --> Final output sent to browser
DEBUG - 2015-12-23 18:11:10 --> Total execution time: 0.3132
DEBUG - 2015-12-23 18:11:38 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Hooks Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Utf8 Class Initialized
DEBUG - 2015-12-23 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-23 18:11:38 --> URI Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Router Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Output Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Security Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Input Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-23 18:11:38 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Language Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Config Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Loader Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Helper loaded: url_helper
DEBUG - 2015-12-23 18:11:38 --> Helper loaded: form_helper
DEBUG - 2015-12-23 18:11:38 --> Database Driver Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Session Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Helper loaded: string_helper
DEBUG - 2015-12-23 18:11:38 --> Session routines successfully run
DEBUG - 2015-12-23 18:11:38 --> Form Validation Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Pagination Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Encrypt Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Email Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Controller Class Initialized
DEBUG - 2015-12-23 18:11:38 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-23 18:11:38 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:38 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-23 18:11:38 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-23 18:11:38 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-23 18:11:38 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-23 18:11:38 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-23 18:11:38 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-23 18:11:38 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:38 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-23 18:11:38 --> Model Class Initialized
DEBUG - 2015-12-23 18:11:38 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-23 18:11:38 --> Final output sent to browser
DEBUG - 2015-12-23 18:11:38 --> Total execution time: 0.2595
