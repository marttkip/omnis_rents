<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-10 21:23:28 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:28 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:23:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:23:28 --> URI Class Initialized
DEBUG - 2016-02-10 21:23:28 --> Router Class Initialized
DEBUG - 2016-02-10 21:23:28 --> No URI present. Default controller set.
DEBUG - 2016-02-10 21:23:28 --> Output Class Initialized
DEBUG - 2016-02-10 21:23:28 --> Security Class Initialized
DEBUG - 2016-02-10 21:23:28 --> Input Class Initialized
DEBUG - 2016-02-10 21:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:23:29 --> Language Class Initialized
DEBUG - 2016-02-10 21:23:29 --> Language Class Initialized
DEBUG - 2016-02-10 21:23:29 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:29 --> Loader Class Initialized
DEBUG - 2016-02-10 21:23:29 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:23:29 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:23:29 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:23:31 --> Session Class Initialized
DEBUG - 2016-02-10 21:23:31 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:23:31 --> A session cookie was not found.
DEBUG - 2016-02-10 21:23:31 --> Session routines successfully run
DEBUG - 2016-02-10 21:23:31 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:23:31 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:23:31 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:23:31 --> Email Class Initialized
DEBUG - 2016-02-10 21:23:31 --> Controller Class Initialized
DEBUG - 2016-02-10 21:23:31 --> Auth MX_Controller Initialized
DEBUG - 2016-02-10 21:23:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:23:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:23:32 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:23:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:23:32 --> URI Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Router Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Output Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Security Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Input Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:23:32 --> Language Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Language Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Loader Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:23:32 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:23:32 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Session Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:23:32 --> Session routines successfully run
DEBUG - 2016-02-10 21:23:32 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Email Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Controller Class Initialized
DEBUG - 2016-02-10 21:23:32 --> Auth MX_Controller Initialized
DEBUG - 2016-02-10 21:23:32 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:23:32 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:23:32 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:23:33 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-10 21:23:33 --> Final output sent to browser
DEBUG - 2016-02-10 21:23:33 --> Total execution time: 1.0983
DEBUG - 2016-02-10 21:23:39 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:39 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:39 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:23:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:23:39 --> URI Class Initialized
DEBUG - 2016-02-10 21:23:39 --> Router Class Initialized
ERROR - 2016-02-10 21:23:41 --> 404 Page Not Found --> 
DEBUG - 2016-02-10 21:23:42 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:42 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:42 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:42 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:42 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:23:42 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:23:42 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:23:42 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:23:42 --> URI Class Initialized
DEBUG - 2016-02-10 21:23:42 --> Router Class Initialized
DEBUG - 2016-02-10 21:23:42 --> URI Class Initialized
DEBUG - 2016-02-10 21:23:42 --> Router Class Initialized
DEBUG - 2016-02-10 21:23:42 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:42 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:42 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:23:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:23:43 --> URI Class Initialized
DEBUG - 2016-02-10 21:23:43 --> Router Class Initialized
ERROR - 2016-02-10 21:23:43 --> 404 Page Not Found --> 
ERROR - 2016-02-10 21:23:43 --> 404 Page Not Found --> 
ERROR - 2016-02-10 21:23:43 --> 404 Page Not Found --> 
DEBUG - 2016-02-10 21:23:46 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:23:46 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:23:46 --> URI Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Router Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Output Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Security Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Input Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:23:46 --> Language Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Language Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Loader Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:23:46 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:23:46 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Session Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:23:46 --> Session routines successfully run
DEBUG - 2016-02-10 21:23:46 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Email Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Controller Class Initialized
DEBUG - 2016-02-10 21:23:46 --> Auth MX_Controller Initialized
DEBUG - 2016-02-10 21:23:46 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:23:46 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:23:46 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 21:23:47 --> XSS Filtering completed
DEBUG - 2016-02-10 21:23:47 --> Unable to find validation rule: exists
DEBUG - 2016-02-10 21:23:47 --> XSS Filtering completed
DEBUG - 2016-02-10 21:23:47 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:23:47 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:23:47 --> URI Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Router Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Output Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Security Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Input Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:23:47 --> Language Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Language Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Config Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Loader Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:23:47 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:23:47 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Session Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:23:47 --> Session routines successfully run
DEBUG - 2016-02-10 21:23:47 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Email Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Controller Class Initialized
DEBUG - 2016-02-10 21:23:47 --> Admin MX_Controller Initialized
DEBUG - 2016-02-10 21:23:47 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:23:47 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:23:47 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:23:47 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:23:47 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:23:47 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:23:47 --> Model Class Initialized
DEBUG - 2016-02-10 21:23:48 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-02-10 21:23:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:23:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:23:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:23:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:23:48 --> Final output sent to browser
DEBUG - 2016-02-10 21:23:48 --> Total execution time: 1.0498
DEBUG - 2016-02-10 21:24:01 --> Config Class Initialized
DEBUG - 2016-02-10 21:24:01 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:24:01 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:24:01 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:24:01 --> URI Class Initialized
DEBUG - 2016-02-10 21:24:01 --> Router Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Output Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Security Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Input Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:24:02 --> Language Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Language Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Config Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Loader Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:24:02 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:24:02 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Session Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:24:02 --> Session routines successfully run
DEBUG - 2016-02-10 21:24:02 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Email Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Controller Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:24:02 --> Model Class Initialized
DEBUG - 2016-02-10 21:24:02 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:24:03 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 21:24:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:24:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:24:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:24:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:24:03 --> Final output sent to browser
DEBUG - 2016-02-10 21:24:03 --> Total execution time: 1.8150
DEBUG - 2016-02-10 21:25:22 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:25:22 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:25:22 --> URI Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Router Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Output Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Security Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Input Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:25:22 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Loader Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:25:22 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:25:22 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Session Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:25:22 --> Session routines successfully run
DEBUG - 2016-02-10 21:25:22 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Email Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Controller Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:25:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:22 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:25:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:25:22 --> Final output sent to browser
DEBUG - 2016-02-10 21:25:22 --> Total execution time: 0.4318
DEBUG - 2016-02-10 21:25:26 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:25:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:25:26 --> URI Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Router Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Output Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Security Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Input Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:25:26 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Loader Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:25:26 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:25:26 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Session Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:25:26 --> Session routines successfully run
DEBUG - 2016-02-10 21:25:26 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Email Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Controller Class Initialized
DEBUG - 2016-02-10 21:25:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:25:26 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:25:26 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:25:26 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:25:26 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:25:26 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:25:26 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:25:26 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:25:27 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:25:27 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:25:27 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:27 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:25:27 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:25:27 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:25:27 --> Model Class Initialized
ERROR - 2016-02-10 21:25:27 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 52
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:25:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:25:27 --> Final output sent to browser
DEBUG - 2016-02-10 21:25:27 --> Total execution time: 0.7068
DEBUG - 2016-02-10 21:25:43 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:25:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:25:43 --> URI Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Router Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Output Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Security Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Input Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:25:43 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Loader Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:25:43 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:25:43 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Session Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:25:43 --> Session routines successfully run
DEBUG - 2016-02-10 21:25:43 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Email Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Controller Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:25:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:43 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:25:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:25:43 --> Final output sent to browser
DEBUG - 2016-02-10 21:25:43 --> Total execution time: 0.3871
DEBUG - 2016-02-10 21:25:48 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:25:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:25:48 --> URI Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Router Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Output Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Security Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Input Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:25:48 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Loader Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:25:48 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:25:48 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Session Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:25:48 --> Session routines successfully run
DEBUG - 2016-02-10 21:25:48 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Email Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Controller Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:25:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:25:48 --> Final output sent to browser
DEBUG - 2016-02-10 21:25:48 --> Total execution time: 0.7483
DEBUG - 2016-02-10 21:25:54 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:25:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:25:54 --> URI Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Router Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Output Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Security Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Input Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:25:54 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Loader Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:25:54 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:25:54 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Session Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:25:54 --> Session routines successfully run
DEBUG - 2016-02-10 21:25:54 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Email Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Controller Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:25:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:25:54 --> URI Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Router Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:25:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:25:54 --> URI Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Output Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Security Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Router Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Input Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Output Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Security Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Input Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:25:54 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:25:54 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Loader Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:25:54 --> Loader Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:25:54 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:25:54 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:25:54 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Session Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:25:54 --> Session routines successfully run
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 21:25:54 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:25:54 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:25:54 --> Session Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:25:54 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:25:54 --> Final output sent to browser
DEBUG - 2016-02-10 21:25:54 --> Total execution time: 0.6821
DEBUG - 2016-02-10 21:25:54 --> Session routines successfully run
DEBUG - 2016-02-10 21:25:54 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Email Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Controller Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Email Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Controller Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:25:54 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:25:54 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 21:25:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:25:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:25:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:25:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:25:55 --> Final output sent to browser
DEBUG - 2016-02-10 21:25:55 --> Total execution time: 0.5825
DEBUG - 2016-02-10 21:25:55 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 21:25:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:25:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:25:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:25:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:25:55 --> Final output sent to browser
DEBUG - 2016-02-10 21:25:55 --> Total execution time: 0.7814
DEBUG - 2016-02-10 21:25:59 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:25:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:25:59 --> URI Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Router Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Output Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Security Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Input Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:25:59 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Language Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Config Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Loader Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:25:59 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:25:59 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Session Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:25:59 --> Session routines successfully run
DEBUG - 2016-02-10 21:25:59 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Email Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Controller Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:25:59 --> Model Class Initialized
ERROR - 2016-02-10 21:25:59 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 52
ERROR - 2016-02-10 21:25:59 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 52
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:25:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:25:59 --> Final output sent to browser
DEBUG - 2016-02-10 21:25:59 --> Total execution time: 0.3221
DEBUG - 2016-02-10 21:29:24 --> Config Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:29:24 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:29:24 --> URI Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Router Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Output Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Security Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Input Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:29:24 --> Language Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Language Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Config Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Loader Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:29:24 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:29:24 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Session Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:29:24 --> Session routines successfully run
DEBUG - 2016-02-10 21:29:24 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Email Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Controller Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:29:24 --> Model Class Initialized
ERROR - 2016-02-10 21:29:24 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 52
ERROR - 2016-02-10 21:29:24 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 52
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:29:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:29:24 --> Final output sent to browser
DEBUG - 2016-02-10 21:29:24 --> Total execution time: 0.2976
DEBUG - 2016-02-10 21:35:06 --> Config Class Initialized
DEBUG - 2016-02-10 21:35:06 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:35:06 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:35:06 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:35:06 --> URI Class Initialized
DEBUG - 2016-02-10 21:35:06 --> Router Class Initialized
DEBUG - 2016-02-10 21:35:06 --> Output Class Initialized
DEBUG - 2016-02-10 21:35:06 --> Security Class Initialized
DEBUG - 2016-02-10 21:35:06 --> Input Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:35:07 --> Language Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Language Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Config Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Loader Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:35:07 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:35:07 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Session Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:35:07 --> Session routines successfully run
DEBUG - 2016-02-10 21:35:07 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Email Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Controller Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:35:07 --> Model Class Initialized
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:35:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:35:07 --> Final output sent to browser
DEBUG - 2016-02-10 21:35:07 --> Total execution time: 0.3387
DEBUG - 2016-02-10 21:41:37 --> Config Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:41:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:41:37 --> URI Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Router Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Output Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Security Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Input Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:41:37 --> Language Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Language Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Config Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Loader Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:41:37 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:41:37 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Session Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:41:37 --> Session routines successfully run
DEBUG - 2016-02-10 21:41:37 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Email Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Controller Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:41:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:41:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:41:37 --> Final output sent to browser
DEBUG - 2016-02-10 21:41:37 --> Total execution time: 0.4877
DEBUG - 2016-02-10 21:47:22 --> Config Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:47:22 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:47:22 --> URI Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Router Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Output Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Security Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Input Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:47:22 --> Language Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Language Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Config Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Loader Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:47:22 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:47:22 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Session Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:47:22 --> Session routines successfully run
DEBUG - 2016-02-10 21:47:22 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Email Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Controller Class Initialized
DEBUG - 2016-02-10 21:47:22 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:47:22 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:23 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:47:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:47:23 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:47:23 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:47:23 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:23 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:47:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:47:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:47:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:47:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:47:23 --> Final output sent to browser
DEBUG - 2016-02-10 21:47:23 --> Total execution time: 0.3663
DEBUG - 2016-02-10 21:47:31 --> Config Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:47:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:47:31 --> URI Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Router Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Output Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Security Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Input Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:47:31 --> Language Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Language Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Config Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Loader Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:47:31 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:47:31 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Session Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:47:31 --> Session routines successfully run
DEBUG - 2016-02-10 21:47:31 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Email Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Controller Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 21:47:31 --> XSS Filtering completed
DEBUG - 2016-02-10 21:47:31 --> Config Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:47:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:47:31 --> URI Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Router Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Output Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Security Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Input Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:47:31 --> Language Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Language Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Config Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Loader Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:47:31 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:47:31 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Session Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:47:31 --> Session routines successfully run
DEBUG - 2016-02-10 21:47:31 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Email Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Controller Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:47:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:47:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:47:31 --> Final output sent to browser
DEBUG - 2016-02-10 21:47:31 --> Total execution time: 0.3004
DEBUG - 2016-02-10 21:48:00 --> Config Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:48:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:48:00 --> URI Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Router Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Output Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Security Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Input Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:48:00 --> Language Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Language Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Config Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Loader Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:48:00 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:48:00 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Session Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:48:00 --> Session routines successfully run
DEBUG - 2016-02-10 21:48:00 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Email Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Controller Class Initialized
DEBUG - 2016-02-10 21:48:00 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:48:00 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:48:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 21:48:00 --> XSS Filtering completed
DEBUG - 2016-02-10 21:48:00 --> XSS Filtering completed
DEBUG - 2016-02-10 21:48:00 --> XSS Filtering completed
DEBUG - 2016-02-10 21:48:00 --> XSS Filtering completed
DEBUG - 2016-02-10 21:48:00 --> DB Transaction Failure
ERROR - 2016-02-10 21:48:00 --> Query error: Unknown column 'arreas_bf' in 'field list'
DEBUG - 2016-02-10 21:48:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-02-10 21:48:40 --> Config Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:48:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:48:40 --> URI Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Router Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Output Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Security Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Input Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:48:40 --> Language Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Language Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Config Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Loader Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:48:40 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:48:40 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Session Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:48:40 --> Session routines successfully run
DEBUG - 2016-02-10 21:48:40 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Email Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Controller Class Initialized
DEBUG - 2016-02-10 21:48:40 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:48:40 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 21:48:40 --> XSS Filtering completed
DEBUG - 2016-02-10 21:48:40 --> XSS Filtering completed
DEBUG - 2016-02-10 21:48:40 --> XSS Filtering completed
DEBUG - 2016-02-10 21:48:40 --> XSS Filtering completed
DEBUG - 2016-02-10 21:48:40 --> Config Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:48:40 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:48:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:48:40 --> URI Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Router Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Output Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Security Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Input Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:48:41 --> Language Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Language Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Config Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Loader Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:48:41 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:48:41 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Session Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:48:41 --> Session routines successfully run
DEBUG - 2016-02-10 21:48:41 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Email Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Controller Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:48:41 --> Model Class Initialized
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:48:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:48:41 --> Final output sent to browser
DEBUG - 2016-02-10 21:48:41 --> Total execution time: 0.2961
DEBUG - 2016-02-10 21:50:37 --> Config Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:50:37 --> URI Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Router Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Output Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Security Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Input Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:50:37 --> Language Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Language Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Config Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Loader Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:50:37 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:50:37 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Session Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:50:37 --> Session routines successfully run
DEBUG - 2016-02-10 21:50:37 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Email Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Controller Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:50:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:50:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:50:37 --> Final output sent to browser
DEBUG - 2016-02-10 21:50:37 --> Total execution time: 0.2664
DEBUG - 2016-02-10 21:50:43 --> Config Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:50:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:50:43 --> URI Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Router Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Output Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Security Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Input Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:50:43 --> Language Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Language Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Config Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Loader Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:50:43 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:50:43 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Session Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:50:43 --> Session routines successfully run
DEBUG - 2016-02-10 21:50:43 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Email Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Controller Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 21:50:43 --> XSS Filtering completed
DEBUG - 2016-02-10 21:50:43 --> Config Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:50:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:50:43 --> URI Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Router Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Output Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Security Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Input Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:50:43 --> Language Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Language Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Config Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Loader Class Initialized
DEBUG - 2016-02-10 21:50:43 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:50:43 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:50:43 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:50:44 --> Session Class Initialized
DEBUG - 2016-02-10 21:50:44 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:50:44 --> Session routines successfully run
DEBUG - 2016-02-10 21:50:44 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:50:44 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:50:44 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:50:44 --> Email Class Initialized
DEBUG - 2016-02-10 21:50:44 --> Controller Class Initialized
DEBUG - 2016-02-10 21:50:44 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:50:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:50:44 --> Final output sent to browser
DEBUG - 2016-02-10 21:50:44 --> Total execution time: 0.3245
DEBUG - 2016-02-10 21:54:31 --> Config Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:54:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:54:31 --> URI Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Router Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Output Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Security Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Input Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:54:31 --> Language Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Language Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Config Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Loader Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:54:31 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:54:31 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Session Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:54:31 --> Session routines successfully run
DEBUG - 2016-02-10 21:54:31 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Email Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Controller Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:54:31 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:54:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:54:31 --> Final output sent to browser
DEBUG - 2016-02-10 21:54:31 --> Total execution time: 0.3661
DEBUG - 2016-02-10 21:54:37 --> Config Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:54:37 --> URI Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Router Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Output Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Security Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Input Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:54:37 --> Language Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Language Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Config Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Loader Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:54:37 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:54:37 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Session Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:54:37 --> Session routines successfully run
DEBUG - 2016-02-10 21:54:37 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Email Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Controller Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:37 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:54:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:54:37 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 21:54:38 --> XSS Filtering completed
DEBUG - 2016-02-10 21:54:38 --> Config Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:54:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:54:38 --> URI Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Router Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Output Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Security Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Input Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:54:38 --> Language Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Language Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Config Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Loader Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:54:38 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:54:38 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Session Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:54:38 --> Session routines successfully run
DEBUG - 2016-02-10 21:54:38 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Email Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Controller Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:54:38 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 21:54:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 21:54:38 --> Final output sent to browser
DEBUG - 2016-02-10 21:54:38 --> Total execution time: 0.3187
DEBUG - 2016-02-10 21:54:58 --> Config Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Utf8 Class Initialized
DEBUG - 2016-02-10 21:54:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 21:54:58 --> URI Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Router Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Output Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Security Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Input Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 21:54:58 --> Language Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Language Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Config Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Loader Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Helper loaded: url_helper
DEBUG - 2016-02-10 21:54:58 --> Helper loaded: form_helper
DEBUG - 2016-02-10 21:54:58 --> Database Driver Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Session Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Helper loaded: string_helper
DEBUG - 2016-02-10 21:54:58 --> Session routines successfully run
DEBUG - 2016-02-10 21:54:58 --> Form Validation Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Pagination Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Encrypt Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Email Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Controller Class Initialized
DEBUG - 2016-02-10 21:54:58 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 21:54:58 --> Model Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Image Lib Class Initialized
DEBUG - 2016-02-10 21:54:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 21:54:58 --> XSS Filtering completed
DEBUG - 2016-02-10 21:54:58 --> XSS Filtering completed
DEBUG - 2016-02-10 21:54:58 --> XSS Filtering completed
DEBUG - 2016-02-10 21:54:58 --> XSS Filtering completed
DEBUG - 2016-02-10 21:54:58 --> DB Transaction Failure
ERROR - 2016-02-10 21:54:58 --> Query error: Unknown column 'arreas_bf' in 'field list'
DEBUG - 2016-02-10 21:54:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-02-10 22:00:05 --> Config Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:00:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:00:05 --> URI Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Router Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Output Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Security Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Input Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:00:05 --> Language Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Language Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Config Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Loader Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:00:05 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:00:05 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Session Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:00:05 --> Session routines successfully run
DEBUG - 2016-02-10 22:00:05 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Email Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Controller Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:00:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:00:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:00:05 --> Final output sent to browser
DEBUG - 2016-02-10 22:00:05 --> Total execution time: 0.2871
DEBUG - 2016-02-10 22:00:28 --> Config Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:00:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:00:28 --> URI Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Router Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Output Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Security Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Input Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:00:28 --> Language Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Language Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Config Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Loader Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:00:28 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:00:28 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Session Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:00:28 --> Session routines successfully run
DEBUG - 2016-02-10 22:00:28 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Email Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Controller Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:00:28 --> XSS Filtering completed
DEBUG - 2016-02-10 22:00:28 --> Config Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:00:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:00:28 --> URI Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Router Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Output Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Security Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Input Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:00:28 --> Language Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Language Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Config Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Loader Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:00:28 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:00:28 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Session Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:00:28 --> Session routines successfully run
DEBUG - 2016-02-10 22:00:28 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Email Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Controller Class Initialized
DEBUG - 2016-02-10 22:00:28 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:00:28 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:29 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:00:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:00:29 --> Final output sent to browser
DEBUG - 2016-02-10 22:00:29 --> Total execution time: 0.2799
DEBUG - 2016-02-10 22:04:32 --> Config Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:04:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:04:32 --> URI Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Router Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Output Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Security Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Input Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:04:32 --> Language Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Language Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Config Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Loader Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:04:32 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:04:32 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Session Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:04:32 --> Session routines successfully run
DEBUG - 2016-02-10 22:04:32 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Email Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Controller Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:04:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:04:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:04:33 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:04:33 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:04:33 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:04:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:04:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:04:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:04:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:04:33 --> Final output sent to browser
DEBUG - 2016-02-10 22:04:33 --> Total execution time: 0.2968
DEBUG - 2016-02-10 22:05:07 --> Config Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:05:07 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:05:07 --> URI Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Router Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Output Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Security Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Input Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:05:07 --> Language Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Language Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Config Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Loader Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:05:07 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:05:07 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Session Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:05:07 --> Session routines successfully run
DEBUG - 2016-02-10 22:05:07 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Email Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Controller Class Initialized
DEBUG - 2016-02-10 22:05:07 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:05:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:05:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:05:07 --> XSS Filtering completed
DEBUG - 2016-02-10 22:05:07 --> XSS Filtering completed
DEBUG - 2016-02-10 22:05:07 --> XSS Filtering completed
DEBUG - 2016-02-10 22:05:07 --> XSS Filtering completed
DEBUG - 2016-02-10 22:05:07 --> DB Transaction Failure
ERROR - 2016-02-10 22:05:07 --> Query error: Unknown column 'arreas_bf' in 'field list'
DEBUG - 2016-02-10 22:05:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-02-10 22:05:52 --> Config Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:05:52 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:05:52 --> URI Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Router Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Output Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Security Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Input Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:05:52 --> Language Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Language Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Config Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Loader Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:05:52 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:05:52 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Session Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:05:52 --> Session routines successfully run
DEBUG - 2016-02-10 22:05:52 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Email Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Controller Class Initialized
DEBUG - 2016-02-10 22:05:52 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:05:52 --> XSS Filtering completed
DEBUG - 2016-02-10 22:05:52 --> XSS Filtering completed
DEBUG - 2016-02-10 22:05:52 --> XSS Filtering completed
DEBUG - 2016-02-10 22:05:52 --> XSS Filtering completed
DEBUG - 2016-02-10 22:05:52 --> Config Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:05:52 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:05:52 --> URI Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Router Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Output Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Security Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Input Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:05:52 --> Language Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Language Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Config Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Loader Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:05:52 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:05:52 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Session Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:05:52 --> Session routines successfully run
DEBUG - 2016-02-10 22:05:52 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Email Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Controller Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:05:52 --> Model Class Initialized
ERROR - 2016-02-10 22:05:52 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 52
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:05:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:05:52 --> Final output sent to browser
DEBUG - 2016-02-10 22:05:52 --> Total execution time: 0.2928
DEBUG - 2016-02-10 22:06:38 --> Config Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:06:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:06:38 --> URI Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Router Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Output Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Security Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Input Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:06:38 --> Language Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Language Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Config Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Loader Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:06:38 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:06:38 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Session Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:06:38 --> Session routines successfully run
DEBUG - 2016-02-10 22:06:38 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Email Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Controller Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:06:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:06:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:06:38 --> Final output sent to browser
DEBUG - 2016-02-10 22:06:38 --> Total execution time: 0.3827
DEBUG - 2016-02-10 22:07:41 --> Config Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:07:41 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:07:41 --> URI Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Router Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Output Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Security Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Input Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:07:41 --> Language Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Language Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Config Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Loader Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:07:41 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:07:41 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Session Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:07:41 --> Session routines successfully run
DEBUG - 2016-02-10 22:07:41 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Email Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Controller Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:07:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:41 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:07:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:07:41 --> Final output sent to browser
DEBUG - 2016-02-10 22:07:41 --> Total execution time: 0.3077
DEBUG - 2016-02-10 22:07:49 --> Config Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:07:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:07:49 --> URI Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Router Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Output Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Security Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Input Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:07:49 --> Language Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Language Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Config Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Loader Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:07:49 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:07:49 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Session Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:07:49 --> Session routines successfully run
DEBUG - 2016-02-10 22:07:49 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Email Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Controller Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:07:49 --> Model Class Initialized
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:07:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:07:49 --> Final output sent to browser
DEBUG - 2016-02-10 22:07:49 --> Total execution time: 0.2923
DEBUG - 2016-02-10 22:09:15 --> Config Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:09:15 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:09:15 --> URI Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Router Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Output Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Security Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Input Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:09:15 --> Language Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Language Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Config Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Loader Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:09:15 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:09:15 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Session Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:09:15 --> Session routines successfully run
DEBUG - 2016-02-10 22:09:15 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Email Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Controller Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:09:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:09:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:09:15 --> Final output sent to browser
DEBUG - 2016-02-10 22:09:15 --> Total execution time: 0.3209
DEBUG - 2016-02-10 22:13:33 --> Config Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:13:33 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:13:33 --> URI Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Router Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Output Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Security Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Input Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:13:33 --> Language Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Language Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Config Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Loader Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:13:33 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:13:33 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Session Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:13:33 --> Session routines successfully run
DEBUG - 2016-02-10 22:13:33 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Email Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Controller Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:13:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:13:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:13:33 --> Final output sent to browser
DEBUG - 2016-02-10 22:13:33 --> Total execution time: 0.2832
DEBUG - 2016-02-10 22:13:46 --> Config Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:13:46 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:13:46 --> URI Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Router Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Output Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Security Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Input Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:13:46 --> Language Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Language Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Config Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Loader Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:13:46 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:13:46 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Session Class Initialized
DEBUG - 2016-02-10 22:13:46 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:13:46 --> Session routines successfully run
DEBUG - 2016-02-10 22:13:46 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Email Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Controller Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:13:47 --> XSS Filtering completed
DEBUG - 2016-02-10 22:13:47 --> Config Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:13:47 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:13:47 --> URI Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Router Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Output Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Security Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Input Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:13:47 --> Language Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Language Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Config Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Loader Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:13:47 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:13:47 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Session Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:13:47 --> Session routines successfully run
DEBUG - 2016-02-10 22:13:47 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Email Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Controller Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:13:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:13:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:13:47 --> Final output sent to browser
DEBUG - 2016-02-10 22:13:47 --> Total execution time: 0.3305
DEBUG - 2016-02-10 22:14:11 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:14:11 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:14:11 --> URI Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Router Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Output Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Security Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Input Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:14:11 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Loader Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:14:11 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:14:11 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Session Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:14:11 --> Session routines successfully run
DEBUG - 2016-02-10 22:14:11 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Email Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Controller Class Initialized
DEBUG - 2016-02-10 22:14:11 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:14:11 --> XSS Filtering completed
DEBUG - 2016-02-10 22:14:11 --> XSS Filtering completed
DEBUG - 2016-02-10 22:14:11 --> XSS Filtering completed
DEBUG - 2016-02-10 22:14:11 --> XSS Filtering completed
DEBUG - 2016-02-10 22:14:11 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:14:11 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:14:11 --> URI Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Router Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Output Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Security Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Input Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:14:11 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Loader Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:14:11 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:14:11 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Session Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:14:11 --> Session routines successfully run
DEBUG - 2016-02-10 22:14:11 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Email Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Controller Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:14:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:14:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:14:11 --> Final output sent to browser
DEBUG - 2016-02-10 22:14:11 --> Total execution time: 0.2955
DEBUG - 2016-02-10 22:14:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:14:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:14:16 --> URI Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Router Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Output Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Security Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Input Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:14:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Loader Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:14:16 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:14:16 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Session Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:14:16 --> Session routines successfully run
DEBUG - 2016-02-10 22:14:16 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Email Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Controller Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:14:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:16 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:14:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:14:16 --> Final output sent to browser
DEBUG - 2016-02-10 22:14:16 --> Total execution time: 0.3122
DEBUG - 2016-02-10 22:14:26 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:14:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:14:26 --> URI Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Router Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Output Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Security Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Input Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:14:26 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Loader Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:14:26 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:14:26 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Session Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:14:26 --> Session routines successfully run
DEBUG - 2016-02-10 22:14:26 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Email Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Controller Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:14:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:14:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:14:26 --> Final output sent to browser
DEBUG - 2016-02-10 22:14:26 --> Total execution time: 0.2698
DEBUG - 2016-02-10 22:14:32 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:14:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:14:32 --> URI Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Router Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Output Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Security Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Input Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:14:32 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Loader Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:14:32 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:14:32 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Session Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:14:32 --> Session routines successfully run
DEBUG - 2016-02-10 22:14:32 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Email Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Controller Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:14:32 --> XSS Filtering completed
DEBUG - 2016-02-10 22:14:32 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:14:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:14:32 --> URI Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Router Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Output Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Security Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Input Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:14:32 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Loader Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:14:32 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:14:32 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Session Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:14:32 --> Session routines successfully run
DEBUG - 2016-02-10 22:14:32 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Email Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Controller Class Initialized
DEBUG - 2016-02-10 22:14:32 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:14:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:14:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:14:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:14:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:33 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:14:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:14:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:14:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:14:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:14:33 --> Final output sent to browser
DEBUG - 2016-02-10 22:14:33 --> Total execution time: 0.3169
DEBUG - 2016-02-10 22:14:56 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:14:56 --> URI Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Router Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Output Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Security Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Input Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:14:56 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Loader Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:14:56 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:14:56 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Session Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:14:56 --> Session routines successfully run
DEBUG - 2016-02-10 22:14:56 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Email Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Controller Class Initialized
DEBUG - 2016-02-10 22:14:56 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:14:56 --> XSS Filtering completed
DEBUG - 2016-02-10 22:14:56 --> XSS Filtering completed
DEBUG - 2016-02-10 22:14:56 --> XSS Filtering completed
DEBUG - 2016-02-10 22:14:56 --> XSS Filtering completed
DEBUG - 2016-02-10 22:14:56 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:14:56 --> URI Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Router Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Output Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Security Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Input Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:14:56 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Language Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Config Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Loader Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:14:56 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:14:56 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Session Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:14:56 --> Session routines successfully run
DEBUG - 2016-02-10 22:14:56 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Email Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Controller Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:14:56 --> Model Class Initialized
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:14:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:14:56 --> Final output sent to browser
DEBUG - 2016-02-10 22:14:56 --> Total execution time: 0.2815
DEBUG - 2016-02-10 22:15:00 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:15:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:15:00 --> URI Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Router Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Output Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Security Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Input Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:15:00 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Loader Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:15:00 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:15:00 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Session Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:15:00 --> Session routines successfully run
DEBUG - 2016-02-10 22:15:00 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Email Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Controller Class Initialized
DEBUG - 2016-02-10 22:15:00 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 22:15:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:15:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:15:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:15:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:15:01 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:15:01 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:15:01 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:15:01 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:15:01 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:15:01 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:01 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:15:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:15:01 --> Final output sent to browser
DEBUG - 2016-02-10 22:15:01 --> Total execution time: 0.3236
DEBUG - 2016-02-10 22:15:20 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:15:20 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:15:20 --> URI Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Router Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Output Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Security Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Input Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:15:20 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Loader Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:15:20 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:15:20 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Session Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:15:20 --> Session routines successfully run
DEBUG - 2016-02-10 22:15:20 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Email Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Controller Class Initialized
DEBUG - 2016-02-10 22:15:20 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:15:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:15:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:15:21 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:15:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:15:21 --> Final output sent to browser
DEBUG - 2016-02-10 22:15:21 --> Total execution time: 0.2870
DEBUG - 2016-02-10 22:15:26 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:15:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:15:26 --> URI Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Router Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Output Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Security Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Input Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:15:26 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Loader Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:15:26 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:15:26 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Session Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:15:26 --> Session routines successfully run
DEBUG - 2016-02-10 22:15:26 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Email Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Controller Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:15:26 --> XSS Filtering completed
DEBUG - 2016-02-10 22:15:26 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:15:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:15:26 --> URI Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Router Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Output Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Security Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Input Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:15:26 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Loader Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:15:26 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:15:26 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Session Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:15:26 --> Session routines successfully run
DEBUG - 2016-02-10 22:15:26 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Email Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Controller Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:15:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:15:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:15:26 --> Final output sent to browser
DEBUG - 2016-02-10 22:15:26 --> Total execution time: 0.3288
DEBUG - 2016-02-10 22:15:58 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:15:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:15:58 --> URI Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Router Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Output Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Security Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Input Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:15:58 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Loader Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:15:58 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:15:58 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Session Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:15:58 --> Session routines successfully run
DEBUG - 2016-02-10 22:15:58 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Email Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Controller Class Initialized
DEBUG - 2016-02-10 22:15:58 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:15:58 --> XSS Filtering completed
DEBUG - 2016-02-10 22:15:58 --> XSS Filtering completed
DEBUG - 2016-02-10 22:15:58 --> XSS Filtering completed
DEBUG - 2016-02-10 22:15:58 --> XSS Filtering completed
DEBUG - 2016-02-10 22:15:58 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:15:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:15:58 --> URI Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Router Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Output Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Security Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Input Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:15:58 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Language Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Config Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Loader Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:15:58 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:15:58 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Session Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:15:58 --> Session routines successfully run
DEBUG - 2016-02-10 22:15:58 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Email Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Controller Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:15:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:15:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:15:58 --> Final output sent to browser
DEBUG - 2016-02-10 22:15:58 --> Total execution time: 0.2952
DEBUG - 2016-02-10 22:16:06 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:06 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:06 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:06 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:06 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:06 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:06 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:06 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:16:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:06 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:16:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:16:06 --> Final output sent to browser
DEBUG - 2016-02-10 22:16:06 --> Total execution time: 0.3452
DEBUG - 2016-02-10 22:16:10 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:10 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:10 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:10 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:10 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:10 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:10 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:10 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:10 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:11 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:11 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:11 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:16:11 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:16:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:16:11 --> Final output sent to browser
DEBUG - 2016-02-10 22:16:11 --> Total execution time: 0.4676
DEBUG - 2016-02-10 22:16:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:16 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:16 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:16 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:16 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:16 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:16:16 --> XSS Filtering completed
DEBUG - 2016-02-10 22:16:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:16 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:16 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:16 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:16 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:16 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:16:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:16:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:16:16 --> Final output sent to browser
DEBUG - 2016-02-10 22:16:16 --> Total execution time: 0.3116
DEBUG - 2016-02-10 22:16:38 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:38 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:38 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:38 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:38 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:38 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:38 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:38 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:16:38 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:16:38 --> XSS Filtering completed
DEBUG - 2016-02-10 22:16:38 --> XSS Filtering completed
DEBUG - 2016-02-10 22:16:38 --> XSS Filtering completed
DEBUG - 2016-02-10 22:16:38 --> XSS Filtering completed
DEBUG - 2016-02-10 22:16:38 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:38 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:38 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:39 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:39 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:39 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:39 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:39 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:16:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:16:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:16:39 --> Final output sent to browser
DEBUG - 2016-02-10 22:16:39 --> Total execution time: 0.3024
DEBUG - 2016-02-10 22:16:41 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:41 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:41 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:41 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:41 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:41 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:41 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:16:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:41 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:16:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:16:41 --> Final output sent to browser
DEBUG - 2016-02-10 22:16:41 --> Total execution time: 0.3052
DEBUG - 2016-02-10 22:16:51 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:51 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:51 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:51 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:51 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:51 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:51 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:51 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:16:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:16:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:16:51 --> Final output sent to browser
DEBUG - 2016-02-10 22:16:51 --> Total execution time: 0.3514
DEBUG - 2016-02-10 22:16:57 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:57 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:57 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:57 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:57 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:57 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:57 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:16:57 --> XSS Filtering completed
DEBUG - 2016-02-10 22:16:57 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:16:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:16:57 --> URI Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Router Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Output Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Security Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Input Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:16:57 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Language Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Config Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Loader Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:16:57 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:16:57 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Session Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:16:57 --> Session routines successfully run
DEBUG - 2016-02-10 22:16:57 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Email Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Controller Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:16:57 --> Model Class Initialized
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:16:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:16:57 --> Final output sent to browser
DEBUG - 2016-02-10 22:16:57 --> Total execution time: 0.3603
DEBUG - 2016-02-10 22:17:17 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:17:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:17:17 --> URI Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Router Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Output Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Security Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Input Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:17:17 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Loader Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:17:17 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:17:17 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Session Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:17:17 --> Session routines successfully run
DEBUG - 2016-02-10 22:17:17 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Email Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Controller Class Initialized
DEBUG - 2016-02-10 22:17:17 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:17:17 --> XSS Filtering completed
DEBUG - 2016-02-10 22:17:17 --> XSS Filtering completed
DEBUG - 2016-02-10 22:17:17 --> XSS Filtering completed
DEBUG - 2016-02-10 22:17:17 --> XSS Filtering completed
DEBUG - 2016-02-10 22:17:17 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:17:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:17:17 --> URI Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Router Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Output Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Security Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Input Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:17:17 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Loader Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:17:17 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:17:17 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Session Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:17:17 --> Session routines successfully run
DEBUG - 2016-02-10 22:17:17 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Email Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Controller Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:17:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:17:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:17:17 --> Final output sent to browser
DEBUG - 2016-02-10 22:17:17 --> Total execution time: 0.3032
DEBUG - 2016-02-10 22:17:20 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:17:20 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:17:20 --> URI Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Router Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Output Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Security Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Input Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:17:20 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Loader Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:17:20 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:17:20 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Session Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:17:20 --> Session routines successfully run
DEBUG - 2016-02-10 22:17:20 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Email Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Controller Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:17:20 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:20 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:17:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:17:20 --> Final output sent to browser
DEBUG - 2016-02-10 22:17:20 --> Total execution time: 0.2936
DEBUG - 2016-02-10 22:17:35 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:17:35 --> URI Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Router Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Output Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Security Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Input Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:17:35 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Loader Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:17:35 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:17:35 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Session Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:17:35 --> Session routines successfully run
DEBUG - 2016-02-10 22:17:35 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Email Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Controller Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:17:35 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:17:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:17:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:17:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:17:36 --> Final output sent to browser
DEBUG - 2016-02-10 22:17:36 --> Total execution time: 0.3106
DEBUG - 2016-02-10 22:17:41 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:17:41 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:17:41 --> URI Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Router Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Output Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Security Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Input Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:17:41 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Loader Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:17:41 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:17:41 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Session Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:17:41 --> Session routines successfully run
DEBUG - 2016-02-10 22:17:41 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Email Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Controller Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:17:41 --> XSS Filtering completed
DEBUG - 2016-02-10 22:17:41 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:17:41 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:17:41 --> URI Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Router Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Output Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Security Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Input Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:17:41 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Language Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Config Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Loader Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:17:41 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:17:41 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Session Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:17:41 --> Session routines successfully run
DEBUG - 2016-02-10 22:17:41 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Email Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Controller Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:17:41 --> Model Class Initialized
DEBUG - 2016-02-10 22:17:42 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:17:42 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:17:42 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:17:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:17:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:17:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:17:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:17:42 --> Final output sent to browser
DEBUG - 2016-02-10 22:17:42 --> Total execution time: 0.2995
DEBUG - 2016-02-10 22:18:04 --> Config Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:18:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:18:04 --> URI Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Router Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Output Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Security Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Input Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:18:04 --> Language Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Language Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Config Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Loader Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:18:04 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:18:04 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Session Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:18:04 --> Session routines successfully run
DEBUG - 2016-02-10 22:18:04 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Email Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Controller Class Initialized
DEBUG - 2016-02-10 22:18:04 --> leases MX_Controller Initialized
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 22:18:04 --> XSS Filtering completed
DEBUG - 2016-02-10 22:18:04 --> XSS Filtering completed
DEBUG - 2016-02-10 22:18:04 --> XSS Filtering completed
DEBUG - 2016-02-10 22:18:04 --> XSS Filtering completed
DEBUG - 2016-02-10 22:18:04 --> Config Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:18:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:18:04 --> URI Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Router Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Output Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Security Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Input Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:18:04 --> Language Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Language Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Config Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Loader Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:18:04 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:18:04 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Session Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:18:04 --> Session routines successfully run
DEBUG - 2016-02-10 22:18:04 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Email Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Controller Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:18:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:05 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-10 22:18:05 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-10 22:18:05 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-10 22:18:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:18:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:18:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:18:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:18:05 --> Final output sent to browser
DEBUG - 2016-02-10 22:18:05 --> Total execution time: 0.3012
DEBUG - 2016-02-10 22:18:07 --> Config Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:18:07 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:18:07 --> URI Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Router Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Output Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Security Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Input Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:18:07 --> Language Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Language Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Config Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Loader Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:18:07 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:18:07 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Session Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:18:07 --> Session routines successfully run
DEBUG - 2016-02-10 22:18:07 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Email Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Controller Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:18:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:07 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:18:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:18:07 --> Final output sent to browser
DEBUG - 2016-02-10 22:18:07 --> Total execution time: 0.2914
DEBUG - 2016-02-10 22:18:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:18:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:18:16 --> URI Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Router Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Output Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Security Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Input Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:18:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Loader Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:18:16 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:18:16 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Session Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:18:16 --> Session routines successfully run
DEBUG - 2016-02-10 22:18:16 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Email Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Controller Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:18:16 --> Model Class Initialized
ERROR - 2016-02-10 22:18:16 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:18:16 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:18:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:18:16 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:18:17 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:18:17 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:18:17 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:18:17 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:18:17 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:18:17 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:18:17 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:18:17 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 22:18:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:18:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:18:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:18:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:18:17 --> Final output sent to browser
DEBUG - 2016-02-10 22:18:17 --> Total execution time: 0.5945
DEBUG - 2016-02-10 22:19:17 --> Config Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:19:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:19:17 --> URI Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Router Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Output Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Security Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Input Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:19:17 --> Language Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Language Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Config Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Loader Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:19:17 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:19:17 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Session Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:19:17 --> Session routines successfully run
DEBUG - 2016-02-10 22:19:17 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Email Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Controller Class Initialized
DEBUG - 2016-02-10 22:19:17 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 22:19:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:19:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:19:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 22:19:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:19:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:19:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:19:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:19:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:19:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:19:17 --> Final output sent to browser
DEBUG - 2016-02-10 22:19:17 --> Total execution time: 0.4417
DEBUG - 2016-02-10 22:22:00 --> Config Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:22:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:22:00 --> URI Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Router Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Output Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Security Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Input Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:22:00 --> Language Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Language Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Config Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Loader Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:22:00 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:22:00 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Session Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:22:00 --> Session routines successfully run
DEBUG - 2016-02-10 22:22:00 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Email Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Controller Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:00 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:22:00 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Config Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:22:14 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:22:14 --> URI Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Router Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Output Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Security Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Input Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:22:14 --> Language Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Language Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Config Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Loader Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:22:14 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:22:14 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Session Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:22:14 --> Session routines successfully run
DEBUG - 2016-02-10 22:22:14 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Email Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Controller Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:14 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:22:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Config Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:22:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:22:50 --> URI Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Router Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Output Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Security Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Input Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:22:50 --> Language Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Language Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Config Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Loader Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:22:50 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:22:50 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Session Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:22:50 --> Session routines successfully run
DEBUG - 2016-02-10 22:22:50 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Email Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Controller Class Initialized
DEBUG - 2016-02-10 22:22:50 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:22:50 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:22:50 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:22:50 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:22:50 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:22:50 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:22:50 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:22:50 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:22:50 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:22:50 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:22:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:51 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:22:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:22:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:22:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:22:51 --> Model Class Initialized
ERROR - 2016-02-10 22:22:51 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:22:51 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:22:51 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:22:51 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:22:51 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:22:51 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:22:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:22:51 --> Final output sent to browser
DEBUG - 2016-02-10 22:22:51 --> Total execution time: 0.3610
DEBUG - 2016-02-10 22:23:44 --> Config Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:23:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:23:44 --> URI Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Router Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Output Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Security Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Input Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:23:44 --> Language Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Language Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Config Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Loader Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:23:44 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:23:44 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Session Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:23:44 --> Session routines successfully run
DEBUG - 2016-02-10 22:23:44 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Email Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Controller Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:23:44 --> Model Class Initialized
ERROR - 2016-02-10 22:23:44 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:23:44 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:23:44 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:23:44 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:23:44 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-10 22:23:44 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:23:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:23:44 --> Final output sent to browser
DEBUG - 2016-02-10 22:23:44 --> Total execution time: 0.4101
DEBUG - 2016-02-10 22:25:48 --> Config Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:25:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:25:48 --> URI Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Router Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Output Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Security Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Input Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:25:48 --> Language Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Language Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Config Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Loader Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:25:48 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:25:48 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Session Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:25:48 --> Session routines successfully run
DEBUG - 2016-02-10 22:25:48 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Email Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Controller Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:25:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:25:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:25:48 --> Final output sent to browser
DEBUG - 2016-02-10 22:25:48 --> Total execution time: 0.4883
DEBUG - 2016-02-10 22:28:32 --> Config Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:28:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:28:32 --> URI Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Router Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Output Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Security Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Input Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:28:32 --> Language Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Language Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Config Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Loader Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:28:32 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:28:32 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Session Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:28:32 --> Session routines successfully run
DEBUG - 2016-02-10 22:28:32 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Email Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Controller Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:32 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:28:32 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Config Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:28:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:28:58 --> URI Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Router Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Output Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Security Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Input Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:28:58 --> Language Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Language Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Config Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Loader Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:28:58 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:28:58 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Session Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:28:58 --> Session routines successfully run
DEBUG - 2016-02-10 22:28:58 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Email Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Controller Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:28:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:28:58 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Config Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:30:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:30:04 --> URI Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Router Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Output Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Security Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Input Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:30:04 --> Language Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Language Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Config Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Loader Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:30:04 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:30:04 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Session Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:30:04 --> Session routines successfully run
DEBUG - 2016-02-10 22:30:04 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Email Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Controller Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:04 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:30:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Config Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:30:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:30:39 --> URI Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Router Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Output Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Security Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Input Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:30:39 --> Language Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Language Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Config Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Loader Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:30:39 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:30:39 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Session Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:30:39 --> Session routines successfully run
DEBUG - 2016-02-10 22:30:39 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Email Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Controller Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:30:39 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:30:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Config Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:31:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:31:05 --> URI Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Router Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Output Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Security Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Input Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:31:05 --> Language Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Language Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Config Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Loader Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:31:05 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:31:05 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Session Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:31:05 --> Session routines successfully run
DEBUG - 2016-02-10 22:31:05 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Email Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Controller Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:31:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Config Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:31:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:31:37 --> URI Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Router Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Output Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Security Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Input Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:31:37 --> Language Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Language Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Config Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Loader Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:31:37 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:31:37 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Session Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:31:37 --> Session routines successfully run
DEBUG - 2016-02-10 22:31:37 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Email Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Controller Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:31:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:31:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:32:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:32:16 --> URI Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Router Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Output Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Security Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Input Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:32:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Language Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Config Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Loader Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:32:16 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:32:16 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Session Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:32:16 --> Session routines successfully run
DEBUG - 2016-02-10 22:32:16 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Email Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Controller Class Initialized
DEBUG - 2016-02-10 22:32:16 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:32:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:32:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:32:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:32:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:32:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:32:16 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:32:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:32:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:32:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:32:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:17 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:32:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:32:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:32:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:32:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:17 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:32:17 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Config Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:32:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:32:50 --> URI Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Router Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Output Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Security Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Input Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:32:50 --> Language Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Language Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Config Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Loader Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:32:50 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:32:50 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Session Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:32:50 --> Session routines successfully run
DEBUG - 2016-02-10 22:32:50 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Email Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Controller Class Initialized
DEBUG - 2016-02-10 22:32:50 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:32:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:32:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Config Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:33:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:33:05 --> URI Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Router Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Output Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Security Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Input Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:33:05 --> Language Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Language Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Config Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Loader Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:33:05 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:33:05 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Session Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:33:05 --> Session routines successfully run
DEBUG - 2016-02-10 22:33:05 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Email Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Controller Class Initialized
DEBUG - 2016-02-10 22:33:05 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:33:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:33:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:33:05 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:06 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:33:06 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Config Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:33:07 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:33:07 --> URI Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Router Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Output Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Security Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Input Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:33:07 --> Language Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Language Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Config Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Loader Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:33:07 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:33:07 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Session Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:33:07 --> Session routines successfully run
DEBUG - 2016-02-10 22:33:07 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Email Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Controller Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:07 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:33:07 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Config Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:33:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:33:26 --> URI Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Router Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Output Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Security Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Input Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:33:26 --> Language Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Language Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Config Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Loader Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:33:26 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:33:26 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Session Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:33:26 --> Session routines successfully run
DEBUG - 2016-02-10 22:33:26 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Email Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Controller Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:33:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:33:26 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:34:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:34:04 --> URI Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Router Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Output Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Security Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Input Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:34:04 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Loader Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:34:04 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:34:04 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Session Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:34:04 --> Session routines successfully run
DEBUG - 2016-02-10 22:34:04 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Email Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Controller Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:04 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:34:04 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:34:14 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:34:14 --> URI Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Router Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Output Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Security Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Input Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:34:14 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Loader Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:34:14 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:34:14 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Session Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:34:14 --> Session routines successfully run
DEBUG - 2016-02-10 22:34:14 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Email Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Controller Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:14 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:34:14 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:34:15 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:34:15 --> URI Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Router Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Output Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Security Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Input Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:34:15 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Loader Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:34:15 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:34:15 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Session Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:34:15 --> Session routines successfully run
DEBUG - 2016-02-10 22:34:15 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Email Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Controller Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:15 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:34:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:34:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:34:25 --> URI Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Router Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Output Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Security Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Input Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:34:25 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Loader Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:34:25 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:34:25 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Session Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:34:25 --> Session routines successfully run
DEBUG - 2016-02-10 22:34:25 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Email Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Controller Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:25 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:34:25 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:34:34 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:34:34 --> URI Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Router Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Output Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Security Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Input Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:34:34 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Language Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Config Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Loader Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:34:34 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:34:34 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Session Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:34:34 --> Session routines successfully run
DEBUG - 2016-02-10 22:34:34 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Email Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Controller Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:34:34 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:34:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Config Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:35:33 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:35:33 --> URI Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Router Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Output Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Security Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Input Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:35:33 --> Language Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Language Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Config Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Loader Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:35:33 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:35:33 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Session Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:35:33 --> Session routines successfully run
DEBUG - 2016-02-10 22:35:33 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Email Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Controller Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:35:33 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:35:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:50 --> Config Class Initialized
DEBUG - 2016-02-10 22:36:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:36:50 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:36:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:36:50 --> URI Class Initialized
DEBUG - 2016-02-10 22:36:50 --> Router Class Initialized
DEBUG - 2016-02-10 22:36:50 --> Output Class Initialized
DEBUG - 2016-02-10 22:36:50 --> Security Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Input Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:36:51 --> Language Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Language Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Config Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Loader Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:36:51 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:36:51 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Session Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:36:51 --> Session routines successfully run
DEBUG - 2016-02-10 22:36:51 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Email Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Controller Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:36:51 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:52 --> Config Class Initialized
DEBUG - 2016-02-10 22:36:52 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:36:52 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:36:52 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:36:52 --> URI Class Initialized
DEBUG - 2016-02-10 22:36:52 --> Router Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Output Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Security Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Input Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:36:53 --> Language Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Language Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Config Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Loader Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:36:53 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:36:53 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Session Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:36:53 --> Session routines successfully run
DEBUG - 2016-02-10 22:36:53 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Email Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Controller Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:36:53 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:36:53 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Config Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:37:03 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:37:03 --> URI Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Router Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Output Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Security Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Input Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:37:03 --> Language Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Language Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Config Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Loader Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:37:03 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:37:03 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Session Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:37:03 --> Session routines successfully run
DEBUG - 2016-02-10 22:37:03 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Email Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Controller Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:03 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:37:03 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Config Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:37:15 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:37:15 --> URI Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Router Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Output Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Security Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Input Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:37:15 --> Language Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Language Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Config Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Loader Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:37:15 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:37:15 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Session Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:37:15 --> Session routines successfully run
DEBUG - 2016-02-10 22:37:15 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Email Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Controller Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:37:15 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:37:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Config Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:50:33 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:50:33 --> URI Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Router Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Output Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Security Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Input Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:50:33 --> Language Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Language Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Config Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Loader Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:50:33 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:50:33 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Session Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:50:33 --> Session routines successfully run
DEBUG - 2016-02-10 22:50:33 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Email Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Controller Class Initialized
DEBUG - 2016-02-10 22:50:33 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:50:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:50:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:50:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:50:33 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:34 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:50:34 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Config Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:50:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:50:43 --> URI Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Router Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Output Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Security Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Input Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:50:43 --> Language Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Language Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Config Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Loader Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:50:43 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:50:43 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Session Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:50:43 --> Session routines successfully run
DEBUG - 2016-02-10 22:50:43 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Email Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Controller Class Initialized
DEBUG - 2016-02-10 22:50:43 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:50:43 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:44 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:50:44 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:44 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:44 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:50:44 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:50:44 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Config Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:51:47 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:51:47 --> URI Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Router Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Output Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Security Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Input Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:51:47 --> Language Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Language Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Config Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Loader Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:51:47 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:51:47 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Session Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:51:47 --> Session routines successfully run
DEBUG - 2016-02-10 22:51:47 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Email Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Controller Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:47 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:51:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Config Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:51:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:51:48 --> URI Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Router Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Output Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Security Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Input Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:51:48 --> Language Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Language Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Config Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Loader Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:51:48 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:51:48 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Session Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:51:48 --> Session routines successfully run
DEBUG - 2016-02-10 22:51:48 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Email Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Controller Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:51:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:51:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Config Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:52:15 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:52:15 --> URI Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Router Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Output Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Security Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Input Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:52:15 --> Language Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Language Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Config Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Loader Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:52:15 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:52:15 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Session Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:52:15 --> Session routines successfully run
DEBUG - 2016-02-10 22:52:15 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Email Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Controller Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:52:15 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:52:15 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Config Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:53:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:53:36 --> URI Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Router Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Output Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Security Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Input Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:53:36 --> Language Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Language Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Config Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Loader Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:53:36 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:53:36 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Session Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:53:36 --> Session routines successfully run
DEBUG - 2016-02-10 22:53:36 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Email Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Controller Class Initialized
DEBUG - 2016-02-10 22:53:36 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:53:36 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:37 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:53:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:53:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:53:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:53:37 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:53:37 --> Model Class Initialized
ERROR - 2016-02-10 22:53:37 --> Severity: Notice  --> Undefined variable: diff C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 1309
DEBUG - 2016-02-10 22:53:47 --> Config Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:53:47 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:53:47 --> URI Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Router Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Output Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Security Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Input Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:53:47 --> Language Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Language Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Config Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Loader Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:53:47 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:53:47 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Session Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:53:47 --> Session routines successfully run
DEBUG - 2016-02-10 22:53:47 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Email Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Controller Class Initialized
DEBUG - 2016-02-10 22:53:47 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:53:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:53:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:53:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:53:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:53:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:53:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:53:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:53:47 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:53:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:53:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:48 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:53:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:53:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:53:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:53:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:53:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:53:48 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:08 --> Config Class Initialized
DEBUG - 2016-02-10 22:54:08 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:54:08 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:54:08 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:54:08 --> URI Class Initialized
DEBUG - 2016-02-10 22:54:08 --> Router Class Initialized
DEBUG - 2016-02-10 22:54:08 --> Output Class Initialized
DEBUG - 2016-02-10 22:54:08 --> Security Class Initialized
DEBUG - 2016-02-10 22:54:08 --> Input Class Initialized
DEBUG - 2016-02-10 22:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:54:08 --> Language Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Language Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Config Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Loader Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:54:09 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:54:09 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Session Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:54:09 --> Session routines successfully run
DEBUG - 2016-02-10 22:54:09 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Email Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Controller Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:09 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:54:09 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:38 --> Config Class Initialized
DEBUG - 2016-02-10 22:54:38 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:54:38 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:54:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:54:38 --> URI Class Initialized
DEBUG - 2016-02-10 22:54:38 --> Router Class Initialized
DEBUG - 2016-02-10 22:54:38 --> Output Class Initialized
DEBUG - 2016-02-10 22:54:38 --> Security Class Initialized
DEBUG - 2016-02-10 22:54:38 --> Input Class Initialized
DEBUG - 2016-02-10 22:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:54:38 --> Language Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Language Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Config Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Loader Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:54:39 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:54:39 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Session Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:54:39 --> Session routines successfully run
DEBUG - 2016-02-10 22:54:39 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Email Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Controller Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:39 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:54:39 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Config Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Hooks Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Utf8 Class Initialized
DEBUG - 2016-02-10 22:54:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 22:54:45 --> URI Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Router Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Output Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Security Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Input Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 22:54:45 --> Language Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Language Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Config Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Loader Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Helper loaded: url_helper
DEBUG - 2016-02-10 22:54:45 --> Helper loaded: form_helper
DEBUG - 2016-02-10 22:54:45 --> Database Driver Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Session Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Helper loaded: string_helper
DEBUG - 2016-02-10 22:54:45 --> Session routines successfully run
DEBUG - 2016-02-10 22:54:45 --> Form Validation Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Pagination Class Initialized
DEBUG - 2016-02-10 22:54:45 --> Encrypt Class Initialized
DEBUG - 2016-02-10 22:54:46 --> Email Class Initialized
DEBUG - 2016-02-10 22:54:46 --> Controller Class Initialized
DEBUG - 2016-02-10 22:54:46 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> Image Lib Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 22:54:46 --> Model Class Initialized
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 22:54:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 22:54:46 --> Final output sent to browser
DEBUG - 2016-02-10 22:54:46 --> Total execution time: 0.7344
DEBUG - 2016-02-10 23:00:25 --> Config Class Initialized
DEBUG - 2016-02-10 23:00:25 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:00:25 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:00:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:00:25 --> URI Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Router Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Output Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Security Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Input Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:00:26 --> Language Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Language Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Config Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Loader Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:00:26 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:00:26 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Session Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:00:26 --> Session routines successfully run
DEBUG - 2016-02-10 23:00:26 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Email Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Controller Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:00:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:00:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:00:26 --> Final output sent to browser
DEBUG - 2016-02-10 23:00:26 --> Total execution time: 0.5259
DEBUG - 2016-02-10 23:00:29 --> Config Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:00:29 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:00:29 --> URI Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Router Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Output Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Security Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Input Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:00:29 --> Language Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Language Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Config Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Loader Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:00:29 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:00:29 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Session Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:00:29 --> Session routines successfully run
DEBUG - 2016-02-10 23:00:29 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Email Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Controller Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:00:29 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:00:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:00:29 --> Final output sent to browser
DEBUG - 2016-02-10 23:00:29 --> Total execution time: 0.3750
DEBUG - 2016-02-10 23:00:55 --> Config Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:00:55 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:00:55 --> URI Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Router Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Output Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Security Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Input Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:00:55 --> Language Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Language Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Config Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Loader Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:00:55 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:00:55 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Session Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:00:55 --> Session routines successfully run
DEBUG - 2016-02-10 23:00:55 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Email Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Controller Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:00:55 --> Model Class Initialized
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:00:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:00:55 --> Final output sent to browser
DEBUG - 2016-02-10 23:00:55 --> Total execution time: 0.3597
DEBUG - 2016-02-10 23:01:35 --> Config Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:01:35 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:01:35 --> URI Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Router Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Output Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Security Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Input Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:01:35 --> Language Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Language Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Config Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Loader Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:01:35 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:01:35 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Session Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:01:35 --> Session routines successfully run
DEBUG - 2016-02-10 23:01:35 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Email Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Controller Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:35 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:01:35 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Config Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:01:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:01:44 --> URI Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Router Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Output Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Security Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Input Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:01:44 --> Language Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Language Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Config Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Loader Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:01:44 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:01:44 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Session Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:01:44 --> Session routines successfully run
DEBUG - 2016-02-10 23:01:44 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Email Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Controller Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:44 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:01:44 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Config Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:01:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:01:50 --> URI Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Router Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Output Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Security Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Input Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:01:50 --> Language Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Language Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Config Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Loader Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:01:50 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:01:50 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Session Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:01:50 --> Session routines successfully run
DEBUG - 2016-02-10 23:01:50 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Email Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Controller Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:01:50 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:01:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Config Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:02:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:02:17 --> URI Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Router Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Output Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Security Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Input Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:02:17 --> Language Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Language Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Config Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Loader Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:02:17 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:02:17 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Session Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:02:17 --> Session routines successfully run
DEBUG - 2016-02-10 23:02:17 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Email Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Controller Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:17 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:02:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Config Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:02:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:02:54 --> URI Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Router Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Output Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Security Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Input Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:02:54 --> Language Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Language Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Config Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Loader Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:02:54 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:02:54 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Session Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:02:54 --> Session routines successfully run
DEBUG - 2016-02-10 23:02:54 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Email Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Controller Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:02:54 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:02:54 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:25 --> Config Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:04:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:04:26 --> URI Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Router Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Output Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Security Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Input Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:04:26 --> Language Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Language Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Config Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Loader Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:04:26 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:04:26 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Session Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:04:26 --> Session routines successfully run
DEBUG - 2016-02-10 23:04:26 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Email Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Controller Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:04:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:04:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:04:26 --> Final output sent to browser
DEBUG - 2016-02-10 23:04:26 --> Total execution time: 0.4566
DEBUG - 2016-02-10 23:04:47 --> Config Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:04:47 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:04:47 --> URI Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Router Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Output Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Security Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Input Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:04:47 --> Language Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Language Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Config Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Loader Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:04:47 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:04:47 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Session Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:04:47 --> Session routines successfully run
DEBUG - 2016-02-10 23:04:47 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Email Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Controller Class Initialized
DEBUG - 2016-02-10 23:04:47 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:04:47 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:04:47 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:04:47 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:04:47 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:04:47 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:04:47 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:04:47 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:04:47 --> Model Class Initialized
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:04:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:04:47 --> Final output sent to browser
DEBUG - 2016-02-10 23:04:47 --> Total execution time: 0.3124
DEBUG - 2016-02-10 23:05:28 --> Config Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:05:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:05:28 --> URI Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Router Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Output Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Security Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Input Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:05:28 --> Language Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Language Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Config Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Loader Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:05:28 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:05:28 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Session Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:05:28 --> Session routines successfully run
DEBUG - 2016-02-10 23:05:28 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Email Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Controller Class Initialized
DEBUG - 2016-02-10 23:05:28 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:05:28 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:05:28 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:05:28 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:28 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:05:28 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:05:28 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:05:28 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:05:28 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:28 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:05:28 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:28 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:05:29 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-10 23:05:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:05:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:05:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:05:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:05:29 --> Final output sent to browser
DEBUG - 2016-02-10 23:05:29 --> Total execution time: 0.5112
DEBUG - 2016-02-10 23:05:59 --> Config Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:05:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:05:59 --> URI Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Router Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Output Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Security Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Input Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:05:59 --> Language Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Language Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Config Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Loader Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:05:59 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:05:59 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Session Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:05:59 --> Session routines successfully run
DEBUG - 2016-02-10 23:05:59 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Email Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Controller Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:05:59 --> Model Class Initialized
ERROR - 2016-02-10 23:05:59 --> Severity: Warning  --> Missing argument 2 for Accounts_model::get_months_last_amount(), called in C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php on line 374 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 81
ERROR - 2016-02-10 23:05:59 --> Severity: Notice  --> Undefined variable: rent_amount C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 101
ERROR - 2016-02-10 23:05:59 --> Severity: Warning  --> Missing argument 2 for Accounts_model::get_months_last_amount(), called in C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php on line 374 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 81
ERROR - 2016-02-10 23:05:59 --> Severity: Notice  --> Undefined variable: rent_amount C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 101
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:05:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:05:59 --> Final output sent to browser
DEBUG - 2016-02-10 23:05:59 --> Total execution time: 0.4840
DEBUG - 2016-02-10 23:07:19 --> Config Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:07:19 --> URI Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Router Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Output Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Security Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Input Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:07:19 --> Language Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Language Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Config Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Loader Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:07:19 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:07:19 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Session Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:07:19 --> Session routines successfully run
DEBUG - 2016-02-10 23:07:19 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Email Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Controller Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:07:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:07:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:07:19 --> Final output sent to browser
DEBUG - 2016-02-10 23:07:19 --> Total execution time: 0.3012
DEBUG - 2016-02-10 23:14:07 --> Config Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:14:07 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:14:07 --> URI Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Router Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Output Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Security Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Input Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:14:07 --> Language Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Language Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Config Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Loader Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:14:07 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:14:07 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Session Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:14:07 --> Session routines successfully run
DEBUG - 2016-02-10 23:14:07 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Email Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Controller Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:14:07 --> Model Class Initialized
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:14:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:14:07 --> Final output sent to browser
DEBUG - 2016-02-10 23:14:07 --> Total execution time: 0.3008
DEBUG - 2016-02-10 23:15:49 --> Config Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:15:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:15:49 --> URI Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Router Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Output Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Security Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Input Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:15:49 --> Language Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Language Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Config Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Loader Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:15:49 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:15:49 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Session Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:15:49 --> Session routines successfully run
DEBUG - 2016-02-10 23:15:49 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Email Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Controller Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:15:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:50 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:15:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:50 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:15:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:15:50 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:15:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:15:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:15:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:15:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:15:50 --> Final output sent to browser
DEBUG - 2016-02-10 23:15:50 --> Total execution time: 0.3132
DEBUG - 2016-02-10 23:16:59 --> Config Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:16:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:16:59 --> URI Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Router Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Output Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Security Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Input Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:16:59 --> Language Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Language Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Config Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Loader Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:16:59 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:16:59 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Session Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:16:59 --> Session routines successfully run
DEBUG - 2016-02-10 23:16:59 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Email Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Controller Class Initialized
DEBUG - 2016-02-10 23:16:59 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:16:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:16:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:16:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:16:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:16:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:16:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:16:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:16:59 --> Model Class Initialized
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:16:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:16:59 --> Final output sent to browser
DEBUG - 2016-02-10 23:16:59 --> Total execution time: 0.4539
DEBUG - 2016-02-10 23:18:40 --> Config Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:18:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:18:40 --> URI Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Router Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Output Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Security Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Input Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:18:40 --> Language Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Language Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Config Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Loader Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:18:40 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:18:40 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Session Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:18:40 --> Session routines successfully run
DEBUG - 2016-02-10 23:18:40 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Email Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Controller Class Initialized
DEBUG - 2016-02-10 23:18:40 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:40 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:18:40 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:41 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:18:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:18:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:18:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:18:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:18:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:18:41 --> Final output sent to browser
DEBUG - 2016-02-10 23:18:41 --> Total execution time: 0.4194
DEBUG - 2016-02-10 23:19:02 --> Config Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:19:02 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:19:02 --> URI Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Router Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Output Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Security Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Input Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:19:02 --> Language Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Language Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Config Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Loader Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:19:02 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:19:02 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Session Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:19:02 --> Session routines successfully run
DEBUG - 2016-02-10 23:19:02 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Email Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Controller Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:19:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:19:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:19:02 --> Final output sent to browser
DEBUG - 2016-02-10 23:19:02 --> Total execution time: 0.3708
DEBUG - 2016-02-10 23:19:30 --> Config Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:19:30 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:19:30 --> URI Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Router Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Output Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Security Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Input Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:19:30 --> Language Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Language Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Config Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Loader Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:19:30 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:19:30 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Session Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:19:30 --> Session routines successfully run
DEBUG - 2016-02-10 23:19:30 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Email Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Controller Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:19:30 --> Model Class Initialized
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:19:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:19:30 --> Final output sent to browser
DEBUG - 2016-02-10 23:19:30 --> Total execution time: 0.3936
DEBUG - 2016-02-10 23:25:17 --> Config Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:25:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:25:17 --> URI Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Router Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Output Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Security Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Input Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:25:17 --> Language Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Language Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Config Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Loader Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:25:17 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:25:17 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Session Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:25:17 --> Session routines successfully run
DEBUG - 2016-02-10 23:25:17 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:25:17 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:25:18 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:25:18 --> Email Class Initialized
DEBUG - 2016-02-10 23:25:18 --> Controller Class Initialized
DEBUG - 2016-02-10 23:25:18 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:25:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:25:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:25:18 --> Final output sent to browser
DEBUG - 2016-02-10 23:25:18 --> Total execution time: 0.5807
DEBUG - 2016-02-10 23:25:56 --> Config Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:25:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:25:56 --> URI Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Router Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Output Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Security Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Input Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:25:56 --> Language Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Language Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Config Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Loader Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:25:56 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:25:56 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Session Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:25:56 --> Session routines successfully run
DEBUG - 2016-02-10 23:25:56 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Email Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Controller Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:25:56 --> Model Class Initialized
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:25:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:25:56 --> Final output sent to browser
DEBUG - 2016-02-10 23:25:56 --> Total execution time: 0.3892
DEBUG - 2016-02-10 23:29:05 --> Config Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:29:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:29:05 --> URI Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Router Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Output Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Security Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Input Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:29:05 --> Language Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Language Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Config Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Loader Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:29:05 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:29:05 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Session Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:29:05 --> Session routines successfully run
DEBUG - 2016-02-10 23:29:05 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Email Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Controller Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:29:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:29:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:29:05 --> Final output sent to browser
DEBUG - 2016-02-10 23:29:05 --> Total execution time: 0.3486
DEBUG - 2016-02-10 23:29:49 --> Config Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:29:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:29:49 --> URI Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Router Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Output Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Security Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Input Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:29:49 --> Language Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Language Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Config Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Loader Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:29:49 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:29:49 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Session Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:29:49 --> Session routines successfully run
DEBUG - 2016-02-10 23:29:49 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Email Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Controller Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:29:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 23:29:49 --> XSS Filtering completed
DEBUG - 2016-02-10 23:29:49 --> XSS Filtering completed
DEBUG - 2016-02-10 23:29:49 --> XSS Filtering completed
DEBUG - 2016-02-10 23:29:50 --> Config Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:29:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:29:50 --> URI Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Router Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Output Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Security Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Input Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:29:50 --> Language Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Language Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Config Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Loader Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:29:50 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:29:50 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Session Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:29:50 --> Session routines successfully run
DEBUG - 2016-02-10 23:29:50 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Email Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Controller Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:29:50 --> Model Class Initialized
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:29:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:29:50 --> Final output sent to browser
DEBUG - 2016-02-10 23:29:50 --> Total execution time: 0.2912
DEBUG - 2016-02-10 23:30:20 --> Config Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:30:20 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:30:20 --> URI Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Router Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Output Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Security Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Input Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:30:20 --> Language Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Language Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Config Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Loader Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:30:20 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:30:20 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Session Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:30:20 --> Session routines successfully run
DEBUG - 2016-02-10 23:30:20 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Email Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Controller Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:30:20 --> Model Class Initialized
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:30:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:30:20 --> Final output sent to browser
DEBUG - 2016-02-10 23:30:20 --> Total execution time: 0.3194
DEBUG - 2016-02-10 23:31:00 --> Config Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:31:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:31:00 --> URI Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Router Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Output Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Security Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Input Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:31:00 --> Language Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Language Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Config Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Loader Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:31:00 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:31:00 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Session Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:31:00 --> Session routines successfully run
DEBUG - 2016-02-10 23:31:00 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Email Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Controller Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:31:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 23:31:00 --> XSS Filtering completed
DEBUG - 2016-02-10 23:31:00 --> XSS Filtering completed
DEBUG - 2016-02-10 23:31:00 --> XSS Filtering completed
DEBUG - 2016-02-10 23:31:00 --> XSS Filtering completed
DEBUG - 2016-02-10 23:31:00 --> Config Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:31:00 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:31:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:31:00 --> URI Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Router Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Output Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Security Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Input Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:31:01 --> Language Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Language Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Config Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Loader Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:31:01 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:31:01 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Session Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:31:01 --> Session routines successfully run
DEBUG - 2016-02-10 23:31:01 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Email Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Controller Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:31:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:31:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:31:01 --> Final output sent to browser
DEBUG - 2016-02-10 23:31:01 --> Total execution time: 0.3080
DEBUG - 2016-02-10 23:31:16 --> Config Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:31:16 --> URI Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Router Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Output Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Security Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Input Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:31:16 --> Language Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Language Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Config Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Loader Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:31:16 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:31:16 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Session Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:31:16 --> Session routines successfully run
DEBUG - 2016-02-10 23:31:16 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Email Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Controller Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:31:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:31:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:31:16 --> Final output sent to browser
DEBUG - 2016-02-10 23:31:16 --> Total execution time: 0.3584
DEBUG - 2016-02-10 23:31:41 --> Config Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:31:41 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:31:41 --> URI Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Router Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Output Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Security Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Input Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:31:41 --> Language Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Language Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Config Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Loader Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:31:41 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:31:41 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Session Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:31:41 --> Session routines successfully run
DEBUG - 2016-02-10 23:31:41 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Email Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Controller Class Initialized
DEBUG - 2016-02-10 23:31:41 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:31:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:31:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:31:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:31:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:31:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:31:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:31:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:31:41 --> Model Class Initialized
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:31:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:31:41 --> Final output sent to browser
DEBUG - 2016-02-10 23:31:41 --> Total execution time: 0.2746
DEBUG - 2016-02-10 23:32:48 --> Config Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:32:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:32:48 --> URI Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Router Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Output Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Security Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Input Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:32:48 --> Language Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Language Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Config Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Loader Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:32:48 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:32:48 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Session Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:32:48 --> Session routines successfully run
DEBUG - 2016-02-10 23:32:48 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Email Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Controller Class Initialized
DEBUG - 2016-02-10 23:32:48 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:32:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:32:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:32:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:32:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:32:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:32:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:32:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:32:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:32:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:32:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:32:49 --> Final output sent to browser
DEBUG - 2016-02-10 23:32:49 --> Total execution time: 0.5219
DEBUG - 2016-02-10 23:34:03 --> Config Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:34:03 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:34:03 --> URI Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Router Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Output Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Security Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Input Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:34:03 --> Language Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Language Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Config Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Loader Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:34:03 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:34:03 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Session Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:34:03 --> Session routines successfully run
DEBUG - 2016-02-10 23:34:03 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Email Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Controller Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-10 23:34:03 --> XSS Filtering completed
DEBUG - 2016-02-10 23:34:03 --> XSS Filtering completed
DEBUG - 2016-02-10 23:34:03 --> XSS Filtering completed
DEBUG - 2016-02-10 23:34:03 --> XSS Filtering completed
DEBUG - 2016-02-10 23:34:03 --> Config Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:34:03 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:34:03 --> URI Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Router Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Output Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Security Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Input Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:34:03 --> Language Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Language Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Config Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Loader Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:34:03 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:34:03 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Session Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:34:03 --> Session routines successfully run
DEBUG - 2016-02-10 23:34:03 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Email Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Controller Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:34:03 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:34:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:34:03 --> Final output sent to browser
DEBUG - 2016-02-10 23:34:03 --> Total execution time: 0.2955
DEBUG - 2016-02-10 23:34:11 --> Config Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:34:11 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:34:11 --> URI Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Router Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Output Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Security Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Input Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:34:11 --> Language Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Language Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Config Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Loader Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:34:11 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:34:11 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Session Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:34:11 --> Session routines successfully run
DEBUG - 2016-02-10 23:34:11 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Email Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Controller Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:34:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:34:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:34:11 --> Final output sent to browser
DEBUG - 2016-02-10 23:34:11 --> Total execution time: 0.3777
DEBUG - 2016-02-10 23:38:52 --> Config Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:38:52 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:38:52 --> URI Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Router Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Output Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Security Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Input Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:38:52 --> Language Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Language Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Config Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Loader Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:38:52 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:38:52 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Session Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:38:52 --> Session routines successfully run
DEBUG - 2016-02-10 23:38:52 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Email Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Controller Class Initialized
DEBUG - 2016-02-10 23:38:52 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:38:52 --> Model Class Initialized
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:38:52 --> Model Class Initialized
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:38:52 --> Model Class Initialized
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:38:52 --> Model Class Initialized
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:38:52 --> Model Class Initialized
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:38:52 --> Model Class Initialized
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:38:52 --> Model Class Initialized
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:38:52 --> Model Class Initialized
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:38:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:38:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:38:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:38:53 --> Final output sent to browser
DEBUG - 2016-02-10 23:38:53 --> Total execution time: 0.2801
DEBUG - 2016-02-10 23:39:00 --> Config Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:39:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:39:00 --> URI Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Router Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Output Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Security Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Input Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:39:00 --> Language Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Language Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Config Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Loader Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:39:00 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:39:00 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Session Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:39:00 --> Session routines successfully run
DEBUG - 2016-02-10 23:39:00 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Email Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Controller Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:39:00 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:39:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:39:00 --> Final output sent to browser
DEBUG - 2016-02-10 23:39:00 --> Total execution time: 0.3747
DEBUG - 2016-02-10 23:39:36 --> Config Class Initialized
DEBUG - 2016-02-10 23:39:36 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:39:36 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:39:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:39:36 --> URI Class Initialized
DEBUG - 2016-02-10 23:39:36 --> Router Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Output Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Security Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Input Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:39:37 --> Language Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Language Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Config Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Loader Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:39:37 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:39:37 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Session Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:39:37 --> Session routines successfully run
DEBUG - 2016-02-10 23:39:37 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Email Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Controller Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:39:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:39:37 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Config Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:40:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:40:57 --> URI Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Router Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Output Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Security Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Input Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:40:57 --> Language Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Language Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Config Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Loader Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:40:57 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:40:57 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Session Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:40:57 --> Session routines successfully run
DEBUG - 2016-02-10 23:40:57 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Email Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Controller Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:40:57 --> Model Class Initialized
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:40:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:40:57 --> Final output sent to browser
DEBUG - 2016-02-10 23:40:57 --> Total execution time: 0.3568
DEBUG - 2016-02-10 23:41:13 --> Config Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:41:13 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:41:13 --> URI Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Router Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Output Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Security Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Input Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:41:13 --> Language Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Language Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Config Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Loader Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:41:13 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:41:13 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Session Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:41:13 --> Session routines successfully run
DEBUG - 2016-02-10 23:41:13 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Email Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Controller Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:41:13 --> Model Class Initialized
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:41:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:41:13 --> Final output sent to browser
DEBUG - 2016-02-10 23:41:13 --> Total execution time: 0.3711
DEBUG - 2016-02-10 23:42:11 --> Config Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:42:11 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:42:11 --> URI Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Router Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Output Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Security Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Input Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:42:11 --> Language Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Language Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Config Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Loader Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:42:11 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:42:11 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Session Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:42:11 --> Session routines successfully run
DEBUG - 2016-02-10 23:42:11 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Email Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Controller Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:42:11 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:42:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:42:11 --> Final output sent to browser
DEBUG - 2016-02-10 23:42:11 --> Total execution time: 0.3868
DEBUG - 2016-02-10 23:42:18 --> Config Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:42:18 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:42:18 --> URI Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Router Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Output Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Security Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Input Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:42:18 --> Language Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Language Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Config Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Loader Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:42:18 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:42:18 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Session Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:42:18 --> Session routines successfully run
DEBUG - 2016-02-10 23:42:18 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Email Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Controller Class Initialized
DEBUG - 2016-02-10 23:42:18 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:42:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:42:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:42:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:42:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:42:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:42:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:42:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:42:18 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:42:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:42:18 --> Final output sent to browser
DEBUG - 2016-02-10 23:42:18 --> Total execution time: 0.3028
DEBUG - 2016-02-10 23:42:25 --> Config Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:42:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:42:25 --> URI Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Router Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Output Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Security Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Input Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:42:25 --> Language Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Language Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Config Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Loader Class Initialized
DEBUG - 2016-02-10 23:42:25 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:42:25 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:42:26 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:42:26 --> Session Class Initialized
DEBUG - 2016-02-10 23:42:26 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:42:26 --> Session routines successfully run
DEBUG - 2016-02-10 23:42:26 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:42:26 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:42:26 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:42:26 --> Email Class Initialized
DEBUG - 2016-02-10 23:42:26 --> Controller Class Initialized
DEBUG - 2016-02-10 23:42:26 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:42:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:42:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:42:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:42:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:42:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:42:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:42:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:42:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:42:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:42:26 --> Final output sent to browser
DEBUG - 2016-02-10 23:42:26 --> Total execution time: 0.3098
DEBUG - 2016-02-10 23:42:48 --> Config Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:42:48 --> URI Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Router Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Output Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Security Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Input Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:42:48 --> Language Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Language Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Config Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Loader Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:42:48 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:42:48 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Session Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:42:48 --> Session routines successfully run
DEBUG - 2016-02-10 23:42:48 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Email Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Controller Class Initialized
DEBUG - 2016-02-10 23:42:48 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:42:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:42:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:42:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:48 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:42:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:42:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:42:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:42:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:42:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:42:48 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:43:05 --> Config Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:43:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:43:05 --> URI Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Router Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Output Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Security Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Input Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:43:05 --> Language Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Language Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Config Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Loader Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:43:05 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:43:05 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Session Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:43:05 --> Session routines successfully run
DEBUG - 2016-02-10 23:43:05 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Email Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Controller Class Initialized
DEBUG - 2016-02-10 23:43:05 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:43:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:43:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:43:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:43:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:43:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:43:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:43:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:43:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:43:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:43:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:43:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:43:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:43:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:43:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:43:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:43:05 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:44:32 --> Config Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:44:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:44:32 --> URI Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Router Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Output Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Security Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Input Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:44:32 --> Language Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Language Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Config Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Loader Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:44:32 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:44:32 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Session Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:44:32 --> Session routines successfully run
DEBUG - 2016-02-10 23:44:32 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Email Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Controller Class Initialized
DEBUG - 2016-02-10 23:44:32 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:44:32 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:44:32 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:44:32 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:32 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:44:32 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:44:32 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:44:32 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:44:32 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:32 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:44:32 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:32 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-10 23:44:38 --> Config Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:44:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:44:38 --> URI Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Router Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Output Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Security Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Input Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:44:38 --> Language Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Language Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Config Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Loader Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:44:38 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:44:38 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Session Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:44:38 --> Session routines successfully run
DEBUG - 2016-02-10 23:44:38 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Email Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Controller Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:44:38 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:44:38 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Config Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:45:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:45:05 --> URI Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Router Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Output Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Security Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Input Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:45:05 --> Language Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Language Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Config Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Loader Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:45:05 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:45:05 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Session Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:45:05 --> Session routines successfully run
DEBUG - 2016-02-10 23:45:05 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Email Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Controller Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:45:05 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Config Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:45:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:45:49 --> URI Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Router Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Output Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Security Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Input Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:45:49 --> Language Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Language Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Config Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Loader Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:45:49 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:45:49 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Session Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:45:49 --> Session routines successfully run
DEBUG - 2016-02-10 23:45:49 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Email Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Controller Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:45:49 --> Model Class Initialized
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:45:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:45:49 --> Final output sent to browser
DEBUG - 2016-02-10 23:45:49 --> Total execution time: 0.3604
DEBUG - 2016-02-10 23:47:45 --> Config Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:47:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:47:45 --> URI Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Router Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Output Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Security Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Input Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:47:45 --> Language Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Language Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Config Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Loader Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:47:45 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:47:45 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Session Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:47:45 --> Session routines successfully run
DEBUG - 2016-02-10 23:47:45 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Email Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Controller Class Initialized
DEBUG - 2016-02-10 23:47:45 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-10 23:47:45 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:47:45 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:47:45 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:47:45 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:47:46 --> Model Class Initialized
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:47:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:47:46 --> Final output sent to browser
DEBUG - 2016-02-10 23:47:46 --> Total execution time: 0.4466
DEBUG - 2016-02-10 23:50:25 --> Config Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:50:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:50:25 --> URI Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Router Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Output Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Security Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Input Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:50:25 --> Language Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Language Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Config Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Loader Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:50:25 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:50:25 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Session Class Initialized
DEBUG - 2016-02-10 23:50:25 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:50:25 --> Session routines successfully run
DEBUG - 2016-02-10 23:50:25 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:50:26 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:50:26 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:50:26 --> Email Class Initialized
DEBUG - 2016-02-10 23:50:26 --> Controller Class Initialized
DEBUG - 2016-02-10 23:50:26 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:50:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:50:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:50:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:50:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:50:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:50:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:50:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:50:26 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:50:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:50:26 --> Final output sent to browser
DEBUG - 2016-02-10 23:50:26 --> Total execution time: 0.3159
DEBUG - 2016-02-10 23:50:48 --> Config Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:50:48 --> URI Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Router Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Output Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Security Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Input Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:50:48 --> Language Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Language Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Config Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Loader Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:50:48 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:50:48 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Session Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:50:48 --> Session routines successfully run
DEBUG - 2016-02-10 23:50:48 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Email Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Controller Class Initialized
DEBUG - 2016-02-10 23:50:48 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:50:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:50:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:50:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:48 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:50:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:50:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:50:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:50:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:50:48 --> Model Class Initialized
DEBUG - 2016-02-10 23:50:49 --> Final output sent to browser
DEBUG - 2016-02-10 23:50:49 --> Total execution time: 0.4397
DEBUG - 2016-02-10 23:51:16 --> Config Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:51:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:51:16 --> URI Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Router Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Output Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Security Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Input Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:51:16 --> Language Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Language Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Config Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Loader Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:51:16 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:51:16 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Session Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:51:16 --> Session routines successfully run
DEBUG - 2016-02-10 23:51:16 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Email Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Controller Class Initialized
DEBUG - 2016-02-10 23:51:16 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:51:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:51:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:51:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:51:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:51:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:51:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:51:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:51:16 --> Model Class Initialized
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:51:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:51:16 --> Final output sent to browser
DEBUG - 2016-02-10 23:51:16 --> Total execution time: 0.4794
DEBUG - 2016-02-10 23:52:52 --> Config Class Initialized
DEBUG - 2016-02-10 23:52:52 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:52:52 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:52:52 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:52:52 --> URI Class Initialized
DEBUG - 2016-02-10 23:52:52 --> Router Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Output Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Security Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Input Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:52:53 --> Language Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Language Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Config Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Loader Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:52:53 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:52:53 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Session Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:52:53 --> Session routines successfully run
DEBUG - 2016-02-10 23:52:53 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Email Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Controller Class Initialized
DEBUG - 2016-02-10 23:52:53 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:52:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:52:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:52:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:52:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:52:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:52:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:52:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:52:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:52:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:52:53 --> Final output sent to browser
DEBUG - 2016-02-10 23:52:53 --> Total execution time: 0.4606
DEBUG - 2016-02-10 23:53:08 --> Config Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:53:08 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:53:08 --> URI Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Router Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Output Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Security Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Input Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:53:08 --> Language Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Language Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Config Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Loader Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:53:08 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:53:08 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Session Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:53:08 --> Session routines successfully run
DEBUG - 2016-02-10 23:53:08 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Email Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Controller Class Initialized
DEBUG - 2016-02-10 23:53:08 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:53:08 --> Model Class Initialized
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:53:08 --> Model Class Initialized
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:53:08 --> Model Class Initialized
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:53:08 --> Model Class Initialized
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:53:08 --> Model Class Initialized
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:53:08 --> Model Class Initialized
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:53:08 --> Model Class Initialized
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:53:08 --> Model Class Initialized
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:53:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:53:08 --> Final output sent to browser
DEBUG - 2016-02-10 23:53:08 --> Total execution time: 0.3297
DEBUG - 2016-02-10 23:56:14 --> Config Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:56:14 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:56:14 --> URI Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Router Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Output Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Security Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Input Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:56:14 --> Language Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Language Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Config Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Loader Class Initialized
DEBUG - 2016-02-10 23:56:14 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:56:14 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:56:14 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:56:15 --> Session Class Initialized
DEBUG - 2016-02-10 23:56:15 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:56:15 --> Session routines successfully run
DEBUG - 2016-02-10 23:56:15 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:56:15 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:56:15 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:56:15 --> Email Class Initialized
DEBUG - 2016-02-10 23:56:15 --> Controller Class Initialized
DEBUG - 2016-02-10 23:56:15 --> Property MX_Controller Initialized
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:56:15 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:15 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:56:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:56:15 --> Final output sent to browser
DEBUG - 2016-02-10 23:56:15 --> Total execution time: 0.3697
DEBUG - 2016-02-10 23:56:17 --> Config Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:56:17 --> URI Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Router Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Output Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Security Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Input Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:56:17 --> Language Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Language Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Config Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Loader Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:56:17 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:56:17 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Session Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:56:17 --> Session routines successfully run
DEBUG - 2016-02-10 23:56:17 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Email Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Controller Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Property MX_Controller Initialized
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:56:17 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:17 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:56:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:56:17 --> Final output sent to browser
DEBUG - 2016-02-10 23:56:17 --> Total execution time: 0.4377
DEBUG - 2016-02-10 23:56:19 --> Config Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:56:19 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:56:19 --> URI Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Router Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Output Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Security Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Input Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:56:19 --> Language Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Language Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Config Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Loader Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:56:19 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:56:19 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Session Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:56:19 --> Session routines successfully run
DEBUG - 2016-02-10 23:56:19 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Email Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Controller Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Property MX_Controller Initialized
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:56:19 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:19 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:56:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:56:19 --> Final output sent to browser
DEBUG - 2016-02-10 23:56:19 --> Total execution time: 0.3052
DEBUG - 2016-02-10 23:56:21 --> Config Class Initialized
DEBUG - 2016-02-10 23:56:21 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:56:21 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:56:21 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:56:21 --> URI Class Initialized
DEBUG - 2016-02-10 23:56:21 --> Router Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Output Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Security Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Input Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:56:22 --> Language Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Language Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Config Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Loader Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:56:22 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:56:22 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Session Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:56:22 --> Session routines successfully run
DEBUG - 2016-02-10 23:56:22 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Email Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Controller Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Property MX_Controller Initialized
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:56:22 --> Model Class Initialized
DEBUG - 2016-02-10 23:56:22 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:56:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:56:22 --> Final output sent to browser
DEBUG - 2016-02-10 23:56:22 --> Total execution time: 0.3050
DEBUG - 2016-02-10 23:57:23 --> Config Class Initialized
DEBUG - 2016-02-10 23:57:23 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:57:23 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:57:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:57:23 --> URI Class Initialized
DEBUG - 2016-02-10 23:57:23 --> Router Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Output Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Security Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Input Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:57:24 --> Language Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Language Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Config Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Loader Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:57:24 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:57:24 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Session Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:57:24 --> Session routines successfully run
DEBUG - 2016-02-10 23:57:24 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Email Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Controller Class Initialized
DEBUG - 2016-02-10 23:57:24 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:57:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:57:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:57:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:57:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:57:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:57:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:57:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:57:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:57:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:57:24 --> Final output sent to browser
DEBUG - 2016-02-10 23:57:24 --> Total execution time: 0.4216
DEBUG - 2016-02-10 23:57:43 --> Config Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:57:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:57:43 --> URI Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Router Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Output Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Security Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Input Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:57:43 --> Language Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Language Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Config Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Loader Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:57:43 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:57:43 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Session Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:57:43 --> Session routines successfully run
DEBUG - 2016-02-10 23:57:43 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Email Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Controller Class Initialized
DEBUG - 2016-02-10 23:57:43 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:57:43 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:57:43 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:57:43 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:57:43 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:57:43 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:57:43 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:57:43 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:57:43 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:57:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:57:43 --> Final output sent to browser
DEBUG - 2016-02-10 23:57:43 --> Total execution time: 0.2989
DEBUG - 2016-02-10 23:57:53 --> Config Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:57:53 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:57:53 --> URI Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Router Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Output Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Security Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Input Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:57:53 --> Language Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Language Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Config Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Loader Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:57:53 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:57:53 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Session Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:57:53 --> Session routines successfully run
DEBUG - 2016-02-10 23:57:53 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Email Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Controller Class Initialized
DEBUG - 2016-02-10 23:57:53 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:57:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:57:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:57:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:57:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:57:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:57:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:57:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:57:53 --> Model Class Initialized
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:57:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:57:53 --> Final output sent to browser
DEBUG - 2016-02-10 23:57:53 --> Total execution time: 0.3560
DEBUG - 2016-02-10 23:58:01 --> Config Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:58:01 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:58:01 --> URI Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Router Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Output Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Security Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Input Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:58:01 --> Language Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Language Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Config Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Loader Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:58:01 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:58:01 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Session Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:58:01 --> Session routines successfully run
DEBUG - 2016-02-10 23:58:01 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Email Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Controller Class Initialized
DEBUG - 2016-02-10 23:58:01 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:58:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:01 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:58:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:58:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:58:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:58:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:58:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:58:01 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:01 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:58:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Config Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:58:02 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:58:02 --> URI Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Router Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Output Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Security Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Input Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:58:02 --> Language Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Language Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Config Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Loader Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:58:02 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:58:02 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Session Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:58:02 --> Session routines successfully run
DEBUG - 2016-02-10 23:58:02 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Email Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Controller Class Initialized
DEBUG - 2016-02-10 23:58:02 --> Reports MX_Controller Initialized
DEBUG - 2016-02-10 23:58:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:58:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:58:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-10 23:58:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:58:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:58:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:58:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-10 23:58:02 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:58:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:58:02 --> Final output sent to browser
DEBUG - 2016-02-10 23:58:02 --> Total execution time: 0.2914
DEBUG - 2016-02-10 23:58:23 --> Config Class Initialized
DEBUG - 2016-02-10 23:58:23 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:58:23 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:58:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:58:23 --> URI Class Initialized
DEBUG - 2016-02-10 23:58:23 --> Router Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Output Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Security Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Input Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:58:24 --> Language Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Language Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Config Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Loader Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:58:24 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:58:24 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Session Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:58:24 --> Session routines successfully run
DEBUG - 2016-02-10 23:58:24 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Email Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Controller Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Property MX_Controller Initialized
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:58:24 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:24 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:58:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:58:24 --> Final output sent to browser
DEBUG - 2016-02-10 23:58:24 --> Total execution time: 0.2814
DEBUG - 2016-02-10 23:58:27 --> Config Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:58:27 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:58:27 --> URI Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Router Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Output Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Security Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Input Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:58:27 --> Language Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Language Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Config Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Loader Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:58:27 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:58:27 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Session Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:58:27 --> Session routines successfully run
DEBUG - 2016-02-10 23:58:27 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Email Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Controller Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Property MX_Controller Initialized
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:58:27 --> Model Class Initialized
DEBUG - 2016-02-10 23:58:27 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:58:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:58:27 --> Final output sent to browser
DEBUG - 2016-02-10 23:58:27 --> Total execution time: 0.3353
DEBUG - 2016-02-10 23:59:10 --> Config Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Hooks Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Utf8 Class Initialized
DEBUG - 2016-02-10 23:59:10 --> UTF-8 Support Enabled
DEBUG - 2016-02-10 23:59:10 --> URI Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Router Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Output Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Security Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Input Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-10 23:59:10 --> Language Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Language Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Config Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Loader Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Helper loaded: url_helper
DEBUG - 2016-02-10 23:59:10 --> Helper loaded: form_helper
DEBUG - 2016-02-10 23:59:10 --> Database Driver Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Session Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Helper loaded: string_helper
DEBUG - 2016-02-10 23:59:10 --> Session routines successfully run
DEBUG - 2016-02-10 23:59:10 --> Form Validation Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Pagination Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Encrypt Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Email Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Controller Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Property MX_Controller Initialized
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-10 23:59:10 --> Model Class Initialized
DEBUG - 2016-02-10 23:59:10 --> Image Lib Class Initialized
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-10 23:59:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-10 23:59:10 --> Final output sent to browser
DEBUG - 2016-02-10 23:59:10 --> Total execution time: 0.2542
