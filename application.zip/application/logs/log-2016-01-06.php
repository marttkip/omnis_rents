<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-06 07:48:28 --> Config Class Initialized
DEBUG - 2016-01-06 07:48:28 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:48:28 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:48:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:48:28 --> URI Class Initialized
DEBUG - 2016-01-06 07:48:30 --> Router Class Initialized
DEBUG - 2016-01-06 07:48:31 --> No URI present. Default controller set.
DEBUG - 2016-01-06 07:48:32 --> Output Class Initialized
DEBUG - 2016-01-06 07:48:32 --> Security Class Initialized
DEBUG - 2016-01-06 07:48:32 --> Input Class Initialized
DEBUG - 2016-01-06 07:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 07:48:32 --> Language Class Initialized
DEBUG - 2016-01-06 07:48:35 --> Language Class Initialized
DEBUG - 2016-01-06 07:48:35 --> Config Class Initialized
DEBUG - 2016-01-06 07:48:35 --> Loader Class Initialized
DEBUG - 2016-01-06 07:48:36 --> Helper loaded: url_helper
DEBUG - 2016-01-06 07:48:37 --> Helper loaded: form_helper
DEBUG - 2016-01-06 07:48:39 --> Database Driver Class Initialized
DEBUG - 2016-01-06 07:48:46 --> Session Class Initialized
DEBUG - 2016-01-06 07:48:46 --> Helper loaded: string_helper
DEBUG - 2016-01-06 07:48:46 --> A session cookie was not found.
DEBUG - 2016-01-06 07:48:46 --> Session routines successfully run
DEBUG - 2016-01-06 07:48:46 --> Form Validation Class Initialized
DEBUG - 2016-01-06 07:48:46 --> Pagination Class Initialized
DEBUG - 2016-01-06 07:48:47 --> Encrypt Class Initialized
DEBUG - 2016-01-06 07:48:47 --> Email Class Initialized
DEBUG - 2016-01-06 07:48:47 --> Controller Class Initialized
DEBUG - 2016-01-06 07:48:47 --> Auth MX_Controller Initialized
DEBUG - 2016-01-06 07:48:47 --> Model Class Initialized
DEBUG - 2016-01-06 07:48:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 07:48:47 --> Model Class Initialized
DEBUG - 2016-01-06 07:48:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 07:48:48 --> Model Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Config Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:48:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:48:48 --> URI Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Router Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Output Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Security Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Input Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 07:48:48 --> Language Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Language Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Config Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Loader Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Helper loaded: url_helper
DEBUG - 2016-01-06 07:48:48 --> Helper loaded: form_helper
DEBUG - 2016-01-06 07:48:48 --> Database Driver Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Session Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Helper loaded: string_helper
DEBUG - 2016-01-06 07:48:48 --> Session routines successfully run
DEBUG - 2016-01-06 07:48:48 --> Form Validation Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Pagination Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Encrypt Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Email Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Controller Class Initialized
DEBUG - 2016-01-06 07:48:48 --> Auth MX_Controller Initialized
DEBUG - 2016-01-06 07:48:48 --> Model Class Initialized
DEBUG - 2016-01-06 07:48:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 07:48:48 --> Model Class Initialized
DEBUG - 2016-01-06 07:48:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 07:48:48 --> Model Class Initialized
DEBUG - 2016-01-06 07:48:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 07:48:51 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-06 07:48:51 --> Final output sent to browser
DEBUG - 2016-01-06 07:48:51 --> Total execution time: 3.4229
DEBUG - 2016-01-06 07:49:13 --> Config Class Initialized
DEBUG - 2016-01-06 07:49:13 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:49:13 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:49:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:49:13 --> URI Class Initialized
DEBUG - 2016-01-06 07:49:13 --> Config Class Initialized
DEBUG - 2016-01-06 07:49:13 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:49:13 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:49:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:49:13 --> URI Class Initialized
DEBUG - 2016-01-06 07:49:13 --> Config Class Initialized
DEBUG - 2016-01-06 07:49:13 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:49:13 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:49:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:49:13 --> URI Class Initialized
DEBUG - 2016-01-06 07:49:14 --> Config Class Initialized
DEBUG - 2016-01-06 07:49:14 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:49:14 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:49:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:49:14 --> URI Class Initialized
DEBUG - 2016-01-06 07:49:14 --> Router Class Initialized
DEBUG - 2016-01-06 07:49:14 --> Router Class Initialized
DEBUG - 2016-01-06 07:49:14 --> Router Class Initialized
DEBUG - 2016-01-06 07:49:14 --> Router Class Initialized
ERROR - 2016-01-06 07:49:14 --> 404 Page Not Found --> 
ERROR - 2016-01-06 07:49:14 --> 404 Page Not Found --> 
ERROR - 2016-01-06 07:49:14 --> 404 Page Not Found --> 
ERROR - 2016-01-06 07:49:14 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 07:49:36 --> Config Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:49:36 --> URI Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Router Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Output Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Security Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Input Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 07:49:36 --> Language Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Language Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Config Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Loader Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Helper loaded: url_helper
DEBUG - 2016-01-06 07:49:36 --> Helper loaded: form_helper
DEBUG - 2016-01-06 07:49:36 --> Database Driver Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Session Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Helper loaded: string_helper
DEBUG - 2016-01-06 07:49:36 --> Session routines successfully run
DEBUG - 2016-01-06 07:49:36 --> Form Validation Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Pagination Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Encrypt Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Email Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Controller Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Auth MX_Controller Initialized
DEBUG - 2016-01-06 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 07:49:36 --> XSS Filtering completed
DEBUG - 2016-01-06 07:49:36 --> Unable to find validation rule: exists
DEBUG - 2016-01-06 07:49:36 --> XSS Filtering completed
DEBUG - 2016-01-06 07:49:37 --> Config Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:49:37 --> URI Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Router Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Output Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Security Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Input Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 07:49:37 --> Language Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Language Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Config Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Loader Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Helper loaded: url_helper
DEBUG - 2016-01-06 07:49:37 --> Helper loaded: form_helper
DEBUG - 2016-01-06 07:49:37 --> Database Driver Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Session Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Helper loaded: string_helper
DEBUG - 2016-01-06 07:49:37 --> Session routines successfully run
DEBUG - 2016-01-06 07:49:37 --> Form Validation Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Pagination Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Encrypt Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Email Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Controller Class Initialized
DEBUG - 2016-01-06 07:49:37 --> Admin MX_Controller Initialized
DEBUG - 2016-01-06 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 07:49:38 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 07:49:38 --> Model Class Initialized
DEBUG - 2016-01-06 07:49:38 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-06 07:49:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 07:49:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 07:49:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 07:49:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 07:49:40 --> Final output sent to browser
DEBUG - 2016-01-06 07:49:40 --> Total execution time: 3.4793
DEBUG - 2016-01-06 07:50:50 --> Config Class Initialized
DEBUG - 2016-01-06 07:50:50 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:50:50 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:50:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:50:50 --> URI Class Initialized
DEBUG - 2016-01-06 07:50:50 --> Router Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Output Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Security Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Input Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 07:50:51 --> Language Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Language Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Config Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Loader Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Helper loaded: url_helper
DEBUG - 2016-01-06 07:50:51 --> Helper loaded: form_helper
DEBUG - 2016-01-06 07:50:51 --> Database Driver Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Session Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Helper loaded: string_helper
DEBUG - 2016-01-06 07:50:51 --> Session routines successfully run
DEBUG - 2016-01-06 07:50:51 --> Form Validation Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Pagination Class Initialized
DEBUG - 2016-01-06 07:50:51 --> Encrypt Class Initialized
DEBUG - 2016-01-06 07:50:52 --> Email Class Initialized
DEBUG - 2016-01-06 07:50:52 --> Controller Class Initialized
DEBUG - 2016-01-06 07:50:52 --> Property MX_Controller Initialized
DEBUG - 2016-01-06 07:50:52 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 07:50:52 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 07:50:52 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 07:50:52 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 07:50:52 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 07:50:52 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 07:50:52 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 07:50:52 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 07:50:53 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 07:50:53 --> Model Class Initialized
DEBUG - 2016-01-06 07:50:53 --> Image Lib Class Initialized
DEBUG - 2016-01-06 07:50:55 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-06 07:50:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 07:50:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 07:50:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 07:50:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 07:50:55 --> Final output sent to browser
DEBUG - 2016-01-06 07:50:55 --> Total execution time: 4.8447
DEBUG - 2016-01-06 07:51:03 --> Config Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:51:03 --> URI Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Router Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Output Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Security Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Input Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 07:51:03 --> Language Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Language Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Config Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Loader Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Helper loaded: url_helper
DEBUG - 2016-01-06 07:51:03 --> Helper loaded: form_helper
DEBUG - 2016-01-06 07:51:03 --> Database Driver Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Session Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Helper loaded: string_helper
DEBUG - 2016-01-06 07:51:03 --> Session routines successfully run
DEBUG - 2016-01-06 07:51:03 --> Form Validation Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Pagination Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Encrypt Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Email Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Controller Class Initialized
DEBUG - 2016-01-06 07:51:03 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:04 --> Image Lib Class Initialized
DEBUG - 2016-01-06 07:51:07 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-06 07:51:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 07:51:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 07:51:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 07:51:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 07:51:07 --> Final output sent to browser
DEBUG - 2016-01-06 07:51:07 --> Total execution time: 4.6066
DEBUG - 2016-01-06 07:51:36 --> Config Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:51:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:51:36 --> URI Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Router Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Output Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Security Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Input Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 07:51:36 --> Language Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Language Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Config Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Loader Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Helper loaded: url_helper
DEBUG - 2016-01-06 07:51:36 --> Helper loaded: form_helper
DEBUG - 2016-01-06 07:51:36 --> Database Driver Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Session Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Helper loaded: string_helper
DEBUG - 2016-01-06 07:51:36 --> Session routines successfully run
DEBUG - 2016-01-06 07:51:36 --> Form Validation Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Pagination Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Encrypt Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Email Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Controller Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> Image Lib Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 07:51:36 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:37 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 07:51:37 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 07:51:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 07:51:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 07:51:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 07:51:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 07:51:37 --> Final output sent to browser
DEBUG - 2016-01-06 07:51:37 --> Total execution time: 1.2453
DEBUG - 2016-01-06 07:51:40 --> Config Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Hooks Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Utf8 Class Initialized
DEBUG - 2016-01-06 07:51:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 07:51:40 --> URI Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Router Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Output Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Security Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Input Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 07:51:40 --> Language Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Language Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Config Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Loader Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Helper loaded: url_helper
DEBUG - 2016-01-06 07:51:40 --> Helper loaded: form_helper
DEBUG - 2016-01-06 07:51:40 --> Database Driver Class Initialized
DEBUG - 2016-01-06 07:51:40 --> Session Class Initialized
DEBUG - 2016-01-06 07:51:41 --> Helper loaded: string_helper
DEBUG - 2016-01-06 07:51:41 --> Session routines successfully run
DEBUG - 2016-01-06 07:51:41 --> Form Validation Class Initialized
DEBUG - 2016-01-06 07:51:41 --> Pagination Class Initialized
DEBUG - 2016-01-06 07:51:41 --> Encrypt Class Initialized
DEBUG - 2016-01-06 07:51:41 --> Email Class Initialized
DEBUG - 2016-01-06 07:51:41 --> Controller Class Initialized
DEBUG - 2016-01-06 07:51:41 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> Image Lib Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 07:51:41 --> Model Class Initialized
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 07:51:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 07:51:41 --> Final output sent to browser
DEBUG - 2016-01-06 07:51:41 --> Total execution time: 0.4829
DEBUG - 2016-01-06 08:01:37 --> Config Class Initialized
DEBUG - 2016-01-06 08:01:37 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:01:37 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:01:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:01:38 --> URI Class Initialized
DEBUG - 2016-01-06 08:01:39 --> Router Class Initialized
DEBUG - 2016-01-06 08:01:39 --> Output Class Initialized
DEBUG - 2016-01-06 08:01:40 --> Security Class Initialized
DEBUG - 2016-01-06 08:01:40 --> Input Class Initialized
DEBUG - 2016-01-06 08:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:01:40 --> Language Class Initialized
DEBUG - 2016-01-06 08:01:41 --> Language Class Initialized
DEBUG - 2016-01-06 08:01:41 --> Config Class Initialized
DEBUG - 2016-01-06 08:01:41 --> Loader Class Initialized
DEBUG - 2016-01-06 08:01:42 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:01:42 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:01:44 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:01:48 --> Session Class Initialized
DEBUG - 2016-01-06 08:01:48 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:01:48 --> Session routines successfully run
DEBUG - 2016-01-06 08:01:48 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:01:48 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:01:48 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:01:49 --> Email Class Initialized
DEBUG - 2016-01-06 08:01:49 --> Controller Class Initialized
DEBUG - 2016-01-06 08:01:49 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:01:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:01:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:51 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:01:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:01:51 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:01:51 --> Model Class Initialized
DEBUG - 2016-01-06 08:01:52 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:01:52 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:01:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:01:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:01:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:01:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:01:53 --> Final output sent to browser
DEBUG - 2016-01-06 08:01:53 --> Total execution time: 18.0950
DEBUG - 2016-01-06 08:02:08 --> Config Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:02:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:02:08 --> URI Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Router Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Output Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Security Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Input Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:02:08 --> Language Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Language Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Config Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Loader Class Initialized
DEBUG - 2016-01-06 08:02:08 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:02:08 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:02:08 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:02:11 --> Session Class Initialized
DEBUG - 2016-01-06 08:02:11 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:02:11 --> Session routines successfully run
DEBUG - 2016-01-06 08:02:11 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:02:11 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:02:11 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:02:11 --> Email Class Initialized
DEBUG - 2016-01-06 08:02:11 --> Controller Class Initialized
DEBUG - 2016-01-06 08:02:11 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:02:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:02:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:02:11 --> Final output sent to browser
DEBUG - 2016-01-06 08:02:11 --> Total execution time: 3.5125
DEBUG - 2016-01-06 08:05:30 --> Config Class Initialized
DEBUG - 2016-01-06 08:05:31 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:05:31 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:05:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:05:31 --> URI Class Initialized
DEBUG - 2016-01-06 08:05:31 --> Router Class Initialized
DEBUG - 2016-01-06 08:05:31 --> Output Class Initialized
DEBUG - 2016-01-06 08:05:31 --> Security Class Initialized
DEBUG - 2016-01-06 08:05:31 --> Input Class Initialized
DEBUG - 2016-01-06 08:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:05:31 --> Language Class Initialized
DEBUG - 2016-01-06 08:05:32 --> Language Class Initialized
DEBUG - 2016-01-06 08:05:32 --> Config Class Initialized
DEBUG - 2016-01-06 08:05:32 --> Loader Class Initialized
DEBUG - 2016-01-06 08:05:32 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:05:32 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:05:33 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:05:33 --> Session Class Initialized
DEBUG - 2016-01-06 08:05:33 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:05:33 --> Session routines successfully run
DEBUG - 2016-01-06 08:05:33 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:05:33 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:05:33 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:05:33 --> Email Class Initialized
DEBUG - 2016-01-06 08:05:33 --> Controller Class Initialized
DEBUG - 2016-01-06 08:05:33 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:34 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:05:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:05:35 --> Model Class Initialized
DEBUG - 2016-01-06 08:05:35 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:05:35 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:05:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:05:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:05:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:05:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:05:35 --> Final output sent to browser
DEBUG - 2016-01-06 08:05:35 --> Total execution time: 4.7985
DEBUG - 2016-01-06 08:07:30 --> Config Class Initialized
DEBUG - 2016-01-06 08:07:30 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:07:30 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:07:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:07:30 --> URI Class Initialized
DEBUG - 2016-01-06 08:07:30 --> Router Class Initialized
DEBUG - 2016-01-06 08:07:30 --> Output Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Security Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Input Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:07:31 --> Language Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Language Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Config Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Loader Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:07:31 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:07:31 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Session Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:07:31 --> Session routines successfully run
DEBUG - 2016-01-06 08:07:31 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Email Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Controller Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:07:31 --> Model Class Initialized
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:07:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:07:31 --> Final output sent to browser
DEBUG - 2016-01-06 08:07:31 --> Total execution time: 0.8519
DEBUG - 2016-01-06 08:09:42 --> Config Class Initialized
DEBUG - 2016-01-06 08:09:42 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:09:42 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:09:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:09:42 --> URI Class Initialized
DEBUG - 2016-01-06 08:09:42 --> Router Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Output Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Security Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Input Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:09:43 --> Language Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Language Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Config Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Loader Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:09:43 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:09:43 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Session Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:09:43 --> Session routines successfully run
DEBUG - 2016-01-06 08:09:43 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Email Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Controller Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:09:43 --> Model Class Initialized
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:09:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:09:43 --> Final output sent to browser
DEBUG - 2016-01-06 08:09:43 --> Total execution time: 0.9253
DEBUG - 2016-01-06 08:09:59 --> Config Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:09:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:09:59 --> URI Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Router Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Output Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Security Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Input Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:09:59 --> Language Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Language Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Config Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Loader Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:09:59 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:09:59 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Session Class Initialized
DEBUG - 2016-01-06 08:09:59 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:09:59 --> Session routines successfully run
DEBUG - 2016-01-06 08:10:00 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:10:00 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:10:00 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:10:00 --> Email Class Initialized
DEBUG - 2016-01-06 08:10:00 --> Controller Class Initialized
DEBUG - 2016-01-06 08:10:00 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:10:00 --> Model Class Initialized
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:10:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:10:00 --> Final output sent to browser
DEBUG - 2016-01-06 08:10:00 --> Total execution time: 1.1014
DEBUG - 2016-01-06 08:11:16 --> Config Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:11:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:11:16 --> URI Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Router Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Output Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Security Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Input Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:11:16 --> Language Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Language Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Config Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Loader Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:11:16 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:11:16 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Session Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:11:16 --> Session routines successfully run
DEBUG - 2016-01-06 08:11:16 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Email Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Controller Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:11:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:11:16 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:11:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:11:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:11:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:11:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:11:17 --> Final output sent to browser
DEBUG - 2016-01-06 08:11:17 --> Total execution time: 0.4690
DEBUG - 2016-01-06 08:11:46 --> Config Class Initialized
DEBUG - 2016-01-06 08:11:46 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:11:46 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:11:46 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:11:46 --> URI Class Initialized
DEBUG - 2016-01-06 08:11:46 --> Router Class Initialized
DEBUG - 2016-01-06 08:11:46 --> Output Class Initialized
DEBUG - 2016-01-06 08:11:46 --> Security Class Initialized
DEBUG - 2016-01-06 08:11:46 --> Input Class Initialized
DEBUG - 2016-01-06 08:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:11:46 --> Language Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Language Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Config Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Loader Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:11:47 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:11:47 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Session Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:11:47 --> Session routines successfully run
DEBUG - 2016-01-06 08:11:47 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Email Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Controller Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:11:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:11:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:11:47 --> Final output sent to browser
DEBUG - 2016-01-06 08:11:47 --> Total execution time: 0.4578
DEBUG - 2016-01-06 08:12:00 --> Config Class Initialized
DEBUG - 2016-01-06 08:12:00 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:12:00 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:12:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:12:00 --> URI Class Initialized
DEBUG - 2016-01-06 08:12:00 --> Router Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Output Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Security Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Input Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:12:01 --> Language Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Language Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Config Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Loader Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:12:01 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:12:01 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Session Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:12:01 --> Session routines successfully run
DEBUG - 2016-01-06 08:12:01 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Email Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Controller Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:12:01 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:12:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:12:01 --> Final output sent to browser
DEBUG - 2016-01-06 08:12:01 --> Total execution time: 0.7103
DEBUG - 2016-01-06 08:12:29 --> Config Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:12:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:12:29 --> URI Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Router Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Output Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Security Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Input Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:12:29 --> Language Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Language Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Config Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Loader Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:12:29 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:12:29 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Session Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:12:29 --> Session routines successfully run
DEBUG - 2016-01-06 08:12:29 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Email Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Controller Class Initialized
DEBUG - 2016-01-06 08:12:29 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:12:30 --> Model Class Initialized
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:12:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:12:30 --> Final output sent to browser
DEBUG - 2016-01-06 08:12:30 --> Total execution time: 0.4737
DEBUG - 2016-01-06 08:13:11 --> Config Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:13:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:13:11 --> URI Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Router Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Output Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Security Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Input Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:13:11 --> Language Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Language Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Config Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Loader Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:13:11 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:13:11 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Session Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:13:11 --> Session routines successfully run
DEBUG - 2016-01-06 08:13:11 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Email Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Controller Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:13:11 --> Model Class Initialized
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:13:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:13:11 --> Final output sent to browser
DEBUG - 2016-01-06 08:13:11 --> Total execution time: 0.3134
DEBUG - 2016-01-06 08:14:49 --> Config Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:14:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:14:49 --> URI Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Router Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Output Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Security Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Input Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:14:49 --> Language Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Language Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Config Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Loader Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:14:49 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:14:49 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Session Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:14:49 --> Session routines successfully run
DEBUG - 2016-01-06 08:14:49 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Email Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Controller Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:14:49 --> Model Class Initialized
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:14:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:14:49 --> Final output sent to browser
DEBUG - 2016-01-06 08:14:49 --> Total execution time: 0.2699
DEBUG - 2016-01-06 08:15:12 --> Config Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:15:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:15:12 --> URI Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Router Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Output Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Security Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Input Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:15:12 --> Language Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Language Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Config Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Loader Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:15:12 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:15:12 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Session Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:15:12 --> Session routines successfully run
DEBUG - 2016-01-06 08:15:12 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Email Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Controller Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:15:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:15:12 --> Final output sent to browser
DEBUG - 2016-01-06 08:15:12 --> Total execution time: 0.2664
DEBUG - 2016-01-06 08:15:25 --> Config Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:15:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:15:25 --> URI Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Router Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Output Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Security Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Input Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:15:25 --> Language Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Language Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Config Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Loader Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:15:25 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:15:25 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Session Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:15:25 --> Session routines successfully run
DEBUG - 2016-01-06 08:15:25 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Email Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Controller Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:15:25 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:15:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:15:25 --> Final output sent to browser
DEBUG - 2016-01-06 08:15:25 --> Total execution time: 0.3622
DEBUG - 2016-01-06 08:15:37 --> Config Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:15:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:15:37 --> URI Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Router Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Output Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Security Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Input Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:15:37 --> Language Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Language Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Config Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Loader Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:15:37 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:15:37 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Session Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:15:37 --> Session routines successfully run
DEBUG - 2016-01-06 08:15:37 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Email Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Controller Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:15:37 --> Model Class Initialized
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:15:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:15:37 --> Final output sent to browser
DEBUG - 2016-01-06 08:15:37 --> Total execution time: 0.2729
DEBUG - 2016-01-06 08:19:39 --> Config Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:19:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:19:39 --> URI Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Router Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Output Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Security Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Input Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:19:39 --> Language Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Language Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Config Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Loader Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:19:39 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:19:39 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Session Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:19:39 --> Session routines successfully run
DEBUG - 2016-01-06 08:19:39 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Email Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Controller Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:19:39 --> Model Class Initialized
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:19:39 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:19:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:19:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:19:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:19:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:19:40 --> Final output sent to browser
DEBUG - 2016-01-06 08:19:40 --> Total execution time: 0.5887
DEBUG - 2016-01-06 08:20:49 --> Config Class Initialized
DEBUG - 2016-01-06 08:20:49 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:20:49 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:20:49 --> URI Class Initialized
DEBUG - 2016-01-06 08:20:49 --> Router Class Initialized
DEBUG - 2016-01-06 08:20:49 --> Output Class Initialized
DEBUG - 2016-01-06 08:20:49 --> Security Class Initialized
DEBUG - 2016-01-06 08:20:49 --> Input Class Initialized
DEBUG - 2016-01-06 08:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:20:49 --> Language Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Language Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Config Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Loader Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:20:50 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:20:50 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Session Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:20:50 --> Session routines successfully run
DEBUG - 2016-01-06 08:20:50 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Email Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Controller Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:20:50 --> Model Class Initialized
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:20:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:20:50 --> Final output sent to browser
DEBUG - 2016-01-06 08:20:50 --> Total execution time: 0.2616
DEBUG - 2016-01-06 08:21:27 --> Config Class Initialized
DEBUG - 2016-01-06 08:21:27 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:21:27 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:21:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:21:27 --> URI Class Initialized
DEBUG - 2016-01-06 08:21:27 --> Router Class Initialized
DEBUG - 2016-01-06 08:21:27 --> Output Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Security Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Input Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:21:28 --> Language Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Language Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Config Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Loader Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:21:28 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:21:28 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Session Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:21:28 --> Session routines successfully run
DEBUG - 2016-01-06 08:21:28 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Email Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Controller Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:21:28 --> Model Class Initialized
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:21:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:21:28 --> Final output sent to browser
DEBUG - 2016-01-06 08:21:28 --> Total execution time: 0.2982
DEBUG - 2016-01-06 08:22:46 --> Config Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:22:46 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:22:46 --> URI Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Router Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Output Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Security Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Input Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:22:46 --> Language Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Language Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Config Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Loader Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:22:46 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:22:46 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Session Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:22:46 --> Session routines successfully run
DEBUG - 2016-01-06 08:22:46 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Email Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Controller Class Initialized
DEBUG - 2016-01-06 08:22:46 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:22:46 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:22:46 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:22:46 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:22:46 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:22:46 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:22:46 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:22:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:22:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:22:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:22:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:47 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:22:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:22:47 --> Model Class Initialized
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:22:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:22:47 --> Final output sent to browser
DEBUG - 2016-01-06 08:22:47 --> Total execution time: 0.2997
DEBUG - 2016-01-06 08:27:12 --> Config Class Initialized
DEBUG - 2016-01-06 08:27:12 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:27:12 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:27:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:27:13 --> URI Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Router Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Output Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Security Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Input Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:27:13 --> Language Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Language Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Config Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Loader Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:27:13 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:27:13 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Session Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:27:13 --> Session routines successfully run
DEBUG - 2016-01-06 08:27:13 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Email Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Controller Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:27:13 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:27:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:27:13 --> Final output sent to browser
DEBUG - 2016-01-06 08:27:13 --> Total execution time: 0.2802
DEBUG - 2016-01-06 08:27:55 --> Config Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:27:55 --> URI Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Router Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Output Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Security Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Input Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:27:55 --> Language Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Language Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Config Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Loader Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:27:55 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:27:55 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Session Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:27:55 --> Session routines successfully run
DEBUG - 2016-01-06 08:27:55 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Email Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Controller Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:27:55 --> Model Class Initialized
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:27:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:27:55 --> Final output sent to browser
DEBUG - 2016-01-06 08:27:55 --> Total execution time: 0.3056
DEBUG - 2016-01-06 08:30:26 --> Config Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:30:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:30:26 --> URI Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Router Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Output Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Security Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Input Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:30:26 --> Language Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Language Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Config Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Loader Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:30:26 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:30:26 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Session Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:30:26 --> Session routines successfully run
DEBUG - 2016-01-06 08:30:26 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Email Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Controller Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:30:26 --> Model Class Initialized
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:30:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:30:26 --> Final output sent to browser
DEBUG - 2016-01-06 08:30:26 --> Total execution time: 0.2675
DEBUG - 2016-01-06 08:33:15 --> Config Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:33:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:33:15 --> URI Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Router Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Output Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Security Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Input Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:33:15 --> Language Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Language Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Config Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Loader Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:33:15 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:33:15 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Session Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:33:15 --> Session routines successfully run
DEBUG - 2016-01-06 08:33:15 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Email Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Controller Class Initialized
DEBUG - 2016-01-06 08:33:15 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:33:15 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:33:15 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:33:15 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:33:15 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:33:15 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:33:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:33:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:33:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:33:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:33:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:16 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:33:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:33:16 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:33:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:33:16 --> Final output sent to browser
DEBUG - 2016-01-06 08:33:16 --> Total execution time: 0.3485
DEBUG - 2016-01-06 08:33:54 --> Config Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:33:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:33:54 --> URI Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Router Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Output Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Security Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Input Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:33:54 --> Language Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Language Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Config Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Loader Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:33:54 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:33:54 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Session Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:33:54 --> Session routines successfully run
DEBUG - 2016-01-06 08:33:54 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Email Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Controller Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:33:54 --> Model Class Initialized
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:33:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:33:54 --> Final output sent to browser
DEBUG - 2016-01-06 08:33:54 --> Total execution time: 0.2778
DEBUG - 2016-01-06 08:34:14 --> Config Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Hooks Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Utf8 Class Initialized
DEBUG - 2016-01-06 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 08:34:14 --> URI Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Router Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Output Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Security Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Input Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 08:34:14 --> Language Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Language Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Config Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Loader Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Helper loaded: url_helper
DEBUG - 2016-01-06 08:34:14 --> Helper loaded: form_helper
DEBUG - 2016-01-06 08:34:14 --> Database Driver Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Session Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Helper loaded: string_helper
DEBUG - 2016-01-06 08:34:14 --> Session routines successfully run
DEBUG - 2016-01-06 08:34:14 --> Form Validation Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Pagination Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Encrypt Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Email Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Controller Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> Image Lib Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 08:34:14 --> Model Class Initialized
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 08:34:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 08:34:14 --> Final output sent to browser
DEBUG - 2016-01-06 08:34:14 --> Total execution time: 0.2856
DEBUG - 2016-01-06 09:05:31 --> Config Class Initialized
DEBUG - 2016-01-06 09:05:31 --> Hooks Class Initialized
DEBUG - 2016-01-06 09:05:31 --> Utf8 Class Initialized
DEBUG - 2016-01-06 09:05:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 09:05:31 --> URI Class Initialized
DEBUG - 2016-01-06 09:05:31 --> Router Class Initialized
DEBUG - 2016-01-06 09:05:32 --> Output Class Initialized
DEBUG - 2016-01-06 09:05:32 --> Security Class Initialized
DEBUG - 2016-01-06 09:05:32 --> Input Class Initialized
DEBUG - 2016-01-06 09:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 09:05:32 --> Language Class Initialized
DEBUG - 2016-01-06 09:05:32 --> Language Class Initialized
DEBUG - 2016-01-06 09:05:32 --> Config Class Initialized
DEBUG - 2016-01-06 09:05:32 --> Loader Class Initialized
DEBUG - 2016-01-06 09:05:32 --> Helper loaded: url_helper
DEBUG - 2016-01-06 09:05:32 --> Helper loaded: form_helper
DEBUG - 2016-01-06 09:05:32 --> Database Driver Class Initialized
DEBUG - 2016-01-06 09:05:33 --> Session Class Initialized
DEBUG - 2016-01-06 09:05:33 --> Helper loaded: string_helper
DEBUG - 2016-01-06 09:05:33 --> Session routines successfully run
DEBUG - 2016-01-06 09:05:33 --> Form Validation Class Initialized
DEBUG - 2016-01-06 09:05:33 --> Pagination Class Initialized
DEBUG - 2016-01-06 09:05:33 --> Encrypt Class Initialized
DEBUG - 2016-01-06 09:05:33 --> Email Class Initialized
DEBUG - 2016-01-06 09:05:33 --> Controller Class Initialized
DEBUG - 2016-01-06 09:05:33 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 09:05:33 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 09:05:33 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 09:05:33 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 09:05:33 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 09:05:33 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 09:05:33 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 09:05:33 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 09:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 09:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 09:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:34 --> Image Lib Class Initialized
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 09:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 09:05:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 09:05:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 09:05:34 --> Final output sent to browser
DEBUG - 2016-01-06 09:05:34 --> Total execution time: 3.7913
DEBUG - 2016-01-06 09:08:34 --> Config Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Hooks Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Utf8 Class Initialized
DEBUG - 2016-01-06 09:08:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 09:08:34 --> URI Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Router Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Output Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Security Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Input Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 09:08:34 --> Language Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Language Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Config Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Loader Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Helper loaded: url_helper
DEBUG - 2016-01-06 09:08:34 --> Helper loaded: form_helper
DEBUG - 2016-01-06 09:08:34 --> Database Driver Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Session Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Helper loaded: string_helper
DEBUG - 2016-01-06 09:08:34 --> Session routines successfully run
DEBUG - 2016-01-06 09:08:34 --> Form Validation Class Initialized
DEBUG - 2016-01-06 09:08:34 --> Pagination Class Initialized
DEBUG - 2016-01-06 09:08:35 --> Encrypt Class Initialized
DEBUG - 2016-01-06 09:08:35 --> Email Class Initialized
DEBUG - 2016-01-06 09:08:35 --> Controller Class Initialized
DEBUG - 2016-01-06 09:08:35 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> Image Lib Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 09:08:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 09:08:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 09:08:35 --> Final output sent to browser
DEBUG - 2016-01-06 09:08:35 --> Total execution time: 0.6028
DEBUG - 2016-01-06 09:13:17 --> Config Class Initialized
DEBUG - 2016-01-06 09:13:17 --> Hooks Class Initialized
DEBUG - 2016-01-06 09:13:17 --> Utf8 Class Initialized
DEBUG - 2016-01-06 09:13:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 09:13:17 --> URI Class Initialized
DEBUG - 2016-01-06 09:13:17 --> Router Class Initialized
DEBUG - 2016-01-06 09:13:17 --> Output Class Initialized
DEBUG - 2016-01-06 09:13:17 --> Security Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Input Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 09:13:18 --> Language Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Language Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Config Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Loader Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Helper loaded: url_helper
DEBUG - 2016-01-06 09:13:18 --> Helper loaded: form_helper
DEBUG - 2016-01-06 09:13:18 --> Database Driver Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Session Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Helper loaded: string_helper
DEBUG - 2016-01-06 09:13:18 --> Session routines successfully run
DEBUG - 2016-01-06 09:13:18 --> Form Validation Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Pagination Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Encrypt Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Email Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Controller Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> Image Lib Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 09:13:18 --> Model Class Initialized
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 09:13:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 09:13:18 --> Final output sent to browser
DEBUG - 2016-01-06 09:13:18 --> Total execution time: 1.0384
DEBUG - 2016-01-06 09:14:13 --> Config Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Hooks Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Utf8 Class Initialized
DEBUG - 2016-01-06 09:14:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 09:14:13 --> URI Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Router Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Output Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Security Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Input Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 09:14:13 --> Language Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Language Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Config Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Loader Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Helper loaded: url_helper
DEBUG - 2016-01-06 09:14:13 --> Helper loaded: form_helper
DEBUG - 2016-01-06 09:14:13 --> Database Driver Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Session Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Helper loaded: string_helper
DEBUG - 2016-01-06 09:14:13 --> Session routines successfully run
DEBUG - 2016-01-06 09:14:13 --> Form Validation Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Pagination Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Encrypt Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Email Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Controller Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> Image Lib Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 09:14:13 --> Model Class Initialized
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 09:14:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 09:14:13 --> Final output sent to browser
DEBUG - 2016-01-06 09:14:13 --> Total execution time: 0.3196
DEBUG - 2016-01-06 09:53:49 --> Config Class Initialized
DEBUG - 2016-01-06 09:53:49 --> Hooks Class Initialized
DEBUG - 2016-01-06 09:53:49 --> Utf8 Class Initialized
DEBUG - 2016-01-06 09:53:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 09:53:49 --> URI Class Initialized
DEBUG - 2016-01-06 09:53:49 --> Router Class Initialized
DEBUG - 2016-01-06 09:53:49 --> Output Class Initialized
DEBUG - 2016-01-06 09:53:49 --> Security Class Initialized
DEBUG - 2016-01-06 09:53:49 --> Input Class Initialized
DEBUG - 2016-01-06 09:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 09:53:49 --> Language Class Initialized
DEBUG - 2016-01-06 09:53:50 --> Language Class Initialized
DEBUG - 2016-01-06 09:53:50 --> Config Class Initialized
DEBUG - 2016-01-06 09:53:50 --> Loader Class Initialized
DEBUG - 2016-01-06 09:53:50 --> Helper loaded: url_helper
DEBUG - 2016-01-06 09:53:50 --> Helper loaded: form_helper
DEBUG - 2016-01-06 09:53:50 --> Database Driver Class Initialized
DEBUG - 2016-01-06 09:53:51 --> Session Class Initialized
DEBUG - 2016-01-06 09:53:51 --> Helper loaded: string_helper
DEBUG - 2016-01-06 09:53:51 --> Session routines successfully run
DEBUG - 2016-01-06 09:53:51 --> Form Validation Class Initialized
DEBUG - 2016-01-06 09:53:51 --> Pagination Class Initialized
DEBUG - 2016-01-06 09:53:51 --> Encrypt Class Initialized
DEBUG - 2016-01-06 09:53:51 --> Email Class Initialized
DEBUG - 2016-01-06 09:53:51 --> Controller Class Initialized
DEBUG - 2016-01-06 09:53:51 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> Image Lib Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:53:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 09:53:51 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Config Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Hooks Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Utf8 Class Initialized
DEBUG - 2016-01-06 09:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 09:54:01 --> URI Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Router Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Output Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Security Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Input Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 09:54:01 --> Language Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Language Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Config Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Loader Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Helper loaded: url_helper
DEBUG - 2016-01-06 09:54:01 --> Helper loaded: form_helper
DEBUG - 2016-01-06 09:54:01 --> Database Driver Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Session Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Helper loaded: string_helper
DEBUG - 2016-01-06 09:54:01 --> Session routines successfully run
DEBUG - 2016-01-06 09:54:01 --> Form Validation Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Pagination Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Encrypt Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Email Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Controller Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> Image Lib Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 09:54:01 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:33 --> Config Class Initialized
DEBUG - 2016-01-06 09:54:33 --> Hooks Class Initialized
DEBUG - 2016-01-06 09:54:33 --> Utf8 Class Initialized
DEBUG - 2016-01-06 09:54:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 09:54:33 --> URI Class Initialized
DEBUG - 2016-01-06 09:54:33 --> Router Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Output Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Security Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Input Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 09:54:34 --> Language Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Language Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Config Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Loader Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Helper loaded: url_helper
DEBUG - 2016-01-06 09:54:34 --> Helper loaded: form_helper
DEBUG - 2016-01-06 09:54:34 --> Database Driver Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Session Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Helper loaded: string_helper
DEBUG - 2016-01-06 09:54:34 --> Session routines successfully run
DEBUG - 2016-01-06 09:54:34 --> Form Validation Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Pagination Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Encrypt Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Email Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Controller Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> Image Lib Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 09:54:34 --> Model Class Initialized
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 09:54:34 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 09:54:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 09:54:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 09:54:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 09:54:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 09:54:35 --> Final output sent to browser
DEBUG - 2016-01-06 09:54:35 --> Total execution time: 1.3391
DEBUG - 2016-01-06 09:55:35 --> Config Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Hooks Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Utf8 Class Initialized
DEBUG - 2016-01-06 09:55:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 09:55:35 --> URI Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Router Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Output Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Security Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Input Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 09:55:35 --> Language Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Language Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Config Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Loader Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Helper loaded: url_helper
DEBUG - 2016-01-06 09:55:35 --> Helper loaded: form_helper
DEBUG - 2016-01-06 09:55:35 --> Database Driver Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Session Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Helper loaded: string_helper
DEBUG - 2016-01-06 09:55:35 --> Session routines successfully run
DEBUG - 2016-01-06 09:55:35 --> Form Validation Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Pagination Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Encrypt Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Email Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Controller Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> Image Lib Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 09:55:35 --> Model Class Initialized
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 09:55:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 09:55:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 09:55:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 09:55:36 --> Final output sent to browser
DEBUG - 2016-01-06 09:55:36 --> Total execution time: 0.9308
DEBUG - 2016-01-06 10:48:21 --> Config Class Initialized
DEBUG - 2016-01-06 10:48:21 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:48:21 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:48:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:48:21 --> URI Class Initialized
DEBUG - 2016-01-06 10:48:22 --> Router Class Initialized
DEBUG - 2016-01-06 10:48:22 --> Output Class Initialized
DEBUG - 2016-01-06 10:48:22 --> Security Class Initialized
DEBUG - 2016-01-06 10:48:22 --> Input Class Initialized
DEBUG - 2016-01-06 10:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:48:22 --> Language Class Initialized
DEBUG - 2016-01-06 10:48:22 --> Language Class Initialized
DEBUG - 2016-01-06 10:48:23 --> Config Class Initialized
DEBUG - 2016-01-06 10:48:23 --> Loader Class Initialized
DEBUG - 2016-01-06 10:48:23 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:48:23 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:48:23 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:48:25 --> Session Class Initialized
DEBUG - 2016-01-06 10:48:25 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:48:25 --> Session routines successfully run
DEBUG - 2016-01-06 10:48:26 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:48:26 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:48:26 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:48:26 --> Email Class Initialized
DEBUG - 2016-01-06 10:48:26 --> Controller Class Initialized
DEBUG - 2016-01-06 10:48:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:27 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:48:27 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:27 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:27 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-06 10:48:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:48:27 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:48:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:48:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:48:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:48:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:48:27 --> Final output sent to browser
DEBUG - 2016-01-06 10:48:27 --> Total execution time: 6.8534
DEBUG - 2016-01-06 10:49:31 --> Config Class Initialized
DEBUG - 2016-01-06 10:49:31 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:49:31 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:49:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:49:31 --> URI Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Router Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Output Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Security Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Input Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:49:32 --> Language Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Language Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Config Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Loader Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:49:32 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:49:32 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Session Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:49:32 --> Session routines successfully run
DEBUG - 2016-01-06 10:49:32 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Email Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Controller Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:49:32 --> Model Class Initialized
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:49:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:49:32 --> Final output sent to browser
DEBUG - 2016-01-06 10:49:32 --> Total execution time: 0.9492
DEBUG - 2016-01-06 10:50:09 --> Config Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:50:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:50:09 --> URI Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Router Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Output Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Security Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Input Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:50:09 --> Language Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Language Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Config Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Loader Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:50:09 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:50:09 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Session Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:50:09 --> Session routines successfully run
DEBUG - 2016-01-06 10:50:09 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:50:09 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:50:10 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:50:10 --> Email Class Initialized
DEBUG - 2016-01-06 10:50:10 --> Controller Class Initialized
DEBUG - 2016-01-06 10:50:10 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:50:10 --> Model Class Initialized
DEBUG - 2016-01-06 10:50:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 10:50:10 --> Final output sent to browser
DEBUG - 2016-01-06 10:50:10 --> Total execution time: 1.2300
DEBUG - 2016-01-06 10:51:53 --> Config Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:51:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:51:53 --> URI Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Router Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Output Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Security Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Input Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:51:53 --> Language Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Language Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Config Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Loader Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:51:53 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:51:53 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Session Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:51:53 --> Session routines successfully run
DEBUG - 2016-01-06 10:51:53 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Email Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Controller Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:51:53 --> Model Class Initialized
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:51:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:51:53 --> Final output sent to browser
DEBUG - 2016-01-06 10:51:53 --> Total execution time: 0.4137
DEBUG - 2016-01-06 10:52:19 --> Config Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:52:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:52:19 --> URI Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Router Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Output Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Security Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Input Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:52:19 --> Language Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Language Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Config Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Loader Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:52:19 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:52:19 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Session Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:52:19 --> Session routines successfully run
DEBUG - 2016-01-06 10:52:19 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Email Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Controller Class Initialized
DEBUG - 2016-01-06 10:52:19 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:52:19 --> Model Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 10:52:19 --> XSS Filtering completed
DEBUG - 2016-01-06 10:52:19 --> XSS Filtering completed
DEBUG - 2016-01-06 10:52:19 --> Config Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:52:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:52:19 --> URI Class Initialized
DEBUG - 2016-01-06 10:52:19 --> Router Class Initialized
ERROR - 2016-01-06 10:52:19 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 10:53:01 --> Config Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:53:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:53:01 --> URI Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Router Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Output Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Security Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Input Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:53:01 --> Language Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Language Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Config Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Loader Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:53:01 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:53:01 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Session Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:53:01 --> Session routines successfully run
DEBUG - 2016-01-06 10:53:01 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Email Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Controller Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:53:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:53:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:53:01 --> Final output sent to browser
DEBUG - 2016-01-06 10:53:01 --> Total execution time: 0.3717
DEBUG - 2016-01-06 10:53:40 --> Config Class Initialized
DEBUG - 2016-01-06 10:53:40 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:53:40 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:53:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:53:40 --> URI Class Initialized
DEBUG - 2016-01-06 10:53:40 --> Router Class Initialized
DEBUG - 2016-01-06 10:53:40 --> Output Class Initialized
DEBUG - 2016-01-06 10:53:40 --> Security Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Input Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:53:41 --> Language Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Language Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Config Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Loader Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:53:41 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:53:41 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Session Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:53:41 --> Session routines successfully run
DEBUG - 2016-01-06 10:53:41 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Email Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Controller Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:53:41 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:53:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:53:41 --> Final output sent to browser
DEBUG - 2016-01-06 10:53:41 --> Total execution time: 0.6890
DEBUG - 2016-01-06 10:53:56 --> Config Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:53:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:53:56 --> URI Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Router Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Output Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Security Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Input Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:53:56 --> Language Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Language Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Config Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Loader Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:53:56 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:53:56 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Session Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:53:56 --> Session routines successfully run
DEBUG - 2016-01-06 10:53:56 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Email Class Initialized
DEBUG - 2016-01-06 10:53:56 --> Controller Class Initialized
DEBUG - 2016-01-06 10:53:56 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 10:53:56 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:53:56 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:53:56 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 10:53:57 --> XSS Filtering completed
DEBUG - 2016-01-06 10:53:57 --> XSS Filtering completed
DEBUG - 2016-01-06 10:53:57 --> XSS Filtering completed
DEBUG - 2016-01-06 10:53:57 --> Config Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:53:57 --> URI Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Router Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Output Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Security Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Input Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:53:57 --> Language Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Language Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Config Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Loader Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:53:57 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:53:57 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Session Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:53:57 --> Session routines successfully run
DEBUG - 2016-01-06 10:53:57 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Email Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Controller Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:53:57 --> Model Class Initialized
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:53:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:53:57 --> Final output sent to browser
DEBUG - 2016-01-06 10:53:57 --> Total execution time: 0.3136
DEBUG - 2016-01-06 10:54:52 --> Config Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:54:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:54:52 --> URI Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Router Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Output Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Security Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Input Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:54:52 --> Language Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Language Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Config Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Loader Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:54:52 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:54:52 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Session Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:54:52 --> Session routines successfully run
DEBUG - 2016-01-06 10:54:52 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Email Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Controller Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:54:52 --> Model Class Initialized
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:54:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:54:52 --> Final output sent to browser
DEBUG - 2016-01-06 10:54:52 --> Total execution time: 0.3026
DEBUG - 2016-01-06 10:55:10 --> Config Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:55:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:55:10 --> URI Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Router Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Output Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Security Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Input Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:55:10 --> Language Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Language Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Config Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Loader Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:55:10 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:55:10 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Session Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:55:10 --> Session routines successfully run
DEBUG - 2016-01-06 10:55:10 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Email Class Initialized
DEBUG - 2016-01-06 10:55:10 --> Controller Class Initialized
DEBUG - 2016-01-06 10:55:11 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:55:11 --> Model Class Initialized
DEBUG - 2016-01-06 10:55:11 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:55:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 10:55:11 --> XSS Filtering completed
DEBUG - 2016-01-06 10:55:11 --> XSS Filtering completed
DEBUG - 2016-01-06 10:55:11 --> XSS Filtering completed
DEBUG - 2016-01-06 10:55:11 --> XSS Filtering completed
ERROR - 2016-01-06 10:55:11 --> Severity: Warning  --> Missing argument 1 for Leases_model::create_lease_number(), called in C:\xampp\htdocs\rents\application\modules\real_estate_administration\models\leases_model.php on line 51 and defined C:\xampp\htdocs\rents\application\modules\real_estate_administration\models\leases_model.php 119
ERROR - 2016-01-06 10:55:11 --> Severity: Notice  --> Undefined variable: rental_unit_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\models\leases_model.php 122
DEBUG - 2016-01-06 10:55:11 --> DB Transaction Failure
ERROR - 2016-01-06 10:55:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
DEBUG - 2016-01-06 10:55:11 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-01-06 10:55:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\core\Common.php 441
DEBUG - 2016-01-06 10:56:24 --> Config Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:56:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:56:24 --> URI Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Router Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Output Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Security Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Input Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:56:24 --> Language Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Language Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Config Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Loader Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:56:24 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:56:24 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Session Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:56:24 --> Session routines successfully run
DEBUG - 2016-01-06 10:56:24 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Email Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Controller Class Initialized
DEBUG - 2016-01-06 10:56:24 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:56:24 --> Model Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:56:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 10:56:24 --> XSS Filtering completed
DEBUG - 2016-01-06 10:56:24 --> XSS Filtering completed
DEBUG - 2016-01-06 10:56:24 --> XSS Filtering completed
DEBUG - 2016-01-06 10:56:24 --> XSS Filtering completed
DEBUG - 2016-01-06 10:56:24 --> DB Transaction Failure
ERROR - 2016-01-06 10:56:24 --> Query error: Unknown column 'rent_amount' in 'field list'
DEBUG - 2016-01-06 10:56:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-06 10:57:02 --> Config Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:57:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:57:02 --> URI Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Router Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Output Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Security Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Input Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:57:02 --> Language Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Language Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Config Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Loader Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:57:02 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:57:02 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Session Class Initialized
DEBUG - 2016-01-06 10:57:02 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:57:02 --> Session routines successfully run
DEBUG - 2016-01-06 10:57:03 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Email Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Controller Class Initialized
DEBUG - 2016-01-06 10:57:03 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 10:57:03 --> XSS Filtering completed
DEBUG - 2016-01-06 10:57:03 --> XSS Filtering completed
DEBUG - 2016-01-06 10:57:03 --> XSS Filtering completed
DEBUG - 2016-01-06 10:57:03 --> XSS Filtering completed
DEBUG - 2016-01-06 10:57:03 --> Config Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:57:03 --> URI Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Router Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Output Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Security Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Input Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:57:03 --> Language Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Language Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Config Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Loader Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:57:03 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:57:03 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Session Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:57:03 --> Session routines successfully run
DEBUG - 2016-01-06 10:57:03 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Email Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Controller Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:57:03 --> Model Class Initialized
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:57:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:57:03 --> Final output sent to browser
DEBUG - 2016-01-06 10:57:03 --> Total execution time: 0.2965
DEBUG - 2016-01-06 10:58:00 --> Config Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:58:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:58:00 --> URI Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Router Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Output Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Security Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Input Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:58:00 --> Language Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Language Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Config Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Loader Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:58:00 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:58:00 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Session Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:58:00 --> Session routines successfully run
DEBUG - 2016-01-06 10:58:00 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Email Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Controller Class Initialized
DEBUG - 2016-01-06 10:58:00 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:58:00 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:58:00 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:58:00 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:58:00 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:58:00 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:58:00 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:58:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:58:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:58:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:58:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:01 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:58:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:58:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:58:01 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:58:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:58:01 --> Final output sent to browser
DEBUG - 2016-01-06 10:58:01 --> Total execution time: 0.3635
DEBUG - 2016-01-06 10:58:13 --> Config Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:58:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:58:13 --> URI Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Router Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Output Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Security Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Input Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:58:13 --> Language Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Language Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Config Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Loader Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:58:13 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:58:13 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Session Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:58:13 --> Session routines successfully run
DEBUG - 2016-01-06 10:58:13 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:58:13 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Email Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Controller Class Initialized
DEBUG - 2016-01-06 10:58:14 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 10:58:14 --> XSS Filtering completed
DEBUG - 2016-01-06 10:58:14 --> XSS Filtering completed
DEBUG - 2016-01-06 10:58:14 --> XSS Filtering completed
DEBUG - 2016-01-06 10:58:14 --> XSS Filtering completed
DEBUG - 2016-01-06 10:58:14 --> Config Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Hooks Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Utf8 Class Initialized
DEBUG - 2016-01-06 10:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 10:58:14 --> URI Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Router Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Output Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Security Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Input Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 10:58:14 --> Language Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Language Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Config Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Loader Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Helper loaded: url_helper
DEBUG - 2016-01-06 10:58:14 --> Helper loaded: form_helper
DEBUG - 2016-01-06 10:58:14 --> Database Driver Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Session Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Helper loaded: string_helper
DEBUG - 2016-01-06 10:58:14 --> Session routines successfully run
DEBUG - 2016-01-06 10:58:14 --> Form Validation Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Pagination Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Encrypt Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Email Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Controller Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> Image Lib Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 10:58:14 --> Model Class Initialized
ERROR - 2016-01-06 10:58:14 --> Severity: Notice  --> Undefined property: stdClass::$rental_unit_status C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 58
ERROR - 2016-01-06 10:58:14 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 62
ERROR - 2016-01-06 10:58:14 --> Severity: Notice  --> Undefined variable: tenancy_status C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 90
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 10:58:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 10:58:14 --> Final output sent to browser
DEBUG - 2016-01-06 10:58:14 --> Total execution time: 0.4701
DEBUG - 2016-01-06 11:02:12 --> Config Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:02:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:02:12 --> URI Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Router Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Output Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Security Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Input Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:02:12 --> Language Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Language Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Config Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Loader Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:02:12 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:02:12 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Session Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:02:12 --> Session routines successfully run
DEBUG - 2016-01-06 11:02:12 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:02:12 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:02:13 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:02:13 --> Email Class Initialized
DEBUG - 2016-01-06 11:02:13 --> Controller Class Initialized
DEBUG - 2016-01-06 11:02:13 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:02:13 --> Model Class Initialized
ERROR - 2016-01-06 11:02:13 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 62
ERROR - 2016-01-06 11:02:13 --> Severity: Notice  --> Undefined variable: tenancy_status C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 90
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:02:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:02:13 --> Final output sent to browser
DEBUG - 2016-01-06 11:02:13 --> Total execution time: 1.4131
DEBUG - 2016-01-06 11:04:40 --> Config Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:04:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:04:40 --> URI Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Router Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Output Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Security Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Input Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:04:40 --> Language Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Language Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Config Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Loader Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:04:40 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:04:40 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Session Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:04:40 --> Session routines successfully run
DEBUG - 2016-01-06 11:04:40 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Email Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Controller Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:04:40 --> Model Class Initialized
ERROR - 2016-01-06 11:04:40 --> Severity: Notice  --> Undefined variable: tenancy_status C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 90
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:04:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:04:40 --> Final output sent to browser
DEBUG - 2016-01-06 11:04:40 --> Total execution time: 0.3677
DEBUG - 2016-01-06 11:05:49 --> Config Class Initialized
DEBUG - 2016-01-06 11:05:49 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:05:49 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:05:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:05:49 --> URI Class Initialized
DEBUG - 2016-01-06 11:05:49 --> Router Class Initialized
DEBUG - 2016-01-06 11:05:49 --> Output Class Initialized
DEBUG - 2016-01-06 11:05:49 --> Security Class Initialized
DEBUG - 2016-01-06 11:05:49 --> Input Class Initialized
DEBUG - 2016-01-06 11:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:05:49 --> Language Class Initialized
DEBUG - 2016-01-06 11:05:49 --> Language Class Initialized
DEBUG - 2016-01-06 11:05:49 --> Config Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Loader Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:05:50 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:05:50 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Session Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:05:50 --> Session routines successfully run
DEBUG - 2016-01-06 11:05:50 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Email Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Controller Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:05:50 --> Model Class Initialized
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:05:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:05:50 --> Final output sent to browser
DEBUG - 2016-01-06 11:05:50 --> Total execution time: 0.3048
DEBUG - 2016-01-06 11:06:11 --> Config Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:06:11 --> URI Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Router Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Output Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Security Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Input Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:06:11 --> Language Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Language Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Config Class Initialized
DEBUG - 2016-01-06 11:06:11 --> Loader Class Initialized
DEBUG - 2016-01-06 11:06:12 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:06:12 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:06:12 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:06:12 --> Session Class Initialized
DEBUG - 2016-01-06 11:06:12 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:06:12 --> Session routines successfully run
DEBUG - 2016-01-06 11:06:12 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:06:12 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:06:12 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:06:12 --> Email Class Initialized
DEBUG - 2016-01-06 11:06:12 --> Controller Class Initialized
DEBUG - 2016-01-06 11:06:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:06:12 --> Model Class Initialized
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:06:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:06:12 --> Final output sent to browser
DEBUG - 2016-01-06 11:06:12 --> Total execution time: 0.3239
DEBUG - 2016-01-06 11:08:34 --> Config Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:08:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:08:34 --> URI Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Router Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Output Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Security Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Input Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:08:34 --> Language Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Language Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Config Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Loader Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:08:34 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:08:34 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Session Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:08:34 --> Session routines successfully run
DEBUG - 2016-01-06 11:08:34 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Email Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Controller Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:08:34 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:08:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:08:34 --> Final output sent to browser
DEBUG - 2016-01-06 11:08:34 --> Total execution time: 0.2857
DEBUG - 2016-01-06 11:08:52 --> Config Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:08:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:08:52 --> URI Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Router Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Output Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Security Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Input Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:08:52 --> Language Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Language Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Config Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Loader Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:08:52 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:08:52 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Session Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:08:52 --> Session routines successfully run
DEBUG - 2016-01-06 11:08:52 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Email Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Controller Class Initialized
DEBUG - 2016-01-06 11:08:52 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:08:52 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 11:08:52 --> XSS Filtering completed
DEBUG - 2016-01-06 11:08:52 --> XSS Filtering completed
DEBUG - 2016-01-06 11:08:52 --> XSS Filtering completed
DEBUG - 2016-01-06 11:08:52 --> XSS Filtering completed
DEBUG - 2016-01-06 11:08:52 --> Config Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:08:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:08:52 --> URI Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Router Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Output Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Security Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Input Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:08:52 --> Language Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Language Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Config Class Initialized
DEBUG - 2016-01-06 11:08:52 --> Loader Class Initialized
DEBUG - 2016-01-06 11:08:53 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:08:53 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:08:53 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:08:53 --> Session Class Initialized
DEBUG - 2016-01-06 11:08:53 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:08:53 --> Session routines successfully run
DEBUG - 2016-01-06 11:08:53 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:08:53 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:08:53 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:08:53 --> Email Class Initialized
DEBUG - 2016-01-06 11:08:53 --> Controller Class Initialized
DEBUG - 2016-01-06 11:08:53 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:08:53 --> Model Class Initialized
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:08:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:08:53 --> Final output sent to browser
DEBUG - 2016-01-06 11:08:53 --> Total execution time: 0.3195
DEBUG - 2016-01-06 11:10:21 --> Config Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:10:21 --> URI Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Router Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Output Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Security Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Input Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:10:21 --> Language Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Language Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Config Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Loader Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:10:21 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:10:21 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Session Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:10:21 --> Session routines successfully run
DEBUG - 2016-01-06 11:10:21 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Email Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Controller Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:10:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:10:21 --> Final output sent to browser
DEBUG - 2016-01-06 11:10:21 --> Total execution time: 0.2981
DEBUG - 2016-01-06 11:10:39 --> Config Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:10:39 --> URI Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Router Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Output Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Security Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Input Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:10:39 --> Language Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Language Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Config Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Loader Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:10:39 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:10:39 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Session Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:10:39 --> Session routines successfully run
DEBUG - 2016-01-06 11:10:39 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Email Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Controller Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:10:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:10:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:10:39 --> Final output sent to browser
DEBUG - 2016-01-06 11:10:39 --> Total execution time: 0.3035
DEBUG - 2016-01-06 11:13:32 --> Config Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:13:32 --> URI Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Router Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Output Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Security Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Input Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:13:32 --> Language Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Language Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Config Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Loader Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:13:32 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:13:32 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Session Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:13:32 --> Session routines successfully run
DEBUG - 2016-01-06 11:13:32 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Email Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Controller Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:13:32 --> Model Class Initialized
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:13:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:13:32 --> Final output sent to browser
DEBUG - 2016-01-06 11:13:32 --> Total execution time: 0.3274
DEBUG - 2016-01-06 11:15:22 --> Config Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:15:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:15:22 --> URI Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Router Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Output Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Security Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Input Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:15:22 --> Language Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Language Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Config Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Loader Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:15:22 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:15:22 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Session Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:15:22 --> Session routines successfully run
DEBUG - 2016-01-06 11:15:22 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Email Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Controller Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Property MX_Controller Initialized
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:15:22 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:22 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:15:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:15:22 --> Final output sent to browser
DEBUG - 2016-01-06 11:15:22 --> Total execution time: 0.4360
DEBUG - 2016-01-06 11:15:35 --> Config Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:15:35 --> URI Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Router Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Output Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Security Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Input Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:15:35 --> Language Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Language Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Config Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Loader Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:15:35 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:15:35 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Session Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:15:35 --> Session routines successfully run
DEBUG - 2016-01-06 11:15:35 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Email Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Controller Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:15:35 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:35 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:15:36 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-06 11:15:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:15:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:15:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:15:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:15:36 --> Final output sent to browser
DEBUG - 2016-01-06 11:15:36 --> Total execution time: 0.4881
DEBUG - 2016-01-06 11:15:42 --> Config Class Initialized
DEBUG - 2016-01-06 11:15:42 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:15:42 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:15:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:15:42 --> URI Class Initialized
DEBUG - 2016-01-06 11:15:42 --> Router Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Output Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Security Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Input Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:15:43 --> Language Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Language Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Config Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Loader Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:15:43 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:15:43 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Session Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:15:43 --> Session routines successfully run
DEBUG - 2016-01-06 11:15:43 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Email Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Controller Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:15:43 --> Model Class Initialized
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:15:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:15:43 --> Final output sent to browser
DEBUG - 2016-01-06 11:15:43 --> Total execution time: 0.3212
DEBUG - 2016-01-06 11:16:26 --> Config Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:16:26 --> URI Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Router Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Output Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Security Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Input Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:16:26 --> Language Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Language Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Config Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Loader Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:16:26 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:16:26 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Session Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:16:26 --> Session routines successfully run
DEBUG - 2016-01-06 11:16:26 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Email Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Controller Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:16:26 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:26 --> DB Transaction Failure
ERROR - 2016-01-06 11:16:26 --> Query error: Column 'rental_unit_id' in where clause is ambiguous
DEBUG - 2016-01-06 11:16:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-06 11:16:39 --> Config Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:16:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:16:39 --> URI Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Router Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Output Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Security Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Input Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:16:39 --> Language Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Language Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Config Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Loader Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:16:39 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:16:39 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Session Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:16:39 --> Session routines successfully run
DEBUG - 2016-01-06 11:16:39 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Email Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Controller Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:16:39 --> Model Class Initialized
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:16:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:16:39 --> Final output sent to browser
DEBUG - 2016-01-06 11:16:39 --> Total execution time: 0.2766
DEBUG - 2016-01-06 11:29:36 --> Config Class Initialized
DEBUG - 2016-01-06 11:29:36 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:29:36 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:29:36 --> URI Class Initialized
DEBUG - 2016-01-06 11:29:36 --> Router Class Initialized
DEBUG - 2016-01-06 11:29:36 --> Output Class Initialized
DEBUG - 2016-01-06 11:29:36 --> Security Class Initialized
DEBUG - 2016-01-06 11:29:36 --> Input Class Initialized
DEBUG - 2016-01-06 11:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:29:36 --> Language Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Config Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:30:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:30:18 --> URI Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Router Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Output Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Security Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Input Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:30:18 --> Language Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Language Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Config Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Loader Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:30:18 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:30:18 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Session Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:30:18 --> Session routines successfully run
DEBUG - 2016-01-06 11:30:18 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Email Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Controller Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:30:18 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:30:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:30:18 --> Final output sent to browser
DEBUG - 2016-01-06 11:30:18 --> Total execution time: 0.3083
DEBUG - 2016-01-06 11:30:24 --> Config Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:30:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:30:24 --> URI Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Router Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Output Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Security Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Input Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:30:24 --> Language Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Language Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Config Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Loader Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:30:24 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:30:24 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Session Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:30:24 --> Session routines successfully run
DEBUG - 2016-01-06 11:30:24 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Email Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Controller Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:30:24 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 11:30:24 --> XSS Filtering completed
ERROR - 2016-01-06 11:30:24 --> Severity: Notice  --> Undefined property: CI::$tenant_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2016-01-06 11:30:50 --> Config Class Initialized
DEBUG - 2016-01-06 11:30:50 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:30:50 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:30:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:30:50 --> URI Class Initialized
DEBUG - 2016-01-06 11:30:50 --> Router Class Initialized
DEBUG - 2016-01-06 11:30:50 --> Output Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Security Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Input Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:30:51 --> Language Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Language Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Config Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Loader Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:30:51 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:30:51 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Session Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:30:51 --> Session routines successfully run
DEBUG - 2016-01-06 11:30:51 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Email Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Controller Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:30:51 --> Model Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 11:30:51 --> XSS Filtering completed
DEBUG - 2016-01-06 11:30:51 --> Config Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:30:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:30:51 --> URI Class Initialized
DEBUG - 2016-01-06 11:30:51 --> Router Class Initialized
ERROR - 2016-01-06 11:30:51 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 11:31:02 --> Config Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:31:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:31:02 --> URI Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Router Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Output Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Security Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Input Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:31:02 --> Language Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Language Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Config Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Loader Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:31:02 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:31:02 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Session Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:31:02 --> Session routines successfully run
DEBUG - 2016-01-06 11:31:02 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Email Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Controller Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:31:02 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:31:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:31:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:31:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:31:03 --> Final output sent to browser
DEBUG - 2016-01-06 11:31:03 --> Total execution time: 0.3953
DEBUG - 2016-01-06 11:31:37 --> Config Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:31:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:31:37 --> URI Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Router Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Output Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Security Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Input Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:31:37 --> Language Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Language Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Config Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Loader Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:31:37 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:31:37 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Session Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:31:37 --> Session routines successfully run
DEBUG - 2016-01-06 11:31:37 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Email Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Controller Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:31:37 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:31:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:31:37 --> Final output sent to browser
DEBUG - 2016-01-06 11:31:37 --> Total execution time: 0.2749
DEBUG - 2016-01-06 11:31:58 --> Config Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:31:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:31:58 --> URI Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Router Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Output Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Security Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Input Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:31:58 --> Language Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Language Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Config Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Loader Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:31:58 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:31:58 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Session Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:31:58 --> Session routines successfully run
DEBUG - 2016-01-06 11:31:58 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Email Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Controller Class Initialized
DEBUG - 2016-01-06 11:31:58 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:31:58 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 11:31:58 --> XSS Filtering completed
DEBUG - 2016-01-06 11:31:58 --> XSS Filtering completed
DEBUG - 2016-01-06 11:31:58 --> XSS Filtering completed
DEBUG - 2016-01-06 11:31:58 --> XSS Filtering completed
DEBUG - 2016-01-06 11:31:58 --> Config Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Hooks Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Utf8 Class Initialized
DEBUG - 2016-01-06 11:31:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 11:31:58 --> URI Class Initialized
DEBUG - 2016-01-06 11:31:58 --> Router Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Output Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Security Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Input Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 11:31:59 --> Language Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Language Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Config Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Loader Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Helper loaded: url_helper
DEBUG - 2016-01-06 11:31:59 --> Helper loaded: form_helper
DEBUG - 2016-01-06 11:31:59 --> Database Driver Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Session Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Helper loaded: string_helper
DEBUG - 2016-01-06 11:31:59 --> Session routines successfully run
DEBUG - 2016-01-06 11:31:59 --> Form Validation Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Pagination Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Encrypt Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Email Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Controller Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> Image Lib Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 11:31:59 --> Model Class Initialized
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 11:31:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 11:31:59 --> Final output sent to browser
DEBUG - 2016-01-06 11:31:59 --> Total execution time: 0.2665
DEBUG - 2016-01-06 12:19:46 --> Config Class Initialized
DEBUG - 2016-01-06 12:19:46 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:19:47 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:19:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:19:47 --> URI Class Initialized
DEBUG - 2016-01-06 12:19:47 --> Router Class Initialized
DEBUG - 2016-01-06 12:19:47 --> Output Class Initialized
DEBUG - 2016-01-06 12:19:47 --> Security Class Initialized
DEBUG - 2016-01-06 12:19:47 --> Input Class Initialized
DEBUG - 2016-01-06 12:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:19:47 --> Language Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Language Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Config Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Loader Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:19:48 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:19:48 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Session Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:19:48 --> Session routines successfully run
DEBUG - 2016-01-06 12:19:48 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Email Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Controller Class Initialized
DEBUG - 2016-01-06 12:19:48 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:19:48 --> Model Class Initialized
DEBUG - 2016-01-06 12:19:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:19:48 --> Model Class Initialized
DEBUG - 2016-01-06 12:19:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:19:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:19:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:19:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:19:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:19:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:19:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:19:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:19:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:19:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:19:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:19:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:19:49 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 12:19:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:19:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:19:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:19:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:19:50 --> Final output sent to browser
DEBUG - 2016-01-06 12:19:50 --> Total execution time: 3.9605
DEBUG - 2016-01-06 12:20:00 --> Config Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:20:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:20:00 --> URI Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Router Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Output Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Security Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Input Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:20:00 --> Language Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Language Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Config Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Loader Class Initialized
DEBUG - 2016-01-06 12:20:00 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:20:00 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:20:00 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:20:01 --> Session Class Initialized
DEBUG - 2016-01-06 12:20:01 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:20:01 --> Session routines successfully run
DEBUG - 2016-01-06 12:20:01 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:20:01 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:20:01 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:20:01 --> Email Class Initialized
DEBUG - 2016-01-06 12:20:01 --> Controller Class Initialized
DEBUG - 2016-01-06 12:20:01 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:20:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:20:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:20:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:20:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:20:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:20:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:20:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:20:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:20:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:20:01 --> Final output sent to browser
DEBUG - 2016-01-06 12:20:01 --> Total execution time: 0.2258
DEBUG - 2016-01-06 12:20:40 --> Config Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:20:40 --> URI Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Router Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Output Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Security Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Input Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:20:40 --> Language Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Language Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Config Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Loader Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:20:40 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:20:40 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Session Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:20:40 --> Session routines successfully run
DEBUG - 2016-01-06 12:20:40 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Email Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Controller Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:20:40 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:20:40 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:20:40 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:20:40 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:20:40 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:20:40 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:20:40 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:20:40 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 12:20:40 --> XSS Filtering completed
DEBUG - 2016-01-06 12:20:40 --> XSS Filtering completed
DEBUG - 2016-01-06 12:20:40 --> XSS Filtering completed
DEBUG - 2016-01-06 12:20:40 --> XSS Filtering completed
DEBUG - 2016-01-06 12:20:40 --> XSS Filtering completed
DEBUG - 2016-01-06 12:20:41 --> Config Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:20:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:20:41 --> URI Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Router Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Output Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Security Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Input Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:20:41 --> Language Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Language Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Config Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Loader Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:20:41 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:20:41 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Session Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:20:41 --> Session routines successfully run
DEBUG - 2016-01-06 12:20:41 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Email Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Controller Class Initialized
DEBUG - 2016-01-06 12:20:41 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:20:41 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:20:41 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:20:41 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:20:41 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:20:41 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:20:41 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:20:41 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:20:41 --> Model Class Initialized
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:20:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:20:41 --> Final output sent to browser
DEBUG - 2016-01-06 12:20:41 --> Total execution time: 0.2407
DEBUG - 2016-01-06 12:24:13 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:24:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:24:13 --> URI Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Router Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Output Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Security Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Input Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:24:13 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Loader Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:24:13 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:24:13 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Session Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:24:13 --> Session routines successfully run
DEBUG - 2016-01-06 12:24:13 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Email Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Controller Class Initialized
DEBUG - 2016-01-06 12:24:13 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:24:13 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:24:13 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:24:13 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:24:13 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:24:13 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:24:13 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:24:13 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:24:13 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:24:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:24:13 --> Final output sent to browser
DEBUG - 2016-01-06 12:24:13 --> Total execution time: 0.3059
DEBUG - 2016-01-06 12:24:34 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:24:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:24:34 --> URI Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Router Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Output Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Security Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Input Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:24:34 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Loader Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:24:34 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:24:34 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Session Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:24:34 --> Session routines successfully run
DEBUG - 2016-01-06 12:24:34 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Email Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Controller Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:24:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:24:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:24:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:24:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:24:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:24:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:24:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:24:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 12:24:34 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:34 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:34 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:34 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:34 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:35 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:24:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:24:35 --> URI Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Router Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Output Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Security Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Input Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:24:35 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Loader Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:24:35 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:24:35 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Session Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:24:35 --> Session routines successfully run
DEBUG - 2016-01-06 12:24:35 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Email Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Controller Class Initialized
DEBUG - 2016-01-06 12:24:35 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:24:35 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:24:35 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:24:35 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:24:35 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:24:35 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:24:35 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:24:35 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:24:35 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:24:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:24:35 --> Final output sent to browser
DEBUG - 2016-01-06 12:24:35 --> Total execution time: 0.2335
DEBUG - 2016-01-06 12:24:38 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:24:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:24:38 --> URI Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Router Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Output Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Security Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Input Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:24:38 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Loader Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:24:38 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:24:38 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Session Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:24:38 --> Session routines successfully run
DEBUG - 2016-01-06 12:24:38 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Email Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Controller Class Initialized
DEBUG - 2016-01-06 12:24:38 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:24:38 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:24:38 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:24:38 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:24:38 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:24:38 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:24:38 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:24:38 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:24:38 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:24:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:24:38 --> Final output sent to browser
DEBUG - 2016-01-06 12:24:38 --> Total execution time: 0.2348
DEBUG - 2016-01-06 12:24:52 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:24:52 --> URI Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Router Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Output Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Security Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Input Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:24:52 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Loader Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:24:52 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:24:52 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Session Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:24:52 --> Session routines successfully run
DEBUG - 2016-01-06 12:24:52 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Email Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Controller Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:24:52 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:24:52 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:24:52 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:24:52 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:24:52 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:24:52 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:24:52 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:24:52 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 12:24:52 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:52 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:52 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:52 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:52 --> XSS Filtering completed
DEBUG - 2016-01-06 12:24:52 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:24:52 --> URI Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Router Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Output Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Security Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Input Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:24:52 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Language Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Config Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Loader Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:24:52 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:24:52 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Session Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:24:52 --> Session routines successfully run
DEBUG - 2016-01-06 12:24:52 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:24:52 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:24:53 --> Email Class Initialized
DEBUG - 2016-01-06 12:24:53 --> Controller Class Initialized
DEBUG - 2016-01-06 12:24:53 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:24:53 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:24:53 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:24:53 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:24:53 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:24:53 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:24:53 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:24:53 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:24:53 --> Model Class Initialized
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:24:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:24:53 --> Final output sent to browser
DEBUG - 2016-01-06 12:24:53 --> Total execution time: 0.2221
DEBUG - 2016-01-06 12:25:15 --> Config Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:25:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:25:15 --> URI Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Router Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Output Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Security Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Input Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:25:15 --> Language Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Language Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Config Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Loader Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:25:15 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:25:15 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Session Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:25:15 --> Session routines successfully run
DEBUG - 2016-01-06 12:25:15 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Email Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Controller Class Initialized
DEBUG - 2016-01-06 12:25:15 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:25:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:25:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:25:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:25:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:25:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:25:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:25:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:25:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:25:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:25:15 --> Final output sent to browser
DEBUG - 2016-01-06 12:25:15 --> Total execution time: 0.2829
DEBUG - 2016-01-06 12:25:28 --> Config Class Initialized
DEBUG - 2016-01-06 12:25:28 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:25:28 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:25:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:25:28 --> URI Class Initialized
DEBUG - 2016-01-06 12:25:28 --> Router Class Initialized
ERROR - 2016-01-06 12:25:28 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 12:25:37 --> Config Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:25:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:25:37 --> URI Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Router Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Output Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Security Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Input Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:25:37 --> Language Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Language Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Config Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Loader Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:25:37 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:25:37 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Session Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:25:37 --> Session routines successfully run
DEBUG - 2016-01-06 12:25:37 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Email Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Controller Class Initialized
DEBUG - 2016-01-06 12:25:37 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:25:37 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:25:37 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:25:37 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:25:37 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:25:37 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:25:37 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:25:37 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:25:37 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:25:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:25:37 --> Final output sent to browser
DEBUG - 2016-01-06 12:25:37 --> Total execution time: 0.2677
DEBUG - 2016-01-06 12:25:43 --> Config Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:25:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:25:43 --> URI Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Router Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Output Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Security Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Input Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:25:43 --> Language Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Language Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Config Class Initialized
DEBUG - 2016-01-06 12:25:43 --> Loader Class Initialized
DEBUG - 2016-01-06 12:25:44 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:25:44 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:25:44 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:25:44 --> Session Class Initialized
DEBUG - 2016-01-06 12:25:44 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:25:44 --> Session routines successfully run
DEBUG - 2016-01-06 12:25:44 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:25:44 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:25:44 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:25:44 --> Email Class Initialized
DEBUG - 2016-01-06 12:25:44 --> Controller Class Initialized
DEBUG - 2016-01-06 12:25:44 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:25:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:25:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:25:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:25:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:25:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:25:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:25:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:25:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:25:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:25:44 --> Final output sent to browser
DEBUG - 2016-01-06 12:25:44 --> Total execution time: 0.2241
DEBUG - 2016-01-06 12:25:49 --> Config Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:25:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:25:49 --> URI Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Router Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Output Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Security Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Input Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:25:49 --> Language Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Language Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Config Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Loader Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:25:49 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:25:49 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Session Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:25:49 --> Session routines successfully run
DEBUG - 2016-01-06 12:25:49 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Email Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Controller Class Initialized
DEBUG - 2016-01-06 12:25:49 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:25:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:25:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:25:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:25:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:25:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:25:49 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:25:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:25:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:25:50 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 12:25:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:25:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:25:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:25:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:25:50 --> Final output sent to browser
DEBUG - 2016-01-06 12:25:50 --> Total execution time: 0.2216
DEBUG - 2016-01-06 12:26:05 --> Config Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:26:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:26:05 --> URI Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Router Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Output Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Security Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Input Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:26:05 --> Language Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Language Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Config Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Loader Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:26:05 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:26:05 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Session Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:26:05 --> Session routines successfully run
DEBUG - 2016-01-06 12:26:05 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Email Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Controller Class Initialized
DEBUG - 2016-01-06 12:26:05 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:26:05 --> Model Class Initialized
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:26:05 --> Model Class Initialized
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:26:05 --> Model Class Initialized
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:26:05 --> Model Class Initialized
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:26:05 --> Model Class Initialized
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:26:05 --> Model Class Initialized
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:26:05 --> Model Class Initialized
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:26:05 --> Model Class Initialized
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:26:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:26:05 --> Final output sent to browser
DEBUG - 2016-01-06 12:26:05 --> Total execution time: 0.2718
DEBUG - 2016-01-06 12:26:09 --> Config Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:26:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:26:09 --> URI Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Router Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Output Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Security Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Input Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:26:09 --> Language Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Language Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Config Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Loader Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:26:09 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:26:09 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Session Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:26:09 --> Session routines successfully run
DEBUG - 2016-01-06 12:26:09 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Email Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Controller Class Initialized
DEBUG - 2016-01-06 12:26:09 --> Administration MX_Controller Initialized
DEBUG - 2016-01-06 12:27:34 --> Config Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:27:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:27:34 --> URI Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Router Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Output Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Security Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Input Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:27:34 --> Language Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Language Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Config Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Loader Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:27:34 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:27:34 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Session Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:27:34 --> Session routines successfully run
DEBUG - 2016-01-06 12:27:34 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Email Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Controller Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Property MX_Controller Initialized
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 12:27:34 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:34 --> Image Lib Class Initialized
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:27:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:27:34 --> Final output sent to browser
DEBUG - 2016-01-06 12:27:34 --> Total execution time: 0.6926
DEBUG - 2016-01-06 12:27:44 --> Config Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:27:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:27:44 --> URI Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Router Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Output Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Security Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Input Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:27:44 --> Language Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Language Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Config Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Loader Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:27:44 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:27:44 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Session Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:27:44 --> Session routines successfully run
DEBUG - 2016-01-06 12:27:44 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Email Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Controller Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 12:27:44 --> Model Class Initialized
DEBUG - 2016-01-06 12:27:44 --> Image Lib Class Initialized
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:27:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:27:44 --> Final output sent to browser
DEBUG - 2016-01-06 12:27:44 --> Total execution time: 0.5993
DEBUG - 2016-01-06 12:28:30 --> Config Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:28:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:28:30 --> URI Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Router Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Output Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Security Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Input Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:28:30 --> Language Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Language Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Config Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Loader Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:28:30 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:28:30 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Session Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:28:30 --> Session routines successfully run
DEBUG - 2016-01-06 12:28:30 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Email Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Controller Class Initialized
DEBUG - 2016-01-06 12:28:30 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 12:28:30 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:28:30 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:28:30 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:28:30 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:28:30 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:28:30 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:28:30 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:28:30 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 12:28:31 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 12:28:31 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:31 --> Image Lib Class Initialized
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 12:28:31 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 12:28:31 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 12:28:31 --> Model Class Initialized
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:28:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:28:31 --> Final output sent to browser
DEBUG - 2016-01-06 12:28:31 --> Total execution time: 0.8187
DEBUG - 2016-01-06 12:30:19 --> Config Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:30:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:30:19 --> URI Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Router Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Output Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Security Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Input Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:30:19 --> Language Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Language Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Config Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Loader Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:30:19 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:30:19 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Session Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:30:19 --> Session routines successfully run
DEBUG - 2016-01-06 12:30:19 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Email Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Controller Class Initialized
DEBUG - 2016-01-06 12:30:19 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:30:19 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:30:19 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:30:19 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:30:19 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:30:19 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:30:19 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:30:19 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:30:19 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:30:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:30:19 --> Final output sent to browser
DEBUG - 2016-01-06 12:30:19 --> Total execution time: 0.2584
DEBUG - 2016-01-06 12:30:28 --> Config Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:30:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:30:28 --> URI Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Router Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Output Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Security Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Input Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:30:28 --> Language Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Language Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Config Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Loader Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:30:28 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:30:28 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Session Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:30:28 --> Session routines successfully run
DEBUG - 2016-01-06 12:30:28 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Email Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Controller Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:30:28 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:30:28 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:30:28 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:30:28 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:30:28 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:30:28 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:30:28 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:30:28 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 12:30:28 --> XSS Filtering completed
DEBUG - 2016-01-06 12:30:28 --> XSS Filtering completed
DEBUG - 2016-01-06 12:30:28 --> XSS Filtering completed
DEBUG - 2016-01-06 12:30:28 --> XSS Filtering completed
DEBUG - 2016-01-06 12:30:29 --> XSS Filtering completed
DEBUG - 2016-01-06 12:30:29 --> Config Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:30:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:30:29 --> URI Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Router Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Output Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Security Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Input Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:30:29 --> Language Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Language Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Config Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Loader Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:30:29 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:30:29 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Session Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:30:29 --> Session routines successfully run
DEBUG - 2016-01-06 12:30:29 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Email Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Controller Class Initialized
DEBUG - 2016-01-06 12:30:29 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 12:30:29 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:30:29 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:30:29 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:30:29 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:30:29 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:30:29 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:30:29 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:30:29 --> Model Class Initialized
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:30:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:30:29 --> Final output sent to browser
DEBUG - 2016-01-06 12:30:29 --> Total execution time: 0.2498
DEBUG - 2016-01-06 12:44:01 --> Config Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:44:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:44:01 --> URI Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Router Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Output Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Security Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Input Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:44:01 --> Language Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Language Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Config Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Loader Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:44:01 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:44:01 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Session Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:44:01 --> Session routines successfully run
DEBUG - 2016-01-06 12:44:01 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Email Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Controller Class Initialized
DEBUG - 2016-01-06 12:44:01 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 12:44:01 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:01 --> Image Lib Class Initialized
ERROR - 2016-01-06 12:44:01 --> Severity: Notice  --> Undefined property: CI::$lease_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2016-01-06 12:44:15 --> Config Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:44:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:44:15 --> URI Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Router Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Output Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Security Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Input Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:44:15 --> Language Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Language Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Config Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Loader Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:44:15 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:44:15 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Session Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:44:15 --> Session routines successfully run
DEBUG - 2016-01-06 12:44:15 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Email Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Controller Class Initialized
DEBUG - 2016-01-06 12:44:15 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 12:44:15 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:15 --> Image Lib Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Config Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:44:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:44:26 --> URI Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Router Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Output Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Security Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Input Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:44:26 --> Language Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Language Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Config Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Loader Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:44:26 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:44:26 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Session Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:44:26 --> Session routines successfully run
DEBUG - 2016-01-06 12:44:26 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Email Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Controller Class Initialized
DEBUG - 2016-01-06 12:44:26 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 12:44:26 --> Model Class Initialized
DEBUG - 2016-01-06 12:44:26 --> Image Lib Class Initialized
ERROR - 2016-01-06 12:44:26 --> Severity: Notice  --> Undefined variable: rental_unit_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\all_leases.php 66
ERROR - 2016-01-06 12:44:26 --> Severity: Notice  --> Undefined variable: rental_unit_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\all_leases.php 66
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:44:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:44:26 --> Final output sent to browser
DEBUG - 2016-01-06 12:44:26 --> Total execution time: 0.2771
DEBUG - 2016-01-06 12:46:16 --> Config Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:46:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:46:16 --> URI Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Router Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Output Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Security Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Input Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:46:16 --> Language Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Language Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Config Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Loader Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:46:16 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:46:16 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Session Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:46:16 --> Session routines successfully run
DEBUG - 2016-01-06 12:46:16 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Email Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Controller Class Initialized
DEBUG - 2016-01-06 12:46:16 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 12:46:16 --> Model Class Initialized
DEBUG - 2016-01-06 12:46:16 --> Image Lib Class Initialized
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:46:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:46:16 --> Final output sent to browser
DEBUG - 2016-01-06 12:46:16 --> Total execution time: 0.3604
DEBUG - 2016-01-06 12:50:49 --> Config Class Initialized
DEBUG - 2016-01-06 12:50:49 --> Hooks Class Initialized
DEBUG - 2016-01-06 12:50:49 --> Utf8 Class Initialized
DEBUG - 2016-01-06 12:50:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 12:50:49 --> URI Class Initialized
DEBUG - 2016-01-06 12:50:49 --> Router Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Output Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Security Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Input Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 12:50:50 --> Language Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Language Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Config Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Loader Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Helper loaded: url_helper
DEBUG - 2016-01-06 12:50:50 --> Helper loaded: form_helper
DEBUG - 2016-01-06 12:50:50 --> Database Driver Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Session Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Helper loaded: string_helper
DEBUG - 2016-01-06 12:50:50 --> Session routines successfully run
DEBUG - 2016-01-06 12:50:50 --> Form Validation Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Pagination Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Encrypt Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Email Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Controller Class Initialized
DEBUG - 2016-01-06 12:50:50 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 12:50:50 --> Model Class Initialized
DEBUG - 2016-01-06 12:50:50 --> Image Lib Class Initialized
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 12:50:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 12:50:50 --> Final output sent to browser
DEBUG - 2016-01-06 12:50:50 --> Total execution time: 0.4292
DEBUG - 2016-01-06 13:09:08 --> Config Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:09:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:09:08 --> URI Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Router Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Output Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Security Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Input Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:09:08 --> Language Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Language Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Config Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Loader Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:09:08 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:09:08 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Session Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:09:08 --> Session routines successfully run
DEBUG - 2016-01-06 13:09:08 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Email Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Controller Class Initialized
DEBUG - 2016-01-06 13:09:08 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:09:08 --> Model Class Initialized
DEBUG - 2016-01-06 13:09:08 --> Image Lib Class Initialized
ERROR - 2016-01-06 13:09:09 --> Severity: Notice  --> Undefined variable: tenant_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\all_leases.php 88
DEBUG - 2016-01-06 13:09:09 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
ERROR - 2016-01-06 13:09:09 --> Severity: Notice  --> Undefined variable: tenant_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\all_leases.php 88
DEBUG - 2016-01-06 13:09:09 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
ERROR - 2016-01-06 13:09:09 --> Severity: Notice  --> Undefined variable: tenant_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\all_leases.php 88
DEBUG - 2016-01-06 13:09:09 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:09:09 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:09:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:09:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:09:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:09:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:09:09 --> Final output sent to browser
DEBUG - 2016-01-06 13:09:09 --> Total execution time: 0.3854
DEBUG - 2016-01-06 13:11:26 --> Config Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:11:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:11:26 --> URI Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Router Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Output Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Security Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Input Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:11:26 --> Language Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Language Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Config Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Loader Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:11:26 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:11:26 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Session Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:11:26 --> Session routines successfully run
DEBUG - 2016-01-06 13:11:26 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Email Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Controller Class Initialized
DEBUG - 2016-01-06 13:11:26 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:11:26 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:26 --> Image Lib Class Initialized
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:11:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:11:26 --> Final output sent to browser
DEBUG - 2016-01-06 13:11:26 --> Total execution time: 0.2956
DEBUG - 2016-01-06 13:11:52 --> Config Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:11:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:11:52 --> URI Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Router Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Output Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Security Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Input Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:11:52 --> Language Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Language Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Config Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Loader Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:11:52 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:11:52 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Session Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:11:52 --> Session routines successfully run
DEBUG - 2016-01-06 13:11:52 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Email Class Initialized
DEBUG - 2016-01-06 13:11:52 --> Controller Class Initialized
DEBUG - 2016-01-06 13:11:52 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:11:52 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:11:53 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:11:53 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:11:53 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:11:53 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:11:53 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:11:53 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:11:53 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:11:53 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:11:53 --> Model Class Initialized
DEBUG - 2016-01-06 13:11:53 --> Image Lib Class Initialized
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:11:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:11:53 --> Final output sent to browser
DEBUG - 2016-01-06 13:11:53 --> Total execution time: 0.3894
DEBUG - 2016-01-06 13:13:51 --> Config Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:13:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:13:51 --> URI Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Router Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Output Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Security Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Input Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:13:51 --> Language Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Language Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Config Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Loader Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:13:51 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:13:51 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Session Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:13:51 --> Session routines successfully run
DEBUG - 2016-01-06 13:13:51 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Email Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Controller Class Initialized
DEBUG - 2016-01-06 13:13:51 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:13:51 --> Model Class Initialized
DEBUG - 2016-01-06 13:13:51 --> Image Lib Class Initialized
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:13:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:13:51 --> Final output sent to browser
DEBUG - 2016-01-06 13:13:51 --> Total execution time: 0.2691
DEBUG - 2016-01-06 13:18:40 --> Config Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:18:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:18:40 --> URI Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Router Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Output Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Security Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Input Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:18:40 --> Language Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Language Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Config Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Loader Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:18:40 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:18:40 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Session Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:18:40 --> Session routines successfully run
DEBUG - 2016-01-06 13:18:40 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Email Class Initialized
DEBUG - 2016-01-06 13:18:40 --> Controller Class Initialized
DEBUG - 2016-01-06 13:18:40 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:18:40 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:18:40 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:18:40 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:18:41 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:18:41 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:18:41 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:18:41 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:18:41 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:18:41 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:18:41 --> Model Class Initialized
DEBUG - 2016-01-06 13:18:41 --> Image Lib Class Initialized
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:18:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:18:41 --> Final output sent to browser
DEBUG - 2016-01-06 13:18:41 --> Total execution time: 0.3738
DEBUG - 2016-01-06 13:19:28 --> Config Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:19:28 --> URI Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Router Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Output Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Security Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Input Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:19:28 --> Language Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Language Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Config Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Loader Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:19:28 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:19:28 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Session Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:19:28 --> Session routines successfully run
DEBUG - 2016-01-06 13:19:28 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Email Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Controller Class Initialized
DEBUG - 2016-01-06 13:19:28 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-06 13:19:28 --> Image Lib Class Initialized
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:19:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:19:28 --> Final output sent to browser
DEBUG - 2016-01-06 13:19:28 --> Total execution time: 0.2940
DEBUG - 2016-01-06 13:25:11 --> Config Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:25:11 --> URI Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Router Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Output Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Security Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Input Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:25:11 --> Language Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Language Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Config Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Loader Class Initialized
DEBUG - 2016-01-06 13:25:11 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:25:11 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:25:11 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:25:12 --> Session Class Initialized
DEBUG - 2016-01-06 13:25:12 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:25:12 --> Session routines successfully run
DEBUG - 2016-01-06 13:25:12 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:25:12 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:25:12 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:25:12 --> Email Class Initialized
DEBUG - 2016-01-06 13:25:12 --> Controller Class Initialized
DEBUG - 2016-01-06 13:25:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> Image Lib Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:25:12 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:25:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:25:12 --> Final output sent to browser
DEBUG - 2016-01-06 13:25:12 --> Total execution time: 0.7464
DEBUG - 2016-01-06 13:25:18 --> Config Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:25:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:25:18 --> URI Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Router Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Output Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Security Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Input Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:25:18 --> Language Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Language Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Config Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Loader Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:25:18 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:25:18 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Session Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:25:18 --> Session routines successfully run
DEBUG - 2016-01-06 13:25:18 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Email Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Controller Class Initialized
DEBUG - 2016-01-06 13:25:18 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:25:18 --> Model Class Initialized
DEBUG - 2016-01-06 13:25:18 --> Image Lib Class Initialized
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: rental_amount C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 25
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: rental_amount C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 25
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: rental_amount C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 25
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: tenant_phone_number C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 100
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: tenant_national_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 101
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 127
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 128
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 128
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: rental_amount C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 25
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: rental_amount C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 25
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: rental_amount C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 25
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: tenant_phone_number C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 100
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: tenant_national_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 101
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 127
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 128
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 128
DEBUG - 2016-01-06 13:25:18 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: rental_amount C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 25
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: rental_amount C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 25
ERROR - 2016-01-06 13:25:18 --> Severity: Notice  --> Undefined variable: rental_amount C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 25
ERROR - 2016-01-06 13:25:19 --> Severity: Notice  --> Undefined variable: tenant_phone_number C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 100
ERROR - 2016-01-06 13:25:19 --> Severity: Notice  --> Undefined variable: tenant_national_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 101
ERROR - 2016-01-06 13:25:19 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 127
ERROR - 2016-01-06 13:25:19 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 128
ERROR - 2016-01-06 13:25:19 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 128
DEBUG - 2016-01-06 13:25:19 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:25:19 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:25:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:25:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:25:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:25:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:25:19 --> Final output sent to browser
DEBUG - 2016-01-06 13:25:19 --> Total execution time: 0.4127
DEBUG - 2016-01-06 13:26:22 --> Config Class Initialized
DEBUG - 2016-01-06 13:26:22 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:26:22 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:26:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:26:23 --> URI Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Router Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Output Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Security Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Input Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:26:23 --> Language Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Language Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Config Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Loader Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:26:23 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:26:23 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Session Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:26:23 --> Session routines successfully run
DEBUG - 2016-01-06 13:26:23 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Email Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Controller Class Initialized
DEBUG - 2016-01-06 13:26:23 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:26:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:23 --> Image Lib Class Initialized
ERROR - 2016-01-06 13:26:23 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 129
ERROR - 2016-01-06 13:26:23 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 130
ERROR - 2016-01-06 13:26:23 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 130
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
ERROR - 2016-01-06 13:26:23 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 129
ERROR - 2016-01-06 13:26:23 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 130
ERROR - 2016-01-06 13:26:23 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 130
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
ERROR - 2016-01-06 13:26:23 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 129
ERROR - 2016-01-06 13:26:23 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 130
ERROR - 2016-01-06 13:26:23 --> Severity: Notice  --> Undefined variable: total_paid C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\lease_details.php 130
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:26:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:26:23 --> Final output sent to browser
DEBUG - 2016-01-06 13:26:23 --> Total execution time: 0.3791
DEBUG - 2016-01-06 13:26:50 --> Config Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:26:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:26:50 --> URI Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Router Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Output Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Security Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Input Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:26:50 --> Language Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Language Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Config Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Loader Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:26:50 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:26:50 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Session Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:26:50 --> Session routines successfully run
DEBUG - 2016-01-06 13:26:50 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Email Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Controller Class Initialized
DEBUG - 2016-01-06 13:26:50 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:26:50 --> Model Class Initialized
DEBUG - 2016-01-06 13:26:50 --> Image Lib Class Initialized
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:26:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:26:50 --> Final output sent to browser
DEBUG - 2016-01-06 13:26:50 --> Total execution time: 0.2807
DEBUG - 2016-01-06 13:28:07 --> Config Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:28:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:28:07 --> URI Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Router Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Output Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Security Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Input Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:28:07 --> Language Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Language Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Config Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Loader Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:28:07 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:28:07 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Session Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:28:07 --> Session routines successfully run
DEBUG - 2016-01-06 13:28:07 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Email Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Controller Class Initialized
DEBUG - 2016-01-06 13:28:07 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 13:28:07 --> Image Lib Class Initialized
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:28:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:28:07 --> Final output sent to browser
DEBUG - 2016-01-06 13:28:07 --> Total execution time: 0.2991
DEBUG - 2016-01-06 13:46:28 --> Config Class Initialized
DEBUG - 2016-01-06 13:46:28 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:46:28 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:46:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:46:28 --> URI Class Initialized
DEBUG - 2016-01-06 13:46:28 --> Router Class Initialized
DEBUG - 2016-01-06 13:46:28 --> Output Class Initialized
DEBUG - 2016-01-06 13:46:28 --> Security Class Initialized
DEBUG - 2016-01-06 13:46:29 --> Input Class Initialized
DEBUG - 2016-01-06 13:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:46:29 --> Language Class Initialized
DEBUG - 2016-01-06 13:46:29 --> Language Class Initialized
DEBUG - 2016-01-06 13:46:29 --> Config Class Initialized
DEBUG - 2016-01-06 13:46:29 --> Loader Class Initialized
DEBUG - 2016-01-06 13:46:29 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:46:29 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:46:29 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:46:32 --> Session Class Initialized
DEBUG - 2016-01-06 13:46:32 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:46:32 --> Session routines successfully run
DEBUG - 2016-01-06 13:46:32 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:46:32 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:46:32 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:46:32 --> Email Class Initialized
DEBUG - 2016-01-06 13:46:32 --> Controller Class Initialized
DEBUG - 2016-01-06 13:46:32 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 13:46:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:46:33 --> Image Lib Class Initialized
DEBUG - 2016-01-06 13:46:34 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:46:34 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:46:34 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 13:46:34 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 13:46:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:46:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:46:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:46:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:46:35 --> Final output sent to browser
DEBUG - 2016-01-06 13:46:35 --> Total execution time: 8.1859
DEBUG - 2016-01-06 13:48:22 --> Config Class Initialized
DEBUG - 2016-01-06 13:48:22 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:48:22 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:48:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:48:22 --> URI Class Initialized
DEBUG - 2016-01-06 13:48:22 --> Router Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Output Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Security Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Input Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:48:23 --> Language Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Language Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Config Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Loader Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:48:23 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:48:23 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Session Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:48:23 --> Session routines successfully run
DEBUG - 2016-01-06 13:48:23 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Email Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Controller Class Initialized
DEBUG - 2016-01-06 13:48:23 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:48:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:48:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:48:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:48:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:48:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:48:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:48:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:48:23 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:48:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:48:23 --> Final output sent to browser
DEBUG - 2016-01-06 13:48:23 --> Total execution time: 0.7554
DEBUG - 2016-01-06 13:48:33 --> Config Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:48:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:48:33 --> URI Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Router Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Output Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Security Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Input Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:48:33 --> Language Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Language Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Config Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Loader Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:48:33 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:48:33 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Session Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:48:33 --> Session routines successfully run
DEBUG - 2016-01-06 13:48:33 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Email Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Controller Class Initialized
DEBUG - 2016-01-06 13:48:33 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:48:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:48:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:48:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:48:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:48:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:48:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:48:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:48:33 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:48:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:48:33 --> Final output sent to browser
DEBUG - 2016-01-06 13:48:33 --> Total execution time: 0.3241
DEBUG - 2016-01-06 13:48:58 --> Config Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:48:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:48:58 --> URI Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Router Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Output Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Security Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Input Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:48:58 --> Language Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Language Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Config Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Loader Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:48:58 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:48:58 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Session Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:48:58 --> Session routines successfully run
DEBUG - 2016-01-06 13:48:58 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Email Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Controller Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:48:58 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:48:58 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:48:58 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:48:58 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:48:58 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:48:58 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:48:58 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:48:58 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 13:48:59 --> XSS Filtering completed
DEBUG - 2016-01-06 13:48:59 --> XSS Filtering completed
DEBUG - 2016-01-06 13:48:59 --> XSS Filtering completed
DEBUG - 2016-01-06 13:48:59 --> XSS Filtering completed
DEBUG - 2016-01-06 13:48:59 --> XSS Filtering completed
DEBUG - 2016-01-06 13:48:59 --> Config Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:48:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:48:59 --> URI Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Router Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Output Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Security Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Input Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:48:59 --> Language Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Language Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Config Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Loader Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:48:59 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:48:59 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Session Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:48:59 --> Session routines successfully run
DEBUG - 2016-01-06 13:48:59 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Email Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Controller Class Initialized
DEBUG - 2016-01-06 13:48:59 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:48:59 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:48:59 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:48:59 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:48:59 --> Model Class Initialized
DEBUG - 2016-01-06 13:48:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:48:59 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:49:00 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:49:00 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:49:00 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:00 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 13:49:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:49:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:49:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:49:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:49:00 --> Final output sent to browser
DEBUG - 2016-01-06 13:49:00 --> Total execution time: 0.2402
DEBUG - 2016-01-06 13:49:04 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:49:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:49:04 --> URI Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Router Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Output Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Security Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Input Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:49:04 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Loader Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:49:04 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:49:04 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Session Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:49:04 --> Session routines successfully run
DEBUG - 2016-01-06 13:49:04 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Email Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Controller Class Initialized
DEBUG - 2016-01-06 13:49:04 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:49:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:49:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:49:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:49:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:49:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:49:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:49:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:49:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:49:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:49:04 --> Final output sent to browser
DEBUG - 2016-01-06 13:49:04 --> Total execution time: 0.3081
DEBUG - 2016-01-06 13:49:05 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:49:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:49:05 --> URI Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Router Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Output Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Security Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Input Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:49:05 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Loader Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:49:05 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:49:05 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Session Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:49:05 --> Session routines successfully run
DEBUG - 2016-01-06 13:49:05 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Email Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Controller Class Initialized
DEBUG - 2016-01-06 13:49:05 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:49:05 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:49:05 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:49:05 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:49:05 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:49:05 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:49:05 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:49:05 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:49:05 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:06 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-06 13:49:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:49:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:49:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:49:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:49:06 --> Final output sent to browser
DEBUG - 2016-01-06 13:49:06 --> Total execution time: 0.7474
DEBUG - 2016-01-06 13:49:21 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:49:21 --> URI Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Router Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Output Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Security Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Input Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:49:21 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Loader Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:49:21 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:49:21 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Session Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:49:21 --> Session routines successfully run
DEBUG - 2016-01-06 13:49:21 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Email Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Controller Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:49:21 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:49:21 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:49:21 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:49:21 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:49:21 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:49:21 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:49:21 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:49:21 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 13:49:21 --> XSS Filtering completed
DEBUG - 2016-01-06 13:49:21 --> XSS Filtering completed
DEBUG - 2016-01-06 13:49:21 --> XSS Filtering completed
DEBUG - 2016-01-06 13:49:21 --> XSS Filtering completed
DEBUG - 2016-01-06 13:49:21 --> XSS Filtering completed
DEBUG - 2016-01-06 13:49:22 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:49:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:49:22 --> URI Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Router Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Output Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Security Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Input Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:49:22 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Loader Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:49:22 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:49:22 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Session Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:49:22 --> Session routines successfully run
DEBUG - 2016-01-06 13:49:22 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Email Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Controller Class Initialized
DEBUG - 2016-01-06 13:49:22 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:49:22 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:49:22 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:49:22 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:49:22 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:49:22 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:49:22 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:49:22 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:49:22 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:49:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:49:22 --> Final output sent to browser
DEBUG - 2016-01-06 13:49:22 --> Total execution time: 0.4289
DEBUG - 2016-01-06 13:49:25 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:49:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:49:25 --> URI Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Router Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Output Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Security Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Input Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:49:25 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Language Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Config Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Loader Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:49:25 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:49:25 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Session Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:49:25 --> Session routines successfully run
DEBUG - 2016-01-06 13:49:25 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Email Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Controller Class Initialized
DEBUG - 2016-01-06 13:49:25 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:49:25 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:49:25 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:49:25 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:49:25 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:49:25 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:49:25 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:49:25 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:49:25 --> Model Class Initialized
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:49:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:49:25 --> Final output sent to browser
DEBUG - 2016-01-06 13:49:25 --> Total execution time: 0.5204
DEBUG - 2016-01-06 13:50:35 --> Config Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:50:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:50:35 --> URI Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Router Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Output Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Security Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Input Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:50:35 --> Language Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Language Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Config Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Loader Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:50:35 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:50:35 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Session Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:50:35 --> Session routines successfully run
DEBUG - 2016-01-06 13:50:35 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Email Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Controller Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 13:50:35 --> XSS Filtering completed
DEBUG - 2016-01-06 13:50:35 --> XSS Filtering completed
DEBUG - 2016-01-06 13:50:35 --> XSS Filtering completed
DEBUG - 2016-01-06 13:50:35 --> XSS Filtering completed
DEBUG - 2016-01-06 13:50:35 --> XSS Filtering completed
DEBUG - 2016-01-06 13:50:35 --> Config Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:50:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:50:35 --> URI Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Router Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Output Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Security Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Input Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:50:35 --> Language Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Language Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Config Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Loader Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:50:35 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:50:35 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Session Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:50:35 --> Session routines successfully run
DEBUG - 2016-01-06 13:50:35 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Email Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Controller Class Initialized
DEBUG - 2016-01-06 13:50:35 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:50:35 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:50:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:50:35 --> Final output sent to browser
DEBUG - 2016-01-06 13:50:35 --> Total execution time: 0.2595
DEBUG - 2016-01-06 13:50:38 --> Config Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:50:38 --> URI Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Router Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Output Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Security Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Input Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:50:38 --> Language Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Language Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Config Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Loader Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:50:38 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:50:38 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Session Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:50:38 --> Session routines successfully run
DEBUG - 2016-01-06 13:50:38 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Email Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Controller Class Initialized
DEBUG - 2016-01-06 13:50:38 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:50:38 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:50:38 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:50:38 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:50:38 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:50:38 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:50:38 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:50:38 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:50:38 --> Model Class Initialized
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:50:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:50:38 --> Final output sent to browser
DEBUG - 2016-01-06 13:50:38 --> Total execution time: 0.2629
DEBUG - 2016-01-06 13:51:04 --> Config Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:51:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:51:04 --> URI Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Router Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Output Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Security Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Input Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:51:04 --> Language Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Language Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Config Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Loader Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:51:04 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:51:04 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Session Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:51:04 --> Session routines successfully run
DEBUG - 2016-01-06 13:51:04 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Email Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Controller Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 13:51:04 --> XSS Filtering completed
DEBUG - 2016-01-06 13:51:04 --> XSS Filtering completed
DEBUG - 2016-01-06 13:51:04 --> XSS Filtering completed
DEBUG - 2016-01-06 13:51:04 --> XSS Filtering completed
DEBUG - 2016-01-06 13:51:04 --> XSS Filtering completed
DEBUG - 2016-01-06 13:51:04 --> Config Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Hooks Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Utf8 Class Initialized
DEBUG - 2016-01-06 13:51:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 13:51:04 --> URI Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Router Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Output Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Security Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Input Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 13:51:04 --> Language Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Language Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Config Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Loader Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Helper loaded: url_helper
DEBUG - 2016-01-06 13:51:04 --> Helper loaded: form_helper
DEBUG - 2016-01-06 13:51:04 --> Database Driver Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Session Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Helper loaded: string_helper
DEBUG - 2016-01-06 13:51:04 --> Session routines successfully run
DEBUG - 2016-01-06 13:51:04 --> Form Validation Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Pagination Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Encrypt Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Email Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Controller Class Initialized
DEBUG - 2016-01-06 13:51:04 --> Sections MX_Controller Initialized
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 13:51:04 --> Model Class Initialized
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 13:51:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 13:51:04 --> Final output sent to browser
DEBUG - 2016-01-06 13:51:04 --> Total execution time: 0.2484
DEBUG - 2016-01-06 14:22:59 --> Config Class Initialized
DEBUG - 2016-01-06 14:22:59 --> Hooks Class Initialized
DEBUG - 2016-01-06 14:22:59 --> Utf8 Class Initialized
DEBUG - 2016-01-06 14:22:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 14:22:59 --> URI Class Initialized
DEBUG - 2016-01-06 14:23:00 --> Router Class Initialized
ERROR - 2016-01-06 14:23:01 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 14:26:21 --> Config Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Hooks Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Utf8 Class Initialized
DEBUG - 2016-01-06 14:26:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 14:26:21 --> URI Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Router Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Output Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Security Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Input Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 14:26:21 --> Language Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Language Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Config Class Initialized
DEBUG - 2016-01-06 14:26:21 --> Loader Class Initialized
DEBUG - 2016-01-06 14:26:22 --> Helper loaded: url_helper
DEBUG - 2016-01-06 14:26:22 --> Helper loaded: form_helper
DEBUG - 2016-01-06 14:26:22 --> Database Driver Class Initialized
DEBUG - 2016-01-06 14:26:22 --> Session Class Initialized
DEBUG - 2016-01-06 14:26:22 --> Helper loaded: string_helper
DEBUG - 2016-01-06 14:26:22 --> Session routines successfully run
DEBUG - 2016-01-06 14:26:22 --> Form Validation Class Initialized
DEBUG - 2016-01-06 14:26:22 --> Pagination Class Initialized
DEBUG - 2016-01-06 14:26:22 --> Encrypt Class Initialized
DEBUG - 2016-01-06 14:26:22 --> Email Class Initialized
DEBUG - 2016-01-06 14:26:22 --> Controller Class Initialized
DEBUG - 2016-01-06 14:26:22 --> leases MX_Controller Initialized
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 14:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 14:26:22 --> Image Lib Class Initialized
DEBUG - 2016-01-06 14:26:23 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 14:26:23 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 14:26:23 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-06 14:26:23 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-06 14:26:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 14:26:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 14:26:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 14:26:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 14:26:23 --> Final output sent to browser
DEBUG - 2016-01-06 14:26:23 --> Total execution time: 1.9355
DEBUG - 2016-01-06 14:29:21 --> Config Class Initialized
DEBUG - 2016-01-06 14:29:21 --> Hooks Class Initialized
DEBUG - 2016-01-06 14:29:21 --> Utf8 Class Initialized
DEBUG - 2016-01-06 14:29:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 14:29:21 --> URI Class Initialized
DEBUG - 2016-01-06 14:29:21 --> Router Class Initialized
ERROR - 2016-01-06 14:29:21 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 15:10:15 --> Config Class Initialized
DEBUG - 2016-01-06 15:10:15 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:10:15 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:10:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:10:15 --> URI Class Initialized
DEBUG - 2016-01-06 15:10:16 --> Router Class Initialized
DEBUG - 2016-01-06 15:10:16 --> Output Class Initialized
DEBUG - 2016-01-06 15:10:16 --> Security Class Initialized
DEBUG - 2016-01-06 15:10:16 --> Input Class Initialized
DEBUG - 2016-01-06 15:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 15:10:16 --> Language Class Initialized
DEBUG - 2016-01-06 15:10:17 --> Language Class Initialized
DEBUG - 2016-01-06 15:10:17 --> Config Class Initialized
DEBUG - 2016-01-06 15:10:17 --> Loader Class Initialized
DEBUG - 2016-01-06 15:10:17 --> Helper loaded: url_helper
DEBUG - 2016-01-06 15:10:17 --> Helper loaded: form_helper
DEBUG - 2016-01-06 15:10:18 --> Database Driver Class Initialized
DEBUG - 2016-01-06 15:10:20 --> Session Class Initialized
DEBUG - 2016-01-06 15:10:20 --> Helper loaded: string_helper
DEBUG - 2016-01-06 15:10:20 --> Session routines successfully run
DEBUG - 2016-01-06 15:10:20 --> Form Validation Class Initialized
DEBUG - 2016-01-06 15:10:21 --> Pagination Class Initialized
DEBUG - 2016-01-06 15:10:21 --> Encrypt Class Initialized
DEBUG - 2016-01-06 15:10:21 --> Email Class Initialized
DEBUG - 2016-01-06 15:10:21 --> Controller Class Initialized
DEBUG - 2016-01-06 15:10:21 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 15:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 15:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 15:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 15:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 15:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 15:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 15:10:21 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 15:10:22 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 15:10:22 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:22 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 15:10:22 --> Model Class Initialized
DEBUG - 2016-01-06 15:10:22 --> Image Lib Class Initialized
DEBUG - 2016-01-06 15:10:22 --> DB Transaction Failure
ERROR - 2016-01-06 15:10:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' property.property_id = rental_unit.property_id' at line 3
DEBUG - 2016-01-06 15:10:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-06 15:11:37 --> Config Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:11:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:11:37 --> URI Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Router Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Output Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Security Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Input Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 15:11:37 --> Language Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Language Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Config Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Loader Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Helper loaded: url_helper
DEBUG - 2016-01-06 15:11:37 --> Helper loaded: form_helper
DEBUG - 2016-01-06 15:11:37 --> Database Driver Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Session Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Helper loaded: string_helper
DEBUG - 2016-01-06 15:11:37 --> Session routines successfully run
DEBUG - 2016-01-06 15:11:37 --> Form Validation Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Pagination Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Encrypt Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Email Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Controller Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 15:11:37 --> Model Class Initialized
DEBUG - 2016-01-06 15:11:37 --> Image Lib Class Initialized
DEBUG - 2016-01-06 15:11:38 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 15:11:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 15:11:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 15:11:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 15:11:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 15:11:39 --> Final output sent to browser
DEBUG - 2016-01-06 15:11:39 --> Total execution time: 1.6737
DEBUG - 2016-01-06 15:13:35 --> Config Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:13:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:13:35 --> URI Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Router Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Output Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Security Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Input Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 15:13:35 --> Language Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Language Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Config Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Loader Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Helper loaded: url_helper
DEBUG - 2016-01-06 15:13:35 --> Helper loaded: form_helper
DEBUG - 2016-01-06 15:13:35 --> Database Driver Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Session Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Helper loaded: string_helper
DEBUG - 2016-01-06 15:13:35 --> Session routines successfully run
DEBUG - 2016-01-06 15:13:35 --> Form Validation Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Pagination Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Encrypt Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Email Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Controller Class Initialized
DEBUG - 2016-01-06 15:13:35 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 15:13:35 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 15:13:35 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 15:13:35 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 15:13:35 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 15:13:35 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 15:13:35 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 15:13:35 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 15:13:35 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 15:13:36 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 15:13:36 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:36 --> Image Lib Class Initialized
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 15:13:36 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 15:13:36 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 15:13:36 --> Model Class Initialized
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 15:13:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 15:13:36 --> Final output sent to browser
DEBUG - 2016-01-06 15:13:36 --> Total execution time: 1.4810
DEBUG - 2016-01-06 15:14:03 --> Config Class Initialized
DEBUG - 2016-01-06 15:14:03 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:14:03 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:14:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:14:03 --> URI Class Initialized
DEBUG - 2016-01-06 15:14:03 --> Router Class Initialized
ERROR - 2016-01-06 15:14:03 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 15:16:55 --> Config Class Initialized
DEBUG - 2016-01-06 15:16:55 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:16:55 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:16:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:16:55 --> URI Class Initialized
DEBUG - 2016-01-06 15:16:55 --> Router Class Initialized
DEBUG - 2016-01-06 15:16:56 --> Output Class Initialized
DEBUG - 2016-01-06 15:16:56 --> Security Class Initialized
DEBUG - 2016-01-06 15:16:56 --> Input Class Initialized
DEBUG - 2016-01-06 15:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 15:16:56 --> Language Class Initialized
DEBUG - 2016-01-06 15:16:56 --> Language Class Initialized
DEBUG - 2016-01-06 15:16:56 --> Config Class Initialized
DEBUG - 2016-01-06 15:16:56 --> Loader Class Initialized
DEBUG - 2016-01-06 15:16:56 --> Helper loaded: url_helper
DEBUG - 2016-01-06 15:16:56 --> Helper loaded: form_helper
DEBUG - 2016-01-06 15:16:56 --> Database Driver Class Initialized
DEBUG - 2016-01-06 15:16:58 --> Session Class Initialized
DEBUG - 2016-01-06 15:16:58 --> Helper loaded: string_helper
DEBUG - 2016-01-06 15:16:58 --> Session routines successfully run
DEBUG - 2016-01-06 15:16:58 --> Form Validation Class Initialized
DEBUG - 2016-01-06 15:16:58 --> Pagination Class Initialized
DEBUG - 2016-01-06 15:16:58 --> Encrypt Class Initialized
DEBUG - 2016-01-06 15:16:58 --> Email Class Initialized
DEBUG - 2016-01-06 15:16:58 --> Controller Class Initialized
DEBUG - 2016-01-06 15:16:58 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> Image Lib Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 15:16:58 --> Model Class Initialized
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 15:16:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 15:16:58 --> Final output sent to browser
DEBUG - 2016-01-06 15:16:58 --> Total execution time: 2.9149
DEBUG - 2016-01-06 15:31:52 --> Config Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:31:52 --> URI Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Router Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Output Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Security Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Input Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 15:31:52 --> Language Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Language Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Config Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Loader Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Helper loaded: url_helper
DEBUG - 2016-01-06 15:31:52 --> Helper loaded: form_helper
DEBUG - 2016-01-06 15:31:52 --> Database Driver Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Session Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Helper loaded: string_helper
DEBUG - 2016-01-06 15:31:52 --> Session routines successfully run
DEBUG - 2016-01-06 15:31:52 --> Form Validation Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Pagination Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Encrypt Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Email Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Controller Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 15:31:52 --> Model Class Initialized
DEBUG - 2016-01-06 15:31:52 --> Image Lib Class Initialized
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 15:31:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 15:31:52 --> Final output sent to browser
DEBUG - 2016-01-06 15:31:52 --> Total execution time: 0.3666
DEBUG - 2016-01-06 15:34:04 --> Config Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:34:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:34:04 --> URI Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Router Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Output Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Security Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Input Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 15:34:04 --> Language Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Language Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Config Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Loader Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Helper loaded: url_helper
DEBUG - 2016-01-06 15:34:04 --> Helper loaded: form_helper
DEBUG - 2016-01-06 15:34:04 --> Database Driver Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Session Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Helper loaded: string_helper
DEBUG - 2016-01-06 15:34:04 --> Session routines successfully run
DEBUG - 2016-01-06 15:34:04 --> Form Validation Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Pagination Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Encrypt Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Email Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Controller Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 15:34:04 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:04 --> Image Lib Class Initialized
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 15:34:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 15:34:04 --> Final output sent to browser
DEBUG - 2016-01-06 15:34:04 --> Total execution time: 0.2900
DEBUG - 2016-01-06 15:34:47 --> Config Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:34:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:34:47 --> URI Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Router Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Output Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Security Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Input Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 15:34:47 --> Language Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Language Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Config Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Loader Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Helper loaded: url_helper
DEBUG - 2016-01-06 15:34:47 --> Helper loaded: form_helper
DEBUG - 2016-01-06 15:34:47 --> Database Driver Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Session Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Helper loaded: string_helper
DEBUG - 2016-01-06 15:34:47 --> Session routines successfully run
DEBUG - 2016-01-06 15:34:47 --> Form Validation Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Pagination Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Encrypt Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Email Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Controller Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 15:34:47 --> Model Class Initialized
DEBUG - 2016-01-06 15:34:47 --> Image Lib Class Initialized
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 15:34:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 15:34:47 --> Final output sent to browser
DEBUG - 2016-01-06 15:34:47 --> Total execution time: 0.2872
DEBUG - 2016-01-06 15:58:52 --> Config Class Initialized
DEBUG - 2016-01-06 15:58:52 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:58:52 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:58:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:58:52 --> URI Class Initialized
DEBUG - 2016-01-06 15:58:52 --> Router Class Initialized
DEBUG - 2016-01-06 15:58:52 --> Output Class Initialized
DEBUG - 2016-01-06 15:58:52 --> Security Class Initialized
DEBUG - 2016-01-06 15:58:53 --> Input Class Initialized
DEBUG - 2016-01-06 15:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 15:58:53 --> Language Class Initialized
DEBUG - 2016-01-06 15:58:53 --> Language Class Initialized
DEBUG - 2016-01-06 15:58:53 --> Config Class Initialized
DEBUG - 2016-01-06 15:58:53 --> Loader Class Initialized
DEBUG - 2016-01-06 15:58:53 --> Helper loaded: url_helper
DEBUG - 2016-01-06 15:58:53 --> Helper loaded: form_helper
DEBUG - 2016-01-06 15:58:53 --> Database Driver Class Initialized
DEBUG - 2016-01-06 15:58:54 --> Session Class Initialized
DEBUG - 2016-01-06 15:58:54 --> Helper loaded: string_helper
DEBUG - 2016-01-06 15:58:54 --> Session routines successfully run
DEBUG - 2016-01-06 15:58:54 --> Form Validation Class Initialized
DEBUG - 2016-01-06 15:58:54 --> Pagination Class Initialized
DEBUG - 2016-01-06 15:58:55 --> Encrypt Class Initialized
DEBUG - 2016-01-06 15:58:55 --> Email Class Initialized
DEBUG - 2016-01-06 15:58:55 --> Controller Class Initialized
DEBUG - 2016-01-06 15:58:55 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 15:58:55 --> Model Class Initialized
DEBUG - 2016-01-06 15:58:55 --> Image Lib Class Initialized
DEBUG - 2016-01-06 15:58:56 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 15:58:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 15:58:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 15:58:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 15:58:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 15:58:56 --> Final output sent to browser
DEBUG - 2016-01-06 15:58:56 --> Total execution time: 4.1744
DEBUG - 2016-01-06 15:59:13 --> Config Class Initialized
DEBUG - 2016-01-06 15:59:13 --> Hooks Class Initialized
DEBUG - 2016-01-06 15:59:13 --> Utf8 Class Initialized
DEBUG - 2016-01-06 15:59:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 15:59:13 --> URI Class Initialized
DEBUG - 2016-01-06 15:59:13 --> Router Class Initialized
ERROR - 2016-01-06 15:59:13 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 16:01:34 --> Config Class Initialized
DEBUG - 2016-01-06 16:01:34 --> Hooks Class Initialized
DEBUG - 2016-01-06 16:01:34 --> Utf8 Class Initialized
DEBUG - 2016-01-06 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 16:01:34 --> URI Class Initialized
DEBUG - 2016-01-06 16:01:34 --> Router Class Initialized
ERROR - 2016-01-06 16:01:35 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 16:01:49 --> Config Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Hooks Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Utf8 Class Initialized
DEBUG - 2016-01-06 16:01:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 16:01:49 --> URI Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Router Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Output Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Security Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Input Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 16:01:49 --> Language Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Language Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Config Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Loader Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Helper loaded: url_helper
DEBUG - 2016-01-06 16:01:49 --> Helper loaded: form_helper
DEBUG - 2016-01-06 16:01:49 --> Database Driver Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Session Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Helper loaded: string_helper
DEBUG - 2016-01-06 16:01:49 --> Session routines successfully run
DEBUG - 2016-01-06 16:01:49 --> Form Validation Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Pagination Class Initialized
DEBUG - 2016-01-06 16:01:49 --> Encrypt Class Initialized
DEBUG - 2016-01-06 16:01:50 --> Email Class Initialized
DEBUG - 2016-01-06 16:01:50 --> Controller Class Initialized
DEBUG - 2016-01-06 16:01:50 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 16:01:50 --> Model Class Initialized
DEBUG - 2016-01-06 16:01:50 --> Image Lib Class Initialized
DEBUG - 2016-01-06 16:01:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 16:01:50 --> XSS Filtering completed
DEBUG - 2016-01-06 16:01:50 --> XSS Filtering completed
DEBUG - 2016-01-06 16:01:50 --> DB Transaction Failure
ERROR - 2016-01-06 16:01:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND rental_unit_name = 'EX-A'' at line 3
DEBUG - 2016-01-06 16:01:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-06 16:02:32 --> Config Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Hooks Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Utf8 Class Initialized
DEBUG - 2016-01-06 16:02:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 16:02:32 --> URI Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Router Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Output Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Security Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Input Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 16:02:32 --> Language Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Language Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Config Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Loader Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Helper loaded: url_helper
DEBUG - 2016-01-06 16:02:32 --> Helper loaded: form_helper
DEBUG - 2016-01-06 16:02:32 --> Database Driver Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Session Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Helper loaded: string_helper
DEBUG - 2016-01-06 16:02:32 --> Session routines successfully run
DEBUG - 2016-01-06 16:02:32 --> Form Validation Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Pagination Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Encrypt Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Email Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Controller Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 16:02:32 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:32 --> Image Lib Class Initialized
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 16:02:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 16:02:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 16:02:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 16:02:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 16:02:33 --> Final output sent to browser
DEBUG - 2016-01-06 16:02:33 --> Total execution time: 0.3708
DEBUG - 2016-01-06 16:02:44 --> Config Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Hooks Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Utf8 Class Initialized
DEBUG - 2016-01-06 16:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 16:02:44 --> URI Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Router Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Output Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Security Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Input Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 16:02:44 --> Language Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Language Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Config Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Loader Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Helper loaded: url_helper
DEBUG - 2016-01-06 16:02:44 --> Helper loaded: form_helper
DEBUG - 2016-01-06 16:02:44 --> Database Driver Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Session Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Helper loaded: string_helper
DEBUG - 2016-01-06 16:02:44 --> Session routines successfully run
DEBUG - 2016-01-06 16:02:44 --> Form Validation Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Pagination Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Encrypt Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Email Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Controller Class Initialized
DEBUG - 2016-01-06 16:02:44 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 16:02:44 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 16:02:44 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 16:02:44 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 16:02:44 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 16:02:44 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 16:02:44 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 16:02:44 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 16:02:44 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Image Lib Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 16:02:45 --> XSS Filtering completed
DEBUG - 2016-01-06 16:02:45 --> XSS Filtering completed
DEBUG - 2016-01-06 16:02:45 --> Config Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Hooks Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Utf8 Class Initialized
DEBUG - 2016-01-06 16:02:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 16:02:45 --> URI Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Router Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Output Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Security Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Input Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 16:02:45 --> Language Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Language Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Config Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Loader Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Helper loaded: url_helper
DEBUG - 2016-01-06 16:02:45 --> Helper loaded: form_helper
DEBUG - 2016-01-06 16:02:45 --> Database Driver Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Session Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Helper loaded: string_helper
DEBUG - 2016-01-06 16:02:45 --> Session routines successfully run
DEBUG - 2016-01-06 16:02:45 --> Form Validation Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Pagination Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Encrypt Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Email Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Controller Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 16:02:45 --> Model Class Initialized
DEBUG - 2016-01-06 16:02:45 --> Image Lib Class Initialized
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 16:02:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 16:02:45 --> Final output sent to browser
DEBUG - 2016-01-06 16:02:45 --> Total execution time: 0.2571
DEBUG - 2016-01-06 16:04:04 --> Config Class Initialized
DEBUG - 2016-01-06 16:04:04 --> Hooks Class Initialized
DEBUG - 2016-01-06 16:04:04 --> Utf8 Class Initialized
DEBUG - 2016-01-06 16:04:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 16:04:04 --> URI Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Router Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Output Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Security Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Input Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 16:04:05 --> Language Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Language Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Config Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Loader Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Helper loaded: url_helper
DEBUG - 2016-01-06 16:04:05 --> Helper loaded: form_helper
DEBUG - 2016-01-06 16:04:05 --> Database Driver Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Session Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Helper loaded: string_helper
DEBUG - 2016-01-06 16:04:05 --> Session routines successfully run
DEBUG - 2016-01-06 16:04:05 --> Form Validation Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Pagination Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Encrypt Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Email Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Controller Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> Image Lib Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 16:04:05 --> Model Class Initialized
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 16:04:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 16:04:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 16:04:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 16:04:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 16:04:06 --> Final output sent to browser
DEBUG - 2016-01-06 16:04:06 --> Total execution time: 1.0491
DEBUG - 2016-01-06 16:12:22 --> Config Class Initialized
DEBUG - 2016-01-06 16:12:22 --> Hooks Class Initialized
DEBUG - 2016-01-06 16:12:22 --> Utf8 Class Initialized
DEBUG - 2016-01-06 16:12:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 16:12:22 --> URI Class Initialized
DEBUG - 2016-01-06 16:12:22 --> Router Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Output Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Security Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Input Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 16:12:23 --> Language Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Language Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Config Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Loader Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Helper loaded: url_helper
DEBUG - 2016-01-06 16:12:23 --> Helper loaded: form_helper
DEBUG - 2016-01-06 16:12:23 --> Database Driver Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Session Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Helper loaded: string_helper
DEBUG - 2016-01-06 16:12:23 --> Session routines successfully run
DEBUG - 2016-01-06 16:12:23 --> Form Validation Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Pagination Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Encrypt Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Email Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Controller Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> Image Lib Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 16:12:23 --> Model Class Initialized
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 16:12:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 16:12:23 --> Final output sent to browser
DEBUG - 2016-01-06 16:12:23 --> Total execution time: 0.9926
DEBUG - 2016-01-06 16:15:12 --> Config Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Hooks Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Utf8 Class Initialized
DEBUG - 2016-01-06 16:15:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 16:15:12 --> URI Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Router Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Output Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Security Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Input Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 16:15:12 --> Language Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Language Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Config Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Loader Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Helper loaded: url_helper
DEBUG - 2016-01-06 16:15:12 --> Helper loaded: form_helper
DEBUG - 2016-01-06 16:15:12 --> Database Driver Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Session Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Helper loaded: string_helper
DEBUG - 2016-01-06 16:15:12 --> Session routines successfully run
DEBUG - 2016-01-06 16:15:12 --> Form Validation Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Pagination Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Encrypt Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Email Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Controller Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> Image Lib Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 16:15:12 --> Model Class Initialized
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 16:15:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 16:15:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 16:15:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 16:15:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 16:15:13 --> Final output sent to browser
DEBUG - 2016-01-06 16:15:13 --> Total execution time: 0.5195
DEBUG - 2016-01-06 16:19:58 --> Config Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Hooks Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Utf8 Class Initialized
DEBUG - 2016-01-06 16:19:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 16:19:58 --> URI Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Router Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Output Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Security Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Input Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 16:19:58 --> Language Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Language Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Config Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Loader Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Helper loaded: url_helper
DEBUG - 2016-01-06 16:19:58 --> Helper loaded: form_helper
DEBUG - 2016-01-06 16:19:58 --> Database Driver Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Session Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Helper loaded: string_helper
DEBUG - 2016-01-06 16:19:58 --> Session routines successfully run
DEBUG - 2016-01-06 16:19:58 --> Form Validation Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Pagination Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Encrypt Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Email Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Controller Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> Image Lib Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 16:19:58 --> Model Class Initialized
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 16:19:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 16:19:58 --> Final output sent to browser
DEBUG - 2016-01-06 16:19:58 --> Total execution time: 0.3998
DEBUG - 2016-01-06 17:10:38 --> Config Class Initialized
DEBUG - 2016-01-06 17:10:38 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:10:38 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:10:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:10:39 --> URI Class Initialized
DEBUG - 2016-01-06 17:10:39 --> Router Class Initialized
DEBUG - 2016-01-06 17:10:40 --> Output Class Initialized
DEBUG - 2016-01-06 17:10:40 --> Security Class Initialized
DEBUG - 2016-01-06 17:10:40 --> Input Class Initialized
DEBUG - 2016-01-06 17:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:10:40 --> Language Class Initialized
DEBUG - 2016-01-06 17:10:40 --> Language Class Initialized
DEBUG - 2016-01-06 17:10:40 --> Config Class Initialized
DEBUG - 2016-01-06 17:10:40 --> Loader Class Initialized
DEBUG - 2016-01-06 17:10:40 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:10:40 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:10:41 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:10:41 --> Session Class Initialized
DEBUG - 2016-01-06 17:10:41 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:10:41 --> Session routines successfully run
DEBUG - 2016-01-06 17:10:42 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:10:42 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:10:42 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:10:42 --> Email Class Initialized
DEBUG - 2016-01-06 17:10:42 --> Controller Class Initialized
DEBUG - 2016-01-06 17:10:42 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:10:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:42 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:10:45 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 17:10:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:10:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:10:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:10:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:10:46 --> Final output sent to browser
DEBUG - 2016-01-06 17:10:46 --> Total execution time: 9.1854
DEBUG - 2016-01-06 17:10:52 --> Config Class Initialized
DEBUG - 2016-01-06 17:10:52 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:10:52 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:10:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:10:52 --> URI Class Initialized
DEBUG - 2016-01-06 17:10:52 --> Router Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Output Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Security Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Input Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:10:53 --> Language Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Language Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Config Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Loader Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:10:53 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:10:53 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Session Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:10:53 --> Session routines successfully run
DEBUG - 2016-01-06 17:10:53 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Email Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Controller Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:10:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:10:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:10:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:10:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:10:54 --> Final output sent to browser
DEBUG - 2016-01-06 17:10:54 --> Total execution time: 1.2780
DEBUG - 2016-01-06 17:11:12 --> Config Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:11:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:11:12 --> URI Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Router Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Output Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Security Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Input Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:11:12 --> Language Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Language Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Config Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Loader Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:11:12 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:11:12 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Session Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:11:12 --> Session routines successfully run
DEBUG - 2016-01-06 17:11:12 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Email Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Controller Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:11:12 --> Model Class Initialized
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:11:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:11:12 --> Final output sent to browser
DEBUG - 2016-01-06 17:11:12 --> Total execution time: 0.2878
DEBUG - 2016-01-06 17:12:01 --> Config Class Initialized
DEBUG - 2016-01-06 17:12:01 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:12:01 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:12:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:12:01 --> URI Class Initialized
DEBUG - 2016-01-06 17:12:01 --> Router Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Output Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Security Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Input Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:12:02 --> Language Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Language Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Config Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Loader Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:12:02 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:12:02 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Session Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:12:02 --> Session routines successfully run
DEBUG - 2016-01-06 17:12:02 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Email Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Controller Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:02 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:12:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:03 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:12:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:12:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:12:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:12:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:12:03 --> Final output sent to browser
DEBUG - 2016-01-06 17:12:03 --> Total execution time: 1.2872
DEBUG - 2016-01-06 17:12:29 --> Config Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:12:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:12:29 --> URI Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Router Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Output Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Security Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Input Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:12:29 --> Language Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Language Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Config Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Loader Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:12:29 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:12:29 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Session Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:12:29 --> Session routines successfully run
DEBUG - 2016-01-06 17:12:29 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Email Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Controller Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:29 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:12:29 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Config Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:12:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:12:51 --> URI Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Router Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Output Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Security Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Input Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:12:51 --> Language Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Language Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Config Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Loader Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:12:51 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:12:51 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Session Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:12:51 --> Session routines successfully run
DEBUG - 2016-01-06 17:12:51 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Email Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Controller Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:12:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:12:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:12:51 --> Final output sent to browser
DEBUG - 2016-01-06 17:12:51 --> Total execution time: 0.3731
DEBUG - 2016-01-06 17:15:09 --> Config Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:15:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:15:09 --> URI Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Router Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Output Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Security Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Input Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:15:09 --> Language Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Language Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Config Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Loader Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:15:09 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:15:09 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Session Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:15:09 --> Session routines successfully run
DEBUG - 2016-01-06 17:15:09 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Email Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Controller Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:15:09 --> Model Class Initialized
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:15:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:15:09 --> Final output sent to browser
DEBUG - 2016-01-06 17:15:09 --> Total execution time: 0.2843
DEBUG - 2016-01-06 17:16:25 --> Config Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:16:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:16:25 --> URI Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Router Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Output Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Security Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Input Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:16:25 --> Language Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Language Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Config Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Loader Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:16:25 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:16:25 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Session Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:16:25 --> Session routines successfully run
DEBUG - 2016-01-06 17:16:25 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Email Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Controller Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:16:25 --> Model Class Initialized
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:16:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:16:25 --> Final output sent to browser
DEBUG - 2016-01-06 17:16:25 --> Total execution time: 0.5037
DEBUG - 2016-01-06 17:20:24 --> Config Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:20:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:20:24 --> URI Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Router Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Output Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Security Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Input Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:20:24 --> Language Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Language Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Config Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Loader Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:20:24 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:20:24 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Session Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:20:24 --> Session routines successfully run
DEBUG - 2016-01-06 17:20:24 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Email Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Controller Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:20:24 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:20:25 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:20:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:20:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:20:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:20:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:20:25 --> Final output sent to browser
DEBUG - 2016-01-06 17:20:25 --> Total execution time: 0.6912
DEBUG - 2016-01-06 17:20:42 --> Config Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:20:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:20:42 --> URI Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Router Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Output Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Security Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Input Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:20:42 --> Language Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Language Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Config Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Loader Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:20:42 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:20:42 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Session Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:20:42 --> Session routines successfully run
DEBUG - 2016-01-06 17:20:42 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Email Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Controller Class Initialized
DEBUG - 2016-01-06 17:20:42 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:20:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:20:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:20:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:20:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:20:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:20:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:20:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:20:42 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:20:43 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:20:43 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:43 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:20:43 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:20:43 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:20:43 --> Model Class Initialized
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:20:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:20:43 --> Final output sent to browser
DEBUG - 2016-01-06 17:20:43 --> Total execution time: 0.2812
DEBUG - 2016-01-06 17:21:06 --> Config Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:21:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:21:06 --> URI Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Router Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Output Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Security Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Input Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:21:06 --> Language Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Language Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Config Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Loader Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:21:06 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:21:06 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Session Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:21:06 --> Session routines successfully run
DEBUG - 2016-01-06 17:21:06 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Email Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Controller Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:21:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:21:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:21:06 --> Final output sent to browser
DEBUG - 2016-01-06 17:21:06 --> Total execution time: 0.2766
DEBUG - 2016-01-06 17:21:58 --> Config Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:21:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:21:58 --> URI Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Router Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Output Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Security Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Input Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:21:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Config Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Loader Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:21:58 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:21:58 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Session Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:21:58 --> Session routines successfully run
DEBUG - 2016-01-06 17:21:58 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Email Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Controller Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:21:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:21:58 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:21:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:21:58 --> Final output sent to browser
DEBUG - 2016-01-06 17:21:58 --> Total execution time: 0.3151
DEBUG - 2016-01-06 17:22:01 --> Config Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:22:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:22:01 --> URI Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Router Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Output Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Security Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Input Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:22:01 --> Language Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Language Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Config Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Loader Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:22:01 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:22:01 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Session Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:22:01 --> Session routines successfully run
DEBUG - 2016-01-06 17:22:01 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Email Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Controller Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:22:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:22:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:22:01 --> Final output sent to browser
DEBUG - 2016-01-06 17:22:01 --> Total execution time: 0.2873
DEBUG - 2016-01-06 17:22:57 --> Config Class Initialized
DEBUG - 2016-01-06 17:22:57 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:22:57 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:22:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:22:57 --> URI Class Initialized
DEBUG - 2016-01-06 17:22:57 --> Router Class Initialized
DEBUG - 2016-01-06 17:22:57 --> Output Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Security Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Input Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:22:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Config Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Loader Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:22:58 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:22:58 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Session Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:22:58 --> Session routines successfully run
DEBUG - 2016-01-06 17:22:58 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Email Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Controller Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:22:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:22:58 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:22:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:22:58 --> Final output sent to browser
DEBUG - 2016-01-06 17:22:58 --> Total execution time: 0.2648
DEBUG - 2016-01-06 17:23:06 --> Config Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:23:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:23:06 --> URI Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Router Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Output Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Security Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Input Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:23:06 --> Language Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Language Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Config Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Loader Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:23:06 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:23:06 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Session Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:23:06 --> Session routines successfully run
DEBUG - 2016-01-06 17:23:06 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Email Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Controller Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:23:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:23:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:23:06 --> Final output sent to browser
DEBUG - 2016-01-06 17:23:06 --> Total execution time: 0.2792
DEBUG - 2016-01-06 17:26:22 --> Config Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:26:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:26:22 --> URI Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Router Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Output Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Security Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Input Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:26:22 --> Language Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Language Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Config Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Loader Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:26:22 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:26:22 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Session Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:26:22 --> Session routines successfully run
DEBUG - 2016-01-06 17:26:22 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Email Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Controller Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:26:22 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:22 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:26:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:26:22 --> Final output sent to browser
DEBUG - 2016-01-06 17:26:22 --> Total execution time: 0.2602
DEBUG - 2016-01-06 17:26:38 --> Config Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:26:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:26:38 --> URI Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Router Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Output Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Security Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Input Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:26:38 --> Language Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Language Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Config Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Loader Class Initialized
DEBUG - 2016-01-06 17:26:38 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:26:38 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:26:39 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:26:39 --> Session Class Initialized
DEBUG - 2016-01-06 17:26:39 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:26:39 --> Session routines successfully run
DEBUG - 2016-01-06 17:26:39 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:26:39 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:26:39 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:26:39 --> Email Class Initialized
DEBUG - 2016-01-06 17:26:39 --> Controller Class Initialized
DEBUG - 2016-01-06 17:26:39 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:26:39 --> Model Class Initialized
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:26:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:26:39 --> Final output sent to browser
DEBUG - 2016-01-06 17:26:39 --> Total execution time: 0.2876
DEBUG - 2016-01-06 17:27:53 --> Config Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:27:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:27:53 --> URI Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Router Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Output Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Security Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Input Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:27:53 --> Language Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Language Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Config Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Loader Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:27:53 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:27:53 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Session Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:27:53 --> Session routines successfully run
DEBUG - 2016-01-06 17:27:53 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Email Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Controller Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:27:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:27:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:27:53 --> Final output sent to browser
DEBUG - 2016-01-06 17:27:53 --> Total execution time: 0.3352
DEBUG - 2016-01-06 17:27:58 --> Config Class Initialized
DEBUG - 2016-01-06 17:27:58 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:27:58 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:27:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:27:58 --> URI Class Initialized
DEBUG - 2016-01-06 17:27:58 --> Router Class Initialized
DEBUG - 2016-01-06 17:27:58 --> Output Class Initialized
DEBUG - 2016-01-06 17:27:58 --> Security Class Initialized
DEBUG - 2016-01-06 17:27:58 --> Input Class Initialized
DEBUG - 2016-01-06 17:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:27:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:27:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:27:58 --> Config Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Loader Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:27:59 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:27:59 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Session Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:27:59 --> Session routines successfully run
DEBUG - 2016-01-06 17:27:59 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Email Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Controller Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:27:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:27:59 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:27:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:27:59 --> Final output sent to browser
DEBUG - 2016-01-06 17:27:59 --> Total execution time: 0.3218
DEBUG - 2016-01-06 17:28:02 --> Config Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:28:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:28:02 --> URI Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Router Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Output Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Security Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Input Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:28:02 --> Language Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Language Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Config Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Loader Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:28:02 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:28:02 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Session Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:28:02 --> Session routines successfully run
DEBUG - 2016-01-06 17:28:02 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Email Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Controller Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:28:02 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:28:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:28:02 --> Final output sent to browser
DEBUG - 2016-01-06 17:28:02 --> Total execution time: 0.3400
DEBUG - 2016-01-06 17:28:05 --> Config Class Initialized
DEBUG - 2016-01-06 17:28:05 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:28:05 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:28:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:28:05 --> URI Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Router Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Output Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Security Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Input Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:28:06 --> Language Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Language Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Config Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Loader Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:28:06 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:28:06 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Session Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:28:06 --> Session routines successfully run
DEBUG - 2016-01-06 17:28:06 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Email Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Controller Class Initialized
DEBUG - 2016-01-06 17:28:06 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 17:28:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:28:06 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:28:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:28:07 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:28:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:28:07 --> Final output sent to browser
DEBUG - 2016-01-06 17:28:07 --> Total execution time: 1.1271
DEBUG - 2016-01-06 17:44:48 --> Config Class Initialized
DEBUG - 2016-01-06 17:44:48 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:44:48 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:44:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:44:49 --> URI Class Initialized
DEBUG - 2016-01-06 17:44:49 --> Router Class Initialized
DEBUG - 2016-01-06 17:44:49 --> Output Class Initialized
DEBUG - 2016-01-06 17:44:49 --> Security Class Initialized
DEBUG - 2016-01-06 17:44:49 --> Input Class Initialized
DEBUG - 2016-01-06 17:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:44:49 --> Language Class Initialized
DEBUG - 2016-01-06 17:44:49 --> Language Class Initialized
DEBUG - 2016-01-06 17:44:49 --> Config Class Initialized
DEBUG - 2016-01-06 17:44:49 --> Loader Class Initialized
DEBUG - 2016-01-06 17:44:49 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:44:50 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:44:50 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:44:50 --> Session Class Initialized
DEBUG - 2016-01-06 17:44:50 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:44:50 --> Session routines successfully run
DEBUG - 2016-01-06 17:44:50 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:44:50 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:44:50 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:44:50 --> Email Class Initialized
DEBUG - 2016-01-06 17:44:50 --> Controller Class Initialized
DEBUG - 2016-01-06 17:44:50 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:44:51 --> Config Class Initialized
DEBUG - 2016-01-06 17:44:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:51 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:44:51 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:44:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:44:51 --> URI Class Initialized
DEBUG - 2016-01-06 17:44:51 --> Router Class Initialized
DEBUG - 2016-01-06 17:44:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:44:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:44:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:44:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:44:51 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:44:52 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:44:52 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:44:52 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:44:52 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:52 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:44:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:44:52 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:44:52 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:44:52 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:52 --> Output Class Initialized
DEBUG - 2016-01-06 17:44:52 --> Security Class Initialized
DEBUG - 2016-01-06 17:44:52 --> Input Class Initialized
DEBUG - 2016-01-06 17:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:44:53 --> Language Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:44:53 --> Language Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Config Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Loader Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:44:53 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:44:53 --> Final output sent to browser
DEBUG - 2016-01-06 17:44:53 --> Total execution time: 4.9237
DEBUG - 2016-01-06 17:44:53 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:44:53 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Session Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:44:53 --> Session routines successfully run
DEBUG - 2016-01-06 17:44:53 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Email Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Controller Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:44:53 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:44:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:44:53 --> Final output sent to browser
DEBUG - 2016-01-06 17:44:53 --> Total execution time: 2.3859
DEBUG - 2016-01-06 17:44:58 --> Config Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:44:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:44:58 --> URI Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Router Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Output Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Security Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Input Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:44:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Config Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Loader Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:44:58 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:44:58 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Session Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:44:58 --> Session routines successfully run
DEBUG - 2016-01-06 17:44:58 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Email Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Controller Class Initialized
DEBUG - 2016-01-06 17:44:58 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 17:44:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:44:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:44:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:44:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:44:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:44:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:44:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:44:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:44:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:44:59 --> Model Class Initialized
DEBUG - 2016-01-06 17:44:59 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:44:59 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 17:44:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:44:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:44:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:44:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:44:59 --> Final output sent to browser
DEBUG - 2016-01-06 17:44:59 --> Total execution time: 0.3399
DEBUG - 2016-01-06 17:45:01 --> Config Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:45:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:45:01 --> URI Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Router Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Output Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Security Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Input Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:45:01 --> Language Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Language Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Config Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Loader Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:45:01 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:45:01 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Session Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:45:01 --> Session routines successfully run
DEBUG - 2016-01-06 17:45:01 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Email Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Controller Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:45:01 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:45:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:45:01 --> Final output sent to browser
DEBUG - 2016-01-06 17:45:01 --> Total execution time: 0.3069
DEBUG - 2016-01-06 17:45:04 --> Config Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:45:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:45:04 --> URI Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Router Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Output Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Security Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Input Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:45:04 --> Language Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Language Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Config Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Loader Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:45:04 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:45:04 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Session Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:45:04 --> Session routines successfully run
DEBUG - 2016-01-06 17:45:04 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Email Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Controller Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:45:04 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:04 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:45:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:45:04 --> Final output sent to browser
DEBUG - 2016-01-06 17:45:04 --> Total execution time: 0.3549
DEBUG - 2016-01-06 17:45:07 --> Config Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:45:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:45:07 --> URI Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Router Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Output Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Security Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Input Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:45:07 --> Language Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Language Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Config Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Loader Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:45:07 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:45:07 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Session Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:45:07 --> Session routines successfully run
DEBUG - 2016-01-06 17:45:07 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Email Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Controller Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:45:07 --> Model Class Initialized
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:45:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:45:07 --> Final output sent to browser
DEBUG - 2016-01-06 17:45:07 --> Total execution time: 0.3238
DEBUG - 2016-01-06 17:47:49 --> Config Class Initialized
DEBUG - 2016-01-06 17:47:49 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:47:49 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:47:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:47:49 --> URI Class Initialized
DEBUG - 2016-01-06 17:47:49 --> Router Class Initialized
ERROR - 2016-01-06 17:47:49 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 17:49:18 --> Config Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:49:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:49:18 --> URI Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Router Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Output Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Security Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Input Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:49:18 --> Language Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Language Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Config Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Loader Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:49:18 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:49:18 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Session Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:49:18 --> Session routines successfully run
DEBUG - 2016-01-06 17:49:18 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Email Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Controller Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:49:18 --> Model Class Initialized
DEBUG - 2016-01-06 17:49:18 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:49:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:49:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:49:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:49:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:49:19 --> Final output sent to browser
DEBUG - 2016-01-06 17:49:19 --> Total execution time: 0.9303
DEBUG - 2016-01-06 17:51:58 --> Config Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:51:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:51:58 --> URI Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Router Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Output Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Security Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Input Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:51:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Language Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Config Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Loader Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:51:58 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:51:58 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Session Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:51:58 --> Session routines successfully run
DEBUG - 2016-01-06 17:51:58 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Email Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Controller Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:51:58 --> Model Class Initialized
DEBUG - 2016-01-06 17:51:58 --> DB Transaction Failure
ERROR - 2016-01-06 17:51:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY `leases`.`lease_id` DESC' at line 4
DEBUG - 2016-01-06 17:51:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-06 17:52:48 --> Config Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:52:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:52:48 --> URI Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Router Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Output Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Security Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Input Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:52:48 --> Language Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Language Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Config Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Loader Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:52:48 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:52:48 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Session Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:52:48 --> Session routines successfully run
DEBUG - 2016-01-06 17:52:48 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Email Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Controller Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:52:48 --> Model Class Initialized
DEBUG - 2016-01-06 17:52:48 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:52:49 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:52:49 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:52:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:52:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:52:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:52:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:52:49 --> Final output sent to browser
DEBUG - 2016-01-06 17:52:49 --> Total execution time: 0.6577
DEBUG - 2016-01-06 17:53:31 --> Config Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:53:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:53:31 --> URI Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Router Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Output Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Security Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Input Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:53:31 --> Language Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Language Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Config Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Loader Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:53:31 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:53:31 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Session Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:53:31 --> Session routines successfully run
DEBUG - 2016-01-06 17:53:31 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Email Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Controller Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:53:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:53:31 --> Final output sent to browser
DEBUG - 2016-01-06 17:53:31 --> Total execution time: 0.3662
DEBUG - 2016-01-06 17:55:53 --> Config Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Hooks Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Utf8 Class Initialized
DEBUG - 2016-01-06 17:55:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 17:55:53 --> URI Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Router Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Output Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Security Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Input Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 17:55:53 --> Language Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Language Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Config Class Initialized
DEBUG - 2016-01-06 17:55:53 --> Loader Class Initialized
DEBUG - 2016-01-06 17:55:54 --> Helper loaded: url_helper
DEBUG - 2016-01-06 17:55:54 --> Helper loaded: form_helper
DEBUG - 2016-01-06 17:55:54 --> Database Driver Class Initialized
DEBUG - 2016-01-06 17:55:54 --> Session Class Initialized
DEBUG - 2016-01-06 17:55:54 --> Helper loaded: string_helper
DEBUG - 2016-01-06 17:55:54 --> Session routines successfully run
DEBUG - 2016-01-06 17:55:54 --> Form Validation Class Initialized
DEBUG - 2016-01-06 17:55:54 --> Pagination Class Initialized
DEBUG - 2016-01-06 17:55:54 --> Encrypt Class Initialized
DEBUG - 2016-01-06 17:55:54 --> Email Class Initialized
DEBUG - 2016-01-06 17:55:54 --> Controller Class Initialized
DEBUG - 2016-01-06 17:55:54 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> Image Lib Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 17:55:54 --> Model Class Initialized
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 17:55:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 17:55:54 --> Final output sent to browser
DEBUG - 2016-01-06 17:55:54 --> Total execution time: 1.9186
DEBUG - 2016-01-06 18:04:39 --> Config Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:04:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:04:39 --> URI Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Router Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Output Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Security Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Input Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:04:39 --> Language Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Language Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Config Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Loader Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:04:39 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:04:39 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Session Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:04:39 --> Session routines successfully run
DEBUG - 2016-01-06 18:04:39 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:04:39 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:04:40 --> Email Class Initialized
DEBUG - 2016-01-06 18:04:40 --> Controller Class Initialized
DEBUG - 2016-01-06 18:04:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:04:40 --> Model Class Initialized
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:04:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:04:40 --> Final output sent to browser
DEBUG - 2016-01-06 18:04:40 --> Total execution time: 0.3246
DEBUG - 2016-01-06 18:05:12 --> Config Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:05:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:05:12 --> URI Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Router Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Output Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Security Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Input Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:05:12 --> Language Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Language Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Config Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Loader Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:05:12 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:05:12 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Session Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:05:12 --> Session routines successfully run
DEBUG - 2016-01-06 18:05:12 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Email Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Controller Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:05:12 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 18:05:12 --> XSS Filtering completed
DEBUG - 2016-01-06 18:05:12 --> XSS Filtering completed
DEBUG - 2016-01-06 18:05:12 --> XSS Filtering completed
DEBUG - 2016-01-06 18:05:12 --> XSS Filtering completed
DEBUG - 2016-01-06 18:05:13 --> Config Class Initialized
DEBUG - 2016-01-06 18:05:13 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:05:13 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:05:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:05:13 --> URI Class Initialized
DEBUG - 2016-01-06 18:05:13 --> Router Class Initialized
ERROR - 2016-01-06 18:05:13 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 18:05:43 --> Config Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:05:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:05:43 --> URI Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Router Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Output Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Security Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Input Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:05:43 --> Language Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Language Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Config Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Loader Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:05:43 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:05:43 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Session Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:05:43 --> Session routines successfully run
DEBUG - 2016-01-06 18:05:43 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Email Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Controller Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:05:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:05:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:05:43 --> Final output sent to browser
DEBUG - 2016-01-06 18:05:43 --> Total execution time: 0.3034
DEBUG - 2016-01-06 18:06:38 --> Config Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:06:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:06:38 --> URI Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Router Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Output Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Security Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Input Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:06:38 --> Language Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Language Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Config Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Loader Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:06:38 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:06:38 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Session Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:06:38 --> Session routines successfully run
DEBUG - 2016-01-06 18:06:38 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Email Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Controller Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:06:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:06:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:06:38 --> Final output sent to browser
DEBUG - 2016-01-06 18:06:38 --> Total execution time: 0.3292
DEBUG - 2016-01-06 18:07:09 --> Config Class Initialized
DEBUG - 2016-01-06 18:07:09 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:07:09 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:07:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:07:09 --> URI Class Initialized
DEBUG - 2016-01-06 18:07:09 --> Router Class Initialized
DEBUG - 2016-01-06 18:07:09 --> Output Class Initialized
DEBUG - 2016-01-06 18:07:09 --> Security Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Input Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:07:10 --> Language Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Language Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Config Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Loader Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:07:10 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:07:10 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Session Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:07:10 --> Session routines successfully run
DEBUG - 2016-01-06 18:07:10 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Email Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Controller Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 18:07:10 --> XSS Filtering completed
DEBUG - 2016-01-06 18:07:10 --> XSS Filtering completed
DEBUG - 2016-01-06 18:07:10 --> XSS Filtering completed
DEBUG - 2016-01-06 18:07:10 --> XSS Filtering completed
DEBUG - 2016-01-06 18:07:10 --> Config Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:07:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:07:10 --> URI Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Router Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Output Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Security Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Input Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:07:10 --> Language Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Language Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Config Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Loader Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:07:10 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:07:10 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Session Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:07:10 --> Session routines successfully run
DEBUG - 2016-01-06 18:07:10 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Email Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Controller Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:07:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:07:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:07:10 --> Final output sent to browser
DEBUG - 2016-01-06 18:07:10 --> Total execution time: 0.3662
DEBUG - 2016-01-06 18:12:24 --> Config Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:12:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:12:24 --> URI Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Router Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Output Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Security Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Input Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:12:24 --> Language Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Language Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Config Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Loader Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:12:24 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:12:24 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Session Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:12:24 --> Session routines successfully run
DEBUG - 2016-01-06 18:12:24 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Email Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Controller Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:12:24 --> Model Class Initialized
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:12:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:12:24 --> Final output sent to browser
DEBUG - 2016-01-06 18:12:24 --> Total execution time: 0.4411
DEBUG - 2016-01-06 18:13:37 --> Config Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:13:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:13:37 --> URI Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Router Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Output Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Security Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Input Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:13:37 --> Language Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Language Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Config Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Loader Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:13:37 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:13:37 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Session Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:13:37 --> Session routines successfully run
DEBUG - 2016-01-06 18:13:37 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Email Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Controller Class Initialized
DEBUG - 2016-01-06 18:13:37 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:13:37 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:13:37 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:13:37 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:13:37 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:13:37 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:13:37 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:13:37 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:13:37 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:13:37 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:13:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:38 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:13:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:13:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:13:38 --> Model Class Initialized
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:13:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:13:38 --> Final output sent to browser
DEBUG - 2016-01-06 18:13:38 --> Total execution time: 0.4220
DEBUG - 2016-01-06 18:40:18 --> Config Class Initialized
DEBUG - 2016-01-06 18:40:18 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:40:18 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:40:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:40:18 --> URI Class Initialized
DEBUG - 2016-01-06 18:40:18 --> Router Class Initialized
DEBUG - 2016-01-06 18:40:18 --> Output Class Initialized
DEBUG - 2016-01-06 18:40:18 --> Security Class Initialized
DEBUG - 2016-01-06 18:40:18 --> Input Class Initialized
DEBUG - 2016-01-06 18:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:40:19 --> Language Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Language Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Config Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Loader Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:40:19 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:40:19 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Session Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:40:19 --> Session routines successfully run
DEBUG - 2016-01-06 18:40:19 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Email Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Controller Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:19 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:40:19 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:20 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:40:34 --> Config Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:40:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:40:34 --> URI Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Router Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Output Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Security Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Input Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:40:34 --> Language Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Language Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Config Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Loader Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:40:34 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:40:34 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Session Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:40:34 --> Session routines successfully run
DEBUG - 2016-01-06 18:40:34 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Email Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Controller Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:40:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:34 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:40:55 --> Config Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:40:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:40:55 --> URI Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Router Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Output Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Security Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Input Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:40:55 --> Language Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Language Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Config Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Loader Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:40:55 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:40:55 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Session Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:40:55 --> Session routines successfully run
DEBUG - 2016-01-06 18:40:55 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Email Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Controller Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:40:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:40:55 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:40:55 --> Severity: Notice  --> Undefined variable: tenant_phone_number C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 11
DEBUG - 2016-01-06 18:41:13 --> Config Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:41:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:41:13 --> URI Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Router Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Output Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Security Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Input Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:41:13 --> Language Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Language Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Config Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Loader Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:41:13 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:41:13 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Session Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:41:13 --> Session routines successfully run
DEBUG - 2016-01-06 18:41:13 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Email Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Controller Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:41:13 --> Model Class Initialized
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:41:13 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:41:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:41:13 --> Final output sent to browser
DEBUG - 2016-01-06 18:41:13 --> Total execution time: 0.4855
DEBUG - 2016-01-06 18:46:25 --> Config Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:46:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:46:25 --> URI Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Router Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Output Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Security Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Input Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:46:25 --> Language Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Language Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Config Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Loader Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:46:25 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:46:25 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Session Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:46:25 --> Session routines successfully run
DEBUG - 2016-01-06 18:46:25 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Email Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Controller Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:46:25 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:46:25 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:46:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:46:25 --> Final output sent to browser
DEBUG - 2016-01-06 18:46:25 --> Total execution time: 0.4338
DEBUG - 2016-01-06 18:46:54 --> Config Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:46:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:46:54 --> URI Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Router Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Output Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Security Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Input Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:46:54 --> Language Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Language Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Config Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Loader Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:46:54 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:46:54 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Session Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:46:54 --> Session routines successfully run
DEBUG - 2016-01-06 18:46:54 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:46:54 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:46:55 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:46:55 --> Email Class Initialized
DEBUG - 2016-01-06 18:46:55 --> Controller Class Initialized
DEBUG - 2016-01-06 18:46:55 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:46:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 16
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 59
ERROR - 2016-01-06 18:46:55 --> Severity: Notice  --> Undefined variable: rental_unit_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\view_detail.php 60
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:46:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:46:55 --> Final output sent to browser
DEBUG - 2016-01-06 18:46:55 --> Total execution time: 0.3909
DEBUG - 2016-01-06 18:48:27 --> Config Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:48:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:48:27 --> URI Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Router Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Output Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Security Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Input Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:48:27 --> Language Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Language Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Config Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Loader Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:48:27 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:48:27 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Session Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:48:27 --> Session routines successfully run
DEBUG - 2016-01-06 18:48:27 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Email Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Controller Class Initialized
DEBUG - 2016-01-06 18:48:27 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:48:27 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:48:27 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:48:27 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:48:28 --> Model Class Initialized
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:48:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:48:28 --> Final output sent to browser
DEBUG - 2016-01-06 18:48:28 --> Total execution time: 0.4029
DEBUG - 2016-01-06 18:51:10 --> Config Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:51:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:51:10 --> URI Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Router Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Output Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Security Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Input Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:51:10 --> Language Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Language Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Config Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Loader Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:51:10 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:51:10 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Session Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:51:10 --> Session routines successfully run
DEBUG - 2016-01-06 18:51:10 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Email Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Controller Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:51:10 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:51:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:51:10 --> Final output sent to browser
DEBUG - 2016-01-06 18:51:10 --> Total execution time: 0.3306
DEBUG - 2016-01-06 18:51:26 --> Config Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:51:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:51:26 --> URI Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Router Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Output Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Security Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Input Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:51:26 --> Language Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Language Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Config Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Loader Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:51:26 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:51:26 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Session Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:51:26 --> Session routines successfully run
DEBUG - 2016-01-06 18:51:26 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Email Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Controller Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:51:26 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:51:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:51:26 --> Final output sent to browser
DEBUG - 2016-01-06 18:51:26 --> Total execution time: 0.3269
DEBUG - 2016-01-06 18:51:43 --> Config Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:51:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:51:43 --> URI Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Router Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Output Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Security Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Input Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:51:43 --> Language Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Language Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Config Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Loader Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:51:43 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:51:43 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Session Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:51:43 --> Session routines successfully run
DEBUG - 2016-01-06 18:51:43 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Email Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Controller Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:51:43 --> Model Class Initialized
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:51:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:51:43 --> Final output sent to browser
DEBUG - 2016-01-06 18:51:43 --> Total execution time: 0.3659
DEBUG - 2016-01-06 18:55:55 --> Config Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:55:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:55:55 --> URI Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Router Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Output Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Security Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Input Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:55:55 --> Language Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Language Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Config Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Loader Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:55:55 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:55:55 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Session Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:55:55 --> Session routines successfully run
DEBUG - 2016-01-06 18:55:55 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Email Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Controller Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 18:55:55 --> Model Class Initialized
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:55:55 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:55:56 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 18:55:56 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 18:55:56 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 18:55:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:55:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:55:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:55:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:55:56 --> Final output sent to browser
DEBUG - 2016-01-06 18:55:56 --> Total execution time: 0.4675
DEBUG - 2016-01-06 18:59:34 --> Config Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Hooks Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Utf8 Class Initialized
DEBUG - 2016-01-06 18:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 18:59:34 --> URI Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Router Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Output Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Security Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Input Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 18:59:34 --> Language Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Language Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Config Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Loader Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Helper loaded: url_helper
DEBUG - 2016-01-06 18:59:34 --> Helper loaded: form_helper
DEBUG - 2016-01-06 18:59:34 --> Database Driver Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Session Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Helper loaded: string_helper
DEBUG - 2016-01-06 18:59:34 --> Session routines successfully run
DEBUG - 2016-01-06 18:59:34 --> Form Validation Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Pagination Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Encrypt Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Email Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Controller Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 18:59:34 --> Model Class Initialized
DEBUG - 2016-01-06 18:59:34 --> Image Lib Class Initialized
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 18:59:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 18:59:34 --> Final output sent to browser
DEBUG - 2016-01-06 18:59:34 --> Total execution time: 0.4834
DEBUG - 2016-01-06 19:07:04 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Hooks Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Utf8 Class Initialized
DEBUG - 2016-01-06 19:07:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 19:07:04 --> URI Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Router Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Output Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Security Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Input Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 19:07:04 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Loader Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Helper loaded: url_helper
DEBUG - 2016-01-06 19:07:04 --> Helper loaded: form_helper
DEBUG - 2016-01-06 19:07:04 --> Database Driver Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Session Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Helper loaded: string_helper
DEBUG - 2016-01-06 19:07:04 --> Session routines successfully run
DEBUG - 2016-01-06 19:07:04 --> Form Validation Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Pagination Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Encrypt Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Email Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Controller Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> Image Lib Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 19:07:04 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:05 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 19:07:05 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 19:07:05 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 19:07:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 19:07:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 19:07:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 19:07:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 19:07:05 --> Final output sent to browser
DEBUG - 2016-01-06 19:07:05 --> Total execution time: 0.2940
DEBUG - 2016-01-06 19:07:12 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Hooks Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Utf8 Class Initialized
DEBUG - 2016-01-06 19:07:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 19:07:12 --> URI Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Router Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Output Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Security Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Input Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 19:07:12 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Loader Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Helper loaded: url_helper
DEBUG - 2016-01-06 19:07:12 --> Helper loaded: form_helper
DEBUG - 2016-01-06 19:07:12 --> Database Driver Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Session Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Helper loaded: string_helper
DEBUG - 2016-01-06 19:07:12 --> Session routines successfully run
DEBUG - 2016-01-06 19:07:12 --> Form Validation Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Pagination Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Encrypt Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Email Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Controller Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 19:07:12 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:12 --> Image Lib Class Initialized
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 19:07:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 19:07:12 --> Final output sent to browser
DEBUG - 2016-01-06 19:07:12 --> Total execution time: 0.2702
DEBUG - 2016-01-06 19:07:14 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Hooks Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Utf8 Class Initialized
DEBUG - 2016-01-06 19:07:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 19:07:14 --> URI Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Router Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Output Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Security Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Input Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 19:07:14 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Loader Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Helper loaded: url_helper
DEBUG - 2016-01-06 19:07:14 --> Helper loaded: form_helper
DEBUG - 2016-01-06 19:07:14 --> Database Driver Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Session Class Initialized
DEBUG - 2016-01-06 19:07:14 --> Helper loaded: string_helper
DEBUG - 2016-01-06 19:07:14 --> Session routines successfully run
DEBUG - 2016-01-06 19:07:15 --> Form Validation Class Initialized
DEBUG - 2016-01-06 19:07:15 --> Pagination Class Initialized
DEBUG - 2016-01-06 19:07:15 --> Encrypt Class Initialized
DEBUG - 2016-01-06 19:07:15 --> Email Class Initialized
DEBUG - 2016-01-06 19:07:15 --> Controller Class Initialized
DEBUG - 2016-01-06 19:07:15 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> Image Lib Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 19:07:15 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 19:07:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 19:07:15 --> Final output sent to browser
DEBUG - 2016-01-06 19:07:15 --> Total execution time: 0.2914
DEBUG - 2016-01-06 19:07:18 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Hooks Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Utf8 Class Initialized
DEBUG - 2016-01-06 19:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 19:07:18 --> URI Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Router Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Output Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Security Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Input Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 19:07:18 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Loader Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Helper loaded: url_helper
DEBUG - 2016-01-06 19:07:18 --> Helper loaded: form_helper
DEBUG - 2016-01-06 19:07:18 --> Database Driver Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Session Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Helper loaded: string_helper
DEBUG - 2016-01-06 19:07:18 --> Session routines successfully run
DEBUG - 2016-01-06 19:07:18 --> Form Validation Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Pagination Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Encrypt Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Email Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Controller Class Initialized
DEBUG - 2016-01-06 19:07:18 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-06 19:07:18 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 19:07:19 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 19:07:19 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 19:07:19 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 19:07:19 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 19:07:19 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 19:07:19 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 19:07:19 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 19:07:19 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 19:07:19 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:19 --> Image Lib Class Initialized
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 19:07:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 19:07:19 --> Final output sent to browser
DEBUG - 2016-01-06 19:07:19 --> Total execution time: 0.3007
DEBUG - 2016-01-06 19:07:26 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Hooks Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Utf8 Class Initialized
DEBUG - 2016-01-06 19:07:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 19:07:26 --> URI Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Router Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Output Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Security Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Input Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 19:07:26 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Language Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Config Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Loader Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Helper loaded: url_helper
DEBUG - 2016-01-06 19:07:26 --> Helper loaded: form_helper
DEBUG - 2016-01-06 19:07:26 --> Database Driver Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Session Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Helper loaded: string_helper
DEBUG - 2016-01-06 19:07:26 --> Session routines successfully run
DEBUG - 2016-01-06 19:07:26 --> Form Validation Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Pagination Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Encrypt Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Email Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Controller Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> Image Lib Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 19:07:26 --> Model Class Initialized
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 19:07:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 19:07:27 --> Final output sent to browser
DEBUG - 2016-01-06 19:07:27 --> Total execution time: 0.3570
DEBUG - 2016-01-06 21:40:36 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:36 --> Hooks Class Initialized
DEBUG - 2016-01-06 21:40:36 --> Utf8 Class Initialized
DEBUG - 2016-01-06 21:40:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 21:40:36 --> URI Class Initialized
DEBUG - 2016-01-06 21:40:37 --> Router Class Initialized
DEBUG - 2016-01-06 21:40:37 --> Output Class Initialized
DEBUG - 2016-01-06 21:40:37 --> Security Class Initialized
DEBUG - 2016-01-06 21:40:37 --> Input Class Initialized
DEBUG - 2016-01-06 21:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 21:40:37 --> Language Class Initialized
DEBUG - 2016-01-06 21:40:37 --> Language Class Initialized
DEBUG - 2016-01-06 21:40:37 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:37 --> Loader Class Initialized
DEBUG - 2016-01-06 21:40:37 --> Helper loaded: url_helper
DEBUG - 2016-01-06 21:40:38 --> Helper loaded: form_helper
DEBUG - 2016-01-06 21:40:38 --> Database Driver Class Initialized
DEBUG - 2016-01-06 21:40:38 --> Session Class Initialized
DEBUG - 2016-01-06 21:40:38 --> Helper loaded: string_helper
DEBUG - 2016-01-06 21:40:38 --> A session cookie was not found.
DEBUG - 2016-01-06 21:40:38 --> Session routines successfully run
DEBUG - 2016-01-06 21:40:38 --> Form Validation Class Initialized
DEBUG - 2016-01-06 21:40:38 --> Pagination Class Initialized
DEBUG - 2016-01-06 21:40:38 --> Encrypt Class Initialized
DEBUG - 2016-01-06 21:40:38 --> Email Class Initialized
DEBUG - 2016-01-06 21:40:38 --> Controller Class Initialized
DEBUG - 2016-01-06 21:40:38 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Hooks Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Utf8 Class Initialized
DEBUG - 2016-01-06 21:40:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 21:40:39 --> URI Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Router Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Output Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Security Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Input Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 21:40:39 --> Language Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Language Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Loader Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Helper loaded: url_helper
DEBUG - 2016-01-06 21:40:39 --> Helper loaded: form_helper
DEBUG - 2016-01-06 21:40:39 --> Database Driver Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Session Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Helper loaded: string_helper
DEBUG - 2016-01-06 21:40:39 --> Session routines successfully run
DEBUG - 2016-01-06 21:40:39 --> Form Validation Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Pagination Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Encrypt Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Email Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Controller Class Initialized
DEBUG - 2016-01-06 21:40:39 --> Auth MX_Controller Initialized
DEBUG - 2016-01-06 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 21:40:40 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 21:40:40 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 21:40:40 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-06 21:40:40 --> Final output sent to browser
DEBUG - 2016-01-06 21:40:40 --> Total execution time: 0.8182
DEBUG - 2016-01-06 21:40:42 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:42 --> Hooks Class Initialized
DEBUG - 2016-01-06 21:40:42 --> Utf8 Class Initialized
DEBUG - 2016-01-06 21:40:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 21:40:42 --> URI Class Initialized
DEBUG - 2016-01-06 21:40:42 --> Router Class Initialized
ERROR - 2016-01-06 21:40:42 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 21:40:43 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:43 --> Hooks Class Initialized
DEBUG - 2016-01-06 21:40:43 --> Utf8 Class Initialized
DEBUG - 2016-01-06 21:40:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 21:40:43 --> URI Class Initialized
DEBUG - 2016-01-06 21:40:44 --> Router Class Initialized
DEBUG - 2016-01-06 21:40:44 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:44 --> Hooks Class Initialized
DEBUG - 2016-01-06 21:40:44 --> Utf8 Class Initialized
DEBUG - 2016-01-06 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 21:40:44 --> URI Class Initialized
DEBUG - 2016-01-06 21:40:44 --> Router Class Initialized
DEBUG - 2016-01-06 21:40:45 --> Config Class Initialized
ERROR - 2016-01-06 21:40:45 --> 404 Page Not Found --> 
ERROR - 2016-01-06 21:40:45 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 21:40:45 --> Hooks Class Initialized
DEBUG - 2016-01-06 21:40:45 --> Utf8 Class Initialized
DEBUG - 2016-01-06 21:40:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 21:40:45 --> URI Class Initialized
DEBUG - 2016-01-06 21:40:45 --> Router Class Initialized
ERROR - 2016-01-06 21:40:46 --> 404 Page Not Found --> 
DEBUG - 2016-01-06 21:40:50 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:50 --> Hooks Class Initialized
DEBUG - 2016-01-06 21:40:50 --> Utf8 Class Initialized
DEBUG - 2016-01-06 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 21:40:50 --> URI Class Initialized
DEBUG - 2016-01-06 21:40:50 --> Router Class Initialized
DEBUG - 2016-01-06 21:40:50 --> Output Class Initialized
DEBUG - 2016-01-06 21:40:50 --> Security Class Initialized
DEBUG - 2016-01-06 21:40:50 --> Input Class Initialized
DEBUG - 2016-01-06 21:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 21:40:50 --> Language Class Initialized
DEBUG - 2016-01-06 21:40:51 --> Language Class Initialized
DEBUG - 2016-01-06 21:40:51 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:51 --> Loader Class Initialized
DEBUG - 2016-01-06 21:40:51 --> Helper loaded: url_helper
DEBUG - 2016-01-06 21:40:51 --> Helper loaded: form_helper
DEBUG - 2016-01-06 21:40:51 --> Database Driver Class Initialized
DEBUG - 2016-01-06 21:40:53 --> Session Class Initialized
DEBUG - 2016-01-06 21:40:53 --> Helper loaded: string_helper
DEBUG - 2016-01-06 21:40:53 --> Session routines successfully run
DEBUG - 2016-01-06 21:40:53 --> Form Validation Class Initialized
DEBUG - 2016-01-06 21:40:53 --> Pagination Class Initialized
DEBUG - 2016-01-06 21:40:53 --> Encrypt Class Initialized
DEBUG - 2016-01-06 21:40:53 --> Email Class Initialized
DEBUG - 2016-01-06 21:40:53 --> Controller Class Initialized
DEBUG - 2016-01-06 21:40:53 --> Auth MX_Controller Initialized
DEBUG - 2016-01-06 21:40:53 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 21:40:53 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 21:40:53 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-06 21:40:53 --> XSS Filtering completed
DEBUG - 2016-01-06 21:40:53 --> Unable to find validation rule: exists
DEBUG - 2016-01-06 21:40:53 --> XSS Filtering completed
DEBUG - 2016-01-06 21:40:54 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Hooks Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Utf8 Class Initialized
DEBUG - 2016-01-06 21:40:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 21:40:54 --> URI Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Router Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Output Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Security Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Input Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 21:40:54 --> Language Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Language Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Config Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Loader Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Helper loaded: url_helper
DEBUG - 2016-01-06 21:40:54 --> Helper loaded: form_helper
DEBUG - 2016-01-06 21:40:54 --> Database Driver Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Session Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Helper loaded: string_helper
DEBUG - 2016-01-06 21:40:54 --> Session routines successfully run
DEBUG - 2016-01-06 21:40:54 --> Form Validation Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Pagination Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Encrypt Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Email Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Controller Class Initialized
DEBUG - 2016-01-06 21:40:54 --> Admin MX_Controller Initialized
DEBUG - 2016-01-06 21:40:54 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 21:40:54 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 21:40:54 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 21:40:54 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 21:40:54 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 21:40:54 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 21:40:54 --> Model Class Initialized
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 21:40:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 21:40:54 --> Final output sent to browser
DEBUG - 2016-01-06 21:40:54 --> Total execution time: 0.6027
DEBUG - 2016-01-06 21:41:27 --> Config Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Hooks Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Utf8 Class Initialized
DEBUG - 2016-01-06 21:41:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-06 21:41:27 --> URI Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Router Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Output Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Security Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Input Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-06 21:41:27 --> Language Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Language Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Config Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Loader Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Helper loaded: url_helper
DEBUG - 2016-01-06 21:41:27 --> Helper loaded: form_helper
DEBUG - 2016-01-06 21:41:27 --> Database Driver Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Session Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Helper loaded: string_helper
DEBUG - 2016-01-06 21:41:27 --> Session routines successfully run
DEBUG - 2016-01-06 21:41:27 --> Form Validation Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Pagination Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Encrypt Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Email Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Controller Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> Image Lib Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:27 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-06 21:41:27 --> Model Class Initialized
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-06 21:41:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-06 21:41:28 --> Final output sent to browser
DEBUG - 2016-01-06 21:41:28 --> Total execution time: 0.8815
