<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-04-07 09:57:11 --> Config Class Initialized
DEBUG - 2016-04-07 09:57:11 --> Hooks Class Initialized
DEBUG - 2016-04-07 09:57:11 --> Utf8 Class Initialized
DEBUG - 2016-04-07 09:57:11 --> UTF-8 Support Enabled
DEBUG - 2016-04-07 09:57:11 --> URI Class Initialized
DEBUG - 2016-04-07 09:57:11 --> Router Class Initialized
DEBUG - 2016-04-07 09:57:11 --> No URI present. Default controller set.
DEBUG - 2016-04-07 09:57:11 --> Output Class Initialized
DEBUG - 2016-04-07 09:57:11 --> Security Class Initialized
DEBUG - 2016-04-07 09:57:11 --> Input Class Initialized
DEBUG - 2016-04-07 09:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-07 09:57:12 --> Language Class Initialized
DEBUG - 2016-04-07 09:57:12 --> Language Class Initialized
DEBUG - 2016-04-07 09:57:12 --> Config Class Initialized
DEBUG - 2016-04-07 09:57:12 --> Loader Class Initialized
DEBUG - 2016-04-07 09:57:12 --> Helper loaded: url_helper
DEBUG - 2016-04-07 09:57:12 --> Helper loaded: form_helper
DEBUG - 2016-04-07 09:57:12 --> Database Driver Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Session Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Helper loaded: string_helper
DEBUG - 2016-04-07 09:57:14 --> A session cookie was not found.
DEBUG - 2016-04-07 09:57:14 --> Session routines successfully run
DEBUG - 2016-04-07 09:57:14 --> Form Validation Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Pagination Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Encrypt Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Email Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Controller Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Auth MX_Controller Initialized
DEBUG - 2016-04-07 09:57:14 --> Model Class Initialized
DEBUG - 2016-04-07 09:57:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-07 09:57:14 --> Model Class Initialized
DEBUG - 2016-04-07 09:57:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-07 09:57:14 --> Model Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Config Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Hooks Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Utf8 Class Initialized
DEBUG - 2016-04-07 09:57:14 --> UTF-8 Support Enabled
DEBUG - 2016-04-07 09:57:14 --> URI Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Router Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Output Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Security Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Input Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-07 09:57:14 --> Language Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Language Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Config Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Loader Class Initialized
DEBUG - 2016-04-07 09:57:14 --> Helper loaded: url_helper
DEBUG - 2016-04-07 09:57:14 --> Helper loaded: form_helper
DEBUG - 2016-04-07 09:57:15 --> Database Driver Class Initialized
DEBUG - 2016-04-07 09:57:15 --> Session Class Initialized
DEBUG - 2016-04-07 09:57:15 --> Helper loaded: string_helper
DEBUG - 2016-04-07 09:57:15 --> Session routines successfully run
DEBUG - 2016-04-07 09:57:15 --> Form Validation Class Initialized
DEBUG - 2016-04-07 09:57:15 --> Pagination Class Initialized
DEBUG - 2016-04-07 09:57:15 --> Encrypt Class Initialized
DEBUG - 2016-04-07 09:57:15 --> Email Class Initialized
DEBUG - 2016-04-07 09:57:15 --> Controller Class Initialized
DEBUG - 2016-04-07 09:57:15 --> Auth MX_Controller Initialized
DEBUG - 2016-04-07 09:57:15 --> Model Class Initialized
DEBUG - 2016-04-07 09:57:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-07 09:57:15 --> Model Class Initialized
DEBUG - 2016-04-07 09:57:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-07 09:57:15 --> Model Class Initialized
ERROR - 2016-04-07 09:57:16 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\rents\application\modules\admin\views\includes\header.php 4
DEBUG - 2016-04-07 09:57:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-07 09:57:16 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-04-07 09:57:16 --> Final output sent to browser
DEBUG - 2016-04-07 09:57:16 --> Total execution time: 1.1367
DEBUG - 2016-04-07 09:57:21 --> Config Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Hooks Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Utf8 Class Initialized
DEBUG - 2016-04-07 09:57:21 --> UTF-8 Support Enabled
DEBUG - 2016-04-07 09:57:21 --> Config Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Hooks Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Utf8 Class Initialized
DEBUG - 2016-04-07 09:57:21 --> UTF-8 Support Enabled
DEBUG - 2016-04-07 09:57:21 --> URI Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Router Class Initialized
DEBUG - 2016-04-07 09:57:21 --> URI Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Router Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Config Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Hooks Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Utf8 Class Initialized
DEBUG - 2016-04-07 09:57:21 --> UTF-8 Support Enabled
DEBUG - 2016-04-07 09:57:21 --> Config Class Initialized
DEBUG - 2016-04-07 09:57:21 --> URI Class Initialized
DEBUG - 2016-04-07 09:57:21 --> Router Class Initialized
DEBUG - 2016-04-07 09:57:22 --> Hooks Class Initialized
DEBUG - 2016-04-07 09:57:22 --> Utf8 Class Initialized
DEBUG - 2016-04-07 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2016-04-07 09:57:22 --> URI Class Initialized
DEBUG - 2016-04-07 09:57:22 --> Router Class Initialized
ERROR - 2016-04-07 09:57:22 --> 404 Page Not Found --> 
ERROR - 2016-04-07 09:57:22 --> 404 Page Not Found --> 
ERROR - 2016-04-07 09:57:22 --> 404 Page Not Found --> 
ERROR - 2016-04-07 09:57:22 --> 404 Page Not Found --> 
