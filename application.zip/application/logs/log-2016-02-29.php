<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-29 14:25:19 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:19 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:19 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:19 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:19 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:19 --> Router Class Initialized
DEBUG - 2016-02-29 14:25:20 --> No URI present. Default controller set.
DEBUG - 2016-02-29 14:25:20 --> Output Class Initialized
DEBUG - 2016-02-29 14:25:20 --> Security Class Initialized
DEBUG - 2016-02-29 14:25:20 --> Input Class Initialized
DEBUG - 2016-02-29 14:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:25:20 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:21 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:21 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:21 --> Loader Class Initialized
DEBUG - 2016-02-29 14:25:21 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:25:21 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:25:22 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:25:22 --> Session Class Initialized
DEBUG - 2016-02-29 14:25:22 --> Helper loaded: string_helper
ERROR - 2016-02-29 14:25:22 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-29 14:25:22 --> Session routines successfully run
DEBUG - 2016-02-29 14:25:23 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Email Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Controller Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Auth MX_Controller Initialized
DEBUG - 2016-02-29 14:25:23 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:25:23 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:25:23 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:23 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Router Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Output Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Security Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Input Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:25:23 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Loader Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:25:23 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:25:23 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Session Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:25:23 --> Session routines successfully run
DEBUG - 2016-02-29 14:25:23 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Email Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Controller Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Auth MX_Controller Initialized
DEBUG - 2016-02-29 14:25:23 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:25:23 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:25:23 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-29 14:25:24 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-29 14:25:24 --> Final output sent to browser
DEBUG - 2016-02-29 14:25:24 --> Total execution time: 0.5755
DEBUG - 2016-02-29 14:25:30 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:30 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:30 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:30 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:30 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:30 --> Router Class Initialized
ERROR - 2016-02-29 14:25:32 --> 404 Page Not Found --> 
DEBUG - 2016-02-29 14:25:32 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:32 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:32 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:32 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:32 --> Router Class Initialized
DEBUG - 2016-02-29 14:25:32 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:32 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:32 --> Router Class Initialized
DEBUG - 2016-02-29 14:25:32 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:33 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:33 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:33 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:33 --> Router Class Initialized
ERROR - 2016-02-29 14:25:33 --> 404 Page Not Found --> 
ERROR - 2016-02-29 14:25:33 --> 404 Page Not Found --> 
ERROR - 2016-02-29 14:25:33 --> 404 Page Not Found --> 
DEBUG - 2016-02-29 14:25:38 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:38 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Router Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Output Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Security Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Input Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:25:38 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Loader Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:25:38 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:25:38 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Session Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:25:38 --> Session routines successfully run
DEBUG - 2016-02-29 14:25:38 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Email Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Controller Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Auth MX_Controller Initialized
DEBUG - 2016-02-29 14:25:38 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:25:38 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:25:38 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-29 14:25:38 --> XSS Filtering completed
DEBUG - 2016-02-29 14:25:38 --> Unable to find validation rule: exists
DEBUG - 2016-02-29 14:25:38 --> XSS Filtering completed
DEBUG - 2016-02-29 14:25:38 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:38 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:38 --> Router Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Output Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Security Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Input Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:25:39 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Loader Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:25:39 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:25:39 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Session Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:25:39 --> Session routines successfully run
DEBUG - 2016-02-29 14:25:39 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Email Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Controller Class Initialized
DEBUG - 2016-02-29 14:25:39 --> Admin MX_Controller Initialized
DEBUG - 2016-02-29 14:25:39 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:25:39 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:25:39 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:25:39 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:39 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:25:39 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:25:39 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:25:39 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:39 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-02-29 14:25:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-29 14:25:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-29 14:25:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-29 14:25:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-29 14:25:40 --> Final output sent to browser
DEBUG - 2016-02-29 14:25:40 --> Total execution time: 1.1284
DEBUG - 2016-02-29 14:25:49 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:49 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Router Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Output Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Security Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Input Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:25:49 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Loader Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:25:49 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:25:49 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Session Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:25:49 --> Session routines successfully run
DEBUG - 2016-02-29 14:25:49 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Email Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Controller Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-29 14:25:49 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:49 --> Image Lib Class Initialized
DEBUG - 2016-02-29 14:25:50 --> File loaded: application/modules/real_estate_administration/views/rental_unit/search/rental_unit_search.php
DEBUG - 2016-02-29 14:25:50 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-02-29 14:25:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-29 14:25:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-29 14:25:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-29 14:25:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-29 14:25:50 --> Final output sent to browser
DEBUG - 2016-02-29 14:25:50 --> Total execution time: 1.8889
DEBUG - 2016-02-29 14:25:55 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:25:55 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:25:55 --> URI Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Router Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Output Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Security Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Input Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:25:55 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Language Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Config Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Loader Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:25:55 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:25:55 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Session Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:25:55 --> Session routines successfully run
DEBUG - 2016-02-29 14:25:55 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Email Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Controller Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> Image Lib Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-29 14:25:55 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-29 14:25:56 --> Model Class Initialized
DEBUG - 2016-02-29 14:25:57 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:25:57 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:25:57 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-29 14:25:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-29 14:25:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-29 14:25:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-29 14:25:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-29 14:25:57 --> Final output sent to browser
DEBUG - 2016-02-29 14:25:57 --> Total execution time: 2.0345
DEBUG - 2016-02-29 14:26:06 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:26:06 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:26:06 --> URI Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Router Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Output Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Security Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Input Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:26:06 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Loader Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:26:06 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:26:06 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Session Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:26:06 --> Session routines successfully run
DEBUG - 2016-02-29 14:26:06 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Email Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Controller Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> Image Lib Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-29 14:26:06 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-29 14:26:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-29 14:26:06 --> Final output sent to browser
DEBUG - 2016-02-29 14:26:06 --> Total execution time: 0.3181
DEBUG - 2016-02-29 14:26:13 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:26:13 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:26:13 --> URI Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Router Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Output Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Security Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Input Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:26:13 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Loader Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:26:13 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:26:13 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Session Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:26:13 --> Session routines successfully run
DEBUG - 2016-02-29 14:26:13 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Email Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Controller Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> Image Lib Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-29 14:26:13 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/search/tenants_search.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:13 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-29 14:26:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-29 14:26:14 --> Final output sent to browser
DEBUG - 2016-02-29 14:26:14 --> Total execution time: 0.5505
DEBUG - 2016-02-29 14:26:31 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:26:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:26:31 --> URI Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Router Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Output Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Security Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Input Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:26:31 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Loader Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:26:31 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:26:31 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Session Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:26:31 --> Session routines successfully run
DEBUG - 2016-02-29 14:26:31 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Email Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Controller Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Image Lib Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-29 14:26:31 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-29 14:26:31 --> XSS Filtering completed
DEBUG - 2016-02-29 14:26:31 --> XSS Filtering completed
DEBUG - 2016-02-29 14:26:32 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:26:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:26:32 --> URI Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Router Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Output Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Security Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Input Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:26:32 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Loader Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:26:32 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:26:32 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Session Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:26:32 --> Session routines successfully run
DEBUG - 2016-02-29 14:26:32 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Email Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Controller Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> Image Lib Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-29 14:26:32 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/search/tenants_search.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-29 14:26:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-29 14:26:32 --> Final output sent to browser
DEBUG - 2016-02-29 14:26:32 --> Total execution time: 0.5660
DEBUG - 2016-02-29 14:26:52 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:26:52 --> URI Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Router Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Output Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Security Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Input Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:26:52 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Language Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Config Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Loader Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:26:52 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:26:52 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Session Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:26:52 --> Session routines successfully run
DEBUG - 2016-02-29 14:26:52 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Email Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Controller Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> Image Lib Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-29 14:26:52 --> Model Class Initialized
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-29 14:26:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-29 14:26:52 --> Final output sent to browser
DEBUG - 2016-02-29 14:26:52 --> Total execution time: 0.2775
DEBUG - 2016-02-29 14:27:04 --> Config Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:27:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:27:04 --> URI Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Router Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Output Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Security Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Input Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:27:04 --> Language Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Language Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Config Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Loader Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:27:04 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:27:04 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Session Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:27:04 --> Session routines successfully run
DEBUG - 2016-02-29 14:27:04 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Email Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Controller Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Image Lib Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-29 14:27:04 --> XSS Filtering completed
DEBUG - 2016-02-29 14:27:04 --> Config Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Utf8 Class Initialized
DEBUG - 2016-02-29 14:27:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-29 14:27:04 --> URI Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Router Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Output Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Security Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Input Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-29 14:27:04 --> Language Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Language Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Config Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Loader Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Helper loaded: url_helper
DEBUG - 2016-02-29 14:27:04 --> Helper loaded: form_helper
DEBUG - 2016-02-29 14:27:04 --> Database Driver Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Session Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Helper loaded: string_helper
DEBUG - 2016-02-29 14:27:04 --> Session routines successfully run
DEBUG - 2016-02-29 14:27:04 --> Form Validation Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Pagination Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Encrypt Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Email Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Controller Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> Image Lib Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-29 14:27:04 --> Model Class Initialized
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-29 14:27:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-29 14:27:04 --> Final output sent to browser
DEBUG - 2016-02-29 14:27:04 --> Total execution time: 0.2621
