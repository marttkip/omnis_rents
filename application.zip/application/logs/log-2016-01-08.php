<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-08 08:54:07 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:07 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:07 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:07 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:07 --> Router Class Initialized
DEBUG - 2016-01-08 08:54:08 --> No URI present. Default controller set.
DEBUG - 2016-01-08 08:54:08 --> Output Class Initialized
DEBUG - 2016-01-08 08:54:08 --> Security Class Initialized
DEBUG - 2016-01-08 08:54:08 --> Input Class Initialized
DEBUG - 2016-01-08 08:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:54:08 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:08 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:08 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:08 --> Loader Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:54:09 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:54:09 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:09 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Router Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:54:09 --> No URI present. Default controller set.
DEBUG - 2016-01-08 08:54:09 --> Output Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Security Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Input Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:54:09 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Loader Class Initialized
DEBUG - 2016-01-08 08:54:09 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:54:09 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:54:09 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Session Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Session Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:54:10 --> A session cookie was not found.
DEBUG - 2016-01-08 08:54:10 --> Session routines successfully run
DEBUG - 2016-01-08 08:54:10 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:54:10 --> A session cookie was not found.
DEBUG - 2016-01-08 08:54:10 --> Session routines successfully run
DEBUG - 2016-01-08 08:54:10 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Email Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Email Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Controller Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Auth MX_Controller Initialized
DEBUG - 2016-01-08 08:54:10 --> Controller Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Auth MX_Controller Initialized
DEBUG - 2016-01-08 08:54:10 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:54:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:54:10 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:10 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:54:11 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:54:11 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:11 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Router Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Output Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Security Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Input Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:54:11 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Loader Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:54:11 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:54:11 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Session Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:54:11 --> Session routines successfully run
DEBUG - 2016-01-08 08:54:11 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Email Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Controller Class Initialized
DEBUG - 2016-01-08 08:54:11 --> Auth MX_Controller Initialized
DEBUG - 2016-01-08 08:54:11 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:54:11 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:54:11 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 08:54:11 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-08 08:54:11 --> Final output sent to browser
DEBUG - 2016-01-08 08:54:11 --> Total execution time: 0.7803
DEBUG - 2016-01-08 08:54:14 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:14 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:14 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:14 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:14 --> Router Class Initialized
DEBUG - 2016-01-08 08:54:15 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:15 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:15 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:15 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:15 --> Router Class Initialized
ERROR - 2016-01-08 08:54:15 --> 404 Page Not Found --> 
DEBUG - 2016-01-08 08:54:16 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:16 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:16 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:16 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:16 --> Router Class Initialized
ERROR - 2016-01-08 08:54:16 --> 404 Page Not Found --> 
DEBUG - 2016-01-08 08:54:17 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:17 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:17 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:17 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:17 --> Router Class Initialized
ERROR - 2016-01-08 08:54:18 --> 404 Page Not Found --> 
ERROR - 2016-01-08 08:54:18 --> 404 Page Not Found --> 
DEBUG - 2016-01-08 08:54:25 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:25 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Router Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Output Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Security Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Input Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:54:25 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Loader Class Initialized
DEBUG - 2016-01-08 08:54:25 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:54:25 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:54:25 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Session Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:54:26 --> Session routines successfully run
DEBUG - 2016-01-08 08:54:26 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Email Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Controller Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Auth MX_Controller Initialized
DEBUG - 2016-01-08 08:54:26 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:54:26 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:54:26 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-08 08:54:26 --> XSS Filtering completed
DEBUG - 2016-01-08 08:54:26 --> Unable to find validation rule: exists
DEBUG - 2016-01-08 08:54:26 --> XSS Filtering completed
DEBUG - 2016-01-08 08:54:26 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:26 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Router Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Output Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Security Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Input Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:54:26 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Loader Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:54:26 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:54:26 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Session Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:54:26 --> Session routines successfully run
DEBUG - 2016-01-08 08:54:26 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Email Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Controller Class Initialized
DEBUG - 2016-01-08 08:54:26 --> Admin MX_Controller Initialized
DEBUG - 2016-01-08 08:54:26 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 08:54:26 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:54:26 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:54:26 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 08:54:26 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 08:54:26 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 08:54:27 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:27 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-08 08:54:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 08:54:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-08 08:54:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-08 08:54:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-08 08:54:27 --> Final output sent to browser
DEBUG - 2016-01-08 08:54:27 --> Total execution time: 0.6961
DEBUG - 2016-01-08 08:54:43 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:43 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Router Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Output Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Security Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Input Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:54:43 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Loader Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:54:43 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:54:43 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Session Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:54:43 --> Session routines successfully run
DEBUG - 2016-01-08 08:54:43 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Email Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Controller Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-08 08:54:43 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:43 --> Image Lib Class Initialized
DEBUG - 2016-01-08 08:54:44 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-08 08:54:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 08:54:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-08 08:54:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-08 08:54:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-08 08:54:44 --> Final output sent to browser
DEBUG - 2016-01-08 08:54:44 --> Total execution time: 0.7751
DEBUG - 2016-01-08 08:54:47 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:47 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Router Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Output Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Security Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Input Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:54:47 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Loader Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:54:47 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:54:47 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Session Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:54:47 --> Session routines successfully run
DEBUG - 2016-01-08 08:54:47 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Email Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Controller Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> Image Lib Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:47 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-08 08:54:47 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:48 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-08 08:54:48 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-08 08:54:48 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-08 08:54:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 08:54:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-08 08:54:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-08 08:54:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-08 08:54:48 --> Final output sent to browser
DEBUG - 2016-01-08 08:54:48 --> Total execution time: 0.9729
DEBUG - 2016-01-08 08:54:58 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:54:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:54:58 --> URI Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Router Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Output Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Security Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Input Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:54:58 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Language Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Config Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Loader Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:54:58 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:54:58 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Session Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:54:58 --> Session routines successfully run
DEBUG - 2016-01-08 08:54:58 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Email Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Controller Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-08 08:54:58 --> Model Class Initialized
DEBUG - 2016-01-08 08:54:58 --> Image Lib Class Initialized
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-08 08:54:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-08 08:54:58 --> Final output sent to browser
DEBUG - 2016-01-08 08:54:58 --> Total execution time: 0.2791
DEBUG - 2016-01-08 08:55:36 --> Config Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:55:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:55:36 --> URI Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Router Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Output Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Security Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Input Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:55:36 --> Language Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Language Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Config Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Loader Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:55:36 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:55:36 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Session Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:55:36 --> Session routines successfully run
DEBUG - 2016-01-08 08:55:36 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Email Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Controller Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> Image Lib Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-08 08:55:36 --> Model Class Initialized
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-08 08:55:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-08 08:55:36 --> Final output sent to browser
DEBUG - 2016-01-08 08:55:36 --> Total execution time: 0.2945
DEBUG - 2016-01-08 08:57:05 --> Config Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:57:06 --> URI Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Router Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Output Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Security Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Input Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:57:06 --> Language Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Language Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Config Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Loader Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:57:06 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:57:06 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Session Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:57:06 --> Session routines successfully run
DEBUG - 2016-01-08 08:57:06 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Email Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Controller Class Initialized
DEBUG - 2016-01-08 08:57:06 --> Sections MX_Controller Initialized
DEBUG - 2016-01-08 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-08 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-08 08:57:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-08 08:57:06 --> Final output sent to browser
DEBUG - 2016-01-08 08:57:06 --> Total execution time: 0.5438
DEBUG - 2016-01-08 08:57:09 --> Config Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:57:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:57:09 --> URI Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Router Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Output Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Security Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Input Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:57:09 --> Language Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Language Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Config Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Loader Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:57:09 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:57:09 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Session Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:57:09 --> Session routines successfully run
DEBUG - 2016-01-08 08:57:09 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Email Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Controller Class Initialized
DEBUG - 2016-01-08 08:57:09 --> Sections MX_Controller Initialized
DEBUG - 2016-01-08 08:57:09 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 08:57:09 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:57:09 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:57:09 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 08:57:09 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 08:57:09 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 08:57:09 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-08 08:57:09 --> Model Class Initialized
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-08 08:57:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-08 08:57:09 --> Final output sent to browser
DEBUG - 2016-01-08 08:57:09 --> Total execution time: 0.2308
DEBUG - 2016-01-08 08:59:32 --> Config Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:59:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:59:32 --> URI Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Router Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Output Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Security Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Input Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:59:32 --> Language Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Language Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Config Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Loader Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:59:32 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:59:32 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Session Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:59:32 --> Session routines successfully run
DEBUG - 2016-01-08 08:59:32 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Email Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Controller Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Sections MX_Controller Initialized
DEBUG - 2016-01-08 08:59:32 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 08:59:32 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:59:32 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:59:32 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 08:59:32 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 08:59:32 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 08:59:32 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-08 08:59:32 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-08 08:59:32 --> XSS Filtering completed
DEBUG - 2016-01-08 08:59:32 --> XSS Filtering completed
DEBUG - 2016-01-08 08:59:32 --> XSS Filtering completed
DEBUG - 2016-01-08 08:59:32 --> XSS Filtering completed
DEBUG - 2016-01-08 08:59:32 --> XSS Filtering completed
DEBUG - 2016-01-08 08:59:33 --> Config Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Hooks Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Utf8 Class Initialized
DEBUG - 2016-01-08 08:59:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 08:59:33 --> URI Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Router Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Output Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Security Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Input Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 08:59:33 --> Language Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Language Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Config Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Loader Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Helper loaded: url_helper
DEBUG - 2016-01-08 08:59:33 --> Helper loaded: form_helper
DEBUG - 2016-01-08 08:59:33 --> Database Driver Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Session Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Helper loaded: string_helper
DEBUG - 2016-01-08 08:59:33 --> Session routines successfully run
DEBUG - 2016-01-08 08:59:33 --> Form Validation Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Pagination Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Encrypt Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Email Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Controller Class Initialized
DEBUG - 2016-01-08 08:59:33 --> Sections MX_Controller Initialized
DEBUG - 2016-01-08 08:59:33 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 08:59:33 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 08:59:33 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 08:59:33 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 08:59:33 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 08:59:33 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 08:59:33 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-08 08:59:33 --> Model Class Initialized
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-08 08:59:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-08 08:59:33 --> Final output sent to browser
DEBUG - 2016-01-08 08:59:33 --> Total execution time: 0.3088
DEBUG - 2016-01-08 09:25:55 --> Config Class Initialized
DEBUG - 2016-01-08 09:25:55 --> Hooks Class Initialized
DEBUG - 2016-01-08 09:25:55 --> Utf8 Class Initialized
DEBUG - 2016-01-08 09:25:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 09:25:56 --> URI Class Initialized
DEBUG - 2016-01-08 09:25:56 --> Router Class Initialized
ERROR - 2016-01-08 09:25:56 --> 404 Page Not Found --> 
DEBUG - 2016-01-08 09:27:40 --> Config Class Initialized
DEBUG - 2016-01-08 09:27:40 --> Hooks Class Initialized
DEBUG - 2016-01-08 09:27:40 --> Utf8 Class Initialized
DEBUG - 2016-01-08 09:27:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-08 09:27:40 --> URI Class Initialized
DEBUG - 2016-01-08 09:27:40 --> Router Class Initialized
DEBUG - 2016-01-08 09:27:40 --> Output Class Initialized
DEBUG - 2016-01-08 09:27:40 --> Security Class Initialized
DEBUG - 2016-01-08 09:27:40 --> Input Class Initialized
DEBUG - 2016-01-08 09:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-08 09:27:40 --> Language Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Language Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Config Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Loader Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Helper loaded: url_helper
DEBUG - 2016-01-08 09:27:41 --> Helper loaded: form_helper
DEBUG - 2016-01-08 09:27:41 --> Database Driver Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Session Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Helper loaded: string_helper
DEBUG - 2016-01-08 09:27:41 --> Session routines successfully run
DEBUG - 2016-01-08 09:27:41 --> Form Validation Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Pagination Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Encrypt Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Email Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Controller Class Initialized
DEBUG - 2016-01-08 09:27:41 --> leases MX_Controller Initialized
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-08 09:27:41 --> Model Class Initialized
DEBUG - 2016-01-08 09:27:41 --> Image Lib Class Initialized
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-08 09:27:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-08 09:27:41 --> Final output sent to browser
DEBUG - 2016-01-08 09:27:41 --> Total execution time: 0.4985
