<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-14 08:33:48 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:48 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:33:49 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:33:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:33:49 --> URI Class Initialized
DEBUG - 2015-12-14 08:33:49 --> Router Class Initialized
DEBUG - 2015-12-14 08:33:49 --> No URI present. Default controller set.
DEBUG - 2015-12-14 08:33:49 --> Output Class Initialized
DEBUG - 2015-12-14 08:33:49 --> Security Class Initialized
DEBUG - 2015-12-14 08:33:49 --> Input Class Initialized
DEBUG - 2015-12-14 08:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:33:49 --> Language Class Initialized
DEBUG - 2015-12-14 08:33:49 --> Language Class Initialized
DEBUG - 2015-12-14 08:33:49 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:49 --> Loader Class Initialized
DEBUG - 2015-12-14 08:33:49 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:33:49 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:33:49 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Session Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:33:50 --> A session cookie was not found.
DEBUG - 2015-12-14 08:33:50 --> Session routines successfully run
DEBUG - 2015-12-14 08:33:50 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Email Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Controller Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Auth MX_Controller Initialized
DEBUG - 2015-12-14 08:33:50 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:33:50 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:33:50 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:33:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:33:50 --> URI Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Router Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Output Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Security Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Input Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:33:50 --> Language Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Language Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Loader Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:33:50 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:33:50 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Session Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:33:50 --> Session routines successfully run
DEBUG - 2015-12-14 08:33:50 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Email Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Controller Class Initialized
DEBUG - 2015-12-14 08:33:50 --> Auth MX_Controller Initialized
DEBUG - 2015-12-14 08:33:50 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:33:50 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:33:50 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:33:51 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-14 08:33:51 --> Final output sent to browser
DEBUG - 2015-12-14 08:33:51 --> Total execution time: 0.5901
DEBUG - 2015-12-14 08:33:55 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:33:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:33:55 --> URI Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Router Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:33:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:33:55 --> URI Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Router Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:33:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:33:55 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Hooks Class Initialized
ERROR - 2015-12-14 08:33:55 --> 404 Page Not Found --> 
DEBUG - 2015-12-14 08:33:55 --> URI Class Initialized
DEBUG - 2015-12-14 08:33:55 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:33:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:33:55 --> Router Class Initialized
DEBUG - 2015-12-14 08:33:55 --> URI Class Initialized
ERROR - 2015-12-14 08:33:55 --> 404 Page Not Found --> 
DEBUG - 2015-12-14 08:33:55 --> Router Class Initialized
ERROR - 2015-12-14 08:33:55 --> 404 Page Not Found --> 
ERROR - 2015-12-14 08:33:55 --> 404 Page Not Found --> 
DEBUG - 2015-12-14 08:33:59 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:33:59 --> URI Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Router Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Output Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Security Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Input Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:33:59 --> Language Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Language Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Loader Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:33:59 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:33:59 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Session Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:33:59 --> Session routines successfully run
DEBUG - 2015-12-14 08:33:59 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Email Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Controller Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Auth MX_Controller Initialized
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-14 08:33:59 --> XSS Filtering completed
DEBUG - 2015-12-14 08:33:59 --> Unable to find validation rule: exists
DEBUG - 2015-12-14 08:33:59 --> XSS Filtering completed
DEBUG - 2015-12-14 08:33:59 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:33:59 --> URI Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Router Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Output Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Security Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Input Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:33:59 --> Language Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Language Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Config Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Loader Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:33:59 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:33:59 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Session Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:33:59 --> Session routines successfully run
DEBUG - 2015-12-14 08:33:59 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Email Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Controller Class Initialized
DEBUG - 2015-12-14 08:33:59 --> Admin MX_Controller Initialized
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:33:59 --> Model Class Initialized
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-14 08:33:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:34:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:34:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:34:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:34:00 --> Final output sent to browser
DEBUG - 2015-12-14 08:34:00 --> Total execution time: 0.8366
DEBUG - 2015-12-14 08:34:05 --> Config Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:34:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:34:05 --> URI Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Router Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Output Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Security Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Input Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:34:05 --> Language Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Language Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Config Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Loader Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:34:05 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:34:05 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Session Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:34:05 --> Session routines successfully run
DEBUG - 2015-12-14 08:34:05 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Email Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Controller Class Initialized
DEBUG - 2015-12-14 08:34:05 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:34:05 --> Model Class Initialized
DEBUG - 2015-12-14 08:34:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:34:05 --> Model Class Initialized
DEBUG - 2015-12-14 08:34:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:34:05 --> Model Class Initialized
DEBUG - 2015-12-14 08:34:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:34:05 --> Model Class Initialized
DEBUG - 2015-12-14 08:34:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:34:05 --> Model Class Initialized
DEBUG - 2015-12-14 08:34:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:34:05 --> Model Class Initialized
DEBUG - 2015-12-14 08:34:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:34:05 --> Model Class Initialized
DEBUG - 2015-12-14 08:34:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:34:06 --> Model Class Initialized
DEBUG - 2015-12-14 08:34:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:34:06 --> Model Class Initialized
DEBUG - 2015-12-14 08:34:06 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Config Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:35:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:35:47 --> URI Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Router Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Output Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Security Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Input Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:35:47 --> Language Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Language Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Config Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Loader Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:35:47 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:35:47 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Session Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:35:47 --> Session routines successfully run
DEBUG - 2015-12-14 08:35:47 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Email Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Controller Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:35:47 --> Model Class Initialized
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:35:47 --> Model Class Initialized
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:35:47 --> Model Class Initialized
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:35:47 --> Model Class Initialized
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:35:47 --> Model Class Initialized
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:35:47 --> Model Class Initialized
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:35:47 --> Model Class Initialized
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:35:47 --> Model Class Initialized
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:35:47 --> Model Class Initialized
DEBUG - 2015-12-14 08:35:47 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:35:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:35:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:35:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:35:48 --> Final output sent to browser
DEBUG - 2015-12-14 08:35:48 --> Total execution time: 0.2329
DEBUG - 2015-12-14 08:40:36 --> Config Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:40:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:40:36 --> URI Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Router Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Output Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Security Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Input Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:40:36 --> Language Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Language Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Config Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Loader Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:40:36 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:40:36 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Session Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:40:36 --> Session routines successfully run
DEBUG - 2015-12-14 08:40:36 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Email Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Controller Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:40:36 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:40:36 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:40:36 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:40:36 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:40:36 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:40:36 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:40:36 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:40:36 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:40:36 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:36 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:40:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:40:36 --> Final output sent to browser
DEBUG - 2015-12-14 08:40:36 --> Total execution time: 0.3089
DEBUG - 2015-12-14 08:40:38 --> Config Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:40:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:40:38 --> URI Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Router Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Output Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Security Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Input Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:40:38 --> Language Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Language Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Config Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Loader Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:40:38 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:40:38 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Session Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:40:38 --> Session routines successfully run
DEBUG - 2015-12-14 08:40:38 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Email Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Controller Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:40:38 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:40:38 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:40:38 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:40:38 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:40:38 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:40:38 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:40:38 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:40:38 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:40:38 --> Model Class Initialized
DEBUG - 2015-12-14 08:40:38 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:40:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:40:38 --> Final output sent to browser
DEBUG - 2015-12-14 08:40:38 --> Total execution time: 0.2413
DEBUG - 2015-12-14 08:41:48 --> Config Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:41:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:41:48 --> URI Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Router Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Output Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Security Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Input Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:41:48 --> Language Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Language Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Config Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Loader Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:41:48 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:41:48 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Session Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:41:48 --> Session routines successfully run
DEBUG - 2015-12-14 08:41:48 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Email Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Controller Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:41:48 --> Model Class Initialized
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:41:48 --> Model Class Initialized
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:41:48 --> Model Class Initialized
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:41:48 --> Model Class Initialized
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:41:48 --> Model Class Initialized
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:41:48 --> Model Class Initialized
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:41:48 --> Model Class Initialized
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:41:48 --> Model Class Initialized
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:41:48 --> Model Class Initialized
DEBUG - 2015-12-14 08:41:48 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:41:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:41:48 --> Final output sent to browser
DEBUG - 2015-12-14 08:41:48 --> Total execution time: 0.2515
DEBUG - 2015-12-14 08:43:20 --> Config Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:43:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:43:20 --> URI Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Router Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Output Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Security Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Input Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:43:20 --> Language Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Language Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Config Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Loader Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:43:20 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:43:20 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Session Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:43:20 --> Session routines successfully run
DEBUG - 2015-12-14 08:43:20 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Email Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Controller Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:43:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:43:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:43:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:43:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:43:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:43:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:43:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:43:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:43:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:43:20 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:43:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:43:20 --> Final output sent to browser
DEBUG - 2015-12-14 08:43:20 --> Total execution time: 0.2953
DEBUG - 2015-12-14 08:44:29 --> Config Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:44:29 --> URI Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Router Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Output Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Security Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Input Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:44:29 --> Language Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Language Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Config Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Loader Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:44:29 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:44:29 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Session Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:44:29 --> Session routines successfully run
DEBUG - 2015-12-14 08:44:29 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Email Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Controller Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:44:29 --> Model Class Initialized
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:44:29 --> Model Class Initialized
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:44:29 --> Model Class Initialized
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:44:29 --> Model Class Initialized
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:44:29 --> Model Class Initialized
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:44:29 --> Model Class Initialized
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:44:29 --> Model Class Initialized
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:44:29 --> Model Class Initialized
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:44:29 --> Model Class Initialized
DEBUG - 2015-12-14 08:44:29 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:44:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:44:29 --> Final output sent to browser
DEBUG - 2015-12-14 08:44:29 --> Total execution time: 0.2733
DEBUG - 2015-12-14 08:46:41 --> Config Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:46:41 --> URI Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Router Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Output Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Security Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Input Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:46:41 --> Language Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Language Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Config Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Loader Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:46:41 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:46:41 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Session Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:46:41 --> Session routines successfully run
DEBUG - 2015-12-14 08:46:41 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Email Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Controller Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:46:41 --> Model Class Initialized
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:46:41 --> Model Class Initialized
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:46:41 --> Model Class Initialized
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:46:41 --> Model Class Initialized
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:46:41 --> Model Class Initialized
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:46:41 --> Model Class Initialized
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:46:41 --> Model Class Initialized
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:46:41 --> Model Class Initialized
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:46:41 --> Model Class Initialized
DEBUG - 2015-12-14 08:46:41 --> Image Lib Class Initialized
ERROR - 2015-12-14 08:46:41 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\all_properties.php 3
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:46:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:46:41 --> Final output sent to browser
DEBUG - 2015-12-14 08:46:41 --> Total execution time: 0.3594
DEBUG - 2015-12-14 08:47:13 --> Config Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:47:13 --> URI Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Router Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Output Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Security Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Input Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:47:13 --> Language Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Language Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Config Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Loader Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:47:13 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:47:13 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Session Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:47:13 --> Session routines successfully run
DEBUG - 2015-12-14 08:47:13 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Email Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Controller Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:47:13 --> Model Class Initialized
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:47:13 --> Model Class Initialized
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:47:13 --> Model Class Initialized
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:47:13 --> Model Class Initialized
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:47:13 --> Model Class Initialized
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:47:13 --> Model Class Initialized
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:47:13 --> Model Class Initialized
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:47:13 --> Model Class Initialized
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:47:13 --> Model Class Initialized
DEBUG - 2015-12-14 08:47:13 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:47:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:47:13 --> Final output sent to browser
DEBUG - 2015-12-14 08:47:13 --> Total execution time: 0.2304
DEBUG - 2015-12-14 08:51:02 --> Config Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:51:02 --> URI Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Router Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Output Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Security Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Input Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:51:02 --> Language Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Language Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Config Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Loader Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:51:02 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:51:02 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Session Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:51:02 --> Session routines successfully run
DEBUG - 2015-12-14 08:51:02 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Email Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Controller Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:51:02 --> Model Class Initialized
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:51:02 --> Model Class Initialized
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:51:02 --> Model Class Initialized
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:51:02 --> Model Class Initialized
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:51:02 --> Model Class Initialized
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:51:02 --> Model Class Initialized
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:51:02 --> Model Class Initialized
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:51:02 --> Model Class Initialized
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:51:02 --> Model Class Initialized
DEBUG - 2015-12-14 08:51:02 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:51:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:51:02 --> Final output sent to browser
DEBUG - 2015-12-14 08:51:02 --> Total execution time: 0.2647
DEBUG - 2015-12-14 08:52:18 --> Config Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:52:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:52:18 --> URI Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Router Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Output Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Security Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Input Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:52:18 --> Language Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Language Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Config Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Loader Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:52:18 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:52:18 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Session Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:52:18 --> Session routines successfully run
DEBUG - 2015-12-14 08:52:18 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Email Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Controller Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:52:18 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:52:18 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:52:18 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:52:18 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:52:18 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:52:18 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:52:18 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:52:18 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:52:18 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:18 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:52:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:52:18 --> Final output sent to browser
DEBUG - 2015-12-14 08:52:18 --> Total execution time: 0.2328
DEBUG - 2015-12-14 08:52:20 --> Config Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Hooks Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Utf8 Class Initialized
DEBUG - 2015-12-14 08:52:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-14 08:52:20 --> URI Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Router Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Output Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Security Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Input Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-14 08:52:20 --> Language Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Language Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Config Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Loader Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Helper loaded: url_helper
DEBUG - 2015-12-14 08:52:20 --> Helper loaded: form_helper
DEBUG - 2015-12-14 08:52:20 --> Database Driver Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Session Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Helper loaded: string_helper
DEBUG - 2015-12-14 08:52:20 --> Session routines successfully run
DEBUG - 2015-12-14 08:52:20 --> Form Validation Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Pagination Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Encrypt Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Email Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Controller Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Property MX_Controller Initialized
DEBUG - 2015-12-14 08:52:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-14 08:52:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-14 08:52:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-14 08:52:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-14 08:52:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-14 08:52:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-14 08:52:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-14 08:52:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-14 08:52:20 --> Model Class Initialized
DEBUG - 2015-12-14 08:52:20 --> Image Lib Class Initialized
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-14 08:52:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-14 08:52:20 --> Final output sent to browser
DEBUG - 2015-12-14 08:52:20 --> Total execution time: 0.2903
