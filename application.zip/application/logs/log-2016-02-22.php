<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-22 07:43:17 --> Config Class Initialized
DEBUG - 2016-02-22 07:43:17 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:43:17 --> Utf8 Class Initialized
DEBUG - 2016-02-22 07:43:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-22 07:43:17 --> URI Class Initialized
DEBUG - 2016-02-22 07:43:18 --> Router Class Initialized
DEBUG - 2016-02-22 07:43:19 --> No URI present. Default controller set.
DEBUG - 2016-02-22 07:43:19 --> Output Class Initialized
DEBUG - 2016-02-22 07:43:19 --> Security Class Initialized
DEBUG - 2016-02-22 07:43:19 --> Input Class Initialized
DEBUG - 2016-02-22 07:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-22 07:43:20 --> Language Class Initialized
DEBUG - 2016-02-22 07:43:21 --> Language Class Initialized
DEBUG - 2016-02-22 07:43:21 --> Config Class Initialized
DEBUG - 2016-02-22 07:43:21 --> Loader Class Initialized
DEBUG - 2016-02-22 07:43:22 --> Helper loaded: url_helper
DEBUG - 2016-02-22 07:43:23 --> Helper loaded: form_helper
DEBUG - 2016-02-22 07:43:25 --> Database Driver Class Initialized
DEBUG - 2016-02-22 07:43:33 --> Session Class Initialized
DEBUG - 2016-02-22 07:43:33 --> Helper loaded: string_helper
DEBUG - 2016-02-22 07:43:33 --> A session cookie was not found.
DEBUG - 2016-02-22 07:43:33 --> Session routines successfully run
DEBUG - 2016-02-22 07:43:33 --> Form Validation Class Initialized
DEBUG - 2016-02-22 07:43:33 --> Pagination Class Initialized
DEBUG - 2016-02-22 07:43:33 --> Encrypt Class Initialized
DEBUG - 2016-02-22 07:43:33 --> Email Class Initialized
DEBUG - 2016-02-22 07:43:33 --> Controller Class Initialized
DEBUG - 2016-02-22 07:43:33 --> Auth MX_Controller Initialized
DEBUG - 2016-02-22 07:43:34 --> Model Class Initialized
DEBUG - 2016-02-22 07:43:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-22 07:43:34 --> Model Class Initialized
DEBUG - 2016-02-22 07:43:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-22 07:43:34 --> Model Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Config Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Utf8 Class Initialized
DEBUG - 2016-02-22 07:59:47 --> UTF-8 Support Enabled
DEBUG - 2016-02-22 07:59:47 --> URI Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Router Class Initialized
DEBUG - 2016-02-22 07:59:47 --> No URI present. Default controller set.
DEBUG - 2016-02-22 07:59:47 --> Output Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Security Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Input Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-22 07:59:47 --> Language Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Language Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Config Class Initialized
DEBUG - 2016-02-22 07:59:47 --> Loader Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Helper loaded: url_helper
DEBUG - 2016-02-22 07:59:48 --> Helper loaded: form_helper
DEBUG - 2016-02-22 07:59:48 --> Database Driver Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Session Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Helper loaded: string_helper
ERROR - 2016-02-22 07:59:48 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-22 07:59:48 --> Session routines successfully run
DEBUG - 2016-02-22 07:59:48 --> Form Validation Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Pagination Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Encrypt Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Email Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Controller Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Auth MX_Controller Initialized
DEBUG - 2016-02-22 07:59:48 --> Model Class Initialized
DEBUG - 2016-02-22 07:59:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-22 07:59:48 --> Model Class Initialized
DEBUG - 2016-02-22 07:59:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-22 07:59:48 --> Model Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Config Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Utf8 Class Initialized
DEBUG - 2016-02-22 07:59:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-22 07:59:48 --> URI Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Router Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Output Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Security Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Input Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-22 07:59:48 --> Language Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Language Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Config Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Loader Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Helper loaded: url_helper
DEBUG - 2016-02-22 07:59:48 --> Helper loaded: form_helper
DEBUG - 2016-02-22 07:59:48 --> Database Driver Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Session Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Helper loaded: string_helper
DEBUG - 2016-02-22 07:59:48 --> Session routines successfully run
DEBUG - 2016-02-22 07:59:48 --> Form Validation Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Pagination Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Encrypt Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Email Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Controller Class Initialized
DEBUG - 2016-02-22 07:59:48 --> Auth MX_Controller Initialized
DEBUG - 2016-02-22 07:59:48 --> Model Class Initialized
DEBUG - 2016-02-22 07:59:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-22 07:59:48 --> Model Class Initialized
DEBUG - 2016-02-22 07:59:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-22 07:59:48 --> Model Class Initialized
DEBUG - 2016-02-22 07:59:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-22 07:59:49 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-22 07:59:49 --> Final output sent to browser
DEBUG - 2016-02-22 07:59:49 --> Total execution time: 0.4883
DEBUG - 2016-02-22 07:59:49 --> Config Class Initialized
DEBUG - 2016-02-22 07:59:49 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Utf8 Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Config Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Utf8 Class Initialized
DEBUG - 2016-02-22 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-22 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-22 07:59:50 --> URI Class Initialized
DEBUG - 2016-02-22 07:59:50 --> URI Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Router Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Router Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Config Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Utf8 Class Initialized
DEBUG - 2016-02-22 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-22 07:59:50 --> URI Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Router Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Config Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Utf8 Class Initialized
DEBUG - 2016-02-22 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-22 07:59:50 --> URI Class Initialized
DEBUG - 2016-02-22 07:59:50 --> Router Class Initialized
ERROR - 2016-02-22 07:59:50 --> 404 Page Not Found --> 
ERROR - 2016-02-22 07:59:50 --> 404 Page Not Found --> 
ERROR - 2016-02-22 07:59:50 --> 404 Page Not Found --> 
ERROR - 2016-02-22 07:59:50 --> 404 Page Not Found --> 
DEBUG - 2016-02-22 21:08:49 --> Config Class Initialized
DEBUG - 2016-02-22 21:08:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 21:08:50 --> Utf8 Class Initialized
DEBUG - 2016-02-22 21:08:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-22 21:08:50 --> URI Class Initialized
DEBUG - 2016-02-22 21:08:51 --> Router Class Initialized
DEBUG - 2016-02-22 21:08:51 --> No URI present. Default controller set.
DEBUG - 2016-02-22 21:08:51 --> Output Class Initialized
DEBUG - 2016-02-22 21:08:51 --> Security Class Initialized
DEBUG - 2016-02-22 21:08:51 --> Input Class Initialized
DEBUG - 2016-02-22 21:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-22 21:08:51 --> Language Class Initialized
DEBUG - 2016-02-22 21:08:51 --> Language Class Initialized
DEBUG - 2016-02-22 21:08:51 --> Config Class Initialized
DEBUG - 2016-02-22 21:08:52 --> Loader Class Initialized
DEBUG - 2016-02-22 21:08:52 --> Helper loaded: url_helper
DEBUG - 2016-02-22 21:08:52 --> Helper loaded: form_helper
DEBUG - 2016-02-22 21:08:53 --> Database Driver Class Initialized
DEBUG - 2016-02-22 21:09:08 --> Session Class Initialized
DEBUG - 2016-02-22 21:09:08 --> Helper loaded: string_helper
DEBUG - 2016-02-22 21:09:09 --> A session cookie was not found.
DEBUG - 2016-02-22 21:09:09 --> Session routines successfully run
DEBUG - 2016-02-22 21:09:09 --> Form Validation Class Initialized
DEBUG - 2016-02-22 21:09:09 --> Pagination Class Initialized
DEBUG - 2016-02-22 21:09:09 --> Encrypt Class Initialized
DEBUG - 2016-02-22 21:09:09 --> Email Class Initialized
DEBUG - 2016-02-22 21:09:09 --> Controller Class Initialized
DEBUG - 2016-02-22 21:09:09 --> Auth MX_Controller Initialized
DEBUG - 2016-02-22 21:09:10 --> Model Class Initialized
DEBUG - 2016-02-22 21:09:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-22 21:09:10 --> Model Class Initialized
DEBUG - 2016-02-22 21:09:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-22 21:09:10 --> Model Class Initialized
