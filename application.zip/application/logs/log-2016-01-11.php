<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-11 07:34:39 --> Config Class Initialized
DEBUG - 2016-01-11 07:34:39 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:34:39 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:34:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:34:39 --> URI Class Initialized
DEBUG - 2016-01-11 07:34:41 --> Router Class Initialized
DEBUG - 2016-01-11 07:34:41 --> No URI present. Default controller set.
DEBUG - 2016-01-11 07:34:41 --> Output Class Initialized
DEBUG - 2016-01-11 07:34:41 --> Security Class Initialized
DEBUG - 2016-01-11 07:34:41 --> Input Class Initialized
DEBUG - 2016-01-11 07:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:34:41 --> Language Class Initialized
DEBUG - 2016-01-11 07:34:43 --> Language Class Initialized
DEBUG - 2016-01-11 07:34:43 --> Config Class Initialized
DEBUG - 2016-01-11 07:34:43 --> Loader Class Initialized
DEBUG - 2016-01-11 07:34:44 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:34:44 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:34:45 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:35:23 --> Session Class Initialized
DEBUG - 2016-01-11 07:35:23 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:35:23 --> A session cookie was not found.
DEBUG - 2016-01-11 07:35:23 --> Session routines successfully run
DEBUG - 2016-01-11 07:35:24 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:35:24 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:35:24 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:35:25 --> Email Class Initialized
DEBUG - 2016-01-11 07:35:25 --> Controller Class Initialized
DEBUG - 2016-01-11 07:35:25 --> Auth MX_Controller Initialized
DEBUG - 2016-01-11 07:35:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:35:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:35:26 --> Model Class Initialized
DEBUG - 2016-01-11 07:35:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:35:26 --> Model Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Config Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:35:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:35:29 --> URI Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Router Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Output Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Security Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Input Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:35:29 --> Language Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Language Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Config Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Loader Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:35:29 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:35:29 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Session Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:35:29 --> Session routines successfully run
DEBUG - 2016-01-11 07:35:29 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Email Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Controller Class Initialized
DEBUG - 2016-01-11 07:35:29 --> Auth MX_Controller Initialized
DEBUG - 2016-01-11 07:35:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:35:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:35:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:35:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:35:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:35:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 07:35:32 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-11 07:35:32 --> Final output sent to browser
DEBUG - 2016-01-11 07:35:32 --> Total execution time: 3.7353
DEBUG - 2016-01-11 07:35:53 --> Config Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:35:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:35:53 --> Config Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Config Class Initialized
DEBUG - 2016-01-11 07:35:53 --> URI Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Router Class Initialized
DEBUG - 2016-01-11 07:35:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:35:53 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:35:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:35:53 --> URI Class Initialized
DEBUG - 2016-01-11 07:35:53 --> URI Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Config Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:35:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:35:53 --> Router Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Router Class Initialized
DEBUG - 2016-01-11 07:35:53 --> URI Class Initialized
DEBUG - 2016-01-11 07:35:53 --> Router Class Initialized
ERROR - 2016-01-11 07:35:54 --> 404 Page Not Found --> 
ERROR - 2016-01-11 07:35:54 --> 404 Page Not Found --> 
ERROR - 2016-01-11 07:35:54 --> 404 Page Not Found --> 
ERROR - 2016-01-11 07:35:54 --> 404 Page Not Found --> 
DEBUG - 2016-01-11 07:37:53 --> Config Class Initialized
DEBUG - 2016-01-11 07:37:54 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:37:54 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:37:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:37:54 --> URI Class Initialized
DEBUG - 2016-01-11 07:37:55 --> Router Class Initialized
DEBUG - 2016-01-11 07:37:55 --> Output Class Initialized
DEBUG - 2016-01-11 07:37:55 --> Security Class Initialized
DEBUG - 2016-01-11 07:37:56 --> Input Class Initialized
DEBUG - 2016-01-11 07:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:37:56 --> Language Class Initialized
DEBUG - 2016-01-11 07:37:57 --> Language Class Initialized
DEBUG - 2016-01-11 07:37:57 --> Config Class Initialized
DEBUG - 2016-01-11 07:37:57 --> Loader Class Initialized
DEBUG - 2016-01-11 07:37:58 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:37:59 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:37:59 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:38:00 --> Session Class Initialized
DEBUG - 2016-01-11 07:38:01 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:38:01 --> Session routines successfully run
DEBUG - 2016-01-11 07:38:01 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:38:01 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:38:02 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:38:02 --> Email Class Initialized
DEBUG - 2016-01-11 07:38:02 --> Controller Class Initialized
DEBUG - 2016-01-11 07:38:02 --> Auth MX_Controller Initialized
DEBUG - 2016-01-11 07:38:02 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:38:02 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:38:03 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-11 07:38:03 --> XSS Filtering completed
DEBUG - 2016-01-11 07:38:03 --> Unable to find validation rule: exists
DEBUG - 2016-01-11 07:38:03 --> XSS Filtering completed
DEBUG - 2016-01-11 07:38:04 --> Config Class Initialized
DEBUG - 2016-01-11 07:38:04 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:38:04 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:38:04 --> URI Class Initialized
DEBUG - 2016-01-11 07:38:04 --> Router Class Initialized
DEBUG - 2016-01-11 07:38:04 --> Output Class Initialized
DEBUG - 2016-01-11 07:38:04 --> Security Class Initialized
DEBUG - 2016-01-11 07:38:05 --> Input Class Initialized
DEBUG - 2016-01-11 07:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:38:05 --> Language Class Initialized
DEBUG - 2016-01-11 07:38:05 --> Language Class Initialized
DEBUG - 2016-01-11 07:38:05 --> Config Class Initialized
DEBUG - 2016-01-11 07:38:05 --> Loader Class Initialized
DEBUG - 2016-01-11 07:38:05 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:38:05 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:38:05 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:38:06 --> Session Class Initialized
DEBUG - 2016-01-11 07:38:06 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:38:06 --> Session routines successfully run
DEBUG - 2016-01-11 07:38:06 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:38:06 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:38:06 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:38:06 --> Email Class Initialized
DEBUG - 2016-01-11 07:38:06 --> Controller Class Initialized
DEBUG - 2016-01-11 07:38:06 --> Admin MX_Controller Initialized
DEBUG - 2016-01-11 07:38:06 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:38:06 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:38:07 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:38:07 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:38:08 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:38:08 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:38:09 --> Model Class Initialized
DEBUG - 2016-01-11 07:38:10 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-11 07:38:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 07:38:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 07:38:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 07:38:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 07:38:11 --> Final output sent to browser
DEBUG - 2016-01-11 07:38:11 --> Total execution time: 7.1656
DEBUG - 2016-01-11 07:43:55 --> Config Class Initialized
DEBUG - 2016-01-11 07:43:55 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:43:55 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:43:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:43:55 --> URI Class Initialized
DEBUG - 2016-01-11 07:43:55 --> Router Class Initialized
ERROR - 2016-01-11 07:43:56 --> 404 Page Not Found --> 
DEBUG - 2016-01-11 07:45:05 --> Config Class Initialized
DEBUG - 2016-01-11 07:45:05 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:45:05 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:45:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:45:05 --> URI Class Initialized
DEBUG - 2016-01-11 07:45:05 --> Router Class Initialized
ERROR - 2016-01-11 07:45:05 --> 404 Page Not Found --> 
DEBUG - 2016-01-11 07:46:17 --> Config Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:46:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:46:17 --> URI Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Router Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Output Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Security Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Input Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:46:17 --> Language Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Language Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Config Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Loader Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:46:17 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:46:17 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Session Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:46:17 --> Session routines successfully run
DEBUG - 2016-01-11 07:46:17 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Email Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Controller Class Initialized
DEBUG - 2016-01-11 07:46:17 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:46:18 --> Model Class Initialized
DEBUG - 2016-01-11 07:46:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:46:18 --> Model Class Initialized
DEBUG - 2016-01-11 07:46:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:46:18 --> Model Class Initialized
DEBUG - 2016-01-11 07:46:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:46:18 --> Model Class Initialized
DEBUG - 2016-01-11 07:46:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:46:18 --> Model Class Initialized
DEBUG - 2016-01-11 07:46:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:46:18 --> Model Class Initialized
DEBUG - 2016-01-11 07:46:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:46:18 --> Model Class Initialized
DEBUG - 2016-01-11 07:46:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:46:18 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Config Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:47:03 --> URI Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Router Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Output Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Security Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Input Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:47:03 --> Language Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Language Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Config Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Loader Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:47:03 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:47:03 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Session Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:47:03 --> Session routines successfully run
DEBUG - 2016-01-11 07:47:03 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Email Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Controller Class Initialized
DEBUG - 2016-01-11 07:47:03 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:47:03 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:47:03 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:47:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:47:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:47:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:47:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:47:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:47:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Config Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:47:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:47:05 --> URI Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Router Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Output Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Security Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Input Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:47:05 --> Language Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Language Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Config Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Loader Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:47:05 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:47:05 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Session Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:47:05 --> Session routines successfully run
DEBUG - 2016-01-11 07:47:05 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Email Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Controller Class Initialized
DEBUG - 2016-01-11 07:47:05 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:47:05 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:47:05 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:47:05 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:47:05 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:47:05 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:47:05 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:47:05 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:47:05 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Config Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:47:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:47:55 --> URI Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Router Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Output Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Security Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Input Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:47:55 --> Language Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Language Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Config Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Loader Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:47:55 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:47:55 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Session Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:47:55 --> Session routines successfully run
DEBUG - 2016-01-11 07:47:55 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Email Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Controller Class Initialized
DEBUG - 2016-01-11 07:47:55 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:47:55 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:47:55 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:47:55 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:47:55 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:47:55 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:47:55 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:47:55 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:47:55 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Config Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:47:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:47:57 --> URI Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Router Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Output Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Security Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Input Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:47:57 --> Language Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Language Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Config Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Loader Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:47:57 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:47:57 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Session Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:47:57 --> Session routines successfully run
DEBUG - 2016-01-11 07:47:57 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Email Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Controller Class Initialized
DEBUG - 2016-01-11 07:47:57 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:47:57 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:47:57 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:47:57 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:47:57 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:47:57 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:47:57 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:47:57 --> Model Class Initialized
DEBUG - 2016-01-11 07:47:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:47:57 --> Model Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Config Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:48:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:48:47 --> URI Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Router Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Output Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Security Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Input Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:48:47 --> Language Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Language Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Config Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Loader Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:48:47 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:48:47 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Session Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:48:47 --> Session routines successfully run
DEBUG - 2016-01-11 07:48:47 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Email Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Controller Class Initialized
DEBUG - 2016-01-11 07:48:47 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:48:47 --> Model Class Initialized
DEBUG - 2016-01-11 07:48:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:48:47 --> Model Class Initialized
DEBUG - 2016-01-11 07:48:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:48:47 --> Model Class Initialized
DEBUG - 2016-01-11 07:48:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:48:47 --> Model Class Initialized
DEBUG - 2016-01-11 07:48:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:48:48 --> Model Class Initialized
DEBUG - 2016-01-11 07:48:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:48:48 --> Model Class Initialized
DEBUG - 2016-01-11 07:48:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:48:48 --> Model Class Initialized
DEBUG - 2016-01-11 07:48:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:48:48 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Config Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:49:36 --> URI Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Router Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Output Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Security Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Input Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:49:36 --> Language Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Language Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Config Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Loader Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:49:36 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:49:36 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Session Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:49:36 --> Session routines successfully run
DEBUG - 2016-01-11 07:49:36 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Email Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Controller Class Initialized
DEBUG - 2016-01-11 07:49:36 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:49:36 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:37 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:49:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:49:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:49:58 --> Config Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:49:58 --> URI Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Router Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Output Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Security Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Input Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:49:58 --> Language Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Language Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Config Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Loader Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:49:58 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:49:58 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Session Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:49:58 --> Session routines successfully run
DEBUG - 2016-01-11 07:49:58 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Email Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Controller Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:49:58 --> Model Class Initialized
DEBUG - 2016-01-11 07:49:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:50:00 --> Config Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:50:00 --> URI Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Router Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Output Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Security Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Input Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:50:00 --> Language Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Language Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Config Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Loader Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:50:00 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:50:00 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Session Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:50:00 --> Session routines successfully run
DEBUG - 2016-01-11 07:50:00 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Email Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Controller Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:50:00 --> Model Class Initialized
DEBUG - 2016-01-11 07:50:00 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:51:04 --> Config Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:51:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:51:04 --> URI Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Router Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Output Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Security Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Input Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:51:04 --> Language Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Language Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Config Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Loader Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:51:04 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:51:04 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Session Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:51:04 --> Session routines successfully run
DEBUG - 2016-01-11 07:51:04 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Email Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Controller Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:04 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:51:04 --> Model Class Initialized
DEBUG - 2016-01-11 07:51:05 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 07:51:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 07:51:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 07:51:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 07:51:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 07:51:05 --> Final output sent to browser
DEBUG - 2016-01-11 07:51:05 --> Total execution time: 1.0803
DEBUG - 2016-01-11 07:52:17 --> Config Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:52:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:52:17 --> URI Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Router Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Output Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Security Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Input Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:52:17 --> Language Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Language Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Config Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Loader Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:52:17 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:52:17 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Session Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:52:17 --> Session routines successfully run
DEBUG - 2016-01-11 07:52:17 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Email Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Controller Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:52:17 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 07:52:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 07:52:17 --> Final output sent to browser
DEBUG - 2016-01-11 07:52:17 --> Total execution time: 0.5645
DEBUG - 2016-01-11 07:52:25 --> Config Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:52:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:52:25 --> URI Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Router Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Output Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Security Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Input Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:52:25 --> Language Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Language Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Config Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Loader Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:52:25 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:52:25 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Session Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:52:25 --> Session routines successfully run
DEBUG - 2016-01-11 07:52:25 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Email Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Controller Class Initialized
DEBUG - 2016-01-11 07:52:25 --> leases MX_Controller Initialized
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:52:25 --> Model Class Initialized
DEBUG - 2016-01-11 07:52:25 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 07:52:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 07:52:25 --> Final output sent to browser
DEBUG - 2016-01-11 07:52:25 --> Total execution time: 0.7952
DEBUG - 2016-01-11 07:54:13 --> Config Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:54:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:54:13 --> URI Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Router Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Output Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Security Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Input Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:54:13 --> Language Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Language Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Config Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Loader Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:54:13 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:54:13 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Session Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:54:13 --> Session routines successfully run
DEBUG - 2016-01-11 07:54:13 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Email Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Controller Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:54:13 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:14 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:54:14 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:14 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:54:14 --> Model Class Initialized
ERROR - 2016-01-11 07:54:14 --> Severity: Notice  --> Undefined variable: query C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 6
DEBUG - 2016-01-11 07:54:32 --> Config Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:54:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:54:32 --> URI Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Router Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Output Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Security Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Input Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:54:32 --> Language Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Language Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Config Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Loader Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:54:32 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:54:32 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Session Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:54:32 --> Session routines successfully run
DEBUG - 2016-01-11 07:54:32 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Email Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Controller Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
DEBUG - 2016-01-11 07:54:32 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:54:32 --> Model Class Initialized
ERROR - 2016-01-11 07:54:32 --> Severity: Notice  --> Undefined property: stdClass::$property_name C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 33
DEBUG - 2016-01-11 07:55:37 --> Config Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:55:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:55:37 --> URI Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Router Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Output Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Security Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Input Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:55:37 --> Language Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Language Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Config Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Loader Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:55:37 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:55:37 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Session Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:55:37 --> Session routines successfully run
DEBUG - 2016-01-11 07:55:37 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Email Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Controller Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:55:37 --> Model Class Initialized
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 07:55:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 07:55:37 --> Final output sent to browser
DEBUG - 2016-01-11 07:55:37 --> Total execution time: 0.3544
DEBUG - 2016-01-11 07:56:11 --> Config Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:56:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:56:11 --> URI Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Router Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Output Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Security Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Input Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:56:11 --> Language Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Language Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Config Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Loader Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:56:11 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:56:11 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Session Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:56:11 --> Session routines successfully run
DEBUG - 2016-01-11 07:56:11 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Email Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Controller Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:56:11 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:11 --> DB Transaction Failure
ERROR - 2016-01-11 07:56:11 --> Query error: Unknown column '
LIMIT 20' in 'order clause'
DEBUG - 2016-01-11 07:56:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-11 07:56:29 --> Config Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:56:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:56:29 --> URI Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Router Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Output Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Security Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Input Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:56:29 --> Language Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Language Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Config Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Loader Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:56:29 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:56:29 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Session Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:56:29 --> Session routines successfully run
DEBUG - 2016-01-11 07:56:29 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Email Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Controller Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:56:29 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:29 --> DB Transaction Failure
ERROR - 2016-01-11 07:56:29 --> Query error: Unknown column '
LIMIT 20' in 'order clause'
DEBUG - 2016-01-11 07:56:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-11 07:56:42 --> Config Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:56:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:56:42 --> URI Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Router Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Output Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Security Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Input Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:56:42 --> Language Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Language Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Config Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Loader Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:56:42 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:56:42 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Session Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:56:42 --> Session routines successfully run
DEBUG - 2016-01-11 07:56:42 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Email Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Controller Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:56:42 --> Model Class Initialized
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 07:56:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 07:56:42 --> Final output sent to browser
DEBUG - 2016-01-11 07:56:42 --> Total execution time: 0.4252
DEBUG - 2016-01-11 07:57:23 --> Config Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Hooks Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Utf8 Class Initialized
DEBUG - 2016-01-11 07:57:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 07:57:23 --> URI Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Router Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Output Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Security Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Input Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 07:57:23 --> Language Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Language Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Config Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Loader Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Helper loaded: url_helper
DEBUG - 2016-01-11 07:57:23 --> Helper loaded: form_helper
DEBUG - 2016-01-11 07:57:23 --> Database Driver Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Session Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Helper loaded: string_helper
DEBUG - 2016-01-11 07:57:23 --> Session routines successfully run
DEBUG - 2016-01-11 07:57:23 --> Form Validation Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Pagination Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Encrypt Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Email Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Controller Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> Image Lib Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 07:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 07:57:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 07:57:23 --> Final output sent to browser
DEBUG - 2016-01-11 07:57:23 --> Total execution time: 0.2634
DEBUG - 2016-01-11 08:00:23 --> Config Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:00:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:00:23 --> URI Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Router Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Output Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Security Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Input Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:00:23 --> Language Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Language Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Config Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Loader Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:00:23 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:00:23 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Session Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:00:23 --> Session routines successfully run
DEBUG - 2016-01-11 08:00:23 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Email Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Controller Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:00:23 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:00:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:00:23 --> Final output sent to browser
DEBUG - 2016-01-11 08:00:23 --> Total execution time: 0.2854
DEBUG - 2016-01-11 08:00:51 --> Config Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:00:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:00:51 --> URI Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Router Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Output Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Security Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Input Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:00:51 --> Language Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Language Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Config Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Loader Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:00:51 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:00:51 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Session Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:00:51 --> Session routines successfully run
DEBUG - 2016-01-11 08:00:51 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Email Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Controller Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:00:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:00:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:00:51 --> Final output sent to browser
DEBUG - 2016-01-11 08:00:51 --> Total execution time: 0.3606
DEBUG - 2016-01-11 08:01:05 --> Config Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:01:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:01:05 --> URI Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Router Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Output Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Security Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Input Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:01:05 --> Language Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Language Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Config Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Loader Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:01:05 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:01:05 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Session Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:01:05 --> Session routines successfully run
DEBUG - 2016-01-11 08:01:05 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Email Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Controller Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:01:05 --> Model Class Initialized
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:01:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:01:05 --> Final output sent to browser
DEBUG - 2016-01-11 08:01:05 --> Total execution time: 0.2856
DEBUG - 2016-01-11 08:03:02 --> Config Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:03:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:03:02 --> URI Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Router Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Output Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Security Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Input Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:03:02 --> Language Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Language Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Config Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Loader Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:03:02 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:03:02 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Session Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:03:02 --> Session routines successfully run
DEBUG - 2016-01-11 08:03:02 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Email Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Controller Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:03:02 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:03:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:03:02 --> Final output sent to browser
DEBUG - 2016-01-11 08:03:02 --> Total execution time: 0.3176
DEBUG - 2016-01-11 08:03:30 --> Config Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:03:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:03:30 --> URI Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Router Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Output Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Security Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Input Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:03:30 --> Language Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Language Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Config Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Loader Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:03:30 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:03:30 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Session Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:03:30 --> Session routines successfully run
DEBUG - 2016-01-11 08:03:30 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Email Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Controller Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:03:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:03:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:03:30 --> Final output sent to browser
DEBUG - 2016-01-11 08:03:30 --> Total execution time: 0.2682
DEBUG - 2016-01-11 08:03:59 --> Config Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:03:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:03:59 --> URI Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Router Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Output Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Security Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Input Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:03:59 --> Language Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Language Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Config Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Loader Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:03:59 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:03:59 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Session Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:03:59 --> Session routines successfully run
DEBUG - 2016-01-11 08:03:59 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Email Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Controller Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:03:59 --> Model Class Initialized
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:03:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:03:59 --> Final output sent to browser
DEBUG - 2016-01-11 08:03:59 --> Total execution time: 0.3175
DEBUG - 2016-01-11 08:04:33 --> Config Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:04:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:04:33 --> URI Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Router Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Output Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Security Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Input Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:04:33 --> Language Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Language Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Config Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Loader Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:04:33 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:04:33 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Session Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:04:33 --> Session routines successfully run
DEBUG - 2016-01-11 08:04:33 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Email Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Controller Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:33 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:04:33 --> Model Class Initialized
DEBUG - 2016-01-11 08:04:34 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:04:34 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:04:34 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:04:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:04:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:04:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:04:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:04:34 --> Final output sent to browser
DEBUG - 2016-01-11 08:04:34 --> Total execution time: 0.4152
DEBUG - 2016-01-11 08:05:04 --> Config Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:05:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:05:04 --> URI Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Router Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Output Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Security Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Input Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:05:04 --> Language Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Language Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Config Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Loader Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:05:04 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:05:04 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Session Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:05:04 --> Session routines successfully run
DEBUG - 2016-01-11 08:05:04 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Email Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Controller Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:05:04 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:05:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:05:04 --> Final output sent to browser
DEBUG - 2016-01-11 08:05:04 --> Total execution time: 0.2593
DEBUG - 2016-01-11 08:05:58 --> Config Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:05:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:05:58 --> URI Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Router Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Output Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Security Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Input Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:05:58 --> Language Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Language Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Config Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Loader Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:05:58 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:05:58 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Session Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:05:58 --> Session routines successfully run
DEBUG - 2016-01-11 08:05:58 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Email Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Controller Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:05:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:05:58 --> Final output sent to browser
DEBUG - 2016-01-11 08:05:58 --> Total execution time: 0.2579
DEBUG - 2016-01-11 08:06:35 --> Config Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:06:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:06:35 --> URI Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Router Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Output Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Security Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Input Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:06:35 --> Language Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Language Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Config Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Loader Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:06:35 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:06:35 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Session Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:06:35 --> Session routines successfully run
DEBUG - 2016-01-11 08:06:35 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Email Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Controller Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:06:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:06:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:06:35 --> Final output sent to browser
DEBUG - 2016-01-11 08:06:35 --> Total execution time: 0.2577
DEBUG - 2016-01-11 08:37:28 --> Config Class Initialized
DEBUG - 2016-01-11 08:37:28 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:37:28 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:37:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:37:28 --> URI Class Initialized
DEBUG - 2016-01-11 08:37:29 --> Router Class Initialized
DEBUG - 2016-01-11 08:37:29 --> Output Class Initialized
DEBUG - 2016-01-11 08:37:29 --> Security Class Initialized
DEBUG - 2016-01-11 08:37:29 --> Input Class Initialized
DEBUG - 2016-01-11 08:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:37:29 --> Language Class Initialized
DEBUG - 2016-01-11 08:37:29 --> Language Class Initialized
DEBUG - 2016-01-11 08:37:29 --> Config Class Initialized
DEBUG - 2016-01-11 08:37:29 --> Loader Class Initialized
DEBUG - 2016-01-11 08:37:29 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:37:29 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:37:29 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:37:30 --> Session Class Initialized
DEBUG - 2016-01-11 08:37:30 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:37:30 --> Session routines successfully run
DEBUG - 2016-01-11 08:37:30 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:37:30 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:37:30 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:37:30 --> Email Class Initialized
DEBUG - 2016-01-11 08:37:30 --> Controller Class Initialized
DEBUG - 2016-01-11 08:37:30 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:37:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:37:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:37:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:37:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:37:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:37:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:37:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:37:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:37:31 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:37:31 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:31 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:37:31 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:37:31 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:37:31 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:37:31 --> Model Class Initialized
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:37:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:37:31 --> Final output sent to browser
DEBUG - 2016-01-11 08:37:31 --> Total execution time: 3.4417
DEBUG - 2016-01-11 08:41:34 --> Config Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:41:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:41:34 --> URI Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Router Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Output Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Security Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Input Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:41:34 --> Language Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Language Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Config Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Loader Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:41:34 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:41:34 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Session Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:41:34 --> Session routines successfully run
DEBUG - 2016-01-11 08:41:34 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Email Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Controller Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:41:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:41:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:41:34 --> Final output sent to browser
DEBUG - 2016-01-11 08:41:34 --> Total execution time: 0.2884
DEBUG - 2016-01-11 08:41:38 --> Config Class Initialized
DEBUG - 2016-01-11 08:41:38 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:41:38 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:41:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:41:38 --> URI Class Initialized
DEBUG - 2016-01-11 08:41:38 --> Router Class Initialized
ERROR - 2016-01-11 08:41:38 --> 404 Page Not Found --> 
DEBUG - 2016-01-11 08:41:56 --> Config Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:41:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:41:56 --> URI Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Router Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Output Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Security Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Input Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:41:56 --> Language Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Language Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Config Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Loader Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:41:56 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:41:56 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Session Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:41:56 --> Session routines successfully run
DEBUG - 2016-01-11 08:41:56 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Email Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Controller Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:41:56 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:41:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:41:56 --> Final output sent to browser
DEBUG - 2016-01-11 08:41:56 --> Total execution time: 0.3241
DEBUG - 2016-01-11 08:41:58 --> Config Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:41:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:41:58 --> URI Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Router Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Output Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Security Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Input Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:41:58 --> Language Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Language Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Config Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Loader Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:41:58 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:41:58 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Session Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:41:58 --> Session routines successfully run
DEBUG - 2016-01-11 08:41:58 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Email Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Controller Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:41:58 --> Model Class Initialized
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:41:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:41:58 --> Final output sent to browser
DEBUG - 2016-01-11 08:41:58 --> Total execution time: 0.2677
DEBUG - 2016-01-11 08:46:34 --> Config Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:46:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:46:34 --> URI Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Router Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Output Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Security Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Input Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:46:34 --> Language Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Language Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Config Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Loader Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:46:34 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:46:34 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Session Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:46:34 --> Session routines successfully run
DEBUG - 2016-01-11 08:46:34 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Email Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Controller Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:34 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:46:34 --> Model Class Initialized
ERROR - 2016-01-11 08:46:34 --> Severity: Notice  --> Undefined variable: visit_type_name C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 4
ERROR - 2016-01-11 08:46:34 --> Severity: Notice  --> Undefined variable: patient_surname C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 40
ERROR - 2016-01-11 08:46:34 --> Severity: Notice  --> Undefined variable: patient_othernames C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 51
ERROR - 2016-01-11 08:46:34 --> Severity: Notice  --> Undefined variable: account_balance C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 62
ERROR - 2016-01-11 08:46:34 --> Severity: Notice  --> Undefined variable: patient_id C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 70
DEBUG - 2016-01-11 08:46:53 --> Config Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:46:53 --> URI Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Router Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Output Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Security Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Input Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:46:53 --> Language Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Language Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Config Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Loader Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:46:53 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:46:53 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Session Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:46:53 --> Session routines successfully run
DEBUG - 2016-01-11 08:46:53 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Email Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Controller Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
DEBUG - 2016-01-11 08:46:53 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:46:53 --> Model Class Initialized
ERROR - 2016-01-11 08:46:53 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 4
ERROR - 2016-01-11 08:46:53 --> Severity: Notice  --> Undefined variable: patient_surname C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 40
ERROR - 2016-01-11 08:46:53 --> Severity: Notice  --> Undefined variable: patient_othernames C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 51
ERROR - 2016-01-11 08:46:53 --> Severity: Notice  --> Undefined variable: account_balance C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 62
ERROR - 2016-01-11 08:46:53 --> Severity: Notice  --> Undefined variable: patient_id C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 70
DEBUG - 2016-01-11 08:47:18 --> Config Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:47:18 --> URI Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Router Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Output Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Security Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Input Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:47:18 --> Language Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Language Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Config Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Loader Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:47:18 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:47:18 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Session Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:47:18 --> Session routines successfully run
DEBUG - 2016-01-11 08:47:18 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Email Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Controller Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:47:18 --> Model Class Initialized
ERROR - 2016-01-11 08:47:18 --> Severity: Notice  --> Undefined variable: patient_surname C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 40
ERROR - 2016-01-11 08:47:18 --> Severity: Notice  --> Undefined variable: patient_othernames C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 51
ERROR - 2016-01-11 08:47:18 --> Severity: Notice  --> Undefined variable: account_balance C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 62
ERROR - 2016-01-11 08:47:18 --> Severity: Notice  --> Undefined variable: patient_id C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 70
DEBUG - 2016-01-11 08:47:41 --> Config Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:47:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:47:41 --> URI Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Router Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Output Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Security Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Input Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:47:41 --> Language Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Language Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Config Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Loader Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:47:41 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:47:41 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Session Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:47:41 --> Session routines successfully run
DEBUG - 2016-01-11 08:47:41 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Email Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Controller Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:41 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:47:41 --> Model Class Initialized
ERROR - 2016-01-11 08:47:41 --> Severity: Notice  --> Undefined variable: patient_surname C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 40
ERROR - 2016-01-11 08:47:41 --> Severity: Notice  --> Undefined variable: patient_othernames C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 51
ERROR - 2016-01-11 08:47:41 --> Severity: Notice  --> Undefined variable: account_balance C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 62
ERROR - 2016-01-11 08:47:41 --> Severity: Notice  --> Undefined variable: patient_id C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 70
DEBUG - 2016-01-11 08:47:48 --> Config Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:47:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:47:48 --> URI Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Router Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Output Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Security Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Input Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:47:48 --> Language Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Language Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Config Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Loader Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:47:48 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:47:48 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Session Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:47:48 --> Session routines successfully run
DEBUG - 2016-01-11 08:47:48 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Email Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Controller Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:47:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:47:48 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Config Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:48:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:48:37 --> URI Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Router Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Output Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Security Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Input Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:48:37 --> Language Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Language Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Config Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Loader Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:48:37 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:48:37 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Session Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:48:37 --> Session routines successfully run
DEBUG - 2016-01-11 08:48:37 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Email Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Controller Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
DEBUG - 2016-01-11 08:48:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:48:37 --> Model Class Initialized
ERROR - 2016-01-11 08:48:37 --> Severity: Notice  --> Undefined variable: total_payments C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 122
ERROR - 2016-01-11 08:48:37 --> Severity: Notice  --> Undefined variable: total_amount C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 122
ERROR - 2016-01-11 08:48:37 --> Severity: Notice  --> Undefined variable: close_page C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 143
DEBUG - 2016-01-11 08:49:11 --> Config Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:49:11 --> URI Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Router Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Output Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Security Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Input Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:49:11 --> Language Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Language Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Config Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Loader Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:49:11 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:49:11 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Session Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:49:11 --> Session routines successfully run
DEBUG - 2016-01-11 08:49:11 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Email Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Controller Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
DEBUG - 2016-01-11 08:49:11 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:49:11 --> Model Class Initialized
ERROR - 2016-01-11 08:49:11 --> Severity: Notice  --> Undefined variable: close_page C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 143
DEBUG - 2016-01-11 08:50:17 --> Config Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:50:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:50:17 --> URI Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Router Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Output Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Security Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Input Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:50:17 --> Language Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Language Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Config Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Loader Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:50:17 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:50:17 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Session Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:50:17 --> Session routines successfully run
DEBUG - 2016-01-11 08:50:17 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Email Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Controller Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:17 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:50:17 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Config Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:50:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:50:51 --> URI Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Router Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Output Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Security Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Input Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:50:51 --> Language Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Language Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Config Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Loader Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:50:51 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:50:51 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Session Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:50:51 --> Session routines successfully run
DEBUG - 2016-01-11 08:50:51 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Email Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Controller Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 08:50:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:50:51 --> Model Class Initialized
ERROR - 2016-01-11 08:50:51 --> Severity: Notice  --> Undefined property: CI::$database C:\xampp\htdocs\rents\system\core\Model.php 52
DEBUG - 2016-01-11 08:51:30 --> Config Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:51:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:51:30 --> URI Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Router Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Output Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Security Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Input Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:51:30 --> Language Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Language Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Config Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Loader Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:51:30 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:51:30 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Session Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:51:30 --> Session routines successfully run
DEBUG - 2016-01-11 08:51:30 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Email Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Controller Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:51:30 --> Model Class Initialized
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:51:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:51:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:51:30 --> Final output sent to browser
DEBUG - 2016-01-11 08:51:30 --> Total execution time: 0.4166
DEBUG - 2016-01-11 08:52:35 --> Config Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:52:35 --> URI Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Router Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Output Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Security Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Input Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:52:35 --> Language Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Language Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Config Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Loader Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:52:35 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:52:35 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Session Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:52:35 --> Session routines successfully run
DEBUG - 2016-01-11 08:52:35 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Email Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Controller Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:52:35 --> Model Class Initialized
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 194
ERROR - 2016-01-11 08:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 195
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:52:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:52:35 --> Final output sent to browser
DEBUG - 2016-01-11 08:52:35 --> Total execution time: 0.5902
DEBUG - 2016-01-11 08:55:06 --> Config Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:55:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:55:06 --> URI Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Router Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Output Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Security Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Input Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:55:06 --> Language Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Language Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Config Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Loader Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:55:06 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:55:06 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Session Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:55:06 --> Session routines successfully run
DEBUG - 2016-01-11 08:55:06 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Email Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Controller Class Initialized
DEBUG - 2016-01-11 08:55:06 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:55:06 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:55:06 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:55:07 --> Model Class Initialized
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 176
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 177
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 176
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 177
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 176
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 177
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 176
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 177
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 176
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 177
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 176
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 177
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 176
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 177
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 176
ERROR - 2016-01-11 08:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 177
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:55:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:55:07 --> Final output sent to browser
DEBUG - 2016-01-11 08:55:07 --> Total execution time: 0.5619
DEBUG - 2016-01-11 08:55:29 --> Config Class Initialized
DEBUG - 2016-01-11 08:55:29 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:55:29 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:55:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:55:29 --> URI Class Initialized
DEBUG - 2016-01-11 08:55:29 --> Router Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Output Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Security Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Input Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:55:30 --> Language Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Language Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Config Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Loader Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:55:30 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:55:30 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Session Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:55:30 --> Session routines successfully run
DEBUG - 2016-01-11 08:55:30 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Email Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Controller Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:55:30 --> Model Class Initialized
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 147
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 148
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 147
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 148
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 147
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 148
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 147
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 148
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 147
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 148
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 147
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 148
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 147
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 148
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 147
ERROR - 2016-01-11 08:55:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 148
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:55:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:55:30 --> Final output sent to browser
DEBUG - 2016-01-11 08:55:30 --> Total execution time: 0.7293
DEBUG - 2016-01-11 08:56:40 --> Config Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Hooks Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Utf8 Class Initialized
DEBUG - 2016-01-11 08:56:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 08:56:40 --> URI Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Router Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Output Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Security Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Input Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 08:56:40 --> Language Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Language Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Config Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Loader Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Helper loaded: url_helper
DEBUG - 2016-01-11 08:56:40 --> Helper loaded: form_helper
DEBUG - 2016-01-11 08:56:40 --> Database Driver Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Session Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Helper loaded: string_helper
DEBUG - 2016-01-11 08:56:40 --> Session routines successfully run
DEBUG - 2016-01-11 08:56:40 --> Form Validation Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Pagination Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Encrypt Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Email Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Controller Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> Image Lib Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 08:56:40 --> Model Class Initialized
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 145
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 146
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 145
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 146
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 145
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 146
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 145
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 146
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 145
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 146
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 145
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 146
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 145
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 146
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 145
ERROR - 2016-01-11 08:56:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 146
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 08:56:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 08:56:40 --> Final output sent to browser
DEBUG - 2016-01-11 08:56:40 --> Total execution time: 0.3633
DEBUG - 2016-01-11 09:05:14 --> Config Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:05:15 --> URI Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Router Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Output Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Security Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Input Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:05:15 --> Language Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Language Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Config Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Loader Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:05:15 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:05:15 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Session Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:05:15 --> Session routines successfully run
DEBUG - 2016-01-11 09:05:15 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Email Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Controller Class Initialized
DEBUG - 2016-01-11 09:05:15 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:05:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:05:16 --> Model Class Initialized
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:05:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:05:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:05:16 --> Final output sent to browser
DEBUG - 2016-01-11 09:05:16 --> Total execution time: 1.7289
DEBUG - 2016-01-11 09:06:58 --> Config Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:06:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:06:58 --> URI Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Router Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Output Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Security Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Input Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:06:58 --> Language Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Language Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Config Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Loader Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:06:58 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:06:58 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Session Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:06:58 --> Session routines successfully run
DEBUG - 2016-01-11 09:06:58 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Email Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Controller Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:06:58 --> Model Class Initialized
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:06:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:06:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:06:58 --> Final output sent to browser
DEBUG - 2016-01-11 09:06:58 --> Total execution time: 0.4358
DEBUG - 2016-01-11 09:07:28 --> Config Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:07:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:07:28 --> URI Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Router Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Output Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Security Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Input Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:07:28 --> Language Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Language Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Config Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Loader Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:07:28 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:07:28 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Session Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:07:28 --> Session routines successfully run
DEBUG - 2016-01-11 09:07:28 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Email Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Controller Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:07:28 --> Model Class Initialized
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:07:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:07:28 --> Final output sent to browser
DEBUG - 2016-01-11 09:07:28 --> Total execution time: 0.3723
DEBUG - 2016-01-11 09:07:31 --> Config Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:07:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:07:31 --> URI Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Router Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Output Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Security Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Input Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:07:31 --> Language Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Language Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Config Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Loader Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:07:31 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:07:31 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Session Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:07:31 --> Session routines successfully run
DEBUG - 2016-01-11 09:07:31 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Email Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Controller Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:07:31 --> Model Class Initialized
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:07:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:07:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:07:31 --> Final output sent to browser
DEBUG - 2016-01-11 09:07:31 --> Total execution time: 0.4516
DEBUG - 2016-01-11 09:08:21 --> Config Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:08:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:08:21 --> URI Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Router Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Output Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Security Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Input Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:08:21 --> Language Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Language Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Config Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Loader Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:08:21 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:08:21 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Session Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:08:21 --> Session routines successfully run
DEBUG - 2016-01-11 09:08:21 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Email Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Controller Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:08:21 --> Model Class Initialized
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:08:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:08:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:08:21 --> Final output sent to browser
DEBUG - 2016-01-11 09:08:21 --> Total execution time: 0.3349
DEBUG - 2016-01-11 09:18:15 --> Config Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:18:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:18:15 --> URI Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Router Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Output Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Security Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Input Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:18:15 --> Language Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Language Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Config Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Loader Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:18:15 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:18:15 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Session Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:18:15 --> Session routines successfully run
DEBUG - 2016-01-11 09:18:15 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Email Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Controller Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:18:15 --> Model Class Initialized
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:18:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:18:15 --> Final output sent to browser
DEBUG - 2016-01-11 09:18:15 --> Total execution time: 0.3077
DEBUG - 2016-01-11 09:20:30 --> Config Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:20:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:20:30 --> URI Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Router Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Output Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Security Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Input Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:20:30 --> Language Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Language Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Config Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Loader Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:20:30 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:20:30 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Session Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:20:30 --> Session routines successfully run
DEBUG - 2016-01-11 09:20:30 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Email Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Controller Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:20:30 --> Model Class Initialized
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:20:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:20:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:20:30 --> Final output sent to browser
DEBUG - 2016-01-11 09:20:30 --> Total execution time: 0.3423
DEBUG - 2016-01-11 09:22:05 --> Config Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:22:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:22:05 --> URI Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Router Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Output Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Security Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Input Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:22:05 --> Language Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Language Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Config Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Loader Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:22:05 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:22:05 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Session Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:22:05 --> Session routines successfully run
DEBUG - 2016-01-11 09:22:05 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Email Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Controller Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:22:05 --> Model Class Initialized
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:22:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:22:05 --> Final output sent to browser
DEBUG - 2016-01-11 09:22:05 --> Total execution time: 0.3500
DEBUG - 2016-01-11 09:22:25 --> Config Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:22:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:22:25 --> URI Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Router Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Output Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Security Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Input Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:22:25 --> Language Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Language Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Config Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Loader Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:22:25 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:22:25 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Session Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:22:25 --> Session routines successfully run
DEBUG - 2016-01-11 09:22:25 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Email Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Controller Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:22:25 --> Model Class Initialized
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:22:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:22:25 --> Final output sent to browser
DEBUG - 2016-01-11 09:22:25 --> Total execution time: 0.3105
DEBUG - 2016-01-11 09:23:10 --> Config Class Initialized
DEBUG - 2016-01-11 09:23:10 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:23:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:23:11 --> URI Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Router Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Output Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Security Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Input Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:23:11 --> Language Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Language Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Config Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Loader Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:23:11 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:23:11 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Session Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:23:11 --> Session routines successfully run
DEBUG - 2016-01-11 09:23:11 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Email Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Controller Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:23:11 --> Model Class Initialized
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:23:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:23:11 --> Final output sent to browser
DEBUG - 2016-01-11 09:23:11 --> Total execution time: 0.4074
DEBUG - 2016-01-11 09:23:40 --> Config Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:23:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:23:40 --> URI Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Router Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Output Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Security Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Input Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:23:40 --> Language Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Language Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Config Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Loader Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:23:40 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:23:40 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Session Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:23:40 --> Session routines successfully run
DEBUG - 2016-01-11 09:23:40 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Email Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Controller Class Initialized
DEBUG - 2016-01-11 09:23:40 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:23:40 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:41 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:23:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:23:41 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:23:41 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:41 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:23:41 --> Model Class Initialized
DEBUG - 2016-01-11 09:23:41 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:23:41 --> Model Class Initialized
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:23:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:23:41 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:23:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:23:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:23:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:23:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:23:41 --> Final output sent to browser
DEBUG - 2016-01-11 09:23:41 --> Total execution time: 0.3362
DEBUG - 2016-01-11 09:27:47 --> Config Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:27:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:27:48 --> URI Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Router Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Output Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Security Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Input Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:27:48 --> Language Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Language Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Config Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Loader Class Initialized
DEBUG - 2016-01-11 09:27:48 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:27:48 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:27:48 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:27:49 --> Session Class Initialized
DEBUG - 2016-01-11 09:27:49 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:27:49 --> Session routines successfully run
DEBUG - 2016-01-11 09:27:49 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:27:49 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:27:49 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:27:49 --> Email Class Initialized
DEBUG - 2016-01-11 09:27:49 --> Controller Class Initialized
DEBUG - 2016-01-11 09:27:49 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:27:49 --> Model Class Initialized
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:27:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:27:49 --> Final output sent to browser
DEBUG - 2016-01-11 09:27:49 --> Total execution time: 2.2063
DEBUG - 2016-01-11 09:28:07 --> Config Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:28:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:28:07 --> URI Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Router Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Output Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Security Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Input Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:28:07 --> Language Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Language Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Config Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Loader Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:28:07 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:28:07 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Session Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:28:07 --> Session routines successfully run
DEBUG - 2016-01-11 09:28:07 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Email Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Controller Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:07 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:28:07 --> Model Class Initialized
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:28:28 --> Config Class Initialized
DEBUG - 2016-01-11 09:28:28 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:28:28 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:28:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:28:28 --> URI Class Initialized
DEBUG - 2016-01-11 09:28:28 --> Router Class Initialized
DEBUG - 2016-01-11 09:28:29 --> Output Class Initialized
DEBUG - 2016-01-11 09:28:29 --> Security Class Initialized
DEBUG - 2016-01-11 09:28:29 --> Input Class Initialized
DEBUG - 2016-01-11 09:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:28:29 --> Language Class Initialized
DEBUG - 2016-01-11 09:28:29 --> Language Class Initialized
DEBUG - 2016-01-11 09:28:29 --> Config Class Initialized
DEBUG - 2016-01-11 09:28:29 --> Loader Class Initialized
DEBUG - 2016-01-11 09:28:29 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:28:30 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:28:30 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:28:30 --> Session Class Initialized
DEBUG - 2016-01-11 09:28:30 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:28:30 --> Session routines successfully run
DEBUG - 2016-01-11 09:28:30 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:28:30 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:28:30 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:28:30 --> Email Class Initialized
DEBUG - 2016-01-11 09:28:30 --> Controller Class Initialized
DEBUG - 2016-01-11 09:28:30 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:28:30 --> Model Class Initialized
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:28:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:28:30 --> Final output sent to browser
DEBUG - 2016-01-11 09:28:30 --> Total execution time: 2.0299
DEBUG - 2016-01-11 09:29:25 --> Config Class Initialized
DEBUG - 2016-01-11 09:29:25 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:29:25 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:29:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:29:25 --> URI Class Initialized
DEBUG - 2016-01-11 09:29:25 --> Router Class Initialized
DEBUG - 2016-01-11 09:29:25 --> Output Class Initialized
DEBUG - 2016-01-11 09:29:25 --> Security Class Initialized
DEBUG - 2016-01-11 09:29:25 --> Input Class Initialized
DEBUG - 2016-01-11 09:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:29:26 --> Language Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Language Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Config Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Loader Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:29:26 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:29:26 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Session Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:29:26 --> Session routines successfully run
DEBUG - 2016-01-11 09:29:26 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Email Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Controller Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:29:26 --> Model Class Initialized
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:29:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:29:26 --> Final output sent to browser
DEBUG - 2016-01-11 09:29:26 --> Total execution time: 0.4745
DEBUG - 2016-01-11 09:30:24 --> Config Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:30:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:30:24 --> URI Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Router Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Output Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Security Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Input Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:30:24 --> Language Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Language Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Config Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Loader Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:30:24 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:30:24 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Session Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:30:24 --> Session routines successfully run
DEBUG - 2016-01-11 09:30:24 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Email Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Controller Class Initialized
DEBUG - 2016-01-11 09:30:24 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:30:24 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:30:24 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:30:24 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:30:25 --> Model Class Initialized
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:30:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:30:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:30:25 --> Final output sent to browser
DEBUG - 2016-01-11 09:30:25 --> Total execution time: 0.3455
DEBUG - 2016-01-11 09:33:55 --> Config Class Initialized
DEBUG - 2016-01-11 09:33:55 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:33:56 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:33:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:33:56 --> URI Class Initialized
DEBUG - 2016-01-11 09:33:56 --> Router Class Initialized
DEBUG - 2016-01-11 09:33:56 --> Output Class Initialized
DEBUG - 2016-01-11 09:33:56 --> Security Class Initialized
DEBUG - 2016-01-11 09:33:56 --> Input Class Initialized
DEBUG - 2016-01-11 09:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:33:56 --> Language Class Initialized
DEBUG - 2016-01-11 09:33:57 --> Language Class Initialized
DEBUG - 2016-01-11 09:33:57 --> Config Class Initialized
DEBUG - 2016-01-11 09:33:57 --> Loader Class Initialized
DEBUG - 2016-01-11 09:33:57 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:33:57 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:33:58 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:33:58 --> Session Class Initialized
DEBUG - 2016-01-11 09:33:58 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:33:58 --> Session routines successfully run
DEBUG - 2016-01-11 09:33:58 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:33:58 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:33:58 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:33:58 --> Email Class Initialized
DEBUG - 2016-01-11 09:33:58 --> Controller Class Initialized
DEBUG - 2016-01-11 09:33:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:33:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:33:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:33:58 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:33:59 --> Model Class Initialized
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:33:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:34:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:34:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:34:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:34:00 --> Final output sent to browser
DEBUG - 2016-01-11 09:34:00 --> Total execution time: 5.2981
DEBUG - 2016-01-11 09:34:28 --> Config Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:34:28 --> URI Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Router Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Output Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Security Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Input Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:34:28 --> Language Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Language Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Config Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Loader Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:34:28 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:34:28 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Session Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:34:28 --> Session routines successfully run
DEBUG - 2016-01-11 09:34:28 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Email Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Controller Class Initialized
DEBUG - 2016-01-11 09:34:28 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:34:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:34:29 --> Model Class Initialized
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:34:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:34:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:34:29 --> Final output sent to browser
DEBUG - 2016-01-11 09:34:29 --> Total execution time: 0.3398
DEBUG - 2016-01-11 09:35:09 --> Config Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:35:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:35:09 --> URI Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Router Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Output Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Security Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Input Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:35:09 --> Language Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Language Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Config Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Loader Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:35:09 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:35:09 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Session Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:35:09 --> Session routines successfully run
DEBUG - 2016-01-11 09:35:09 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Email Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Controller Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:35:09 --> Model Class Initialized
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:35:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:35:09 --> Final output sent to browser
DEBUG - 2016-01-11 09:35:09 --> Total execution time: 0.5597
DEBUG - 2016-01-11 09:35:54 --> Config Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:35:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:35:54 --> URI Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Router Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Output Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Security Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Input Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:35:54 --> Language Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Language Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Config Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Loader Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:35:54 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:35:54 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Session Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:35:54 --> Session routines successfully run
DEBUG - 2016-01-11 09:35:54 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Email Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Controller Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:35:54 --> Model Class Initialized
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:35:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:35:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:35:54 --> Final output sent to browser
DEBUG - 2016-01-11 09:35:54 --> Total execution time: 0.3180
DEBUG - 2016-01-11 09:36:18 --> Config Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:36:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:36:18 --> URI Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Router Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Output Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Security Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Input Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:36:18 --> Language Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Language Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Config Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Loader Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:36:18 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:36:18 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Session Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:36:18 --> Session routines successfully run
DEBUG - 2016-01-11 09:36:18 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Email Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Controller Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:36:18 --> Model Class Initialized
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:36:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:36:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:36:18 --> Final output sent to browser
DEBUG - 2016-01-11 09:36:18 --> Total execution time: 0.3263
DEBUG - 2016-01-11 09:37:14 --> Config Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:37:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:37:14 --> URI Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Router Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Output Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Security Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Input Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:37:14 --> Language Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Language Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Config Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Loader Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:37:14 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:37:14 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Session Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:37:14 --> Session routines successfully run
DEBUG - 2016-01-11 09:37:14 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Email Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Controller Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 09:37:14 --> Model Class Initialized
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 09:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:37:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:37:14 --> Final output sent to browser
DEBUG - 2016-01-11 09:37:14 --> Total execution time: 0.3557
DEBUG - 2016-01-11 09:43:27 --> Config Class Initialized
DEBUG - 2016-01-11 09:43:27 --> Hooks Class Initialized
DEBUG - 2016-01-11 09:43:27 --> Utf8 Class Initialized
DEBUG - 2016-01-11 09:43:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 09:43:27 --> URI Class Initialized
DEBUG - 2016-01-11 09:43:27 --> Router Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Output Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Security Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Input Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 09:43:28 --> Language Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Language Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Config Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Loader Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Helper loaded: url_helper
DEBUG - 2016-01-11 09:43:28 --> Helper loaded: form_helper
DEBUG - 2016-01-11 09:43:28 --> Database Driver Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Session Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Helper loaded: string_helper
DEBUG - 2016-01-11 09:43:28 --> Session routines successfully run
DEBUG - 2016-01-11 09:43:28 --> Form Validation Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Pagination Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Encrypt Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Email Class Initialized
DEBUG - 2016-01-11 09:43:28 --> Controller Class Initialized
DEBUG - 2016-01-11 09:43:28 --> leases MX_Controller Initialized
DEBUG - 2016-01-11 09:43:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 09:43:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 09:43:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 09:43:28 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 09:43:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 09:43:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 09:43:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 09:43:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 09:43:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:29 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 09:43:29 --> Model Class Initialized
DEBUG - 2016-01-11 09:43:29 --> Image Lib Class Initialized
DEBUG - 2016-01-11 09:43:32 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-11 09:43:32 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-11 09:43:32 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-11 09:43:32 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-11 09:43:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 09:43:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 09:43:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 09:43:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 09:43:32 --> Final output sent to browser
DEBUG - 2016-01-11 09:43:32 --> Total execution time: 5.1399
DEBUG - 2016-01-11 16:25:23 --> Config Class Initialized
DEBUG - 2016-01-11 16:25:24 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:25:25 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:25:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:25:26 --> URI Class Initialized
DEBUG - 2016-01-11 16:25:27 --> Router Class Initialized
DEBUG - 2016-01-11 16:25:28 --> Output Class Initialized
DEBUG - 2016-01-11 16:25:28 --> Security Class Initialized
DEBUG - 2016-01-11 16:25:28 --> Input Class Initialized
DEBUG - 2016-01-11 16:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 16:25:28 --> Language Class Initialized
DEBUG - 2016-01-11 16:25:29 --> Language Class Initialized
DEBUG - 2016-01-11 16:25:29 --> Config Class Initialized
DEBUG - 2016-01-11 16:25:29 --> Loader Class Initialized
DEBUG - 2016-01-11 16:25:29 --> Helper loaded: url_helper
DEBUG - 2016-01-11 16:25:29 --> Helper loaded: form_helper
DEBUG - 2016-01-11 16:25:30 --> Database Driver Class Initialized
DEBUG - 2016-01-11 16:25:38 --> Session Class Initialized
DEBUG - 2016-01-11 16:25:38 --> Helper loaded: string_helper
DEBUG - 2016-01-11 16:25:38 --> A session cookie was not found.
DEBUG - 2016-01-11 16:25:38 --> Session routines successfully run
DEBUG - 2016-01-11 16:25:38 --> Form Validation Class Initialized
DEBUG - 2016-01-11 16:25:38 --> Pagination Class Initialized
DEBUG - 2016-01-11 16:25:38 --> Encrypt Class Initialized
DEBUG - 2016-01-11 16:25:38 --> Email Class Initialized
DEBUG - 2016-01-11 16:25:38 --> Controller Class Initialized
DEBUG - 2016-01-11 16:25:38 --> leases MX_Controller Initialized
DEBUG - 2016-01-11 16:25:39 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 16:25:39 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 16:25:39 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 16:25:39 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 16:25:39 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 16:25:39 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 16:25:40 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Config Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:25:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:25:41 --> URI Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Router Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Output Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Security Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Input Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 16:25:41 --> Language Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Language Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Config Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Loader Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Helper loaded: url_helper
DEBUG - 2016-01-11 16:25:41 --> Helper loaded: form_helper
DEBUG - 2016-01-11 16:25:41 --> Database Driver Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Session Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Helper loaded: string_helper
DEBUG - 2016-01-11 16:25:41 --> Session routines successfully run
DEBUG - 2016-01-11 16:25:41 --> Form Validation Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Pagination Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Encrypt Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Email Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Controller Class Initialized
DEBUG - 2016-01-11 16:25:41 --> Auth MX_Controller Initialized
DEBUG - 2016-01-11 16:25:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 16:25:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 16:25:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:25:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 16:25:47 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-11 16:25:47 --> Final output sent to browser
DEBUG - 2016-01-11 16:25:47 --> Total execution time: 6.4395
DEBUG - 2016-01-11 16:26:14 --> Config Class Initialized
DEBUG - 2016-01-11 16:26:14 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:26:14 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:26:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:26:14 --> URI Class Initialized
DEBUG - 2016-01-11 16:26:14 --> Router Class Initialized
DEBUG - 2016-01-11 16:26:16 --> Config Class Initialized
DEBUG - 2016-01-11 16:26:18 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:26:18 --> Config Class Initialized
DEBUG - 2016-01-11 16:26:18 --> Config Class Initialized
DEBUG - 2016-01-11 16:26:18 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:26:18 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:26:18 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:26:18 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:26:18 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:26:18 --> URI Class Initialized
DEBUG - 2016-01-11 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:26:18 --> URI Class Initialized
DEBUG - 2016-01-11 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:26:18 --> Router Class Initialized
DEBUG - 2016-01-11 16:26:18 --> Router Class Initialized
DEBUG - 2016-01-11 16:26:18 --> URI Class Initialized
DEBUG - 2016-01-11 16:26:18 --> Router Class Initialized
ERROR - 2016-01-11 16:26:19 --> 404 Page Not Found --> 
ERROR - 2016-01-11 16:26:19 --> 404 Page Not Found --> 
ERROR - 2016-01-11 16:26:20 --> 404 Page Not Found --> 
ERROR - 2016-01-11 16:26:20 --> 404 Page Not Found --> 
DEBUG - 2016-01-11 16:32:40 --> Config Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:32:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:32:40 --> URI Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Router Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Output Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Security Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Input Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 16:32:40 --> Language Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Language Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Config Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Loader Class Initialized
DEBUG - 2016-01-11 16:32:40 --> Helper loaded: url_helper
DEBUG - 2016-01-11 16:32:40 --> Helper loaded: form_helper
DEBUG - 2016-01-11 16:32:40 --> Database Driver Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Session Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Helper loaded: string_helper
DEBUG - 2016-01-11 16:32:41 --> Session routines successfully run
DEBUG - 2016-01-11 16:32:41 --> Form Validation Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Pagination Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Encrypt Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Email Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Controller Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Auth MX_Controller Initialized
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-11 16:32:41 --> XSS Filtering completed
DEBUG - 2016-01-11 16:32:41 --> Unable to find validation rule: exists
DEBUG - 2016-01-11 16:32:41 --> XSS Filtering completed
DEBUG - 2016-01-11 16:32:41 --> Config Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:32:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:32:41 --> URI Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Router Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Output Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Security Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Input Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 16:32:41 --> Language Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Language Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Config Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Loader Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Helper loaded: url_helper
DEBUG - 2016-01-11 16:32:41 --> Helper loaded: form_helper
DEBUG - 2016-01-11 16:32:41 --> Database Driver Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Session Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Helper loaded: string_helper
DEBUG - 2016-01-11 16:32:41 --> Session routines successfully run
DEBUG - 2016-01-11 16:32:41 --> Form Validation Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Pagination Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Encrypt Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Email Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Controller Class Initialized
DEBUG - 2016-01-11 16:32:41 --> Admin MX_Controller Initialized
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 16:32:41 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:42 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-11 16:32:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 16:32:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 16:32:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 16:32:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 16:32:42 --> Final output sent to browser
DEBUG - 2016-01-11 16:32:42 --> Total execution time: 0.9542
DEBUG - 2016-01-11 16:32:50 --> Config Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:32:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:32:50 --> URI Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Router Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Output Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Security Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Input Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 16:32:50 --> Language Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Language Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Config Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Loader Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Helper loaded: url_helper
DEBUG - 2016-01-11 16:32:50 --> Helper loaded: form_helper
DEBUG - 2016-01-11 16:32:50 --> Database Driver Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Session Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Helper loaded: string_helper
DEBUG - 2016-01-11 16:32:50 --> Session routines successfully run
DEBUG - 2016-01-11 16:32:50 --> Form Validation Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Pagination Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Encrypt Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Email Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Controller Class Initialized
DEBUG - 2016-01-11 16:32:50 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 16:32:50 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 16:32:50 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 16:32:50 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 16:32:50 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 16:32:50 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 16:32:50 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 16:32:50 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 16:32:51 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 16:32:51 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 16:32:51 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:51 --> Image Lib Class Initialized
DEBUG - 2016-01-11 16:32:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 16:32:51 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 16:32:51 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 16:32:51 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 16:32:51 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:52 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 16:32:52 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 16:32:52 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 16:32:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 16:32:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 16:32:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 16:32:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 16:32:52 --> Final output sent to browser
DEBUG - 2016-01-11 16:32:52 --> Total execution time: 1.5966
DEBUG - 2016-01-11 16:32:57 --> Config Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Hooks Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Utf8 Class Initialized
DEBUG - 2016-01-11 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 16:32:57 --> URI Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Router Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Output Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Security Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Input Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 16:32:57 --> Language Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Language Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Config Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Loader Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Helper loaded: url_helper
DEBUG - 2016-01-11 16:32:57 --> Helper loaded: form_helper
DEBUG - 2016-01-11 16:32:57 --> Database Driver Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Session Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Helper loaded: string_helper
DEBUG - 2016-01-11 16:32:57 --> Session routines successfully run
DEBUG - 2016-01-11 16:32:57 --> Form Validation Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Pagination Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Encrypt Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Email Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Controller Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> Image Lib Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
DEBUG - 2016-01-11 16:32:57 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 16:32:57 --> Model Class Initialized
ERROR - 2016-01-11 16:32:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 16:32:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 16:32:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 16:32:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 127
ERROR - 2016-01-11 16:32:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 128
DEBUG - 2016-01-11 16:32:58 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 16:32:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 16:32:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 16:32:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 16:32:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 16:32:58 --> Final output sent to browser
DEBUG - 2016-01-11 16:32:58 --> Total execution time: 0.4978
DEBUG - 2016-01-11 19:50:49 --> Config Class Initialized
DEBUG - 2016-01-11 19:50:49 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:50:49 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:50:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:50:49 --> URI Class Initialized
DEBUG - 2016-01-11 19:50:50 --> Router Class Initialized
DEBUG - 2016-01-11 19:50:50 --> Output Class Initialized
DEBUG - 2016-01-11 19:50:50 --> Security Class Initialized
DEBUG - 2016-01-11 19:50:50 --> Input Class Initialized
DEBUG - 2016-01-11 19:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:50:50 --> Language Class Initialized
DEBUG - 2016-01-11 19:50:50 --> Language Class Initialized
DEBUG - 2016-01-11 19:50:50 --> Config Class Initialized
DEBUG - 2016-01-11 19:50:50 --> Loader Class Initialized
DEBUG - 2016-01-11 19:50:51 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:50:51 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:50:51 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:50:54 --> Session Class Initialized
DEBUG - 2016-01-11 19:50:54 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:50:54 --> A session cookie was not found.
DEBUG - 2016-01-11 19:50:54 --> Session routines successfully run
DEBUG - 2016-01-11 19:50:54 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:50:54 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:50:54 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:50:54 --> Email Class Initialized
DEBUG - 2016-01-11 19:50:54 --> Controller Class Initialized
DEBUG - 2016-01-11 19:50:54 --> Property MX_Controller Initialized
DEBUG - 2016-01-11 19:50:54 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:50:54 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:50:54 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:50:54 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:50:54 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:50:54 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:50:55 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Config Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:50:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:50:55 --> URI Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Router Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Output Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Security Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Input Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:50:55 --> Language Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Language Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Config Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Loader Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:50:55 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:50:55 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Session Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:50:55 --> Session routines successfully run
DEBUG - 2016-01-11 19:50:55 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:50:55 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:50:56 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:50:56 --> Email Class Initialized
DEBUG - 2016-01-11 19:50:56 --> Controller Class Initialized
DEBUG - 2016-01-11 19:50:56 --> Auth MX_Controller Initialized
DEBUG - 2016-01-11 19:50:56 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:50:56 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:50:56 --> Model Class Initialized
DEBUG - 2016-01-11 19:50:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 19:50:56 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-11 19:50:56 --> Final output sent to browser
DEBUG - 2016-01-11 19:50:56 --> Total execution time: 0.6007
DEBUG - 2016-01-11 19:51:06 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:06 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:51:06 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:51:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:51:06 --> URI Class Initialized
DEBUG - 2016-01-11 19:51:06 --> Router Class Initialized
ERROR - 2016-01-11 19:51:07 --> 404 Page Not Found --> 
DEBUG - 2016-01-11 19:51:07 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:07 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:51:07 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:51:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:51:08 --> URI Class Initialized
DEBUG - 2016-01-11 19:51:08 --> Router Class Initialized
DEBUG - 2016-01-11 19:51:08 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:08 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:51:08 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:51:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:51:08 --> URI Class Initialized
DEBUG - 2016-01-11 19:51:08 --> Router Class Initialized
ERROR - 2016-01-11 19:51:08 --> 404 Page Not Found --> 
ERROR - 2016-01-11 19:51:08 --> 404 Page Not Found --> 
DEBUG - 2016-01-11 19:51:08 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:08 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:51:08 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:51:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:51:08 --> URI Class Initialized
DEBUG - 2016-01-11 19:51:08 --> Router Class Initialized
ERROR - 2016-01-11 19:51:08 --> 404 Page Not Found --> 
DEBUG - 2016-01-11 19:51:11 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:51:11 --> URI Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Router Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Output Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Security Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Input Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:51:11 --> Language Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Language Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Loader Class Initialized
DEBUG - 2016-01-11 19:51:11 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:51:12 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:51:12 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Session Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:51:12 --> Session routines successfully run
DEBUG - 2016-01-11 19:51:12 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Email Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Controller Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Auth MX_Controller Initialized
DEBUG - 2016-01-11 19:51:12 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:51:12 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:51:12 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-11 19:51:12 --> XSS Filtering completed
DEBUG - 2016-01-11 19:51:12 --> Unable to find validation rule: exists
DEBUG - 2016-01-11 19:51:12 --> XSS Filtering completed
DEBUG - 2016-01-11 19:51:12 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:51:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:51:12 --> URI Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Router Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Output Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Security Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Input Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:51:12 --> Language Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Language Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Loader Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:51:12 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:51:12 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Session Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:51:12 --> Session routines successfully run
DEBUG - 2016-01-11 19:51:12 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Email Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Controller Class Initialized
DEBUG - 2016-01-11 19:51:12 --> Admin MX_Controller Initialized
DEBUG - 2016-01-11 19:51:12 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:51:12 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:51:13 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:51:13 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:51:13 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:51:13 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:51:13 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 19:51:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 19:51:13 --> Final output sent to browser
DEBUG - 2016-01-11 19:51:13 --> Total execution time: 0.8498
DEBUG - 2016-01-11 19:51:19 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:51:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:51:19 --> URI Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Router Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Output Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Security Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Input Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:51:19 --> Language Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Language Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Config Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Loader Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:51:19 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:51:19 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Session Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:51:19 --> Session routines successfully run
DEBUG - 2016-01-11 19:51:19 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Email Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Controller Class Initialized
DEBUG - 2016-01-11 19:51:19 --> Property MX_Controller Initialized
DEBUG - 2016-01-11 19:51:19 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:51:19 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:51:19 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:51:19 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:51:20 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:51:20 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:51:20 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 19:51:20 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 19:51:20 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 19:51:20 --> Model Class Initialized
DEBUG - 2016-01-11 19:51:20 --> Image Lib Class Initialized
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 19:51:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 19:51:20 --> Final output sent to browser
DEBUG - 2016-01-11 19:51:20 --> Total execution time: 0.8803
DEBUG - 2016-01-11 19:54:57 --> Config Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:54:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:54:57 --> URI Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Router Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Output Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Security Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Input Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:54:57 --> Language Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Language Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Config Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Loader Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:54:57 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:54:57 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Session Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:54:57 --> Session routines successfully run
DEBUG - 2016-01-11 19:54:57 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Email Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Controller Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:57 --> Image Lib Class Initialized
DEBUG - 2016-01-11 19:54:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 19:54:57 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 19:54:58 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 19:54:58 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 19:54:58 --> Model Class Initialized
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 19:54:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 19:54:58 --> Final output sent to browser
DEBUG - 2016-01-11 19:54:58 --> Total execution time: 0.8647
DEBUG - 2016-01-11 19:55:01 --> Config Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:55:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:55:01 --> URI Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Router Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Output Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Security Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Input Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:55:01 --> Language Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Language Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Config Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Loader Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:55:01 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:55:01 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Session Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:55:01 --> Session routines successfully run
DEBUG - 2016-01-11 19:55:01 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Email Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Controller Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> Image Lib Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 19:55:01 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:01 --> DB Transaction Failure
ERROR - 2016-01-11 19:55:01 --> Query error: Unknown column 'payments.year' in 'where clause'
DEBUG - 2016-01-11 19:55:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-11 19:55:32 --> Config Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:55:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:55:32 --> URI Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Router Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Output Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Security Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Input Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:55:32 --> Language Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Language Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Config Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Loader Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:55:32 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:55:32 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Session Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:55:32 --> Session routines successfully run
DEBUG - 2016-01-11 19:55:32 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Email Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Controller Class Initialized
DEBUG - 2016-01-11 19:55:32 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 19:55:32 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:55:32 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> Image Lib Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:55:33 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 19:55:33 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Config Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:56:46 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:56:46 --> URI Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Router Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Output Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Security Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Input Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:56:46 --> Language Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Language Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Config Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Loader Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:56:46 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:56:46 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Session Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:56:46 --> Session routines successfully run
DEBUG - 2016-01-11 19:56:46 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Email Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Controller Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> Image Lib Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
DEBUG - 2016-01-11 19:56:46 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 19:56:46 --> Model Class Initialized
ERROR - 2016-01-11 19:56:46 --> Severity: Notice  --> Undefined variable: lease_id C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 2
DEBUG - 2016-01-11 19:56:46 --> DB Transaction Failure
ERROR - 2016-01-11 19:56:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
DEBUG - 2016-01-11 19:56:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-11 19:57:18 --> Config Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:57:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:57:18 --> URI Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Router Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Output Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Security Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Input Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:57:18 --> Language Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Language Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Config Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Loader Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:57:18 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:57:18 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Session Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:57:18 --> Session routines successfully run
DEBUG - 2016-01-11 19:57:18 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Email Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Controller Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> Image Lib Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 19:57:18 --> Model Class Initialized
DEBUG - 2016-01-11 19:57:19 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 19:57:19 --> Model Class Initialized
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
DEBUG - 2016-01-11 19:57:19 --> DB Transaction Failure
ERROR - 2016-01-11 19:57:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(balance_cf) AS balance
FROM (`payments`)
WHERE `lease_id` = 2 AND payment_statu' at line 1
DEBUG - 2016-01-11 19:57:19 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-11 19:58:26 --> Config Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:58:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:58:26 --> URI Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Router Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Output Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Security Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Input Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:58:26 --> Language Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Language Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Config Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Loader Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:58:26 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:58:26 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Session Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:58:26 --> Session routines successfully run
DEBUG - 2016-01-11 19:58:26 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Email Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Controller Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> Image Lib Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 19:58:26 --> Model Class Initialized
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 365
ERROR - 2016-01-11 19:58:26 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 366
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 19:58:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 19:58:26 --> Final output sent to browser
DEBUG - 2016-01-11 19:58:26 --> Total execution time: 0.3093
DEBUG - 2016-01-11 19:59:17 --> Config Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:59:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:59:17 --> URI Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Router Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Output Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Security Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Input Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:59:17 --> Language Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Language Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Config Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Loader Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:59:17 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:59:17 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Session Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:59:17 --> Session routines successfully run
DEBUG - 2016-01-11 19:59:17 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Email Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Controller Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> Image Lib Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 19:59:17 --> Model Class Initialized
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 19:59:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 19:59:17 --> Final output sent to browser
DEBUG - 2016-01-11 19:59:17 --> Total execution time: 0.3055
DEBUG - 2016-01-11 19:59:43 --> Config Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Hooks Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Utf8 Class Initialized
DEBUG - 2016-01-11 19:59:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 19:59:43 --> URI Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Router Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Output Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Security Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Input Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 19:59:43 --> Language Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Language Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Config Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Loader Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Helper loaded: url_helper
DEBUG - 2016-01-11 19:59:43 --> Helper loaded: form_helper
DEBUG - 2016-01-11 19:59:43 --> Database Driver Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Session Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Helper loaded: string_helper
DEBUG - 2016-01-11 19:59:43 --> Session routines successfully run
DEBUG - 2016-01-11 19:59:43 --> Form Validation Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Pagination Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Encrypt Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Email Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Controller Class Initialized
DEBUG - 2016-01-11 19:59:43 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 19:59:43 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 19:59:43 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 19:59:43 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 19:59:43 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 19:59:43 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 19:59:43 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 19:59:44 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 19:59:44 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 19:59:44 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 19:59:44 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:44 --> Image Lib Class Initialized
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 19:59:44 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 19:59:44 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 19:59:44 --> Model Class Initialized
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 19:59:44 --> Model Class Initialized
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 19:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 19:59:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 19:59:44 --> Final output sent to browser
DEBUG - 2016-01-11 19:59:44 --> Total execution time: 0.3295
DEBUG - 2016-01-11 20:02:30 --> Config Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:02:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:02:30 --> URI Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Router Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Output Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Security Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Input Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:02:30 --> Language Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Language Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Config Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Loader Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:02:30 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:02:30 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Session Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:02:30 --> Session routines successfully run
DEBUG - 2016-01-11 20:02:30 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Email Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Controller Class Initialized
DEBUG - 2016-01-11 20:02:30 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:02:30 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:02:30 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:02:30 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:02:31 --> Model Class Initialized
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:02:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:02:31 --> Final output sent to browser
DEBUG - 2016-01-11 20:02:31 --> Total execution time: 0.3444
DEBUG - 2016-01-11 20:02:43 --> Config Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:02:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:02:43 --> URI Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Router Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Output Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Security Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Input Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:02:43 --> Language Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Language Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Config Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Loader Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:02:43 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:02:43 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Session Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:02:43 --> Session routines successfully run
DEBUG - 2016-01-11 20:02:43 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Email Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Controller Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:02:43 --> Model Class Initialized
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:02:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:02:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:02:43 --> Final output sent to browser
DEBUG - 2016-01-11 20:02:43 --> Total execution time: 0.3119
DEBUG - 2016-01-11 20:03:15 --> Config Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:03:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:03:15 --> URI Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Router Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Output Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Security Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Input Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:03:15 --> Language Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Language Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Config Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Loader Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:03:15 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:03:15 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Session Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:03:15 --> Session routines successfully run
DEBUG - 2016-01-11 20:03:15 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Email Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Controller Class Initialized
DEBUG - 2016-01-11 20:03:15 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:03:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:03:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:03:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:03:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:03:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:03:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:03:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:03:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:03:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:03:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:03:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:03:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:03:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:03:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:03:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:03:16 --> Final output sent to browser
DEBUG - 2016-01-11 20:03:16 --> Total execution time: 0.2855
DEBUG - 2016-01-11 20:03:18 --> Config Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:03:18 --> URI Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Router Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Output Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Security Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Input Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:03:18 --> Language Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Language Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Config Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Loader Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:03:18 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:03:18 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Session Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:03:18 --> Session routines successfully run
DEBUG - 2016-01-11 20:03:18 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Email Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Controller Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:03:18 --> Model Class Initialized
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 198
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:03:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:03:18 --> Final output sent to browser
DEBUG - 2016-01-11 20:03:18 --> Total execution time: 0.3220
DEBUG - 2016-01-11 20:05:18 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:05:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:05:18 --> URI Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Router Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Output Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Security Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Input Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:05:18 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Loader Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:05:18 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:05:18 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Session Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:05:18 --> Session routines successfully run
DEBUG - 2016-01-11 20:05:18 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Email Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Controller Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:05:18 --> Model Class Initialized
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:05:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:05:18 --> Final output sent to browser
DEBUG - 2016-01-11 20:05:18 --> Total execution time: 0.3862
DEBUG - 2016-01-11 20:05:36 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:36 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:05:36 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:05:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:05:36 --> URI Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Router Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Output Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Security Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Input Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:05:37 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Loader Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:05:37 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:05:37 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Session Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:05:37 --> Session routines successfully run
DEBUG - 2016-01-11 20:05:37 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Email Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Controller Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:05:37 --> Model Class Initialized
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:05:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:05:37 --> Final output sent to browser
DEBUG - 2016-01-11 20:05:37 --> Total execution time: 0.3703
DEBUG - 2016-01-11 20:05:48 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:05:48 --> URI Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Router Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Output Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Security Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Input Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:05:48 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Loader Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:05:48 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:05:48 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Session Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:05:48 --> Session routines successfully run
DEBUG - 2016-01-11 20:05:48 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Email Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Controller Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:05:48 --> Model Class Initialized
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:05:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:05:48 --> Final output sent to browser
DEBUG - 2016-01-11 20:05:48 --> Total execution time: 0.3643
DEBUG - 2016-01-11 20:05:51 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:05:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:05:51 --> URI Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Router Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Output Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Security Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Input Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:05:51 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Loader Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:05:51 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:05:51 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Session Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:05:51 --> Session routines successfully run
DEBUG - 2016-01-11 20:05:51 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Email Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Controller Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:05:51 --> Model Class Initialized
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:05:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:05:51 --> Final output sent to browser
DEBUG - 2016-01-11 20:05:51 --> Total execution time: 0.3235
DEBUG - 2016-01-11 20:05:58 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:05:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:05:58 --> URI Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Router Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Output Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Security Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Input Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:05:58 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Language Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Config Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Loader Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:05:58 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:05:58 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Session Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:05:58 --> Session routines successfully run
DEBUG - 2016-01-11 20:05:58 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Email Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Controller Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:05:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:05:58 --> Model Class Initialized
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:05:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
DEBUG - 2016-01-11 20:05:59 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:05:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:05:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:05:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:05:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:05:59 --> Final output sent to browser
DEBUG - 2016-01-11 20:05:59 --> Total execution time: 0.3074
DEBUG - 2016-01-11 20:06:08 --> Config Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:06:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:06:08 --> URI Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Router Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Output Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Security Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Input Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:06:08 --> Language Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Language Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Config Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Loader Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:06:08 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:06:08 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Session Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:06:08 --> Session routines successfully run
DEBUG - 2016-01-11 20:06:08 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Email Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Controller Class Initialized
DEBUG - 2016-01-11 20:06:08 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:06:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:09 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:06:09 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:06:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:06:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:09 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:06:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:09 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:06:09 --> Model Class Initialized
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
DEBUG - 2016-01-11 20:06:09 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:06:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:06:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:06:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:06:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:06:09 --> Final output sent to browser
DEBUG - 2016-01-11 20:06:09 --> Total execution time: 0.3310
DEBUG - 2016-01-11 20:06:21 --> Config Class Initialized
DEBUG - 2016-01-11 20:06:21 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:06:21 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:06:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:06:21 --> URI Class Initialized
DEBUG - 2016-01-11 20:06:21 --> Router Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Output Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Security Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Input Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:06:22 --> Language Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Language Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Config Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Loader Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:06:22 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:06:22 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Session Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:06:22 --> Session routines successfully run
DEBUG - 2016-01-11 20:06:22 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Email Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Controller Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:06:22 --> Model Class Initialized
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 196
ERROR - 2016-01-11 20:06:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 197
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:06:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:06:22 --> Final output sent to browser
DEBUG - 2016-01-11 20:06:22 --> Total execution time: 0.3461
DEBUG - 2016-01-11 20:07:16 --> Config Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:07:16 --> URI Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Router Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Output Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Security Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Input Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:07:16 --> Language Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Language Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Config Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Loader Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:07:16 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:07:16 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Session Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:07:16 --> Session routines successfully run
DEBUG - 2016-01-11 20:07:16 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Email Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Controller Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:07:16 --> Model Class Initialized
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:07:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:07:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:07:16 --> Final output sent to browser
DEBUG - 2016-01-11 20:07:16 --> Total execution time: 0.3153
DEBUG - 2016-01-11 20:10:13 --> Config Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:10:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:10:13 --> URI Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Router Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Output Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Security Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Input Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:10:13 --> Language Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Language Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Config Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Loader Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:10:13 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:10:13 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Session Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:10:13 --> Session routines successfully run
DEBUG - 2016-01-11 20:10:13 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Email Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Controller Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:10:13 --> Model Class Initialized
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:10:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:10:13 --> Final output sent to browser
DEBUG - 2016-01-11 20:10:13 --> Total execution time: 0.3300
DEBUG - 2016-01-11 20:10:44 --> Config Class Initialized
DEBUG - 2016-01-11 20:10:44 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:10:44 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:10:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:10:44 --> URI Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Router Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Output Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Security Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Input Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:10:45 --> Language Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Language Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Config Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Loader Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:10:45 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:10:45 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Session Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:10:45 --> Session routines successfully run
DEBUG - 2016-01-11 20:10:45 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Email Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Controller Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:10:45 --> Model Class Initialized
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:10:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:10:45 --> Final output sent to browser
DEBUG - 2016-01-11 20:10:45 --> Total execution time: 0.4745
DEBUG - 2016-01-11 20:10:57 --> Config Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:10:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:10:57 --> URI Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Router Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Output Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Security Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Input Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:10:57 --> Language Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Language Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Config Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Loader Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:10:57 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:10:57 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Session Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:10:57 --> Session routines successfully run
DEBUG - 2016-01-11 20:10:57 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Email Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Controller Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:10:57 --> Model Class Initialized
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:10:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:10:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:10:57 --> Final output sent to browser
DEBUG - 2016-01-11 20:10:57 --> Total execution time: 0.3967
DEBUG - 2016-01-11 20:11:06 --> Config Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:11:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:11:06 --> URI Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Router Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Output Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Security Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Input Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:11:06 --> Language Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Language Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Config Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Loader Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:11:06 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:11:06 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Session Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:11:06 --> Session routines successfully run
DEBUG - 2016-01-11 20:11:06 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Email Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Controller Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:11:06 --> Model Class Initialized
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:11:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:11:06 --> Final output sent to browser
DEBUG - 2016-01-11 20:11:06 --> Total execution time: 0.3633
DEBUG - 2016-01-11 20:11:35 --> Config Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:11:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:11:35 --> URI Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Router Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Output Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Security Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Input Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:11:35 --> Language Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Language Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Config Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Loader Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:11:35 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:11:35 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Session Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:11:35 --> Session routines successfully run
DEBUG - 2016-01-11 20:11:35 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Email Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Controller Class Initialized
DEBUG - 2016-01-11 20:11:35 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:11:35 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:11:35 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:11:35 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:11:35 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:11:35 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:11:35 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:11:35 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:11:35 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:11:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:11:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:36 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:11:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:11:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:11:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:11:36 --> Model Class Initialized
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:11:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:11:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:11:36 --> Final output sent to browser
DEBUG - 2016-01-11 20:11:36 --> Total execution time: 0.4597
DEBUG - 2016-01-11 20:12:00 --> Config Class Initialized
DEBUG - 2016-01-11 20:12:00 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:12:00 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:12:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:12:00 --> URI Class Initialized
DEBUG - 2016-01-11 20:12:00 --> Router Class Initialized
DEBUG - 2016-01-11 20:12:00 --> Output Class Initialized
DEBUG - 2016-01-11 20:12:00 --> Security Class Initialized
DEBUG - 2016-01-11 20:12:00 --> Input Class Initialized
DEBUG - 2016-01-11 20:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:12:00 --> Language Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Language Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Config Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Loader Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:12:01 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:12:01 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Session Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:12:01 --> Session routines successfully run
DEBUG - 2016-01-11 20:12:01 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Email Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Controller Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:12:01 --> Model Class Initialized
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:12:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:12:01 --> Final output sent to browser
DEBUG - 2016-01-11 20:12:01 --> Total execution time: 0.3827
DEBUG - 2016-01-11 20:14:10 --> Config Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:14:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:14:10 --> URI Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Router Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Output Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Security Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Input Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:14:10 --> Language Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Language Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Config Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Loader Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:14:10 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:14:10 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Session Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:14:10 --> Session routines successfully run
DEBUG - 2016-01-11 20:14:10 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Email Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Controller Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:14:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:14:10 --> DB Transaction Failure
ERROR - 2016-01-11 20:14:10 --> Query error: No tables used
DEBUG - 2016-01-11 20:14:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-11 20:15:58 --> Config Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:15:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:15:58 --> URI Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Router Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Output Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Security Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Input Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:15:58 --> Language Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Language Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Config Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Loader Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:15:58 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:15:58 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Session Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:15:58 --> Session routines successfully run
DEBUG - 2016-01-11 20:15:58 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Email Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Controller Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:15:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:58 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:15:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:15:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:15:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:59 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:15:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:15:59 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:15:59 --> Model Class Initialized
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:15:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
DEBUG - 2016-01-11 20:15:59 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:15:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:15:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:15:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:15:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:15:59 --> Final output sent to browser
DEBUG - 2016-01-11 20:15:59 --> Total execution time: 0.3167
DEBUG - 2016-01-11 20:16:34 --> Config Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:16:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:16:34 --> URI Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Router Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Output Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Security Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Input Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:16:34 --> Language Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Language Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Config Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Loader Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:16:34 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:16:34 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Session Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:16:34 --> Session routines successfully run
DEBUG - 2016-01-11 20:16:34 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Email Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Controller Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
DEBUG - 2016-01-11 20:16:34 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:16:34 --> Model Class Initialized
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 189
ERROR - 2016-01-11 20:16:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 190
DEBUG - 2016-01-11 20:16:35 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:16:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:16:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:16:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:16:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:16:35 --> Final output sent to browser
DEBUG - 2016-01-11 20:16:35 --> Total execution time: 0.3858
DEBUG - 2016-01-11 20:17:40 --> Config Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:17:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:17:40 --> URI Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Router Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Output Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Security Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Input Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:17:40 --> Language Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Language Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Config Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Loader Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:17:40 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:17:40 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Session Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:17:40 --> Session routines successfully run
DEBUG - 2016-01-11 20:17:40 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Email Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Controller Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:17:40 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:17:40 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Config Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:18:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:18:51 --> URI Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Router Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Output Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Security Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Input Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:18:51 --> Language Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Language Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Config Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Loader Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:18:51 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:18:51 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Session Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:18:51 --> Session routines successfully run
DEBUG - 2016-01-11 20:18:51 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Email Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Controller Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:18:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:18:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:18:51 --> Final output sent to browser
DEBUG - 2016-01-11 20:18:51 --> Total execution time: 0.2938
DEBUG - 2016-01-11 20:20:05 --> Config Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:20:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:20:05 --> URI Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Router Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Output Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Security Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Input Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:20:05 --> Language Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Language Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Config Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Loader Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:20:05 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:20:05 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Session Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:20:05 --> Session routines successfully run
DEBUG - 2016-01-11 20:20:05 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Email Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Controller Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:20:05 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:20:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:20:05 --> Final output sent to browser
DEBUG - 2016-01-11 20:20:05 --> Total execution time: 0.3686
DEBUG - 2016-01-11 20:20:47 --> Config Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:20:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:20:47 --> URI Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Router Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Output Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Security Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Input Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:20:47 --> Language Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Language Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Config Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Loader Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:20:47 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:20:47 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Session Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:20:47 --> Session routines successfully run
DEBUG - 2016-01-11 20:20:47 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Email Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Controller Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:20:47 --> Model Class Initialized
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:20:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:20:47 --> Final output sent to browser
DEBUG - 2016-01-11 20:20:47 --> Total execution time: 0.3868
DEBUG - 2016-01-11 20:21:58 --> Config Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:21:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:21:58 --> URI Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Router Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Output Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Security Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Input Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:21:58 --> Language Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Language Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Config Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Loader Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:21:58 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:21:58 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Session Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:21:58 --> Session routines successfully run
DEBUG - 2016-01-11 20:21:58 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Email Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Controller Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:21:58 --> Model Class Initialized
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:21:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:21:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:21:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:21:59 --> Final output sent to browser
DEBUG - 2016-01-11 20:21:59 --> Total execution time: 0.4358
DEBUG - 2016-01-11 20:24:28 --> Config Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:24:28 --> URI Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Router Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Output Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Security Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Input Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:24:28 --> Language Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Language Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Config Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Loader Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:24:28 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:24:28 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Session Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:24:28 --> Session routines successfully run
DEBUG - 2016-01-11 20:24:28 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Email Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Controller Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:24:28 --> Model Class Initialized
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:24:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:24:28 --> Final output sent to browser
DEBUG - 2016-01-11 20:24:28 --> Total execution time: 0.2920
DEBUG - 2016-01-11 20:25:13 --> Config Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:25:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:25:13 --> URI Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Router Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Output Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Security Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Input Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:25:13 --> Language Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Language Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Config Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Loader Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:25:13 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:25:13 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Session Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:25:13 --> Session routines successfully run
DEBUG - 2016-01-11 20:25:13 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:25:13 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:25:14 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:25:14 --> Email Class Initialized
DEBUG - 2016-01-11 20:25:14 --> Controller Class Initialized
DEBUG - 2016-01-11 20:25:14 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:25:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:25:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:25:14 --> Final output sent to browser
DEBUG - 2016-01-11 20:25:14 --> Total execution time: 0.2832
DEBUG - 2016-01-11 20:25:26 --> Config Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:25:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:25:26 --> URI Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Router Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Output Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Security Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Input Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:25:26 --> Language Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Language Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Config Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Loader Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:25:26 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:25:26 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Session Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:25:26 --> Session routines successfully run
DEBUG - 2016-01-11 20:25:26 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Email Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Controller Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:25:26 --> Model Class Initialized
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:25:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:25:26 --> Final output sent to browser
DEBUG - 2016-01-11 20:25:26 --> Total execution time: 0.3740
DEBUG - 2016-01-11 20:36:10 --> Config Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:36:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:36:10 --> URI Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Router Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Output Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Security Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Input Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:36:10 --> Language Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Language Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Config Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Loader Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:36:10 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:36:10 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Session Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:36:10 --> Session routines successfully run
DEBUG - 2016-01-11 20:36:10 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Email Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Controller Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:10 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:36:10 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Config Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:36:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:36:16 --> URI Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Router Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Output Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Security Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Input Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:36:16 --> Language Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Language Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Config Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Loader Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:36:16 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:36:16 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Session Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:36:16 --> Session routines successfully run
DEBUG - 2016-01-11 20:36:16 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Email Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Controller Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:36:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Config Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:36:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:36:36 --> URI Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Router Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Output Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Security Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Input Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:36:36 --> Language Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Language Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Config Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Loader Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:36:36 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:36:36 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Session Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:36:36 --> Session routines successfully run
DEBUG - 2016-01-11 20:36:36 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Email Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Controller Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:36:36 --> Model Class Initialized
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:36:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:36:36 --> Final output sent to browser
DEBUG - 2016-01-11 20:36:36 --> Total execution time: 0.3571
DEBUG - 2016-01-11 20:44:59 --> Config Class Initialized
DEBUG - 2016-01-11 20:44:59 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:44:59 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:45:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:45:00 --> URI Class Initialized
DEBUG - 2016-01-11 20:45:01 --> Router Class Initialized
DEBUG - 2016-01-11 20:45:03 --> Output Class Initialized
DEBUG - 2016-01-11 20:45:03 --> Security Class Initialized
DEBUG - 2016-01-11 20:45:03 --> Input Class Initialized
DEBUG - 2016-01-11 20:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:45:03 --> Language Class Initialized
DEBUG - 2016-01-11 20:45:05 --> Language Class Initialized
DEBUG - 2016-01-11 20:45:05 --> Config Class Initialized
DEBUG - 2016-01-11 20:45:06 --> Loader Class Initialized
DEBUG - 2016-01-11 20:45:07 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:45:07 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:45:11 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:45:11 --> Session Class Initialized
DEBUG - 2016-01-11 20:45:11 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:45:11 --> Session routines successfully run
DEBUG - 2016-01-11 20:45:12 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:45:13 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:45:13 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:45:14 --> Email Class Initialized
DEBUG - 2016-01-11 20:45:14 --> Controller Class Initialized
DEBUG - 2016-01-11 20:45:14 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:45:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:45:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:45:14 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:45:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:45:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:45:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:45:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:45:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:45:16 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:45:17 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:17 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:45:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:45:17 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:45:17 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:45:17 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:17 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:45:17 --> Model Class Initialized
DEBUG - 2016-01-11 20:45:18 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:45:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:45:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:45:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:45:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:45:19 --> Final output sent to browser
DEBUG - 2016-01-11 20:45:19 --> Total execution time: 20.2428
DEBUG - 2016-01-11 20:46:13 --> Config Class Initialized
DEBUG - 2016-01-11 20:46:13 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:46:13 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:46:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:46:13 --> URI Class Initialized
DEBUG - 2016-01-11 20:46:13 --> Router Class Initialized
DEBUG - 2016-01-11 20:46:13 --> Output Class Initialized
DEBUG - 2016-01-11 20:46:13 --> Security Class Initialized
DEBUG - 2016-01-11 20:46:13 --> Input Class Initialized
DEBUG - 2016-01-11 20:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:46:13 --> Language Class Initialized
DEBUG - 2016-01-11 20:46:14 --> Language Class Initialized
DEBUG - 2016-01-11 20:46:14 --> Config Class Initialized
DEBUG - 2016-01-11 20:46:14 --> Loader Class Initialized
DEBUG - 2016-01-11 20:46:14 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:46:14 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:46:15 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:46:15 --> Session Class Initialized
DEBUG - 2016-01-11 20:46:15 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:46:15 --> Session routines successfully run
DEBUG - 2016-01-11 20:46:15 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:46:15 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:46:15 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:46:15 --> Email Class Initialized
DEBUG - 2016-01-11 20:46:15 --> Controller Class Initialized
DEBUG - 2016-01-11 20:46:15 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:46:15 --> Model Class Initialized
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:46:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:46:15 --> Final output sent to browser
DEBUG - 2016-01-11 20:46:15 --> Total execution time: 2.3479
DEBUG - 2016-01-11 20:47:05 --> Config Class Initialized
DEBUG - 2016-01-11 20:47:05 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:47:05 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:47:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:47:05 --> URI Class Initialized
DEBUG - 2016-01-11 20:47:06 --> Router Class Initialized
DEBUG - 2016-01-11 20:47:06 --> Output Class Initialized
DEBUG - 2016-01-11 20:47:06 --> Security Class Initialized
DEBUG - 2016-01-11 20:47:06 --> Input Class Initialized
DEBUG - 2016-01-11 20:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:47:06 --> Language Class Initialized
DEBUG - 2016-01-11 20:47:06 --> Language Class Initialized
DEBUG - 2016-01-11 20:47:06 --> Config Class Initialized
DEBUG - 2016-01-11 20:47:06 --> Loader Class Initialized
DEBUG - 2016-01-11 20:47:06 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:47:06 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:47:07 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:47:07 --> Session Class Initialized
DEBUG - 2016-01-11 20:47:07 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:47:07 --> Session routines successfully run
DEBUG - 2016-01-11 20:47:07 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:47:07 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:47:07 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:47:07 --> Email Class Initialized
DEBUG - 2016-01-11 20:47:07 --> Controller Class Initialized
DEBUG - 2016-01-11 20:47:07 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:47:07 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:47:07 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:47:07 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:08 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:47:08 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:09 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:47:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:47:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-11 20:47:09 --> XSS Filtering completed
DEBUG - 2016-01-11 20:47:09 --> XSS Filtering completed
DEBUG - 2016-01-11 20:47:09 --> XSS Filtering completed
ERROR - 2016-01-11 20:47:09 --> Severity: Notice  --> Undefined variable: visit_id C:\xampp\htdocs\rents\application\modules\accounts\controllers\accounts.php 102
ERROR - 2016-01-11 20:47:09 --> Severity: Notice  --> Undefined variable: lease_id C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 103
ERROR - 2016-01-11 20:47:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\helpers\url_helper.php 543
DEBUG - 2016-01-11 20:50:45 --> Config Class Initialized
DEBUG - 2016-01-11 20:50:45 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:50:45 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:50:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:50:45 --> URI Class Initialized
DEBUG - 2016-01-11 20:50:46 --> Router Class Initialized
DEBUG - 2016-01-11 20:50:48 --> Output Class Initialized
DEBUG - 2016-01-11 20:50:48 --> Security Class Initialized
DEBUG - 2016-01-11 20:50:48 --> Input Class Initialized
DEBUG - 2016-01-11 20:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:50:48 --> Language Class Initialized
DEBUG - 2016-01-11 20:50:48 --> Language Class Initialized
DEBUG - 2016-01-11 20:50:48 --> Config Class Initialized
DEBUG - 2016-01-11 20:50:49 --> Loader Class Initialized
DEBUG - 2016-01-11 20:50:49 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:50:49 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:50:50 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:50:50 --> Session Class Initialized
DEBUG - 2016-01-11 20:50:50 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:50:50 --> Session routines successfully run
DEBUG - 2016-01-11 20:50:50 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:50:50 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:50:50 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:50:50 --> Email Class Initialized
DEBUG - 2016-01-11 20:50:50 --> Controller Class Initialized
DEBUG - 2016-01-11 20:50:50 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:50:50 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:50:50 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:50:50 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:50:50 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:50:50 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:50:50 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:50:50 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:50:50 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:51 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:50:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:50:51 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-11 20:50:51 --> XSS Filtering completed
DEBUG - 2016-01-11 20:50:51 --> XSS Filtering completed
DEBUG - 2016-01-11 20:50:51 --> XSS Filtering completed
DEBUG - 2016-01-11 20:50:52 --> Config Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:50:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:50:52 --> URI Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Router Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Output Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Security Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Input Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:50:52 --> Language Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Language Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Config Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Loader Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:50:52 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:50:52 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Session Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:50:52 --> Session routines successfully run
DEBUG - 2016-01-11 20:50:52 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Email Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Controller Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:50:52 --> Model Class Initialized
DEBUG - 2016-01-11 20:50:53 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:50:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:50:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:50:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:50:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:50:53 --> Final output sent to browser
DEBUG - 2016-01-11 20:50:53 --> Total execution time: 1.7776
DEBUG - 2016-01-11 20:52:04 --> Config Class Initialized
DEBUG - 2016-01-11 20:52:04 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:52:05 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:52:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:52:05 --> URI Class Initialized
DEBUG - 2016-01-11 20:52:05 --> Router Class Initialized
DEBUG - 2016-01-11 20:52:06 --> Output Class Initialized
DEBUG - 2016-01-11 20:52:06 --> Security Class Initialized
DEBUG - 2016-01-11 20:52:06 --> Input Class Initialized
DEBUG - 2016-01-11 20:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:52:06 --> Language Class Initialized
DEBUG - 2016-01-11 20:52:06 --> Language Class Initialized
DEBUG - 2016-01-11 20:52:06 --> Config Class Initialized
DEBUG - 2016-01-11 20:52:06 --> Loader Class Initialized
DEBUG - 2016-01-11 20:52:06 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:52:06 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:52:06 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:52:08 --> Session Class Initialized
DEBUG - 2016-01-11 20:52:08 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:52:08 --> Session routines successfully run
DEBUG - 2016-01-11 20:52:08 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:52:08 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:52:09 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:52:09 --> Email Class Initialized
DEBUG - 2016-01-11 20:52:09 --> Controller Class Initialized
DEBUG - 2016-01-11 20:52:09 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:09 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:52:09 --> Model Class Initialized
DEBUG - 2016-01-11 20:52:10 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:52:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:52:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:52:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:52:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:52:10 --> Final output sent to browser
DEBUG - 2016-01-11 20:52:10 --> Total execution time: 5.3730
DEBUG - 2016-01-11 20:53:24 --> Config Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:53:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:53:24 --> URI Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Router Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Output Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Security Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Input Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:53:24 --> Language Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Language Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Config Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Loader Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:53:24 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:53:24 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Session Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:53:24 --> Session routines successfully run
DEBUG - 2016-01-11 20:53:24 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Email Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Controller Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:53:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:53:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:53:24 --> Final output sent to browser
DEBUG - 2016-01-11 20:53:24 --> Total execution time: 0.5365
DEBUG - 2016-01-11 20:55:21 --> Config Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:55:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:55:21 --> URI Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Router Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Output Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Security Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Input Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:55:21 --> Language Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Language Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Config Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Loader Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:55:21 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:55:21 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Session Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:55:21 --> Session routines successfully run
DEBUG - 2016-01-11 20:55:21 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Email Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Controller Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:21 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:55:21 --> Model Class Initialized
DEBUG - 2016-01-11 20:55:22 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:55:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:55:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:55:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:55:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:55:22 --> Final output sent to browser
DEBUG - 2016-01-11 20:55:22 --> Total execution time: 0.5082
DEBUG - 2016-01-11 20:56:59 --> Config Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:56:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:56:59 --> URI Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Router Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Output Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Security Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Input Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:56:59 --> Language Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Language Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Config Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Loader Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:56:59 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:56:59 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Session Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:56:59 --> Session routines successfully run
DEBUG - 2016-01-11 20:56:59 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Email Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Controller Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:56:59 --> Model Class Initialized
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:56:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:56:59 --> Final output sent to browser
DEBUG - 2016-01-11 20:56:59 --> Total execution time: 0.5519
DEBUG - 2016-01-11 20:57:23 --> Config Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:57:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:57:23 --> URI Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Router Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Output Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Security Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Input Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:57:23 --> Language Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Language Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Config Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Loader Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:57:23 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:57:23 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Session Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:57:23 --> Session routines successfully run
DEBUG - 2016-01-11 20:57:23 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Email Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Controller Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-11 20:57:23 --> XSS Filtering completed
DEBUG - 2016-01-11 20:57:23 --> XSS Filtering completed
DEBUG - 2016-01-11 20:57:23 --> XSS Filtering completed
DEBUG - 2016-01-11 20:57:23 --> Config Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Hooks Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Utf8 Class Initialized
DEBUG - 2016-01-11 20:57:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 20:57:23 --> URI Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Router Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Output Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Security Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Input Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 20:57:23 --> Language Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Language Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Config Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Loader Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Helper loaded: url_helper
DEBUG - 2016-01-11 20:57:23 --> Helper loaded: form_helper
DEBUG - 2016-01-11 20:57:23 --> Database Driver Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Session Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Helper loaded: string_helper
DEBUG - 2016-01-11 20:57:23 --> Session routines successfully run
DEBUG - 2016-01-11 20:57:23 --> Form Validation Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Pagination Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Encrypt Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Email Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Controller Class Initialized
DEBUG - 2016-01-11 20:57:23 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 20:57:23 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> Image Lib Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 20:57:24 --> Model Class Initialized
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 20:57:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 20:57:24 --> Final output sent to browser
DEBUG - 2016-01-11 20:57:24 --> Total execution time: 0.4312
DEBUG - 2016-01-11 21:04:11 --> Config Class Initialized
DEBUG - 2016-01-11 21:04:11 --> Hooks Class Initialized
DEBUG - 2016-01-11 21:04:11 --> Utf8 Class Initialized
DEBUG - 2016-01-11 21:04:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-11 21:04:11 --> URI Class Initialized
DEBUG - 2016-01-11 21:04:11 --> Router Class Initialized
DEBUG - 2016-01-11 21:04:11 --> Output Class Initialized
DEBUG - 2016-01-11 21:04:11 --> Security Class Initialized
DEBUG - 2016-01-11 21:04:11 --> Input Class Initialized
DEBUG - 2016-01-11 21:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-11 21:04:11 --> Language Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Language Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Config Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Loader Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Helper loaded: url_helper
DEBUG - 2016-01-11 21:04:12 --> Helper loaded: form_helper
DEBUG - 2016-01-11 21:04:12 --> Database Driver Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Session Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Helper loaded: string_helper
DEBUG - 2016-01-11 21:04:12 --> Session routines successfully run
DEBUG - 2016-01-11 21:04:12 --> Form Validation Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Pagination Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Encrypt Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Email Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Controller Class Initialized
DEBUG - 2016-01-11 21:04:12 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-11 21:04:12 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:13 --> Image Lib Class Initialized
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-11 21:04:13 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-11 21:04:13 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-11 21:04:13 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-11 21:04:13 --> Model Class Initialized
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-11 21:04:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-11 21:04:13 --> Final output sent to browser
DEBUG - 2016-01-11 21:04:13 --> Total execution time: 2.1294
