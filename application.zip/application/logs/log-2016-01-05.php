<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-05 07:21:56 --> Config Class Initialized
DEBUG - 2016-01-05 07:21:56 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:21:56 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:21:57 --> URI Class Initialized
DEBUG - 2016-01-05 07:21:59 --> Router Class Initialized
DEBUG - 2016-01-05 07:22:00 --> No URI present. Default controller set.
DEBUG - 2016-01-05 07:22:01 --> Output Class Initialized
DEBUG - 2016-01-05 07:22:02 --> Security Class Initialized
DEBUG - 2016-01-05 07:22:02 --> Input Class Initialized
DEBUG - 2016-01-05 07:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 07:22:02 --> Language Class Initialized
DEBUG - 2016-01-05 07:22:04 --> Language Class Initialized
DEBUG - 2016-01-05 07:22:04 --> Config Class Initialized
DEBUG - 2016-01-05 07:22:05 --> Loader Class Initialized
DEBUG - 2016-01-05 07:22:06 --> Helper loaded: url_helper
DEBUG - 2016-01-05 07:22:07 --> Helper loaded: form_helper
DEBUG - 2016-01-05 07:22:08 --> Database Driver Class Initialized
DEBUG - 2016-01-05 07:22:15 --> Session Class Initialized
DEBUG - 2016-01-05 07:22:15 --> Helper loaded: string_helper
DEBUG - 2016-01-05 07:22:15 --> A session cookie was not found.
DEBUG - 2016-01-05 07:22:15 --> Session routines successfully run
DEBUG - 2016-01-05 07:22:16 --> Form Validation Class Initialized
DEBUG - 2016-01-05 07:22:17 --> Pagination Class Initialized
DEBUG - 2016-01-05 07:22:17 --> Encrypt Class Initialized
DEBUG - 2016-01-05 07:22:17 --> Email Class Initialized
DEBUG - 2016-01-05 07:22:18 --> Controller Class Initialized
DEBUG - 2016-01-05 07:22:18 --> Auth MX_Controller Initialized
DEBUG - 2016-01-05 07:22:18 --> Model Class Initialized
DEBUG - 2016-01-05 07:22:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 07:22:18 --> Model Class Initialized
DEBUG - 2016-01-05 07:22:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 07:22:19 --> Model Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Config Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:22:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:22:21 --> URI Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Router Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Output Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Security Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Input Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 07:22:21 --> Language Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Language Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Config Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Loader Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Helper loaded: url_helper
DEBUG - 2016-01-05 07:22:21 --> Helper loaded: form_helper
DEBUG - 2016-01-05 07:22:21 --> Database Driver Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Session Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Helper loaded: string_helper
DEBUG - 2016-01-05 07:22:21 --> Session routines successfully run
DEBUG - 2016-01-05 07:22:21 --> Form Validation Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Pagination Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Encrypt Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Email Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Controller Class Initialized
DEBUG - 2016-01-05 07:22:21 --> Auth MX_Controller Initialized
DEBUG - 2016-01-05 07:22:21 --> Model Class Initialized
DEBUG - 2016-01-05 07:22:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 07:22:21 --> Model Class Initialized
DEBUG - 2016-01-05 07:22:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 07:22:21 --> Model Class Initialized
DEBUG - 2016-01-05 07:22:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 07:22:25 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-05 07:22:25 --> Final output sent to browser
DEBUG - 2016-01-05 07:22:25 --> Total execution time: 4.5712
DEBUG - 2016-01-05 07:23:33 --> Config Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Config Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Config Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Config Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:23:33 --> URI Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:23:33 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:23:33 --> URI Class Initialized
DEBUG - 2016-01-05 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:23:33 --> URI Class Initialized
DEBUG - 2016-01-05 07:23:33 --> URI Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Router Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Router Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Router Class Initialized
DEBUG - 2016-01-05 07:23:33 --> Router Class Initialized
ERROR - 2016-01-05 07:23:34 --> 404 Page Not Found --> 
ERROR - 2016-01-05 07:23:34 --> 404 Page Not Found --> 
ERROR - 2016-01-05 07:23:34 --> 404 Page Not Found --> 
ERROR - 2016-01-05 07:23:34 --> 404 Page Not Found --> 
DEBUG - 2016-01-05 07:24:05 --> Config Class Initialized
DEBUG - 2016-01-05 07:24:05 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:24:06 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:24:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:24:06 --> URI Class Initialized
DEBUG - 2016-01-05 07:24:07 --> Router Class Initialized
DEBUG - 2016-01-05 07:24:08 --> Output Class Initialized
DEBUG - 2016-01-05 07:24:09 --> Security Class Initialized
DEBUG - 2016-01-05 07:24:09 --> Input Class Initialized
DEBUG - 2016-01-05 07:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 07:24:09 --> Language Class Initialized
DEBUG - 2016-01-05 07:24:10 --> Language Class Initialized
DEBUG - 2016-01-05 07:24:10 --> Config Class Initialized
DEBUG - 2016-01-05 07:24:11 --> Loader Class Initialized
DEBUG - 2016-01-05 07:24:12 --> Helper loaded: url_helper
DEBUG - 2016-01-05 07:24:12 --> Helper loaded: form_helper
DEBUG - 2016-01-05 07:24:14 --> Database Driver Class Initialized
DEBUG - 2016-01-05 07:24:14 --> Session Class Initialized
DEBUG - 2016-01-05 07:24:14 --> Helper loaded: string_helper
DEBUG - 2016-01-05 07:24:14 --> Session routines successfully run
DEBUG - 2016-01-05 07:24:15 --> Form Validation Class Initialized
DEBUG - 2016-01-05 07:24:15 --> Pagination Class Initialized
DEBUG - 2016-01-05 07:24:15 --> Encrypt Class Initialized
DEBUG - 2016-01-05 07:24:15 --> Email Class Initialized
DEBUG - 2016-01-05 07:24:15 --> Controller Class Initialized
DEBUG - 2016-01-05 07:24:15 --> Auth MX_Controller Initialized
DEBUG - 2016-01-05 07:24:15 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 07:24:15 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 07:24:16 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 07:24:17 --> XSS Filtering completed
DEBUG - 2016-01-05 07:24:17 --> Unable to find validation rule: exists
DEBUG - 2016-01-05 07:24:17 --> XSS Filtering completed
DEBUG - 2016-01-05 07:24:27 --> Config Class Initialized
DEBUG - 2016-01-05 07:24:27 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:24:27 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:24:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:24:27 --> URI Class Initialized
DEBUG - 2016-01-05 07:24:27 --> Router Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Output Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Security Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Input Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 07:24:28 --> Language Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Language Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Config Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Loader Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Helper loaded: url_helper
DEBUG - 2016-01-05 07:24:28 --> Helper loaded: form_helper
DEBUG - 2016-01-05 07:24:28 --> Database Driver Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Session Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Helper loaded: string_helper
DEBUG - 2016-01-05 07:24:28 --> Session routines successfully run
DEBUG - 2016-01-05 07:24:28 --> Form Validation Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Pagination Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Encrypt Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Email Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Controller Class Initialized
DEBUG - 2016-01-05 07:24:28 --> Admin MX_Controller Initialized
DEBUG - 2016-01-05 07:24:29 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 07:24:29 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 07:24:29 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 07:24:29 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 07:24:29 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 07:24:29 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 07:24:29 --> Model Class Initialized
DEBUG - 2016-01-05 07:24:30 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-05 07:24:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 07:24:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 07:24:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 07:24:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 07:24:32 --> Final output sent to browser
DEBUG - 2016-01-05 07:24:32 --> Total execution time: 4.8224
DEBUG - 2016-01-05 07:30:08 --> Config Class Initialized
DEBUG - 2016-01-05 07:30:08 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:30:08 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:30:08 --> URI Class Initialized
DEBUG - 2016-01-05 07:30:08 --> Router Class Initialized
DEBUG - 2016-01-05 07:30:08 --> Output Class Initialized
DEBUG - 2016-01-05 07:30:08 --> Security Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Input Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 07:30:09 --> Language Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Language Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Config Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Loader Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Helper loaded: url_helper
DEBUG - 2016-01-05 07:30:09 --> Helper loaded: form_helper
DEBUG - 2016-01-05 07:30:09 --> Database Driver Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Session Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Helper loaded: string_helper
DEBUG - 2016-01-05 07:30:09 --> Session routines successfully run
DEBUG - 2016-01-05 07:30:09 --> Form Validation Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Pagination Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Encrypt Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Email Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Controller Class Initialized
DEBUG - 2016-01-05 07:30:09 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 07:30:09 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 07:30:09 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 07:30:09 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 07:30:09 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 07:30:09 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 07:30:09 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 07:30:09 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 07:30:09 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 07:30:09 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 07:30:10 --> Model Class Initialized
DEBUG - 2016-01-05 07:30:10 --> Image Lib Class Initialized
DEBUG - 2016-01-05 07:30:10 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 07:30:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 07:30:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 07:30:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 07:30:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 07:30:10 --> Final output sent to browser
DEBUG - 2016-01-05 07:30:10 --> Total execution time: 2.3921
DEBUG - 2016-01-05 07:33:57 --> Config Class Initialized
DEBUG - 2016-01-05 07:33:57 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:33:57 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:33:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:33:57 --> URI Class Initialized
DEBUG - 2016-01-05 07:33:57 --> Router Class Initialized
ERROR - 2016-01-05 07:33:57 --> 404 Page Not Found --> 
DEBUG - 2016-01-05 07:44:22 --> Config Class Initialized
DEBUG - 2016-01-05 07:44:22 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:44:22 --> Utf8 Class Initialized
DEBUG - 2016-01-05 07:44:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 07:44:22 --> URI Class Initialized
DEBUG - 2016-01-05 07:44:22 --> Router Class Initialized
ERROR - 2016-01-05 07:44:22 --> 404 Page Not Found --> 
DEBUG - 2016-01-05 08:04:54 --> Config Class Initialized
DEBUG - 2016-01-05 08:04:54 --> Hooks Class Initialized
DEBUG - 2016-01-05 08:04:54 --> Utf8 Class Initialized
DEBUG - 2016-01-05 08:04:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 08:04:54 --> URI Class Initialized
DEBUG - 2016-01-05 08:04:55 --> Router Class Initialized
ERROR - 2016-01-05 08:04:55 --> 404 Page Not Found --> 
DEBUG - 2016-01-05 08:05:53 --> Config Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Hooks Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Utf8 Class Initialized
DEBUG - 2016-01-05 08:05:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 08:05:53 --> URI Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Router Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Output Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Security Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Input Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 08:05:53 --> Language Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Language Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Config Class Initialized
DEBUG - 2016-01-05 08:05:53 --> Loader Class Initialized
DEBUG - 2016-01-05 08:05:54 --> Helper loaded: url_helper
DEBUG - 2016-01-05 08:05:54 --> Helper loaded: form_helper
DEBUG - 2016-01-05 08:05:54 --> Database Driver Class Initialized
DEBUG - 2016-01-05 08:05:54 --> Session Class Initialized
DEBUG - 2016-01-05 08:05:54 --> Helper loaded: string_helper
DEBUG - 2016-01-05 08:05:54 --> Session routines successfully run
DEBUG - 2016-01-05 08:05:54 --> Form Validation Class Initialized
DEBUG - 2016-01-05 08:05:55 --> Pagination Class Initialized
DEBUG - 2016-01-05 08:05:55 --> Encrypt Class Initialized
DEBUG - 2016-01-05 08:05:55 --> Email Class Initialized
DEBUG - 2016-01-05 08:05:55 --> Controller Class Initialized
DEBUG - 2016-01-05 08:05:55 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 08:05:55 --> Model Class Initialized
DEBUG - 2016-01-05 08:05:55 --> Image Lib Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Config Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Hooks Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Utf8 Class Initialized
DEBUG - 2016-01-05 08:06:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 08:06:30 --> URI Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Router Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Output Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Security Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Input Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 08:06:30 --> Language Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Language Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Config Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Loader Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Helper loaded: url_helper
DEBUG - 2016-01-05 08:06:30 --> Helper loaded: form_helper
DEBUG - 2016-01-05 08:06:30 --> Database Driver Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Session Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Helper loaded: string_helper
DEBUG - 2016-01-05 08:06:30 --> Session routines successfully run
DEBUG - 2016-01-05 08:06:30 --> Form Validation Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Pagination Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Encrypt Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Email Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Controller Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 08:06:30 --> Model Class Initialized
DEBUG - 2016-01-05 08:06:30 --> Image Lib Class Initialized
DEBUG - 2016-01-05 08:06:30 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 08:06:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 08:06:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 08:06:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 08:06:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 08:06:31 --> Final output sent to browser
DEBUG - 2016-01-05 08:06:31 --> Total execution time: 0.6598
DEBUG - 2016-01-05 08:10:06 --> Config Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Hooks Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Utf8 Class Initialized
DEBUG - 2016-01-05 08:10:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 08:10:06 --> URI Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Router Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Output Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Security Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Input Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 08:10:06 --> Language Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Language Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Config Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Loader Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Helper loaded: url_helper
DEBUG - 2016-01-05 08:10:06 --> Helper loaded: form_helper
DEBUG - 2016-01-05 08:10:06 --> Database Driver Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Session Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Helper loaded: string_helper
DEBUG - 2016-01-05 08:10:06 --> Session routines successfully run
DEBUG - 2016-01-05 08:10:06 --> Form Validation Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Pagination Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Encrypt Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Email Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Controller Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 08:10:06 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:06 --> Image Lib Class Initialized
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 08:10:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 08:10:06 --> Final output sent to browser
DEBUG - 2016-01-05 08:10:06 --> Total execution time: 0.5204
DEBUG - 2016-01-05 08:10:22 --> Config Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Hooks Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Utf8 Class Initialized
DEBUG - 2016-01-05 08:10:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 08:10:22 --> URI Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Router Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Output Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Security Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Input Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 08:10:22 --> Language Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Language Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Config Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Loader Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Helper loaded: url_helper
DEBUG - 2016-01-05 08:10:22 --> Helper loaded: form_helper
DEBUG - 2016-01-05 08:10:22 --> Database Driver Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Session Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Helper loaded: string_helper
DEBUG - 2016-01-05 08:10:22 --> Session routines successfully run
DEBUG - 2016-01-05 08:10:22 --> Form Validation Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Pagination Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Encrypt Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Email Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Controller Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 08:10:22 --> Model Class Initialized
DEBUG - 2016-01-05 08:10:22 --> Image Lib Class Initialized
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 08:10:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 08:10:22 --> Final output sent to browser
DEBUG - 2016-01-05 08:10:22 --> Total execution time: 0.4730
DEBUG - 2016-01-05 08:17:08 --> Config Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Hooks Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Utf8 Class Initialized
DEBUG - 2016-01-05 08:17:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 08:17:08 --> URI Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Router Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Output Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Security Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Input Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 08:17:08 --> Language Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Language Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Config Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Loader Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Helper loaded: url_helper
DEBUG - 2016-01-05 08:17:08 --> Helper loaded: form_helper
DEBUG - 2016-01-05 08:17:08 --> Database Driver Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Session Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Helper loaded: string_helper
DEBUG - 2016-01-05 08:17:08 --> Session routines successfully run
DEBUG - 2016-01-05 08:17:08 --> Form Validation Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Pagination Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Encrypt Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Email Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Controller Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 08:17:08 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:08 --> Image Lib Class Initialized
ERROR - 2016-01-05 08:17:08 --> Severity: Notice  --> Undefined variable: property_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\rental_unit.php 37
DEBUG - 2016-01-05 08:17:08 --> DB Transaction Failure
ERROR - 2016-01-05 08:17:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
DEBUG - 2016-01-05 08:17:08 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-01-05 08:17:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\core\Common.php 441
DEBUG - 2016-01-05 08:17:36 --> Config Class Initialized
DEBUG - 2016-01-05 08:17:36 --> Hooks Class Initialized
DEBUG - 2016-01-05 08:17:36 --> Utf8 Class Initialized
DEBUG - 2016-01-05 08:17:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 08:17:36 --> URI Class Initialized
DEBUG - 2016-01-05 08:17:36 --> Router Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Output Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Security Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Input Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 08:17:37 --> Language Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Language Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Config Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Loader Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Helper loaded: url_helper
DEBUG - 2016-01-05 08:17:37 --> Helper loaded: form_helper
DEBUG - 2016-01-05 08:17:37 --> Database Driver Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Session Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Helper loaded: string_helper
DEBUG - 2016-01-05 08:17:37 --> Session routines successfully run
DEBUG - 2016-01-05 08:17:37 --> Form Validation Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Pagination Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Encrypt Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Email Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Controller Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 08:17:37 --> Model Class Initialized
DEBUG - 2016-01-05 08:17:37 --> Image Lib Class Initialized
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 08:17:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 08:17:37 --> Final output sent to browser
DEBUG - 2016-01-05 08:17:37 --> Total execution time: 0.8520
DEBUG - 2016-01-05 08:58:09 --> Config Class Initialized
DEBUG - 2016-01-05 08:58:09 --> Hooks Class Initialized
DEBUG - 2016-01-05 08:58:09 --> Utf8 Class Initialized
DEBUG - 2016-01-05 08:58:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 08:58:09 --> URI Class Initialized
DEBUG - 2016-01-05 08:58:09 --> Router Class Initialized
DEBUG - 2016-01-05 08:58:10 --> Output Class Initialized
DEBUG - 2016-01-05 08:58:10 --> Security Class Initialized
DEBUG - 2016-01-05 08:58:10 --> Input Class Initialized
DEBUG - 2016-01-05 08:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 08:58:10 --> Language Class Initialized
DEBUG - 2016-01-05 08:58:11 --> Language Class Initialized
DEBUG - 2016-01-05 08:58:11 --> Config Class Initialized
DEBUG - 2016-01-05 08:58:11 --> Loader Class Initialized
DEBUG - 2016-01-05 08:58:11 --> Helper loaded: url_helper
DEBUG - 2016-01-05 08:58:11 --> Helper loaded: form_helper
DEBUG - 2016-01-05 08:58:11 --> Database Driver Class Initialized
DEBUG - 2016-01-05 08:58:12 --> Session Class Initialized
DEBUG - 2016-01-05 08:58:12 --> Helper loaded: string_helper
DEBUG - 2016-01-05 08:58:12 --> Session routines successfully run
DEBUG - 2016-01-05 08:58:12 --> Form Validation Class Initialized
DEBUG - 2016-01-05 08:58:12 --> Pagination Class Initialized
DEBUG - 2016-01-05 08:58:12 --> Encrypt Class Initialized
DEBUG - 2016-01-05 08:58:12 --> Email Class Initialized
DEBUG - 2016-01-05 08:58:12 --> Controller Class Initialized
DEBUG - 2016-01-05 08:58:12 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 08:58:12 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 08:58:12 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 08:58:12 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 08:58:13 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 08:58:13 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 08:58:13 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 08:58:13 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 08:58:13 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 08:58:13 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 08:58:13 --> Model Class Initialized
DEBUG - 2016-01-05 08:58:13 --> Image Lib Class Initialized
DEBUG - 2016-01-05 08:58:13 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 08:58:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 08:58:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 08:58:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 08:58:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 08:58:14 --> Final output sent to browser
DEBUG - 2016-01-05 08:58:14 --> Total execution time: 6.0481
DEBUG - 2016-01-05 09:06:20 --> Config Class Initialized
DEBUG - 2016-01-05 09:06:20 --> Hooks Class Initialized
DEBUG - 2016-01-05 09:06:20 --> Utf8 Class Initialized
DEBUG - 2016-01-05 09:06:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 09:06:20 --> URI Class Initialized
DEBUG - 2016-01-05 09:06:20 --> Router Class Initialized
DEBUG - 2016-01-05 09:06:21 --> Output Class Initialized
DEBUG - 2016-01-05 09:06:21 --> Security Class Initialized
DEBUG - 2016-01-05 09:06:21 --> Input Class Initialized
DEBUG - 2016-01-05 09:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 09:06:21 --> Language Class Initialized
DEBUG - 2016-01-05 09:06:21 --> Language Class Initialized
DEBUG - 2016-01-05 09:06:21 --> Config Class Initialized
DEBUG - 2016-01-05 09:06:21 --> Loader Class Initialized
DEBUG - 2016-01-05 09:06:21 --> Helper loaded: url_helper
DEBUG - 2016-01-05 09:06:21 --> Helper loaded: form_helper
DEBUG - 2016-01-05 09:06:22 --> Database Driver Class Initialized
DEBUG - 2016-01-05 09:06:22 --> Session Class Initialized
DEBUG - 2016-01-05 09:06:22 --> Helper loaded: string_helper
DEBUG - 2016-01-05 09:06:22 --> Session routines successfully run
DEBUG - 2016-01-05 09:06:22 --> Form Validation Class Initialized
DEBUG - 2016-01-05 09:06:22 --> Pagination Class Initialized
DEBUG - 2016-01-05 09:06:22 --> Encrypt Class Initialized
DEBUG - 2016-01-05 09:06:22 --> Email Class Initialized
DEBUG - 2016-01-05 09:06:22 --> Controller Class Initialized
DEBUG - 2016-01-05 09:06:22 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 09:06:22 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:23 --> Image Lib Class Initialized
DEBUG - 2016-01-05 09:06:23 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 09:06:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 09:06:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 09:06:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 09:06:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 09:06:23 --> Final output sent to browser
DEBUG - 2016-01-05 09:06:23 --> Total execution time: 3.3313
DEBUG - 2016-01-05 09:06:46 --> Config Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Hooks Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Utf8 Class Initialized
DEBUG - 2016-01-05 09:06:46 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 09:06:46 --> URI Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Router Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Output Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Security Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Input Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 09:06:46 --> Language Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Language Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Config Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Loader Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Helper loaded: url_helper
DEBUG - 2016-01-05 09:06:46 --> Helper loaded: form_helper
DEBUG - 2016-01-05 09:06:46 --> Database Driver Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Session Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Helper loaded: string_helper
DEBUG - 2016-01-05 09:06:46 --> Session routines successfully run
DEBUG - 2016-01-05 09:06:46 --> Form Validation Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Pagination Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Encrypt Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Email Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Controller Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 09:06:46 --> Model Class Initialized
DEBUG - 2016-01-05 09:06:46 --> Image Lib Class Initialized
DEBUG - 2016-01-05 09:06:47 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-01-05 09:06:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 09:06:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 09:06:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 09:06:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 09:06:47 --> Final output sent to browser
DEBUG - 2016-01-05 09:06:47 --> Total execution time: 0.5290
DEBUG - 2016-01-05 09:07:18 --> Config Class Initialized
DEBUG - 2016-01-05 09:07:18 --> Hooks Class Initialized
DEBUG - 2016-01-05 09:07:18 --> Utf8 Class Initialized
DEBUG - 2016-01-05 09:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 09:07:18 --> URI Class Initialized
DEBUG - 2016-01-05 09:07:18 --> Router Class Initialized
DEBUG - 2016-01-05 09:07:18 --> Output Class Initialized
DEBUG - 2016-01-05 09:07:18 --> Security Class Initialized
DEBUG - 2016-01-05 09:07:18 --> Input Class Initialized
DEBUG - 2016-01-05 09:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 09:07:18 --> Language Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Language Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Config Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Loader Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Helper loaded: url_helper
DEBUG - 2016-01-05 09:07:19 --> Helper loaded: form_helper
DEBUG - 2016-01-05 09:07:19 --> Database Driver Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Session Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Helper loaded: string_helper
DEBUG - 2016-01-05 09:07:19 --> Session routines successfully run
DEBUG - 2016-01-05 09:07:19 --> Form Validation Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Pagination Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Encrypt Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Email Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Controller Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Image Lib Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 09:07:19 --> XSS Filtering completed
DEBUG - 2016-01-05 09:07:19 --> XSS Filtering completed
DEBUG - 2016-01-05 09:07:19 --> XSS Filtering completed
DEBUG - 2016-01-05 09:07:19 --> XSS Filtering completed
DEBUG - 2016-01-05 09:07:19 --> XSS Filtering completed
DEBUG - 2016-01-05 09:07:19 --> XSS Filtering completed
DEBUG - 2016-01-05 09:07:19 --> Config Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Hooks Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Utf8 Class Initialized
DEBUG - 2016-01-05 09:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 09:07:19 --> URI Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Router Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Output Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Security Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Input Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 09:07:19 --> Language Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Language Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Config Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Loader Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Helper loaded: url_helper
DEBUG - 2016-01-05 09:07:19 --> Helper loaded: form_helper
DEBUG - 2016-01-05 09:07:19 --> Database Driver Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Session Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Helper loaded: string_helper
DEBUG - 2016-01-05 09:07:19 --> Session routines successfully run
DEBUG - 2016-01-05 09:07:19 --> Form Validation Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Pagination Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Encrypt Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Email Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Controller Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 09:07:19 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:19 --> Image Lib Class Initialized
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 09:07:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 09:07:19 --> Final output sent to browser
DEBUG - 2016-01-05 09:07:19 --> Total execution time: 0.2475
DEBUG - 2016-01-05 09:07:23 --> Config Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Hooks Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Utf8 Class Initialized
DEBUG - 2016-01-05 09:07:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 09:07:23 --> URI Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Router Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Output Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Security Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Input Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 09:07:23 --> Language Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Language Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Config Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Loader Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Helper loaded: url_helper
DEBUG - 2016-01-05 09:07:23 --> Helper loaded: form_helper
DEBUG - 2016-01-05 09:07:23 --> Database Driver Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Session Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Helper loaded: string_helper
DEBUG - 2016-01-05 09:07:23 --> Session routines successfully run
DEBUG - 2016-01-05 09:07:23 --> Form Validation Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Pagination Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Encrypt Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Email Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Controller Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 09:07:23 --> Model Class Initialized
DEBUG - 2016-01-05 09:07:23 --> Image Lib Class Initialized
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 09:07:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 09:07:23 --> Final output sent to browser
DEBUG - 2016-01-05 09:07:23 --> Total execution time: 0.3238
DEBUG - 2016-01-05 09:16:57 --> Config Class Initialized
DEBUG - 2016-01-05 09:16:57 --> Hooks Class Initialized
DEBUG - 2016-01-05 09:16:57 --> Utf8 Class Initialized
DEBUG - 2016-01-05 09:16:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 09:16:57 --> URI Class Initialized
DEBUG - 2016-01-05 09:16:57 --> Router Class Initialized
DEBUG - 2016-01-05 09:16:57 --> Output Class Initialized
DEBUG - 2016-01-05 09:16:57 --> Security Class Initialized
DEBUG - 2016-01-05 09:16:58 --> Input Class Initialized
DEBUG - 2016-01-05 09:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 09:16:58 --> Language Class Initialized
DEBUG - 2016-01-05 09:16:58 --> Language Class Initialized
DEBUG - 2016-01-05 09:16:58 --> Config Class Initialized
DEBUG - 2016-01-05 09:16:58 --> Loader Class Initialized
DEBUG - 2016-01-05 09:16:58 --> Helper loaded: url_helper
DEBUG - 2016-01-05 09:16:58 --> Helper loaded: form_helper
DEBUG - 2016-01-05 09:16:59 --> Database Driver Class Initialized
DEBUG - 2016-01-05 09:16:59 --> Session Class Initialized
DEBUG - 2016-01-05 09:16:59 --> Helper loaded: string_helper
DEBUG - 2016-01-05 09:16:59 --> Session routines successfully run
DEBUG - 2016-01-05 09:16:59 --> Form Validation Class Initialized
DEBUG - 2016-01-05 09:16:59 --> Pagination Class Initialized
DEBUG - 2016-01-05 09:16:59 --> Encrypt Class Initialized
DEBUG - 2016-01-05 09:16:59 --> Email Class Initialized
DEBUG - 2016-01-05 09:16:59 --> Controller Class Initialized
DEBUG - 2016-01-05 09:16:59 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 09:17:00 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:00 --> Image Lib Class Initialized
DEBUG - 2016-01-05 09:17:00 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 09:17:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 09:17:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 09:17:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 09:17:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 09:17:01 --> Final output sent to browser
DEBUG - 2016-01-05 09:17:01 --> Total execution time: 4.4801
DEBUG - 2016-01-05 09:17:06 --> Config Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Hooks Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Utf8 Class Initialized
DEBUG - 2016-01-05 09:17:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 09:17:06 --> URI Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Router Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Output Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Security Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Input Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 09:17:06 --> Language Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Language Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Config Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Loader Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Helper loaded: url_helper
DEBUG - 2016-01-05 09:17:06 --> Helper loaded: form_helper
DEBUG - 2016-01-05 09:17:06 --> Database Driver Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Session Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Helper loaded: string_helper
DEBUG - 2016-01-05 09:17:06 --> Session routines successfully run
DEBUG - 2016-01-05 09:17:06 --> Form Validation Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Pagination Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Encrypt Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Email Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Controller Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 09:17:06 --> Model Class Initialized
DEBUG - 2016-01-05 09:17:06 --> Image Lib Class Initialized
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 09:17:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 09:17:06 --> Final output sent to browser
DEBUG - 2016-01-05 09:17:06 --> Total execution time: 0.2874
DEBUG - 2016-01-05 10:11:48 --> Config Class Initialized
DEBUG - 2016-01-05 10:11:48 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:11:48 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:11:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:11:48 --> URI Class Initialized
DEBUG - 2016-01-05 10:11:49 --> Router Class Initialized
DEBUG - 2016-01-05 10:11:49 --> Output Class Initialized
DEBUG - 2016-01-05 10:11:49 --> Security Class Initialized
DEBUG - 2016-01-05 10:11:49 --> Input Class Initialized
DEBUG - 2016-01-05 10:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:11:49 --> Language Class Initialized
DEBUG - 2016-01-05 10:12:29 --> Config Class Initialized
DEBUG - 2016-01-05 10:12:29 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:12:29 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:12:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:12:29 --> URI Class Initialized
DEBUG - 2016-01-05 10:12:29 --> Router Class Initialized
DEBUG - 2016-01-05 10:12:29 --> Output Class Initialized
DEBUG - 2016-01-05 10:12:29 --> Security Class Initialized
DEBUG - 2016-01-05 10:12:29 --> Input Class Initialized
DEBUG - 2016-01-05 10:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:12:29 --> Language Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Config Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:13:03 --> URI Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Router Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Output Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Security Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Input Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:13:03 --> Language Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Language Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Config Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Loader Class Initialized
DEBUG - 2016-01-05 10:13:03 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:13:04 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:13:04 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:13:04 --> Session Class Initialized
DEBUG - 2016-01-05 10:13:04 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:13:04 --> Session routines successfully run
DEBUG - 2016-01-05 10:13:04 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:13:04 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:13:05 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:13:05 --> Email Class Initialized
DEBUG - 2016-01-05 10:13:05 --> Controller Class Initialized
DEBUG - 2016-01-05 10:13:05 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:13:05 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:05 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:13:06 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:13:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:13:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:13:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:13:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:13:07 --> Final output sent to browser
DEBUG - 2016-01-05 10:13:07 --> Total execution time: 3.5605
DEBUG - 2016-01-05 10:13:28 --> Config Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:13:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:13:28 --> URI Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Router Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Output Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Security Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Input Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:13:28 --> Language Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Language Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Config Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Loader Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:13:28 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:13:28 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Session Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:13:28 --> Session routines successfully run
DEBUG - 2016-01-05 10:13:28 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Email Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Controller Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:13:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:28 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:13:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:13:28 --> Final output sent to browser
DEBUG - 2016-01-05 10:13:28 --> Total execution time: 0.3930
DEBUG - 2016-01-05 10:13:57 --> Config Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:13:57 --> URI Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Router Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Output Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Security Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Input Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:13:57 --> Language Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Language Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Config Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Loader Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:13:57 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:13:57 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Session Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:13:57 --> Session routines successfully run
DEBUG - 2016-01-05 10:13:57 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Email Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Controller Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:13:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:13:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 10:13:57 --> XSS Filtering completed
DEBUG - 2016-01-05 10:13:57 --> XSS Filtering completed
DEBUG - 2016-01-05 10:13:57 --> XSS Filtering completed
DEBUG - 2016-01-05 10:13:57 --> XSS Filtering completed
DEBUG - 2016-01-05 10:13:57 --> XSS Filtering completed
DEBUG - 2016-01-05 10:13:57 --> XSS Filtering completed
ERROR - 2016-01-05 10:13:57 --> Severity: Notice  --> Undefined variable: property_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 105
ERROR - 2016-01-05 10:13:57 --> Severity: Notice  --> Undefined variable: rental_unit C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 105
DEBUG - 2016-01-05 10:13:58 --> DB Transaction Failure
ERROR - 2016-01-05 10:13:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
DEBUG - 2016-01-05 10:13:58 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-01-05 10:13:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\core\Common.php 441
DEBUG - 2016-01-05 10:16:31 --> Config Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:16:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:16:31 --> URI Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Router Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Output Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Security Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Input Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:16:31 --> Language Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Language Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Config Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Loader Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:16:31 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:16:31 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Session Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:16:31 --> Session routines successfully run
DEBUG - 2016-01-05 10:16:31 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Email Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Controller Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:16:31 --> Model Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:16:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 10:16:31 --> XSS Filtering completed
DEBUG - 2016-01-05 10:16:31 --> XSS Filtering completed
DEBUG - 2016-01-05 10:16:31 --> XSS Filtering completed
DEBUG - 2016-01-05 10:16:31 --> XSS Filtering completed
DEBUG - 2016-01-05 10:16:31 --> XSS Filtering completed
DEBUG - 2016-01-05 10:16:31 --> XSS Filtering completed
DEBUG - 2016-01-05 10:16:31 --> DB Transaction Failure
ERROR - 2016-01-05 10:16:31 --> Query error: Unknown column 'rental_unit_status' in 'field list'
DEBUG - 2016-01-05 10:16:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-05 10:17:49 --> Config Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:17:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:17:49 --> URI Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Router Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Output Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Security Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Input Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:17:49 --> Language Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Language Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Config Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Loader Class Initialized
DEBUG - 2016-01-05 10:17:49 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:17:49 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:17:49 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Session Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:17:50 --> Session routines successfully run
DEBUG - 2016-01-05 10:17:50 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Email Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Controller Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 10:17:50 --> XSS Filtering completed
DEBUG - 2016-01-05 10:17:50 --> XSS Filtering completed
DEBUG - 2016-01-05 10:17:50 --> XSS Filtering completed
DEBUG - 2016-01-05 10:17:50 --> XSS Filtering completed
DEBUG - 2016-01-05 10:17:50 --> XSS Filtering completed
DEBUG - 2016-01-05 10:17:50 --> XSS Filtering completed
DEBUG - 2016-01-05 10:17:50 --> Config Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:17:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:17:50 --> URI Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Router Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Output Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Security Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Input Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:17:50 --> Language Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Language Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Config Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Loader Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:17:50 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:17:50 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Session Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:17:50 --> Session routines successfully run
DEBUG - 2016-01-05 10:17:50 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Email Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Controller Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:17:50 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:50 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:17:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:17:50 --> Final output sent to browser
DEBUG - 2016-01-05 10:17:50 --> Total execution time: 0.2927
DEBUG - 2016-01-05 10:17:57 --> Config Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:17:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:17:57 --> URI Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Router Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Output Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Security Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Input Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:17:57 --> Language Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Language Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Config Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Loader Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:17:57 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:17:57 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Session Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:17:57 --> Session routines successfully run
DEBUG - 2016-01-05 10:17:57 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Email Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Controller Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:17:57 --> Model Class Initialized
DEBUG - 2016-01-05 10:17:57 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:17:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:17:57 --> Final output sent to browser
DEBUG - 2016-01-05 10:17:57 --> Total execution time: 0.8321
DEBUG - 2016-01-05 10:19:54 --> Config Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:19:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:19:54 --> URI Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Router Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Output Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Security Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Input Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:19:54 --> Language Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Language Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Config Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Loader Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:19:54 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:19:54 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Session Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:19:54 --> Session routines successfully run
DEBUG - 2016-01-05 10:19:54 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Email Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Controller Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:19:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:54 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:19:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:19:54 --> Final output sent to browser
DEBUG - 2016-01-05 10:19:54 --> Total execution time: 0.2635
DEBUG - 2016-01-05 10:19:56 --> Config Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:19:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:19:56 --> URI Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Router Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Output Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Security Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Input Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:19:56 --> Language Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Language Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Config Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Loader Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:19:56 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:19:56 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Session Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:19:56 --> Session routines successfully run
DEBUG - 2016-01-05 10:19:56 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Email Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Controller Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:19:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:19:56 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:19:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:19:56 --> Final output sent to browser
DEBUG - 2016-01-05 10:19:56 --> Total execution time: 0.2987
DEBUG - 2016-01-05 10:20:07 --> Config Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:20:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:20:07 --> URI Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Router Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Output Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Security Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Input Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:20:07 --> Language Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Language Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Config Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Loader Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:20:07 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:20:07 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Session Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:20:07 --> Session routines successfully run
DEBUG - 2016-01-05 10:20:07 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Email Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Controller Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 10:20:07 --> XSS Filtering completed
DEBUG - 2016-01-05 10:20:07 --> XSS Filtering completed
DEBUG - 2016-01-05 10:20:07 --> XSS Filtering completed
DEBUG - 2016-01-05 10:20:07 --> XSS Filtering completed
DEBUG - 2016-01-05 10:20:07 --> XSS Filtering completed
DEBUG - 2016-01-05 10:20:07 --> XSS Filtering completed
DEBUG - 2016-01-05 10:20:07 --> Config Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:20:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:20:07 --> URI Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Router Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Output Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Security Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Input Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:20:07 --> Language Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Language Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Config Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Loader Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:20:07 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:20:07 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Session Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:20:07 --> Session routines successfully run
DEBUG - 2016-01-05 10:20:07 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Email Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Controller Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:20:07 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:07 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:20:08 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:20:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:20:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:20:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:20:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:20:08 --> Final output sent to browser
DEBUG - 2016-01-05 10:20:08 --> Total execution time: 0.2412
DEBUG - 2016-01-05 10:20:10 --> Config Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:20:10 --> URI Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Router Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Output Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Security Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Input Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:20:10 --> Language Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Language Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Config Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Loader Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:20:10 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:20:10 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Session Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:20:10 --> Session routines successfully run
DEBUG - 2016-01-05 10:20:10 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Email Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Controller Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:20:10 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:20:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:20:10 --> Final output sent to browser
DEBUG - 2016-01-05 10:20:10 --> Total execution time: 0.2554
DEBUG - 2016-01-05 10:21:30 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:21:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:21:30 --> URI Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Router Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Output Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Security Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Input Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:21:30 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Loader Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:21:30 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:21:30 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Session Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:21:30 --> Session routines successfully run
DEBUG - 2016-01-05 10:21:30 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Email Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Controller Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:21:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:30 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:21:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:21:30 --> Final output sent to browser
DEBUG - 2016-01-05 10:21:30 --> Total execution time: 0.2462
DEBUG - 2016-01-05 10:21:32 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:21:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:21:32 --> URI Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Router Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Output Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Security Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Input Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:21:32 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Loader Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:21:32 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:21:32 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Session Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:21:32 --> Session routines successfully run
DEBUG - 2016-01-05 10:21:32 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Email Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Controller Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:21:32 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:32 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:21:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:21:32 --> Final output sent to browser
DEBUG - 2016-01-05 10:21:32 --> Total execution time: 0.2927
DEBUG - 2016-01-05 10:21:43 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:21:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:21:43 --> URI Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Router Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Output Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Security Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Input Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:21:43 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Loader Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:21:43 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:21:43 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Session Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:21:43 --> Session routines successfully run
DEBUG - 2016-01-05 10:21:43 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Email Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Controller Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 10:21:43 --> XSS Filtering completed
DEBUG - 2016-01-05 10:21:43 --> XSS Filtering completed
DEBUG - 2016-01-05 10:21:43 --> XSS Filtering completed
DEBUG - 2016-01-05 10:21:43 --> XSS Filtering completed
DEBUG - 2016-01-05 10:21:43 --> XSS Filtering completed
DEBUG - 2016-01-05 10:21:43 --> XSS Filtering completed
DEBUG - 2016-01-05 10:21:43 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:21:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:21:43 --> URI Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Router Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Output Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Security Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Input Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:21:43 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Loader Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:21:43 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:21:43 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Session Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:21:43 --> Session routines successfully run
DEBUG - 2016-01-05 10:21:43 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Email Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Controller Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:21:43 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:43 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:21:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:21:43 --> Final output sent to browser
DEBUG - 2016-01-05 10:21:43 --> Total execution time: 0.2199
DEBUG - 2016-01-05 10:21:46 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:21:46 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:21:46 --> URI Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Router Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Output Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Security Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Input Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:21:46 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Language Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Config Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Loader Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:21:46 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:21:46 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Session Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:21:46 --> Session routines successfully run
DEBUG - 2016-01-05 10:21:46 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Email Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Controller Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:21:46 --> Model Class Initialized
DEBUG - 2016-01-05 10:21:46 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:21:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:21:46 --> Final output sent to browser
DEBUG - 2016-01-05 10:21:46 --> Total execution time: 0.2784
DEBUG - 2016-01-05 10:25:01 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:25:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:25:01 --> URI Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Router Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Output Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Security Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Input Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:25:01 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Loader Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:25:01 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:25:01 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Session Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:25:01 --> Session routines successfully run
DEBUG - 2016-01-05 10:25:01 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Email Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Controller Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:25:01 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:01 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:25:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:25:01 --> Final output sent to browser
DEBUG - 2016-01-05 10:25:01 --> Total execution time: 0.3390
DEBUG - 2016-01-05 10:25:03 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:25:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:25:03 --> URI Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Router Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Output Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Security Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Input Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:25:03 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Loader Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:25:03 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:25:03 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Session Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:25:03 --> Session routines successfully run
DEBUG - 2016-01-05 10:25:03 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Email Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Controller Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:25:03 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:03 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:25:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:25:03 --> Final output sent to browser
DEBUG - 2016-01-05 10:25:03 --> Total execution time: 0.3014
DEBUG - 2016-01-05 10:25:09 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:25:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:25:09 --> URI Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Router Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Output Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Security Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Input Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:25:09 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Loader Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:25:09 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:25:09 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Session Class Initialized
DEBUG - 2016-01-05 10:25:09 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:25:10 --> Session routines successfully run
DEBUG - 2016-01-05 10:25:10 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Email Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Controller Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 10:25:10 --> XSS Filtering completed
DEBUG - 2016-01-05 10:25:10 --> XSS Filtering completed
DEBUG - 2016-01-05 10:25:10 --> XSS Filtering completed
DEBUG - 2016-01-05 10:25:10 --> XSS Filtering completed
DEBUG - 2016-01-05 10:25:10 --> XSS Filtering completed
DEBUG - 2016-01-05 10:25:10 --> XSS Filtering completed
DEBUG - 2016-01-05 10:25:10 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:25:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:25:10 --> URI Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Router Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Output Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Security Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Input Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:25:10 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Loader Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:25:10 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:25:10 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Session Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:25:10 --> Session routines successfully run
DEBUG - 2016-01-05 10:25:10 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Email Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Controller Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:25:10 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:10 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:25:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:25:10 --> Final output sent to browser
DEBUG - 2016-01-05 10:25:10 --> Total execution time: 0.2415
DEBUG - 2016-01-05 10:25:12 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:25:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:25:12 --> URI Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Router Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Output Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Security Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Input Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:25:12 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Language Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Config Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Loader Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:25:12 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:25:12 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Session Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:25:12 --> Session routines successfully run
DEBUG - 2016-01-05 10:25:12 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Email Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Controller Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:25:12 --> Model Class Initialized
DEBUG - 2016-01-05 10:25:12 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:25:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:25:12 --> Final output sent to browser
DEBUG - 2016-01-05 10:25:12 --> Total execution time: 0.2876
DEBUG - 2016-01-05 10:26:19 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:26:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:26:19 --> URI Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Router Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Output Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Security Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Input Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:26:19 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Loader Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:26:19 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:26:19 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Session Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:26:19 --> Session routines successfully run
DEBUG - 2016-01-05 10:26:19 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Email Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Controller Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:26:19 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:19 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:26:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:26:19 --> Final output sent to browser
DEBUG - 2016-01-05 10:26:19 --> Total execution time: 0.2282
DEBUG - 2016-01-05 10:26:21 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:26:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:26:21 --> URI Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Router Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Output Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Security Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Input Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:26:21 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Loader Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:26:21 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:26:21 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Session Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:26:21 --> Session routines successfully run
DEBUG - 2016-01-05 10:26:21 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Email Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Controller Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:26:21 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:21 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:26:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:26:21 --> Final output sent to browser
DEBUG - 2016-01-05 10:26:21 --> Total execution time: 0.3645
DEBUG - 2016-01-05 10:26:28 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:26:28 --> URI Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Router Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Output Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Security Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Input Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:26:28 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Loader Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:26:28 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:26:28 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Session Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:26:28 --> Session routines successfully run
DEBUG - 2016-01-05 10:26:28 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Email Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Controller Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 10:26:28 --> XSS Filtering completed
DEBUG - 2016-01-05 10:26:28 --> XSS Filtering completed
DEBUG - 2016-01-05 10:26:28 --> XSS Filtering completed
DEBUG - 2016-01-05 10:26:28 --> XSS Filtering completed
DEBUG - 2016-01-05 10:26:28 --> XSS Filtering completed
DEBUG - 2016-01-05 10:26:28 --> XSS Filtering completed
DEBUG - 2016-01-05 10:26:28 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:26:28 --> URI Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Router Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Output Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Security Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Input Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:26:28 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Loader Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:26:28 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:26:28 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Session Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:26:28 --> Session routines successfully run
DEBUG - 2016-01-05 10:26:28 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Email Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Controller Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:26:28 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:28 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:26:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:26:28 --> Final output sent to browser
DEBUG - 2016-01-05 10:26:28 --> Total execution time: 0.2318
DEBUG - 2016-01-05 10:26:30 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:26:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:26:30 --> URI Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Router Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Output Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Security Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Input Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:26:30 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Language Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Config Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Loader Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:26:30 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:26:30 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Session Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:26:30 --> Session routines successfully run
DEBUG - 2016-01-05 10:26:30 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Email Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Controller Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:26:30 --> Model Class Initialized
DEBUG - 2016-01-05 10:26:30 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:26:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:26:30 --> Final output sent to browser
DEBUG - 2016-01-05 10:26:30 --> Total execution time: 0.2559
DEBUG - 2016-01-05 10:27:47 --> Config Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:27:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:27:47 --> URI Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Router Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Output Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Security Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Input Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:27:47 --> Language Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Language Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Config Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Loader Class Initialized
DEBUG - 2016-01-05 10:27:47 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:27:47 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:27:47 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:27:48 --> Session Class Initialized
DEBUG - 2016-01-05 10:27:48 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:27:48 --> Session routines successfully run
DEBUG - 2016-01-05 10:27:48 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:27:48 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:27:48 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:27:48 --> Email Class Initialized
DEBUG - 2016-01-05 10:27:48 --> Controller Class Initialized
DEBUG - 2016-01-05 10:27:48 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:27:48 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:48 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:27:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:27:48 --> Final output sent to browser
DEBUG - 2016-01-05 10:27:48 --> Total execution time: 0.2484
DEBUG - 2016-01-05 10:27:51 --> Config Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:27:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:27:51 --> URI Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Router Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Output Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Security Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Input Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:27:51 --> Language Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Language Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Config Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Loader Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:27:51 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:27:51 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Session Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:27:51 --> Session routines successfully run
DEBUG - 2016-01-05 10:27:51 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Email Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Controller Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:27:51 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:51 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Config Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:27:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:27:54 --> URI Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Router Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Output Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Security Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Input Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:27:54 --> Language Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Language Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Config Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Loader Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:27:54 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:27:54 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Session Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:27:54 --> Session routines successfully run
DEBUG - 2016-01-05 10:27:54 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Email Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Controller Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:27:54 --> Model Class Initialized
DEBUG - 2016-01-05 10:27:54 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:27:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:27:54 --> Final output sent to browser
DEBUG - 2016-01-05 10:27:54 --> Total execution time: 0.2549
DEBUG - 2016-01-05 10:29:00 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:29:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:29:00 --> URI Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Router Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Output Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Security Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Input Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:29:00 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Loader Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:29:00 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:29:00 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Session Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:29:00 --> Session routines successfully run
DEBUG - 2016-01-05 10:29:00 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Email Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Controller Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:29:00 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:00 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:29:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:29:00 --> Final output sent to browser
DEBUG - 2016-01-05 10:29:00 --> Total execution time: 0.2820
DEBUG - 2016-01-05 10:29:02 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:29:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:29:02 --> URI Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Router Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Output Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Security Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Input Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:29:02 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Loader Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:29:02 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:29:02 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Session Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:29:02 --> Session routines successfully run
DEBUG - 2016-01-05 10:29:02 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Email Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Controller Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:29:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:02 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:29:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:29:02 --> Final output sent to browser
DEBUG - 2016-01-05 10:29:02 --> Total execution time: 0.2459
DEBUG - 2016-01-05 10:29:08 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:29:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:29:08 --> URI Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Router Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Output Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Security Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Input Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:29:08 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Loader Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:29:08 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:29:08 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Session Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:29:08 --> Session routines successfully run
DEBUG - 2016-01-05 10:29:08 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Email Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Controller Class Initialized
DEBUG - 2016-01-05 10:29:08 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:29:08 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:29:08 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 10:29:09 --> XSS Filtering completed
DEBUG - 2016-01-05 10:29:09 --> XSS Filtering completed
DEBUG - 2016-01-05 10:29:09 --> XSS Filtering completed
DEBUG - 2016-01-05 10:29:09 --> XSS Filtering completed
DEBUG - 2016-01-05 10:29:09 --> XSS Filtering completed
DEBUG - 2016-01-05 10:29:09 --> XSS Filtering completed
DEBUG - 2016-01-05 10:29:09 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:29:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:29:09 --> URI Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Router Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Output Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Security Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Input Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:29:09 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Loader Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:29:09 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:29:09 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Session Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:29:09 --> Session routines successfully run
DEBUG - 2016-01-05 10:29:09 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Email Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Controller Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:29:09 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:09 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:29:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:29:09 --> Final output sent to browser
DEBUG - 2016-01-05 10:29:09 --> Total execution time: 0.2673
DEBUG - 2016-01-05 10:29:10 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:10 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:29:10 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:29:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:29:10 --> URI Class Initialized
DEBUG - 2016-01-05 10:29:10 --> Router Class Initialized
DEBUG - 2016-01-05 10:29:10 --> Output Class Initialized
DEBUG - 2016-01-05 10:29:10 --> Security Class Initialized
DEBUG - 2016-01-05 10:29:10 --> Input Class Initialized
DEBUG - 2016-01-05 10:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:29:10 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:10 --> Language Class Initialized
DEBUG - 2016-01-05 10:29:10 --> Config Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Loader Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:29:11 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:29:11 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Session Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:29:11 --> Session routines successfully run
DEBUG - 2016-01-05 10:29:11 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Email Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Controller Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:29:11 --> Model Class Initialized
DEBUG - 2016-01-05 10:29:11 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:29:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:29:11 --> Final output sent to browser
DEBUG - 2016-01-05 10:29:11 --> Total execution time: 0.2774
DEBUG - 2016-01-05 10:33:16 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:33:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:33:16 --> URI Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Router Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Output Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Security Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Input Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:33:16 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Loader Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:33:16 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:33:16 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Session Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:33:16 --> Session routines successfully run
DEBUG - 2016-01-05 10:33:16 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Email Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Controller Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:33:16 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:16 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:33:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:33:16 --> Final output sent to browser
DEBUG - 2016-01-05 10:33:16 --> Total execution time: 0.6593
DEBUG - 2016-01-05 10:33:18 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:18 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:33:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:33:20 --> URI Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Router Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Output Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Security Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Input Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:33:20 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Loader Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:33:20 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:33:20 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Session Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:33:20 --> Session routines successfully run
DEBUG - 2016-01-05 10:33:20 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Email Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Controller Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:33:20 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:20 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:33:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:33:20 --> Final output sent to browser
DEBUG - 2016-01-05 10:33:20 --> Total execution time: 1.9666
DEBUG - 2016-01-05 10:33:27 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:33:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:33:27 --> URI Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Router Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Output Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Security Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Input Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:33:27 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Loader Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:33:27 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:33:27 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Session Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:33:27 --> Session routines successfully run
DEBUG - 2016-01-05 10:33:27 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Email Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Controller Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 10:33:27 --> XSS Filtering completed
DEBUG - 2016-01-05 10:33:27 --> XSS Filtering completed
DEBUG - 2016-01-05 10:33:27 --> XSS Filtering completed
DEBUG - 2016-01-05 10:33:27 --> XSS Filtering completed
DEBUG - 2016-01-05 10:33:27 --> XSS Filtering completed
DEBUG - 2016-01-05 10:33:27 --> XSS Filtering completed
DEBUG - 2016-01-05 10:33:27 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:33:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:33:27 --> URI Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Router Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Output Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Security Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Input Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:33:27 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Loader Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:33:27 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:33:27 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Session Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:33:27 --> Session routines successfully run
DEBUG - 2016-01-05 10:33:27 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Email Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Controller Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:33:27 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:27 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:33:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:33:27 --> Final output sent to browser
DEBUG - 2016-01-05 10:33:27 --> Total execution time: 0.2409
DEBUG - 2016-01-05 10:33:29 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:33:29 --> URI Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Router Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Output Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Security Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Input Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:33:29 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Language Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Config Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Loader Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:33:29 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:33:29 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Session Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:33:29 --> Session routines successfully run
DEBUG - 2016-01-05 10:33:29 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Email Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Controller Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:33:29 --> Model Class Initialized
DEBUG - 2016-01-05 10:33:29 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:33:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:33:29 --> Final output sent to browser
DEBUG - 2016-01-05 10:33:29 --> Total execution time: 0.2574
DEBUG - 2016-01-05 10:34:02 --> Config Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:34:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:34:02 --> URI Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Router Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Output Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Security Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Input Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:34:02 --> Language Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Language Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Config Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Loader Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:34:02 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:34:02 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Session Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:34:02 --> Session routines successfully run
DEBUG - 2016-01-05 10:34:02 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Email Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Controller Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:34:02 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:02 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:34:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:34:02 --> Final output sent to browser
DEBUG - 2016-01-05 10:34:02 --> Total execution time: 0.3210
DEBUG - 2016-01-05 10:34:37 --> Config Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:34:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:34:37 --> URI Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Router Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Output Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Security Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Input Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:34:37 --> Language Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Language Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Config Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Loader Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:34:37 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:34:37 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Session Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:34:37 --> Session routines successfully run
DEBUG - 2016-01-05 10:34:37 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Email Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Controller Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:34:37 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:37 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:34:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:34:37 --> Final output sent to browser
DEBUG - 2016-01-05 10:34:37 --> Total execution time: 0.2790
DEBUG - 2016-01-05 10:34:55 --> Config Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:34:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:34:55 --> URI Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Router Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Output Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Security Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Input Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:34:55 --> Language Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Language Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Config Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Loader Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:34:55 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:34:55 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Session Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:34:55 --> Session routines successfully run
DEBUG - 2016-01-05 10:34:55 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Email Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Controller Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:34:55 --> Model Class Initialized
DEBUG - 2016-01-05 10:34:55 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:34:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:34:55 --> Final output sent to browser
DEBUG - 2016-01-05 10:34:55 --> Total execution time: 0.2607
DEBUG - 2016-01-05 10:50:55 --> Config Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Hooks Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Utf8 Class Initialized
DEBUG - 2016-01-05 10:50:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 10:50:56 --> URI Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Router Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Output Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Security Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Input Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 10:50:56 --> Language Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Language Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Config Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Loader Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Helper loaded: url_helper
DEBUG - 2016-01-05 10:50:56 --> Helper loaded: form_helper
DEBUG - 2016-01-05 10:50:56 --> Database Driver Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Session Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Helper loaded: string_helper
DEBUG - 2016-01-05 10:50:56 --> Session routines successfully run
DEBUG - 2016-01-05 10:50:56 --> Form Validation Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Pagination Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Encrypt Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Email Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Controller Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 10:50:56 --> Model Class Initialized
DEBUG - 2016-01-05 10:50:56 --> Image Lib Class Initialized
DEBUG - 2016-01-05 10:50:57 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 10:50:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 10:50:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 10:50:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 10:50:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 10:50:57 --> Final output sent to browser
DEBUG - 2016-01-05 10:50:57 --> Total execution time: 1.3857
DEBUG - 2016-01-05 11:20:59 --> Config Class Initialized
DEBUG - 2016-01-05 11:20:59 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:20:59 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:20:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:20:59 --> URI Class Initialized
DEBUG - 2016-01-05 11:20:59 --> Router Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Output Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Security Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Input Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:21:00 --> Language Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Language Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Config Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Loader Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:21:00 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:21:00 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Session Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:21:00 --> Session routines successfully run
DEBUG - 2016-01-05 11:21:00 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Email Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Controller Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 11:21:00 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:00 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:21:01 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 11:21:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 11:21:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 11:21:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 11:21:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 11:21:01 --> Final output sent to browser
DEBUG - 2016-01-05 11:21:01 --> Total execution time: 1.9584
DEBUG - 2016-01-05 11:21:03 --> Config Class Initialized
DEBUG - 2016-01-05 11:21:03 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:21:03 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:21:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:21:03 --> URI Class Initialized
DEBUG - 2016-01-05 11:21:03 --> Router Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Output Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Security Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Input Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:21:04 --> Language Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Language Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Config Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Loader Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:21:04 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:21:04 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Session Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:21:04 --> Session routines successfully run
DEBUG - 2016-01-05 11:21:04 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Email Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Controller Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:21:04 --> Model Class Initialized
DEBUG - 2016-01-05 11:21:04 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Config Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:22:02 --> URI Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Router Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Output Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Security Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Input Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:22:02 --> Language Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Language Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Config Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Loader Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:22:02 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:22:02 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Session Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:22:02 --> Session routines successfully run
DEBUG - 2016-01-05 11:22:02 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Email Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Controller Class Initialized
DEBUG - 2016-01-05 11:22:02 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:22:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:22:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:22:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:22:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:22:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:22:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:22:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:22:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:22:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:22:03 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:03 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Config Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:22:31 --> URI Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Router Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Output Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Security Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Input Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:22:31 --> Language Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Language Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Config Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Loader Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:22:31 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:22:31 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Session Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:22:31 --> Session routines successfully run
DEBUG - 2016-01-05 11:22:31 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Email Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Controller Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:22:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:22:31 --> Model Class Initialized
DEBUG - 2016-01-05 11:22:31 --> DB Transaction Failure
ERROR - 2016-01-05 11:22:31 --> Query error: Unknown column '1' in 'order clause'
DEBUG - 2016-01-05 11:22:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-05 11:23:11 --> Config Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:23:11 --> URI Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Router Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Output Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Security Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Input Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:23:11 --> Language Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Language Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Config Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Loader Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:23:11 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:23:11 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Session Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:23:11 --> Session routines successfully run
DEBUG - 2016-01-05 11:23:11 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Email Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Controller Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:23:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:23:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:11 --> DB Transaction Failure
ERROR - 2016-01-05 11:23:11 --> Query error: Unknown column '1' in 'order clause'
DEBUG - 2016-01-05 11:23:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-05 11:23:41 --> Config Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:23:41 --> URI Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Router Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Output Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Security Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Input Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:23:41 --> Language Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Language Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Config Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Loader Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:23:41 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:23:41 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Session Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:23:41 --> Session routines successfully run
DEBUG - 2016-01-05 11:23:41 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Email Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Controller Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:23:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:23:41 --> Model Class Initialized
DEBUG - 2016-01-05 11:23:41 --> DB Transaction Failure
ERROR - 2016-01-05 11:23:41 --> Query error: Unknown column '1' in 'order clause'
DEBUG - 2016-01-05 11:23:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-05 11:24:05 --> Config Class Initialized
DEBUG - 2016-01-05 11:24:05 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:24:05 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:24:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:24:05 --> URI Class Initialized
DEBUG - 2016-01-05 11:24:05 --> Router Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Output Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Security Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Input Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:24:06 --> Language Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Language Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Config Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Loader Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:24:06 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:24:06 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Session Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:24:06 --> Session routines successfully run
DEBUG - 2016-01-05 11:24:06 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Email Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Controller Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:24:06 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:24:06 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:06 --> DB Transaction Failure
ERROR - 2016-01-05 11:24:06 --> Query error: Unknown column '1' in 'order clause'
DEBUG - 2016-01-05 11:24:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-05 11:24:43 --> Config Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:24:43 --> URI Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Router Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Output Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Security Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Input Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:24:43 --> Language Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Language Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Config Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Loader Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:24:43 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:24:43 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Session Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:24:43 --> Session routines successfully run
DEBUG - 2016-01-05 11:24:43 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Email Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Controller Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:24:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:24:43 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:43 --> DB Transaction Failure
ERROR - 2016-01-05 11:24:43 --> Query error: Unknown column '1' in 'order clause'
DEBUG - 2016-01-05 11:24:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-05 11:24:45 --> Config Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:24:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:24:45 --> URI Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Router Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Output Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Security Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Input Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:24:45 --> Language Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Language Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Config Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Loader Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:24:45 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:24:45 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Session Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:24:45 --> Session routines successfully run
DEBUG - 2016-01-05 11:24:45 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Email Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Controller Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:24:45 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:24:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:24:45 --> DB Transaction Failure
ERROR - 2016-01-05 11:24:45 --> Query error: Unknown column '1' in 'order clause'
DEBUG - 2016-01-05 11:24:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-05 11:25:02 --> Config Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:25:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:25:02 --> URI Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Router Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Output Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Security Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Input Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:25:02 --> Language Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Language Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Config Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Loader Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:25:02 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:25:02 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Session Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:25:02 --> Session routines successfully run
DEBUG - 2016-01-05 11:25:02 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Email Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Controller Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:25:02 --> Model Class Initialized
DEBUG - 2016-01-05 11:25:02 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 11:26:05 --> Config Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:26:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:26:05 --> URI Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Router Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Output Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Security Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Input Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:26:05 --> Language Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Language Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Config Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Loader Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:26:05 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:26:05 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Session Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:26:05 --> Session routines successfully run
DEBUG - 2016-01-05 11:26:05 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Email Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Controller Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:26:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 11:26:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 11:26:05 --> Final output sent to browser
DEBUG - 2016-01-05 11:26:05 --> Total execution time: 0.3616
DEBUG - 2016-01-05 11:40:28 --> Config Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:40:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:40:29 --> URI Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Router Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Output Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Security Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Input Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:40:29 --> Language Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Language Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Config Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Loader Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:40:29 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:40:29 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Session Class Initialized
DEBUG - 2016-01-05 11:40:29 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:40:29 --> Session routines successfully run
DEBUG - 2016-01-05 11:40:29 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:40:30 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:40:30 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:40:30 --> Email Class Initialized
DEBUG - 2016-01-05 11:40:30 --> Controller Class Initialized
DEBUG - 2016-01-05 11:40:30 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 11:40:30 --> Model Class Initialized
ERROR - 2016-01-05 11:40:30 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 67
ERROR - 2016-01-05 11:40:30 --> Severity: Notice  --> Undefined variable: order_method C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 67
ERROR - 2016-01-05 11:40:30 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 82
ERROR - 2016-01-05 11:40:30 --> Severity: Notice  --> Undefined variable: order_method C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 83
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 11:40:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 11:40:30 --> Final output sent to browser
DEBUG - 2016-01-05 11:40:30 --> Total execution time: 2.3859
DEBUG - 2016-01-05 11:40:49 --> Config Class Initialized
DEBUG - 2016-01-05 11:40:49 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:40:49 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:40:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:40:50 --> URI Class Initialized
DEBUG - 2016-01-05 11:40:50 --> Router Class Initialized
DEBUG - 2016-01-05 11:40:59 --> Output Class Initialized
DEBUG - 2016-01-05 11:40:59 --> Security Class Initialized
DEBUG - 2016-01-05 11:40:59 --> Input Class Initialized
DEBUG - 2016-01-05 11:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:40:59 --> Language Class Initialized
DEBUG - 2016-01-05 11:40:59 --> Language Class Initialized
DEBUG - 2016-01-05 11:40:59 --> Config Class Initialized
DEBUG - 2016-01-05 11:40:59 --> Loader Class Initialized
DEBUG - 2016-01-05 11:40:59 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:40:59 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:40:59 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:41:04 --> Session Class Initialized
DEBUG - 2016-01-05 11:41:04 --> Config Class Initialized
DEBUG - 2016-01-05 11:41:04 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:41:04 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:41:04 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:41:04 --> Session routines successfully run
DEBUG - 2016-01-05 11:41:04 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:41:04 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:41:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:41:05 --> URI Class Initialized
DEBUG - 2016-01-05 11:41:05 --> Router Class Initialized
DEBUG - 2016-01-05 11:41:05 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:41:05 --> Email Class Initialized
DEBUG - 2016-01-05 11:41:05 --> Controller Class Initialized
DEBUG - 2016-01-05 11:41:05 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 11:41:05 --> Model Class Initialized
ERROR - 2016-01-05 11:41:05 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 67
ERROR - 2016-01-05 11:41:05 --> Severity: Notice  --> Undefined variable: order_method C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 67
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 11:41:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 11:41:05 --> Final output sent to browser
DEBUG - 2016-01-05 11:41:05 --> Total execution time: 18.2322
DEBUG - 2016-01-05 11:41:09 --> Output Class Initialized
DEBUG - 2016-01-05 11:41:09 --> Security Class Initialized
DEBUG - 2016-01-05 11:41:09 --> Input Class Initialized
DEBUG - 2016-01-05 11:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:41:09 --> Language Class Initialized
DEBUG - 2016-01-05 11:41:09 --> Language Class Initialized
DEBUG - 2016-01-05 11:41:09 --> Config Class Initialized
DEBUG - 2016-01-05 11:41:09 --> Loader Class Initialized
DEBUG - 2016-01-05 11:41:09 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:41:09 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:41:09 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:41:10 --> Session Class Initialized
DEBUG - 2016-01-05 11:41:10 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:41:10 --> Session routines successfully run
DEBUG - 2016-01-05 11:41:10 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:41:10 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:41:11 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:41:11 --> Email Class Initialized
DEBUG - 2016-01-05 11:41:11 --> Controller Class Initialized
DEBUG - 2016-01-05 11:41:11 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 11:41:11 --> Model Class Initialized
ERROR - 2016-01-05 11:41:11 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 67
ERROR - 2016-01-05 11:41:11 --> Severity: Notice  --> Undefined variable: order_method C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 67
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 11:41:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 11:41:11 --> Final output sent to browser
DEBUG - 2016-01-05 11:41:11 --> Total execution time: 9.4263
DEBUG - 2016-01-05 11:41:45 --> Config Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Hooks Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Utf8 Class Initialized
DEBUG - 2016-01-05 11:41:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 11:41:45 --> URI Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Router Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Output Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Security Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Input Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 11:41:45 --> Language Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Language Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Config Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Loader Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Helper loaded: url_helper
DEBUG - 2016-01-05 11:41:45 --> Helper loaded: form_helper
DEBUG - 2016-01-05 11:41:45 --> Database Driver Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Session Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Helper loaded: string_helper
DEBUG - 2016-01-05 11:41:45 --> Session routines successfully run
DEBUG - 2016-01-05 11:41:45 --> Form Validation Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Pagination Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Encrypt Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Email Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Controller Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> Image Lib Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 11:41:45 --> Model Class Initialized
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 11:41:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 11:41:45 --> Final output sent to browser
DEBUG - 2016-01-05 11:41:45 --> Total execution time: 0.3549
DEBUG - 2016-01-05 14:56:01 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:02 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:02 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:02 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:02 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:02 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:02 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:02 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:02 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:02 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:02 --> No URI present. Default controller set.
DEBUG - 2016-01-05 14:56:02 --> No URI present. Default controller set.
DEBUG - 2016-01-05 14:56:02 --> Output Class Initialized
DEBUG - 2016-01-05 14:56:02 --> Output Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Security Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Security Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Input Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Input Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 14:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 14:56:03 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Loader Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Loader Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Helper loaded: url_helper
DEBUG - 2016-01-05 14:56:03 --> Helper loaded: url_helper
DEBUG - 2016-01-05 14:56:03 --> Helper loaded: form_helper
DEBUG - 2016-01-05 14:56:03 --> Helper loaded: form_helper
DEBUG - 2016-01-05 14:56:03 --> Database Driver Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Database Driver Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Session Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Session Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Helper loaded: string_helper
DEBUG - 2016-01-05 14:56:03 --> Helper loaded: string_helper
ERROR - 2016-01-05 14:56:03 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2016-01-05 14:56:03 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-01-05 14:56:03 --> Session routines successfully run
DEBUG - 2016-01-05 14:56:03 --> Session routines successfully run
DEBUG - 2016-01-05 14:56:03 --> Form Validation Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Form Validation Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Pagination Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Pagination Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Encrypt Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Encrypt Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Email Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Email Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Controller Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Controller Class Initialized
DEBUG - 2016-01-05 14:56:03 --> Auth MX_Controller Initialized
DEBUG - 2016-01-05 14:56:03 --> Auth MX_Controller Initialized
DEBUG - 2016-01-05 14:56:04 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 14:56:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 14:56:04 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 14:56:04 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 14:56:04 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:04 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Output Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Security Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Input Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 14:56:04 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Loader Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Helper loaded: url_helper
DEBUG - 2016-01-05 14:56:04 --> Helper loaded: form_helper
DEBUG - 2016-01-05 14:56:04 --> Database Driver Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Session Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Helper loaded: string_helper
DEBUG - 2016-01-05 14:56:04 --> Session routines successfully run
DEBUG - 2016-01-05 14:56:04 --> Form Validation Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Pagination Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Encrypt Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Email Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Controller Class Initialized
DEBUG - 2016-01-05 14:56:04 --> Auth MX_Controller Initialized
DEBUG - 2016-01-05 14:56:04 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 14:56:04 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 14:56:04 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 14:56:04 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-05 14:56:04 --> Final output sent to browser
DEBUG - 2016-01-05 14:56:04 --> Total execution time: 0.5217
DEBUG - 2016-01-05 14:56:06 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:06 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:06 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:06 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:06 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:06 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:06 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:06 --> Router Class Initialized
ERROR - 2016-01-05 14:56:06 --> 404 Page Not Found --> 
ERROR - 2016-01-05 14:56:06 --> 404 Page Not Found --> 
ERROR - 2016-01-05 14:56:06 --> 404 Page Not Found --> 
ERROR - 2016-01-05 14:56:06 --> 404 Page Not Found --> 
DEBUG - 2016-01-05 14:56:08 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:08 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:08 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:08 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:08 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:08 --> Output Class Initialized
DEBUG - 2016-01-05 14:56:08 --> Security Class Initialized
DEBUG - 2016-01-05 14:56:08 --> Input Class Initialized
DEBUG - 2016-01-05 14:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 14:56:09 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Loader Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Helper loaded: url_helper
DEBUG - 2016-01-05 14:56:09 --> Helper loaded: form_helper
DEBUG - 2016-01-05 14:56:09 --> Database Driver Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Session Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Helper loaded: string_helper
DEBUG - 2016-01-05 14:56:09 --> Session routines successfully run
DEBUG - 2016-01-05 14:56:09 --> Form Validation Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Pagination Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Encrypt Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Email Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Controller Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Auth MX_Controller Initialized
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 14:56:09 --> XSS Filtering completed
DEBUG - 2016-01-05 14:56:09 --> Unable to find validation rule: exists
DEBUG - 2016-01-05 14:56:09 --> XSS Filtering completed
DEBUG - 2016-01-05 14:56:09 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:09 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Output Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Security Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Input Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 14:56:09 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Loader Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Helper loaded: url_helper
DEBUG - 2016-01-05 14:56:09 --> Helper loaded: form_helper
DEBUG - 2016-01-05 14:56:09 --> Database Driver Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Session Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Helper loaded: string_helper
DEBUG - 2016-01-05 14:56:09 --> Session routines successfully run
DEBUG - 2016-01-05 14:56:09 --> Form Validation Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Pagination Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Encrypt Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Email Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Controller Class Initialized
DEBUG - 2016-01-05 14:56:09 --> Admin MX_Controller Initialized
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 14:56:09 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 14:56:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 14:56:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 14:56:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 14:56:10 --> Final output sent to browser
DEBUG - 2016-01-05 14:56:10 --> Total execution time: 0.7487
DEBUG - 2016-01-05 14:56:26 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:26 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Output Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Security Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Input Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 14:56:26 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Loader Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Helper loaded: url_helper
DEBUG - 2016-01-05 14:56:26 --> Helper loaded: form_helper
DEBUG - 2016-01-05 14:56:26 --> Database Driver Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Session Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Helper loaded: string_helper
DEBUG - 2016-01-05 14:56:26 --> Session routines successfully run
DEBUG - 2016-01-05 14:56:26 --> Form Validation Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Pagination Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Encrypt Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Email Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Controller Class Initialized
DEBUG - 2016-01-05 14:56:26 --> Property MX_Controller Initialized
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 14:56:27 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:27 --> Image Lib Class Initialized
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 14:56:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 14:56:27 --> Final output sent to browser
DEBUG - 2016-01-05 14:56:27 --> Total execution time: 0.9912
DEBUG - 2016-01-05 14:56:37 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:37 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Output Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Security Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Input Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 14:56:37 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Loader Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Helper loaded: url_helper
DEBUG - 2016-01-05 14:56:37 --> Helper loaded: form_helper
DEBUG - 2016-01-05 14:56:37 --> Database Driver Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Session Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Helper loaded: string_helper
DEBUG - 2016-01-05 14:56:37 --> Session routines successfully run
DEBUG - 2016-01-05 14:56:37 --> Form Validation Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Pagination Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Encrypt Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Email Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Controller Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 14:56:37 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:37 --> Image Lib Class Initialized
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 14:56:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 14:56:37 --> Final output sent to browser
DEBUG - 2016-01-05 14:56:37 --> Total execution time: 0.5009
DEBUG - 2016-01-05 14:56:41 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Hooks Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Utf8 Class Initialized
DEBUG - 2016-01-05 14:56:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 14:56:41 --> URI Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Router Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Output Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Security Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Input Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 14:56:41 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Language Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Config Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Loader Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Helper loaded: url_helper
DEBUG - 2016-01-05 14:56:41 --> Helper loaded: form_helper
DEBUG - 2016-01-05 14:56:41 --> Database Driver Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Session Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Helper loaded: string_helper
DEBUG - 2016-01-05 14:56:41 --> Session routines successfully run
DEBUG - 2016-01-05 14:56:41 --> Form Validation Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Pagination Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Encrypt Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Email Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Controller Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> Image Lib Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 14:56:41 --> Model Class Initialized
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 14:56:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 14:56:41 --> Final output sent to browser
DEBUG - 2016-01-05 14:56:41 --> Total execution time: 0.4947
DEBUG - 2016-01-05 15:17:12 --> Config Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:17:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:17:13 --> URI Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Router Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Output Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Security Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Input Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:17:13 --> Language Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Language Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Config Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Loader Class Initialized
DEBUG - 2016-01-05 15:17:13 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:17:13 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:17:13 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:17:14 --> Session Class Initialized
DEBUG - 2016-01-05 15:17:14 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:17:14 --> Session routines successfully run
DEBUG - 2016-01-05 15:17:14 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:17:14 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:17:14 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:17:14 --> Email Class Initialized
DEBUG - 2016-01-05 15:17:14 --> Controller Class Initialized
DEBUG - 2016-01-05 15:17:14 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-05 15:17:14 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:17:14 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:17:14 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:17:14 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:17:14 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:17:14 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:17:14 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:17:14 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:17:14 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:17:15 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:15 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:17:15 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-05 15:17:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:17:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:17:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:17:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:17:15 --> Final output sent to browser
DEBUG - 2016-01-05 15:17:15 --> Total execution time: 2.9507
DEBUG - 2016-01-05 15:17:18 --> Config Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:17:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:17:18 --> URI Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Router Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Output Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Security Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Input Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:17:18 --> Language Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Language Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Config Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Loader Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:17:18 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:17:18 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Session Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:17:18 --> Session routines successfully run
DEBUG - 2016-01-05 15:17:18 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Email Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Controller Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:17:18 --> Model Class Initialized
DEBUG - 2016-01-05 15:17:19 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:17:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:17:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:17:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:17:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:17:19 --> Final output sent to browser
DEBUG - 2016-01-05 15:17:19 --> Total execution time: 0.7533
DEBUG - 2016-01-05 15:24:58 --> Config Class Initialized
DEBUG - 2016-01-05 15:24:58 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:24:58 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:24:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:24:58 --> URI Class Initialized
DEBUG - 2016-01-05 15:24:58 --> Router Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Output Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Security Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Input Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:24:59 --> Language Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Language Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Config Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Loader Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:24:59 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:24:59 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Session Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:24:59 --> Session routines successfully run
DEBUG - 2016-01-05 15:24:59 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Email Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Controller Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
DEBUG - 2016-01-05 15:24:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:24:59 --> Model Class Initialized
ERROR - 2016-01-05 15:25:00 --> Severity: Notice  --> Undefined property: stdClass::$activated C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\all_tenants.php 29
DEBUG - 2016-01-05 15:25:00 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:25:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:25:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:25:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:25:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:25:00 --> Final output sent to browser
DEBUG - 2016-01-05 15:25:00 --> Total execution time: 2.0109
DEBUG - 2016-01-05 15:26:57 --> Config Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:26:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:26:57 --> URI Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Router Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Output Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Security Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Input Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:26:57 --> Language Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Language Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Config Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Loader Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:26:57 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:26:57 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Session Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:26:57 --> Session routines successfully run
DEBUG - 2016-01-05 15:26:57 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Email Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Controller Class Initialized
DEBUG - 2016-01-05 15:26:57 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:26:57 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:58 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:26:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:26:58 --> Model Class Initialized
DEBUG - 2016-01-05 15:26:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:26:58 --> Model Class Initialized
ERROR - 2016-01-05 15:26:58 --> Severity: Notice  --> Undefined property: stdClass::$activated C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\all_tenants.php 31
ERROR - 2016-01-05 15:26:58 --> Severity: Notice  --> Undefined property: stdClass::$tenant_email_address C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\all_tenants.php 50
DEBUG - 2016-01-05 15:26:58 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:26:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:26:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:26:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:26:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:26:58 --> Final output sent to browser
DEBUG - 2016-01-05 15:26:58 --> Total execution time: 0.4672
DEBUG - 2016-01-05 15:27:38 --> Config Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:27:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:27:38 --> URI Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Router Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Output Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Security Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Input Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:27:38 --> Language Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Language Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Config Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Loader Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:27:38 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:27:38 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Session Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:27:38 --> Session routines successfully run
DEBUG - 2016-01-05 15:27:38 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Email Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Controller Class Initialized
DEBUG - 2016-01-05 15:27:38 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:27:38 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:27:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:27:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:27:39 --> Final output sent to browser
DEBUG - 2016-01-05 15:27:39 --> Total execution time: 0.3681
DEBUG - 2016-01-05 15:28:21 --> Config Class Initialized
DEBUG - 2016-01-05 15:28:21 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:28:21 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:28:21 --> URI Class Initialized
DEBUG - 2016-01-05 15:28:21 --> Router Class Initialized
DEBUG - 2016-01-05 15:28:21 --> Output Class Initialized
DEBUG - 2016-01-05 15:28:21 --> Security Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Input Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:28:22 --> Language Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Language Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Config Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Loader Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:28:22 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:28:22 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Session Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:28:22 --> Session routines successfully run
DEBUG - 2016-01-05 15:28:22 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Email Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Controller Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:28:22 --> Model Class Initialized
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:28:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:28:22 --> Final output sent to browser
DEBUG - 2016-01-05 15:28:22 --> Total execution time: 0.3723
DEBUG - 2016-01-05 15:29:39 --> Config Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:29:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:29:39 --> URI Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Router Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Output Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Security Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Input Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:29:39 --> Language Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Language Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Config Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Loader Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:29:39 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:29:39 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Session Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:29:39 --> Session routines successfully run
DEBUG - 2016-01-05 15:29:39 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Email Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Controller Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:29:39 --> Model Class Initialized
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:29:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:29:39 --> Final output sent to browser
DEBUG - 2016-01-05 15:29:39 --> Total execution time: 0.4851
DEBUG - 2016-01-05 15:43:35 --> Config Class Initialized
DEBUG - 2016-01-05 15:43:35 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:43:35 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:43:35 --> URI Class Initialized
DEBUG - 2016-01-05 15:43:35 --> Router Class Initialized
DEBUG - 2016-01-05 15:43:35 --> Output Class Initialized
DEBUG - 2016-01-05 15:43:35 --> Security Class Initialized
DEBUG - 2016-01-05 15:43:35 --> Input Class Initialized
DEBUG - 2016-01-05 15:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:43:35 --> Language Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Language Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Config Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Loader Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:43:36 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:43:36 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Session Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:43:36 --> Session routines successfully run
DEBUG - 2016-01-05 15:43:36 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Email Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Controller Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:43:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:43:36 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Config Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:51:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:51:10 --> URI Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Router Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Output Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Security Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Input Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:51:10 --> Language Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Language Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Config Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Loader Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:51:10 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:51:10 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Session Class Initialized
DEBUG - 2016-01-05 15:51:10 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:51:10 --> Session routines successfully run
DEBUG - 2016-01-05 15:51:11 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:51:11 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:51:11 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:51:11 --> Email Class Initialized
DEBUG - 2016-01-05 15:51:11 --> Controller Class Initialized
DEBUG - 2016-01-05 15:51:11 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:51:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:51:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Config Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:52:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:52:19 --> URI Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Router Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Output Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Security Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Input Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:52:19 --> Language Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Language Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Config Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Loader Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:52:19 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:52:19 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Session Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:52:19 --> Session routines successfully run
DEBUG - 2016-01-05 15:52:19 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Email Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Controller Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:52:19 --> Model Class Initialized
ERROR - 2016-01-05 15:52:19 --> Severity: Notice  --> Undefined variable: items C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\all_tenants.php 30
DEBUG - 2016-01-05 15:52:19 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:52:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:52:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:52:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:52:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:52:20 --> Final output sent to browser
DEBUG - 2016-01-05 15:52:20 --> Total execution time: 0.8265
DEBUG - 2016-01-05 15:52:40 --> Config Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:52:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:52:40 --> URI Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Router Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Output Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Security Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Input Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:52:40 --> Language Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Language Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Config Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Loader Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:52:40 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:52:40 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Session Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:52:40 --> Session routines successfully run
DEBUG - 2016-01-05 15:52:40 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Email Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Controller Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:52:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:52:40 --> Final output sent to browser
DEBUG - 2016-01-05 15:52:40 --> Total execution time: 0.2899
DEBUG - 2016-01-05 15:53:17 --> Config Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:53:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:53:17 --> URI Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Router Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Output Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Security Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Input Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:53:17 --> Language Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Language Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Config Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Loader Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:53:17 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:53:17 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Session Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:53:17 --> Session routines successfully run
DEBUG - 2016-01-05 15:53:17 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Email Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Controller Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:53:17 --> Model Class Initialized
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:53:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:53:17 --> Final output sent to browser
DEBUG - 2016-01-05 15:53:17 --> Total execution time: 0.3061
DEBUG - 2016-01-05 15:54:11 --> Config Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:54:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:54:11 --> URI Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Router Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Output Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Security Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Input Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:54:11 --> Language Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Language Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Config Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Loader Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:54:11 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:54:11 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Session Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:54:11 --> Session routines successfully run
DEBUG - 2016-01-05 15:54:11 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Email Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Controller Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:54:11 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:54:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:54:11 --> Final output sent to browser
DEBUG - 2016-01-05 15:54:11 --> Total execution time: 0.3422
DEBUG - 2016-01-05 15:54:36 --> Config Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:54:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:54:36 --> URI Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Router Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Output Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Security Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Input Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:54:36 --> Language Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Language Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Config Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Loader Class Initialized
DEBUG - 2016-01-05 15:54:36 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:54:36 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:54:36 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:54:37 --> Session Class Initialized
DEBUG - 2016-01-05 15:54:37 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:54:37 --> Session routines successfully run
DEBUG - 2016-01-05 15:54:37 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:54:37 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:54:37 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:54:37 --> Email Class Initialized
DEBUG - 2016-01-05 15:54:37 --> Controller Class Initialized
DEBUG - 2016-01-05 15:54:37 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:54:37 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:54:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:54:37 --> Final output sent to browser
DEBUG - 2016-01-05 15:54:37 --> Total execution time: 0.3623
DEBUG - 2016-01-05 15:54:49 --> Config Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:54:49 --> URI Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Router Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Output Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Security Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Input Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:54:49 --> Language Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Language Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Config Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Loader Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:54:49 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:54:49 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Session Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:54:49 --> Session routines successfully run
DEBUG - 2016-01-05 15:54:49 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Email Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Controller Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:54:49 --> Model Class Initialized
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:54:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:54:49 --> Final output sent to browser
DEBUG - 2016-01-05 15:54:49 --> Total execution time: 0.2747
DEBUG - 2016-01-05 15:55:47 --> Config Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Hooks Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Utf8 Class Initialized
DEBUG - 2016-01-05 15:55:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 15:55:47 --> URI Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Router Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Output Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Security Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Input Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 15:55:47 --> Language Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Language Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Config Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Loader Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Helper loaded: url_helper
DEBUG - 2016-01-05 15:55:47 --> Helper loaded: form_helper
DEBUG - 2016-01-05 15:55:47 --> Database Driver Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Session Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Helper loaded: string_helper
DEBUG - 2016-01-05 15:55:47 --> Session routines successfully run
DEBUG - 2016-01-05 15:55:47 --> Form Validation Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Pagination Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Encrypt Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Email Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Controller Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> Image Lib Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 15:55:47 --> Model Class Initialized
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 15:55:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 15:55:47 --> Final output sent to browser
DEBUG - 2016-01-05 15:55:47 --> Total execution time: 0.3030
DEBUG - 2016-01-05 17:15:39 --> Config Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:15:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:15:39 --> URI Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Router Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Output Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Security Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Input Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:15:39 --> Language Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Language Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Config Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Loader Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:15:39 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:15:39 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:15:39 --> Session Class Initialized
DEBUG - 2016-01-05 17:15:40 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:15:40 --> Session routines successfully run
DEBUG - 2016-01-05 17:15:40 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:15:40 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:15:40 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:15:40 --> Email Class Initialized
DEBUG - 2016-01-05 17:15:40 --> Controller Class Initialized
DEBUG - 2016-01-05 17:15:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:15:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:15:41 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:15:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:15:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:15:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:15:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:15:41 --> Final output sent to browser
DEBUG - 2016-01-05 17:15:41 --> Total execution time: 2.2594
DEBUG - 2016-01-05 17:16:23 --> Config Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:16:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:16:23 --> URI Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Router Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Output Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Security Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Input Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:16:23 --> Language Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Language Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Config Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Loader Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:16:23 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:16:23 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Session Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:16:23 --> Session routines successfully run
DEBUG - 2016-01-05 17:16:23 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Email Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Controller Class Initialized
DEBUG - 2016-01-05 17:16:23 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:16:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:16:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:16:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:16:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:16:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:16:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:16:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:16:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:16:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:16:24 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:24 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:16:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:16:24 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:16:24 --> Model Class Initialized
DEBUG - 2016-01-05 17:16:24 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:16:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:16:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:16:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:16:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:16:24 --> Final output sent to browser
DEBUG - 2016-01-05 17:16:24 --> Total execution time: 0.2973
DEBUG - 2016-01-05 17:17:03 --> Config Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:17:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:17:03 --> URI Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Router Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Output Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Security Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Input Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:17:03 --> Language Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Language Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Config Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Loader Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:17:03 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:17:03 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Session Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:17:03 --> Session routines successfully run
DEBUG - 2016-01-05 17:17:03 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Email Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Controller Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:17:03 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:17:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:17:03 --> Final output sent to browser
DEBUG - 2016-01-05 17:17:03 --> Total execution time: 0.5819
DEBUG - 2016-01-05 17:17:19 --> Config Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:17:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:17:19 --> URI Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Router Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Output Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Security Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Input Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:17:19 --> Language Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Language Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Config Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Loader Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:17:19 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:17:19 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Session Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:17:19 --> Session routines successfully run
DEBUG - 2016-01-05 17:17:19 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Email Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Controller Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:17:19 --> Model Class Initialized
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:17:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:17:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:17:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:17:20 --> Final output sent to browser
DEBUG - 2016-01-05 17:17:20 --> Total execution time: 0.3363
DEBUG - 2016-01-05 17:18:14 --> Config Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:18:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:18:14 --> URI Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Router Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Output Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Security Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Input Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:18:14 --> Language Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Language Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Config Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Loader Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:18:14 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:18:14 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Session Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:18:14 --> Session routines successfully run
DEBUG - 2016-01-05 17:18:14 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Email Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Controller Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:18:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:18:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:18:14 --> Final output sent to browser
DEBUG - 2016-01-05 17:18:14 --> Total execution time: 0.3061
DEBUG - 2016-01-05 17:18:29 --> Config Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:18:29 --> URI Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Router Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Output Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Security Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Input Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:18:29 --> Language Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Language Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Config Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Loader Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:18:29 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:18:29 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Session Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:18:29 --> Session routines successfully run
DEBUG - 2016-01-05 17:18:29 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Email Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Controller Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:18:29 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:18:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:18:29 --> Final output sent to browser
DEBUG - 2016-01-05 17:18:29 --> Total execution time: 0.4789
DEBUG - 2016-01-05 17:18:40 --> Config Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:18:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:18:40 --> URI Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Router Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Output Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Security Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Input Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:18:40 --> Language Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Language Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Config Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Loader Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:18:40 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:18:40 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Session Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:18:40 --> Session routines successfully run
DEBUG - 2016-01-05 17:18:40 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Email Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Controller Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:18:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:18:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:18:40 --> Final output sent to browser
DEBUG - 2016-01-05 17:18:40 --> Total execution time: 0.3279
DEBUG - 2016-01-05 17:20:09 --> Config Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:20:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:20:09 --> URI Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Router Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Output Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Security Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Input Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:20:09 --> Language Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Language Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Config Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Loader Class Initialized
DEBUG - 2016-01-05 17:20:09 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:20:09 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:20:09 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:20:10 --> Session Class Initialized
DEBUG - 2016-01-05 17:20:10 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:20:10 --> Session routines successfully run
DEBUG - 2016-01-05 17:20:10 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:20:10 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:20:10 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:20:10 --> Email Class Initialized
DEBUG - 2016-01-05 17:20:10 --> Controller Class Initialized
DEBUG - 2016-01-05 17:20:10 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:20:10 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:20:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:20:10 --> Final output sent to browser
DEBUG - 2016-01-05 17:20:10 --> Total execution time: 0.4045
DEBUG - 2016-01-05 17:20:22 --> Config Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:20:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:20:22 --> URI Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Router Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Output Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Security Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Input Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:20:22 --> Language Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Language Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Config Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Loader Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:20:22 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:20:22 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Session Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:20:22 --> Session routines successfully run
DEBUG - 2016-01-05 17:20:22 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Email Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Controller Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:20:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:20:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:20:23 --> Final output sent to browser
DEBUG - 2016-01-05 17:20:23 --> Total execution time: 0.3817
DEBUG - 2016-01-05 17:21:50 --> Config Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:21:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:21:50 --> URI Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Router Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Output Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Security Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Input Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:21:50 --> Language Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Language Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Config Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Loader Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:21:50 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:21:50 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Session Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:21:50 --> Session routines successfully run
DEBUG - 2016-01-05 17:21:50 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Email Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Controller Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:21:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:21:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:21:50 --> Final output sent to browser
DEBUG - 2016-01-05 17:21:50 --> Total execution time: 0.3481
DEBUG - 2016-01-05 17:22:14 --> Config Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:22:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:22:14 --> URI Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Router Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Output Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Security Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Input Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:22:14 --> Language Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Language Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Config Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Loader Class Initialized
DEBUG - 2016-01-05 17:22:14 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:22:14 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:22:15 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:22:15 --> Session Class Initialized
DEBUG - 2016-01-05 17:22:15 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:22:15 --> Session routines successfully run
DEBUG - 2016-01-05 17:22:15 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:22:15 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:22:15 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:22:15 --> Email Class Initialized
DEBUG - 2016-01-05 17:22:15 --> Controller Class Initialized
DEBUG - 2016-01-05 17:22:15 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:22:15 --> Model Class Initialized
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:22:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:22:15 --> Final output sent to browser
DEBUG - 2016-01-05 17:22:15 --> Total execution time: 0.4052
DEBUG - 2016-01-05 17:24:55 --> Config Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:24:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:24:55 --> URI Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Router Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Output Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Security Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Input Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:24:55 --> Language Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Language Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Config Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Loader Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:24:55 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:24:55 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Session Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:24:55 --> Session routines successfully run
DEBUG - 2016-01-05 17:24:55 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Email Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Controller Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:24:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:24:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:24:55 --> Final output sent to browser
DEBUG - 2016-01-05 17:24:55 --> Total execution time: 0.3654
DEBUG - 2016-01-05 17:27:27 --> Config Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:27:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:27:27 --> URI Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Router Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Output Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Security Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Input Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:27:27 --> Language Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Language Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Config Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Loader Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:27:27 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:27:27 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Session Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:27:27 --> Session routines successfully run
DEBUG - 2016-01-05 17:27:27 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Email Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Controller Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:27:27 --> Model Class Initialized
ERROR - 2016-01-05 17:27:27 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\all_tenants.php 146
ERROR - 2016-01-05 17:27:27 --> Severity: Notice  --> Undefined variable: property_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\all_tenants.php 153
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:27:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:27:27 --> Final output sent to browser
DEBUG - 2016-01-05 17:27:27 --> Total execution time: 0.4636
DEBUG - 2016-01-05 17:27:47 --> Config Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:27:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:27:47 --> URI Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Router Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Output Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Security Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Input Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:27:47 --> Language Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Language Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Config Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Loader Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:27:47 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:27:47 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Session Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:27:47 --> Session routines successfully run
DEBUG - 2016-01-05 17:27:47 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Email Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Controller Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:27:47 --> Model Class Initialized
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:27:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:27:47 --> Final output sent to browser
DEBUG - 2016-01-05 17:27:47 --> Total execution time: 0.3317
DEBUG - 2016-01-05 17:28:39 --> Config Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:28:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:28:39 --> URI Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Router Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Output Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Security Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Input Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:28:39 --> Language Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Language Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Config Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Loader Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:28:39 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:28:39 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Session Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:28:39 --> Session routines successfully run
DEBUG - 2016-01-05 17:28:39 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Email Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Controller Class Initialized
DEBUG - 2016-01-05 17:28:39 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:28:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:28:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:28:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:28:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:28:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:28:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:28:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:28:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:28:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:28:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:40 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:28:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:28:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:28:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:28:40 --> Final output sent to browser
DEBUG - 2016-01-05 17:28:40 --> Total execution time: 0.5242
DEBUG - 2016-01-05 17:29:25 --> Config Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:29:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:29:25 --> URI Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Router Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Output Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Security Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Input Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:29:25 --> Language Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Language Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Config Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Loader Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:29:25 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:29:25 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Session Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:29:25 --> Session routines successfully run
DEBUG - 2016-01-05 17:29:25 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:29:25 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:29:26 --> Email Class Initialized
DEBUG - 2016-01-05 17:29:26 --> Controller Class Initialized
DEBUG - 2016-01-05 17:29:26 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:29:26 --> Model Class Initialized
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:29:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:29:26 --> Final output sent to browser
DEBUG - 2016-01-05 17:29:26 --> Total execution time: 0.2986
DEBUG - 2016-01-05 17:31:14 --> Config Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:31:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:31:14 --> URI Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Router Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Output Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Security Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Input Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:31:14 --> Language Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Language Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Config Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Loader Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:31:14 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:31:14 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Session Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:31:14 --> Session routines successfully run
DEBUG - 2016-01-05 17:31:14 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Email Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Controller Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:31:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:31:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:31:14 --> Final output sent to browser
DEBUG - 2016-01-05 17:31:14 --> Total execution time: 0.3218
DEBUG - 2016-01-05 17:31:59 --> Config Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:31:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:31:59 --> URI Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Router Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Output Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Security Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Input Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:31:59 --> Language Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Language Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Config Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Loader Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:31:59 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:31:59 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Session Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:31:59 --> Session routines successfully run
DEBUG - 2016-01-05 17:31:59 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Email Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Controller Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:31:59 --> Model Class Initialized
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:31:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:31:59 --> Final output sent to browser
DEBUG - 2016-01-05 17:31:59 --> Total execution time: 0.3382
DEBUG - 2016-01-05 17:32:50 --> Config Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:32:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:32:50 --> URI Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Router Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Output Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Security Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Input Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:32:50 --> Language Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Language Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Config Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Loader Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:32:50 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:32:50 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Session Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:32:50 --> Session routines successfully run
DEBUG - 2016-01-05 17:32:50 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Email Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Controller Class Initialized
DEBUG - 2016-01-05 17:32:50 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:32:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:32:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:32:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:32:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:32:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:32:50 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:32:51 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:32:51 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:32:51 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:32:51 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:51 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:32:51 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:32:51 --> Model Class Initialized
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:32:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:32:51 --> Final output sent to browser
DEBUG - 2016-01-05 17:32:51 --> Total execution time: 0.3644
DEBUG - 2016-01-05 17:33:12 --> Config Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:33:12 --> URI Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Router Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Output Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Security Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Input Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:33:12 --> Language Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Language Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Config Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Loader Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:33:12 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:33:12 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Session Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:33:12 --> Session routines successfully run
DEBUG - 2016-01-05 17:33:12 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Email Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Controller Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:33:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:33:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:33:12 --> Final output sent to browser
DEBUG - 2016-01-05 17:33:12 --> Total execution time: 0.3646
DEBUG - 2016-01-05 17:33:53 --> Config Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:33:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:33:53 --> URI Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Router Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Output Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Security Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Input Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:33:53 --> Language Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Language Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Config Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Loader Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:33:53 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:33:53 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Session Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:33:53 --> Session routines successfully run
DEBUG - 2016-01-05 17:33:53 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Email Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Controller Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:33:53 --> Model Class Initialized
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:33:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:33:53 --> Final output sent to browser
DEBUG - 2016-01-05 17:33:53 --> Total execution time: 0.3135
DEBUG - 2016-01-05 17:34:14 --> Config Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:34:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:34:14 --> URI Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Router Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Output Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Security Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Input Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:34:14 --> Language Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Language Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Config Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Loader Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:34:14 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:34:14 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Session Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:34:14 --> Session routines successfully run
DEBUG - 2016-01-05 17:34:14 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Email Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Controller Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:34:14 --> Model Class Initialized
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:34:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:34:14 --> Final output sent to browser
DEBUG - 2016-01-05 17:34:14 --> Total execution time: 0.3678
DEBUG - 2016-01-05 17:35:01 --> Config Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:35:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:35:01 --> URI Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Router Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Output Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Security Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Input Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:35:01 --> Language Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Language Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Config Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Loader Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:35:01 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:35:01 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Session Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:35:01 --> Session routines successfully run
DEBUG - 2016-01-05 17:35:01 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Email Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Controller Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:35:01 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:35:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:35:01 --> Final output sent to browser
DEBUG - 2016-01-05 17:35:01 --> Total execution time: 0.2817
DEBUG - 2016-01-05 17:35:12 --> Config Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:35:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:35:12 --> URI Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Router Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Output Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Security Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Input Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:35:12 --> Language Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Language Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Config Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Loader Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:35:12 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:35:12 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Session Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:35:12 --> Session routines successfully run
DEBUG - 2016-01-05 17:35:12 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Email Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Controller Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:35:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:35:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:35:12 --> Final output sent to browser
DEBUG - 2016-01-05 17:35:12 --> Total execution time: 0.2958
DEBUG - 2016-01-05 17:35:48 --> Config Class Initialized
DEBUG - 2016-01-05 17:35:48 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:35:48 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:35:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:35:48 --> URI Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Router Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Output Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Security Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Input Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:35:49 --> Language Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Language Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Config Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Loader Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:35:49 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:35:49 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Session Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:35:49 --> Session routines successfully run
DEBUG - 2016-01-05 17:35:49 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Email Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Controller Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:35:49 --> Model Class Initialized
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:35:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:35:49 --> Final output sent to browser
DEBUG - 2016-01-05 17:35:49 --> Total execution time: 0.3502
DEBUG - 2016-01-05 17:37:40 --> Config Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:37:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:37:40 --> URI Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Router Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Output Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Security Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Input Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:37:40 --> Language Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Language Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Config Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Loader Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:37:40 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:37:40 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Session Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:37:40 --> Session routines successfully run
DEBUG - 2016-01-05 17:37:40 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Email Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Controller Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:37:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:37:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:37:40 --> Final output sent to browser
DEBUG - 2016-01-05 17:37:40 --> Total execution time: 0.3640
DEBUG - 2016-01-05 17:39:48 --> Config Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:39:48 --> URI Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Router Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Output Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Security Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Input Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:39:48 --> Language Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Language Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Config Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Loader Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:39:48 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:39:48 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Session Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:39:48 --> Session routines successfully run
DEBUG - 2016-01-05 17:39:48 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Email Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Controller Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:39:48 --> Model Class Initialized
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:39:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:39:48 --> Final output sent to browser
DEBUG - 2016-01-05 17:39:48 --> Total execution time: 0.3116
DEBUG - 2016-01-05 17:40:40 --> Config Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:40:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:40:40 --> URI Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Router Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Output Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Security Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Input Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:40:40 --> Language Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Language Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Config Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Loader Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:40:40 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:40:40 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Session Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:40:40 --> Session routines successfully run
DEBUG - 2016-01-05 17:40:40 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Email Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Controller Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:40:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:40:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:40:40 --> Final output sent to browser
DEBUG - 2016-01-05 17:40:40 --> Total execution time: 0.3709
DEBUG - 2016-01-05 17:40:55 --> Config Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:40:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:40:55 --> URI Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Router Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Output Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Security Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Input Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:40:55 --> Language Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Language Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Config Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Loader Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:40:55 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:40:55 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Session Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:40:55 --> Session routines successfully run
DEBUG - 2016-01-05 17:40:55 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Email Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Controller Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:40:55 --> Model Class Initialized
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:40:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:40:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:40:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:40:56 --> Final output sent to browser
DEBUG - 2016-01-05 17:40:56 --> Total execution time: 0.6481
DEBUG - 2016-01-05 17:41:11 --> Config Class Initialized
DEBUG - 2016-01-05 17:41:11 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:41:11 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:41:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:41:12 --> URI Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Router Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Output Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Security Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Input Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:41:12 --> Language Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Language Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Config Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Loader Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:41:12 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:41:12 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Session Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:41:12 --> Session routines successfully run
DEBUG - 2016-01-05 17:41:12 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Email Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Controller Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:41:12 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:41:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:41:12 --> Final output sent to browser
DEBUG - 2016-01-05 17:41:12 --> Total execution time: 0.5053
DEBUG - 2016-01-05 17:41:30 --> Config Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:41:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:41:30 --> URI Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Router Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Output Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Security Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Input Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:41:30 --> Language Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Language Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Config Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Loader Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:41:30 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:41:30 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Session Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:41:30 --> Session routines successfully run
DEBUG - 2016-01-05 17:41:30 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Email Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Controller Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:41:30 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:41:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:41:30 --> Final output sent to browser
DEBUG - 2016-01-05 17:41:30 --> Total execution time: 0.4146
DEBUG - 2016-01-05 17:41:52 --> Config Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:41:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:41:52 --> URI Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Router Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Output Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Security Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Input Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:41:52 --> Language Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Language Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Config Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Loader Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:41:52 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:41:52 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Session Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:41:52 --> Session routines successfully run
DEBUG - 2016-01-05 17:41:52 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Email Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Controller Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:41:52 --> Model Class Initialized
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:41:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:41:52 --> Final output sent to browser
DEBUG - 2016-01-05 17:41:52 --> Total execution time: 0.6052
DEBUG - 2016-01-05 17:42:13 --> Config Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:42:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:42:13 --> URI Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Router Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Output Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Security Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Input Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:42:13 --> Language Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Language Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Config Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Loader Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:42:13 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:42:13 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Session Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:42:13 --> Session routines successfully run
DEBUG - 2016-01-05 17:42:13 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Email Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Controller Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:42:13 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:42:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:42:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:42:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:42:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:42:14 --> Final output sent to browser
DEBUG - 2016-01-05 17:42:14 --> Total execution time: 0.3087
DEBUG - 2016-01-05 17:42:21 --> Config Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:42:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:42:21 --> URI Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Router Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Output Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Security Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Input Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:42:21 --> Language Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Language Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Config Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Loader Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:42:21 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:42:21 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Session Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:42:21 --> Session routines successfully run
DEBUG - 2016-01-05 17:42:21 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Email Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Controller Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:42:21 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:42:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:42:21 --> Final output sent to browser
DEBUG - 2016-01-05 17:42:21 --> Total execution time: 0.3324
DEBUG - 2016-01-05 17:42:55 --> Config Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:42:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:42:55 --> URI Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Router Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Output Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Security Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Input Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:42:55 --> Language Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Language Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Config Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Loader Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:42:55 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:42:55 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Session Class Initialized
DEBUG - 2016-01-05 17:42:55 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:42:55 --> Session routines successfully run
DEBUG - 2016-01-05 17:42:56 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:42:56 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:42:56 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:42:56 --> Email Class Initialized
DEBUG - 2016-01-05 17:42:56 --> Controller Class Initialized
DEBUG - 2016-01-05 17:42:56 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:42:56 --> Model Class Initialized
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:42:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:42:56 --> Final output sent to browser
DEBUG - 2016-01-05 17:42:56 --> Total execution time: 0.3559
DEBUG - 2016-01-05 17:43:22 --> Config Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:43:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:43:22 --> URI Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Router Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Output Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Security Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Input Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:43:22 --> Language Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Language Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Config Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Loader Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:43:22 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:43:22 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Session Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:43:22 --> Session routines successfully run
DEBUG - 2016-01-05 17:43:22 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Email Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Controller Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:43:22 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:22 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:43:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:43:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:43:23 --> Model Class Initialized
DEBUG - 2016-01-05 17:43:23 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:43:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:43:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:43:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:43:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:43:23 --> Final output sent to browser
DEBUG - 2016-01-05 17:43:23 --> Total execution time: 0.3103
DEBUG - 2016-01-05 17:47:26 --> Config Class Initialized
DEBUG - 2016-01-05 17:47:26 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:47:26 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:47:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:47:26 --> URI Class Initialized
DEBUG - 2016-01-05 17:47:26 --> Router Class Initialized
DEBUG - 2016-01-05 17:47:26 --> Output Class Initialized
DEBUG - 2016-01-05 17:47:26 --> Security Class Initialized
DEBUG - 2016-01-05 17:47:26 --> Input Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:47:27 --> Language Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Language Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Config Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Loader Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:47:27 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:47:27 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Session Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:47:27 --> Session routines successfully run
DEBUG - 2016-01-05 17:47:27 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Email Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Controller Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:47:27 --> Model Class Initialized
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:47:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:47:27 --> Final output sent to browser
DEBUG - 2016-01-05 17:47:27 --> Total execution time: 0.3271
DEBUG - 2016-01-05 17:48:39 --> Config Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:48:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:48:39 --> URI Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Router Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Output Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Security Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Input Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:48:39 --> Language Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Language Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Config Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Loader Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:48:39 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:48:39 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Session Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:48:39 --> Session routines successfully run
DEBUG - 2016-01-05 17:48:39 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Email Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Controller Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:48:39 --> Model Class Initialized
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:48:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:48:39 --> Final output sent to browser
DEBUG - 2016-01-05 17:48:39 --> Total execution time: 0.3991
DEBUG - 2016-01-05 17:50:43 --> Config Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:50:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:50:43 --> URI Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Router Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Output Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Security Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Input Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:50:43 --> Language Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Language Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Config Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Loader Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:50:43 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:50:43 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Session Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:50:43 --> Session routines successfully run
DEBUG - 2016-01-05 17:50:43 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Email Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Controller Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:50:43 --> Model Class Initialized
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:50:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:50:43 --> Final output sent to browser
DEBUG - 2016-01-05 17:50:43 --> Total execution time: 0.3020
DEBUG - 2016-01-05 17:52:05 --> Config Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:52:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:52:05 --> URI Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Router Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Output Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Security Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Input Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:52:05 --> Language Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Language Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Config Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Loader Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:52:05 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:52:05 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Session Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:52:05 --> Session routines successfully run
DEBUG - 2016-01-05 17:52:05 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Email Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Controller Class Initialized
DEBUG - 2016-01-05 17:52:05 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:52:05 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:52:05 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:52:05 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:52:05 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:52:05 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:52:05 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:52:06 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:52:06 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:52:06 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:52:06 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:06 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:52:06 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:52:06 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:52:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:52:06 --> Final output sent to browser
DEBUG - 2016-01-05 17:52:06 --> Total execution time: 0.3081
DEBUG - 2016-01-05 17:52:40 --> Config Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:52:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:52:40 --> URI Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Router Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Output Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Security Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Input Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:52:40 --> Language Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Language Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Config Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Loader Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:52:40 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:52:40 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Session Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:52:40 --> Session routines successfully run
DEBUG - 2016-01-05 17:52:40 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Email Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Controller Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:52:40 --> Model Class Initialized
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:52:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:52:40 --> Final output sent to browser
DEBUG - 2016-01-05 17:52:40 --> Total execution time: 0.3696
DEBUG - 2016-01-05 17:53:02 --> Config Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:53:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:53:02 --> URI Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Router Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Output Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Security Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Input Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:53:02 --> Language Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Language Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Config Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Loader Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:53:02 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:53:02 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Session Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:53:02 --> Session routines successfully run
DEBUG - 2016-01-05 17:53:02 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Email Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Controller Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:53:02 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:53:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:53:02 --> Final output sent to browser
DEBUG - 2016-01-05 17:53:02 --> Total execution time: 0.4878
DEBUG - 2016-01-05 17:53:30 --> Config Class Initialized
DEBUG - 2016-01-05 17:53:30 --> Hooks Class Initialized
DEBUG - 2016-01-05 17:53:30 --> Utf8 Class Initialized
DEBUG - 2016-01-05 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 17:53:30 --> URI Class Initialized
DEBUG - 2016-01-05 17:53:30 --> Router Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Output Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Security Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Input Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 17:53:31 --> Language Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Language Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Config Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Loader Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Helper loaded: url_helper
DEBUG - 2016-01-05 17:53:31 --> Helper loaded: form_helper
DEBUG - 2016-01-05 17:53:31 --> Database Driver Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Session Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Helper loaded: string_helper
DEBUG - 2016-01-05 17:53:31 --> Session routines successfully run
DEBUG - 2016-01-05 17:53:31 --> Form Validation Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Pagination Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Encrypt Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Email Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Controller Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> Image Lib Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 17:53:31 --> Model Class Initialized
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 17:53:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 17:53:31 --> Final output sent to browser
DEBUG - 2016-01-05 17:53:31 --> Total execution time: 0.4329
DEBUG - 2016-01-05 18:10:29 --> Config Class Initialized
DEBUG - 2016-01-05 18:10:29 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:10:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:10:30 --> URI Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Router Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Output Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Security Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Input Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 18:10:30 --> Language Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Language Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Config Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Loader Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Helper loaded: url_helper
DEBUG - 2016-01-05 18:10:30 --> Helper loaded: form_helper
DEBUG - 2016-01-05 18:10:30 --> Database Driver Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Session Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Helper loaded: string_helper
DEBUG - 2016-01-05 18:10:30 --> Session routines successfully run
DEBUG - 2016-01-05 18:10:30 --> Form Validation Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Pagination Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Encrypt Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Email Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Controller Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> Image Lib Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 18:10:30 --> Model Class Initialized
ERROR - 2016-01-05 18:10:31 --> Severity: Notice  --> Undefined property: stdClass::$service_charge_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 77
ERROR - 2016-01-05 18:10:31 --> Severity: Notice  --> Undefined property: stdClass::$service_charge_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 78
ERROR - 2016-01-05 18:10:31 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\all_tenants.php 220
DEBUG - 2016-01-05 18:10:31 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 18:10:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 18:10:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 18:10:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 18:10:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 18:10:31 --> Final output sent to browser
DEBUG - 2016-01-05 18:10:31 --> Total execution time: 1.3952
DEBUG - 2016-01-05 18:10:52 --> Config Class Initialized
DEBUG - 2016-01-05 18:10:52 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:10:52 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:10:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:10:52 --> URI Class Initialized
DEBUG - 2016-01-05 18:10:52 --> Router Class Initialized
DEBUG - 2016-01-05 18:10:52 --> Output Class Initialized
DEBUG - 2016-01-05 18:10:52 --> Security Class Initialized
DEBUG - 2016-01-05 18:10:52 --> Input Class Initialized
DEBUG - 2016-01-05 18:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 18:10:52 --> Language Class Initialized
DEBUG - 2016-01-05 18:10:52 --> Language Class Initialized
DEBUG - 2016-01-05 18:10:52 --> Config Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Loader Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Helper loaded: url_helper
DEBUG - 2016-01-05 18:10:53 --> Helper loaded: form_helper
DEBUG - 2016-01-05 18:10:53 --> Database Driver Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Session Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Helper loaded: string_helper
DEBUG - 2016-01-05 18:10:53 --> Session routines successfully run
DEBUG - 2016-01-05 18:10:53 --> Form Validation Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Pagination Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Encrypt Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Email Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Controller Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> Image Lib Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 18:10:53 --> Model Class Initialized
ERROR - 2016-01-05 18:10:53 --> Severity: Notice  --> Undefined property: stdClass::$service_charge_id C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\tenants.php 77
ERROR - 2016-01-05 18:10:53 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\all_tenants.php 220
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 18:10:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 18:10:53 --> Final output sent to browser
DEBUG - 2016-01-05 18:10:53 --> Total execution time: 1.4685
DEBUG - 2016-01-05 18:11:09 --> Config Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:11:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:11:09 --> URI Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Router Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Output Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Security Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Input Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 18:11:09 --> Language Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Language Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Config Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Loader Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Helper loaded: url_helper
DEBUG - 2016-01-05 18:11:09 --> Helper loaded: form_helper
DEBUG - 2016-01-05 18:11:09 --> Database Driver Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Session Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Helper loaded: string_helper
DEBUG - 2016-01-05 18:11:09 --> Session routines successfully run
DEBUG - 2016-01-05 18:11:09 --> Form Validation Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Pagination Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Encrypt Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Email Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Controller Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> Image Lib Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 18:11:09 --> Model Class Initialized
ERROR - 2016-01-05 18:11:09 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\tenants\all_tenants.php 220
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 18:11:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 18:11:09 --> Final output sent to browser
DEBUG - 2016-01-05 18:11:09 --> Total execution time: 0.2839
DEBUG - 2016-01-05 18:16:42 --> Config Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:16:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:16:42 --> URI Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Router Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Output Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Security Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Input Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 18:16:42 --> Language Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Language Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Config Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Loader Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Helper loaded: url_helper
DEBUG - 2016-01-05 18:16:42 --> Helper loaded: form_helper
DEBUG - 2016-01-05 18:16:42 --> Database Driver Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Session Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Helper loaded: string_helper
DEBUG - 2016-01-05 18:16:42 --> Session routines successfully run
DEBUG - 2016-01-05 18:16:42 --> Form Validation Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Pagination Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Encrypt Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Email Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Controller Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> Image Lib Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 18:16:42 --> Model Class Initialized
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 18:16:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 18:16:42 --> Final output sent to browser
DEBUG - 2016-01-05 18:16:42 --> Total execution time: 0.2976
DEBUG - 2016-01-05 18:47:14 --> Config Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:47:14 --> URI Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Router Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Output Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Security Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Input Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 18:47:14 --> Language Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Language Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Config Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Loader Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Helper loaded: url_helper
DEBUG - 2016-01-05 18:47:14 --> Helper loaded: form_helper
DEBUG - 2016-01-05 18:47:14 --> Database Driver Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Session Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Helper loaded: string_helper
DEBUG - 2016-01-05 18:47:14 --> Session routines successfully run
DEBUG - 2016-01-05 18:47:14 --> Form Validation Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Pagination Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Encrypt Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Email Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Controller Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> Image Lib Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 18:47:14 --> Model Class Initialized
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 18:47:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 18:47:14 --> Final output sent to browser
DEBUG - 2016-01-05 18:47:14 --> Total execution time: 0.3496
DEBUG - 2016-01-05 18:52:03 --> Config Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:52:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:52:03 --> URI Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Router Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Output Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Security Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Input Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 18:52:03 --> Language Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Language Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Config Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Loader Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Helper loaded: url_helper
DEBUG - 2016-01-05 18:52:03 --> Helper loaded: form_helper
DEBUG - 2016-01-05 18:52:03 --> Database Driver Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Session Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Helper loaded: string_helper
DEBUG - 2016-01-05 18:52:03 --> Session routines successfully run
DEBUG - 2016-01-05 18:52:03 --> Form Validation Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Pagination Class Initialized
DEBUG - 2016-01-05 18:52:03 --> Encrypt Class Initialized
DEBUG - 2016-01-05 18:52:04 --> Email Class Initialized
DEBUG - 2016-01-05 18:52:04 --> Controller Class Initialized
DEBUG - 2016-01-05 18:52:04 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> Image Lib Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 18:52:04 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 18:52:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 18:52:04 --> Final output sent to browser
DEBUG - 2016-01-05 18:52:04 --> Total execution time: 0.2756
DEBUG - 2016-01-05 18:52:34 --> Config Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:52:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:52:34 --> URI Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Router Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Output Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Security Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Input Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 18:52:34 --> Language Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Language Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Config Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Loader Class Initialized
DEBUG - 2016-01-05 18:52:34 --> Helper loaded: url_helper
DEBUG - 2016-01-05 18:52:35 --> Helper loaded: form_helper
DEBUG - 2016-01-05 18:52:35 --> Database Driver Class Initialized
DEBUG - 2016-01-05 18:52:35 --> Session Class Initialized
DEBUG - 2016-01-05 18:52:35 --> Helper loaded: string_helper
DEBUG - 2016-01-05 18:52:35 --> Session routines successfully run
DEBUG - 2016-01-05 18:52:35 --> Form Validation Class Initialized
DEBUG - 2016-01-05 18:52:35 --> Pagination Class Initialized
DEBUG - 2016-01-05 18:52:35 --> Encrypt Class Initialized
DEBUG - 2016-01-05 18:52:35 --> Email Class Initialized
DEBUG - 2016-01-05 18:52:35 --> Controller Class Initialized
DEBUG - 2016-01-05 18:52:35 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> Image Lib Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
DEBUG - 2016-01-05 18:52:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 18:52:35 --> Model Class Initialized
ERROR - 2016-01-05 18:52:35 --> 404 Page Not Found --> tenants/add_tenant(:num)
DEBUG - 2016-01-05 18:54:17 --> Config Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:54:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:54:17 --> URI Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Router Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Output Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Security Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Input Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 18:54:17 --> Language Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Language Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Config Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Loader Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Helper loaded: url_helper
DEBUG - 2016-01-05 18:54:17 --> Helper loaded: form_helper
DEBUG - 2016-01-05 18:54:17 --> Database Driver Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Session Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Helper loaded: string_helper
DEBUG - 2016-01-05 18:54:17 --> Session routines successfully run
DEBUG - 2016-01-05 18:54:17 --> Form Validation Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Pagination Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Encrypt Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Email Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Controller Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 18:54:17 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:17 --> Image Lib Class Initialized
DEBUG - 2016-01-05 18:54:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 18:54:18 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 18:54:18 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-05 18:54:18 --> XSS Filtering completed
DEBUG - 2016-01-05 18:54:18 --> XSS Filtering completed
DEBUG - 2016-01-05 18:54:18 --> XSS Filtering completed
DEBUG - 2016-01-05 18:54:18 --> XSS Filtering completed
DEBUG - 2016-01-05 18:54:18 --> Config Class Initialized
DEBUG - 2016-01-05 18:54:18 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:54:18 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:54:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:54:18 --> URI Class Initialized
DEBUG - 2016-01-05 18:54:18 --> Router Class Initialized
DEBUG - 2016-01-05 18:54:29 --> Config Class Initialized
DEBUG - 2016-01-05 18:54:29 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:54:29 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:54:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:54:29 --> URI Class Initialized
DEBUG - 2016-01-05 18:54:29 --> Router Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Config Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Utf8 Class Initialized
DEBUG - 2016-01-05 18:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 18:54:35 --> URI Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Router Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Output Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Security Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Input Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 18:54:35 --> Language Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Language Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Config Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Loader Class Initialized
DEBUG - 2016-01-05 18:54:35 --> Helper loaded: url_helper
DEBUG - 2016-01-05 18:54:35 --> Helper loaded: form_helper
DEBUG - 2016-01-05 18:54:35 --> Database Driver Class Initialized
DEBUG - 2016-01-05 18:54:36 --> Session Class Initialized
DEBUG - 2016-01-05 18:54:36 --> Helper loaded: string_helper
DEBUG - 2016-01-05 18:54:36 --> Session routines successfully run
DEBUG - 2016-01-05 18:54:36 --> Form Validation Class Initialized
DEBUG - 2016-01-05 18:54:36 --> Pagination Class Initialized
DEBUG - 2016-01-05 18:54:36 --> Encrypt Class Initialized
DEBUG - 2016-01-05 18:54:36 --> Email Class Initialized
DEBUG - 2016-01-05 18:54:36 --> Controller Class Initialized
DEBUG - 2016-01-05 18:54:36 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> Image Lib Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 18:54:36 --> Model Class Initialized
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 18:54:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 18:54:36 --> Final output sent to browser
DEBUG - 2016-01-05 18:54:36 --> Total execution time: 0.2851
DEBUG - 2016-01-05 19:04:41 --> Config Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Utf8 Class Initialized
DEBUG - 2016-01-05 19:04:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 19:04:41 --> URI Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Router Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Output Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Security Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Input Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 19:04:41 --> Language Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Language Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Config Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Loader Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Helper loaded: url_helper
DEBUG - 2016-01-05 19:04:41 --> Helper loaded: form_helper
DEBUG - 2016-01-05 19:04:41 --> Database Driver Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Session Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Helper loaded: string_helper
DEBUG - 2016-01-05 19:04:41 --> Session routines successfully run
DEBUG - 2016-01-05 19:04:41 --> Form Validation Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Pagination Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Encrypt Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Email Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Controller Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> Image Lib Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 19:04:41 --> Model Class Initialized
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 19:04:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 19:04:41 --> Final output sent to browser
DEBUG - 2016-01-05 19:04:41 --> Total execution time: 0.2796
DEBUG - 2016-01-05 19:24:51 --> Config Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Utf8 Class Initialized
DEBUG - 2016-01-05 19:24:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-05 19:24:51 --> URI Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Router Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Output Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Security Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Input Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-05 19:24:51 --> Language Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Language Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Config Class Initialized
DEBUG - 2016-01-05 19:24:51 --> Loader Class Initialized
DEBUG - 2016-01-05 19:24:52 --> Helper loaded: url_helper
DEBUG - 2016-01-05 19:24:52 --> Helper loaded: form_helper
DEBUG - 2016-01-05 19:24:52 --> Database Driver Class Initialized
DEBUG - 2016-01-05 19:24:52 --> Session Class Initialized
DEBUG - 2016-01-05 19:24:52 --> Helper loaded: string_helper
DEBUG - 2016-01-05 19:24:52 --> Session routines successfully run
DEBUG - 2016-01-05 19:24:52 --> Form Validation Class Initialized
DEBUG - 2016-01-05 19:24:52 --> Pagination Class Initialized
DEBUG - 2016-01-05 19:24:52 --> Encrypt Class Initialized
DEBUG - 2016-01-05 19:24:52 --> Email Class Initialized
DEBUG - 2016-01-05 19:24:52 --> Controller Class Initialized
DEBUG - 2016-01-05 19:24:52 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> Image Lib Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-05 19:24:52 --> Model Class Initialized
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-05 19:24:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-05 19:24:52 --> Final output sent to browser
DEBUG - 2016-01-05 19:24:52 --> Total execution time: 1.9095
