<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-28 16:11:49 --> Config Class Initialized
DEBUG - 2015-10-28 16:11:49 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:11:49 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:11:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:11:49 --> URI Class Initialized
DEBUG - 2015-10-28 16:11:49 --> Router Class Initialized
DEBUG - 2015-10-28 16:11:50 --> No URI present. Default controller set.
DEBUG - 2015-10-28 16:11:50 --> Output Class Initialized
DEBUG - 2015-10-28 16:11:50 --> Security Class Initialized
DEBUG - 2015-10-28 16:11:51 --> Input Class Initialized
DEBUG - 2015-10-28 16:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:11:51 --> Language Class Initialized
DEBUG - 2015-10-28 16:11:51 --> Language Class Initialized
DEBUG - 2015-10-28 16:11:51 --> Config Class Initialized
DEBUG - 2015-10-28 16:11:51 --> Loader Class Initialized
DEBUG - 2015-10-28 16:11:52 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:11:52 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:11:52 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:11:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:11:53 --> Session Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:11:53 --> A session cookie was not found.
DEBUG - 2015-10-28 16:11:53 --> Session routines successfully run
DEBUG - 2015-10-28 16:11:53 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Email Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Controller Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Auth MX_Controller Initialized
DEBUG - 2015-10-28 16:11:53 --> Model Class Initialized
DEBUG - 2015-10-28 16:11:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:11:53 --> Model Class Initialized
DEBUG - 2015-10-28 16:11:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:11:53 --> Model Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Config Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:11:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:11:53 --> URI Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Router Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Output Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Security Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Input Class Initialized
DEBUG - 2015-10-28 16:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:11:54 --> Language Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Language Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Config Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Loader Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:11:54 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:11:54 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:11:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:11:54 --> Session Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:11:54 --> Session routines successfully run
DEBUG - 2015-10-28 16:11:54 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Email Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Controller Class Initialized
DEBUG - 2015-10-28 16:11:54 --> Auth MX_Controller Initialized
DEBUG - 2015-10-28 16:11:54 --> Model Class Initialized
DEBUG - 2015-10-28 16:11:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:11:54 --> Model Class Initialized
DEBUG - 2015-10-28 16:11:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:11:54 --> Model Class Initialized
DEBUG - 2015-10-28 16:11:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-28 16:11:55 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-10-28 16:11:55 --> Final output sent to browser
DEBUG - 2015-10-28 16:11:55 --> Total execution time: 1.3108
DEBUG - 2015-10-28 16:11:58 --> Config Class Initialized
DEBUG - 2015-10-28 16:11:58 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:11:58 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:11:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:11:58 --> URI Class Initialized
DEBUG - 2015-10-28 16:11:58 --> Router Class Initialized
ERROR - 2015-10-28 16:11:58 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:12:00 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:00 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:00 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:00 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:00 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Router Class Initialized
DEBUG - 2015-10-28 16:12:00 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:00 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Router Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Router Class Initialized
DEBUG - 2015-10-28 16:12:00 --> Router Class Initialized
ERROR - 2015-10-28 16:12:00 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:12:00 --> Router Class Initialized
ERROR - 2015-10-28 16:12:00 --> 404 Page Not Found --> 
ERROR - 2015-10-28 16:12:00 --> 404 Page Not Found --> 
ERROR - 2015-10-28 16:12:00 --> 404 Page Not Found --> 
ERROR - 2015-10-28 16:12:00 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:12:07 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:07 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Router Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Output Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Security Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Input Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:12:07 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Loader Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:12:07 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:12:07 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:12:07 --> Session Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:12:07 --> Session routines successfully run
DEBUG - 2015-10-28 16:12:07 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Email Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Controller Class Initialized
DEBUG - 2015-10-28 16:12:07 --> Auth MX_Controller Initialized
DEBUG - 2015-10-28 16:12:07 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:12:07 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:12:08 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-28 16:12:08 --> XSS Filtering completed
DEBUG - 2015-10-28 16:12:08 --> Unable to find validation rule: exists
DEBUG - 2015-10-28 16:12:08 --> XSS Filtering completed
DEBUG - 2015-10-28 16:12:08 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:08 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Router Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Output Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Security Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Input Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:12:08 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Loader Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:12:08 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:12:08 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:12:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:12:08 --> Session Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:12:08 --> Session routines successfully run
DEBUG - 2015-10-28 16:12:08 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Email Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Controller Class Initialized
DEBUG - 2015-10-28 16:12:08 --> Admin MX_Controller Initialized
DEBUG - 2015-10-28 16:12:08 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-28 16:12:08 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:12:08 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:12:08 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-28 16:12:09 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-28 16:12:09 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-28 16:12:09 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:09 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-28 16:12:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-28 16:12:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-28 16:12:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-28 16:12:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-28 16:12:09 --> Final output sent to browser
DEBUG - 2015-10-28 16:12:09 --> Total execution time: 1.6807
DEBUG - 2015-10-28 16:12:14 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:14 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:14 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:14 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:14 --> Router Class Initialized
ERROR - 2015-10-28 16:12:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:12:16 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:16 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:16 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:16 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:16 --> Router Class Initialized
ERROR - 2015-10-28 16:12:16 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:12:27 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:27 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Router Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Output Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Security Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Input Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:12:27 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Loader Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:12:27 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:12:27 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:12:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:12:27 --> Session Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:12:27 --> Session routines successfully run
DEBUG - 2015-10-28 16:12:27 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:12:27 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:12:28 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:12:28 --> Email Class Initialized
DEBUG - 2015-10-28 16:12:28 --> Controller Class Initialized
DEBUG - 2015-10-28 16:12:28 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-28 16:12:28 --> Model Class Initialized
ERROR - 2015-10-28 16:12:28 --> 404 Page Not Found --> microfinance/deposits
DEBUG - 2015-10-28 16:12:31 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:31 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Router Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Output Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Security Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Input Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:12:31 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Loader Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:12:31 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:12:31 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:12:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:12:31 --> Session Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:12:31 --> Session routines successfully run
DEBUG - 2015-10-28 16:12:31 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Email Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Controller Class Initialized
DEBUG - 2015-10-28 16:12:31 --> Admin MX_Controller Initialized
DEBUG - 2015-10-28 16:12:31 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-28 16:12:31 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:12:31 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:12:31 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-28 16:12:31 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-28 16:12:31 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-28 16:12:32 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:32 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-28 16:12:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-28 16:12:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-28 16:12:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-28 16:12:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-28 16:12:32 --> Final output sent to browser
DEBUG - 2015-10-28 16:12:32 --> Total execution time: 0.7808
DEBUG - 2015-10-28 16:12:35 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:35 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:35 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:35 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:35 --> Router Class Initialized
ERROR - 2015-10-28 16:12:35 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:12:38 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:38 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:38 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:38 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:38 --> Router Class Initialized
ERROR - 2015-10-28 16:12:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:12:47 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:47 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:47 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:47 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:47 --> Router Class Initialized
DEBUG - 2015-10-28 16:12:47 --> Output Class Initialized
DEBUG - 2015-10-28 16:12:47 --> Security Class Initialized
DEBUG - 2015-10-28 16:12:47 --> Input Class Initialized
DEBUG - 2015-10-28 16:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:12:47 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Language Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Loader Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:12:48 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:12:48 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:12:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:12:48 --> Session Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:12:48 --> Session routines successfully run
DEBUG - 2015-10-28 16:12:48 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Email Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Controller Class Initialized
DEBUG - 2015-10-28 16:12:48 --> Group MX_Controller Initialized
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-28 16:12:48 --> Model Class Initialized
DEBUG - 2015-10-28 16:12:52 --> File loaded: application/modules/microfinance/views/group/all_group.php
DEBUG - 2015-10-28 16:12:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-28 16:12:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-28 16:12:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-28 16:12:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-28 16:12:52 --> Final output sent to browser
DEBUG - 2015-10-28 16:12:52 --> Total execution time: 4.5010
DEBUG - 2015-10-28 16:12:55 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:55 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:55 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:55 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:55 --> Router Class Initialized
ERROR - 2015-10-28 16:12:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:12:59 --> Config Class Initialized
DEBUG - 2015-10-28 16:12:59 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:12:59 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:12:59 --> URI Class Initialized
DEBUG - 2015-10-28 16:12:59 --> Router Class Initialized
ERROR - 2015-10-28 16:12:59 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:13:05 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:05 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Router Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Output Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Security Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Input Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:13:05 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Loader Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:13:05 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:13:05 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:13:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:13:05 --> Session Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:13:05 --> Session routines successfully run
DEBUG - 2015-10-28 16:13:05 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Email Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Controller Class Initialized
DEBUG - 2015-10-28 16:13:05 --> Group MX_Controller Initialized
DEBUG - 2015-10-28 16:13:05 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:13:05 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:13:05 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-28 16:13:05 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-28 16:13:05 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-28 16:13:05 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-28 16:13:05 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-28 16:13:05 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-28 16:13:05 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-28 16:13:06 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-28 16:13:06 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-28 16:13:06 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:06 --> DB Transaction Failure
ERROR - 2015-10-28 16:13:06 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-10-28 16:13:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-28 16:13:09 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:09 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Router Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Output Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Security Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Input Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:13:09 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Loader Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:13:09 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:13:09 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:13:09 --> Session Class Initialized
DEBUG - 2015-10-28 16:13:09 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:13:09 --> Session routines successfully run
DEBUG - 2015-10-28 16:13:09 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:13:10 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:13:10 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:13:10 --> Email Class Initialized
DEBUG - 2015-10-28 16:13:10 --> Controller Class Initialized
DEBUG - 2015-10-28 16:13:10 --> Group MX_Controller Initialized
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-28 16:13:10 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/microfinance/views/group/all_group.php
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-28 16:13:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-28 16:13:10 --> Final output sent to browser
DEBUG - 2015-10-28 16:13:10 --> Total execution time: 0.9103
DEBUG - 2015-10-28 16:13:13 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:13 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:13 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:13 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:13 --> Router Class Initialized
ERROR - 2015-10-28 16:13:13 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:13:17 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:17 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:17 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:17 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:17 --> Router Class Initialized
ERROR - 2015-10-28 16:13:17 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:13:29 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:29 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:29 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:29 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Router Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Output Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Security Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Input Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:13:30 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Loader Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:13:30 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:13:30 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:13:30 --> Session Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:13:30 --> Session routines successfully run
DEBUG - 2015-10-28 16:13:30 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Email Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Controller Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Individual MX_Controller Initialized
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-28 16:13:30 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:30 --> Image Lib Class Initialized
DEBUG - 2015-10-28 16:13:31 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-10-28 16:13:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-28 16:13:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-28 16:13:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-28 16:13:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-28 16:13:31 --> Final output sent to browser
DEBUG - 2015-10-28 16:13:31 --> Total execution time: 1.2073
DEBUG - 2015-10-28 16:13:34 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:34 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:34 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:34 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:34 --> Router Class Initialized
ERROR - 2015-10-28 16:13:34 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:13:38 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:38 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:38 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:38 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:38 --> Router Class Initialized
ERROR - 2015-10-28 16:13:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:13:43 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:43 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Router Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Output Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Security Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Input Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:13:43 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Loader Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:13:43 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:13:43 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:13:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:13:43 --> Session Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:13:43 --> Session routines successfully run
DEBUG - 2015-10-28 16:13:43 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Email Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Controller Class Initialized
DEBUG - 2015-10-28 16:13:43 --> Individual MX_Controller Initialized
DEBUG - 2015-10-28 16:13:43 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:13:43 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:13:43 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-28 16:13:43 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-28 16:13:43 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-28 16:13:43 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-28 16:13:43 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-28 16:13:43 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-28 16:13:43 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-28 16:13:44 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-28 16:13:44 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-28 16:13:44 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:44 --> Image Lib Class Initialized
DEBUG - 2015-10-28 16:13:44 --> DB Transaction Failure
ERROR - 2015-10-28 16:13:44 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-10-28 16:13:44 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-28 16:13:47 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:47 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Router Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Output Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Security Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Input Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-28 16:13:47 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Language Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Loader Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Helper loaded: url_helper
DEBUG - 2015-10-28 16:13:47 --> Helper loaded: form_helper
DEBUG - 2015-10-28 16:13:47 --> Database Driver Class Initialized
ERROR - 2015-10-28 16:13:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-28 16:13:47 --> Session Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Helper loaded: string_helper
DEBUG - 2015-10-28 16:13:47 --> Session routines successfully run
DEBUG - 2015-10-28 16:13:47 --> Form Validation Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Pagination Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Encrypt Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Email Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Controller Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Individual MX_Controller Initialized
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-28 16:13:47 --> Model Class Initialized
DEBUG - 2015-10-28 16:13:47 --> Image Lib Class Initialized
DEBUG - 2015-10-28 16:13:48 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-10-28 16:13:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-28 16:13:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-28 16:13:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-28 16:13:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-28 16:13:48 --> Final output sent to browser
DEBUG - 2015-10-28 16:13:48 --> Total execution time: 0.9948
DEBUG - 2015-10-28 16:13:51 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:51 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:51 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:51 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:51 --> Router Class Initialized
ERROR - 2015-10-28 16:13:51 --> 404 Page Not Found --> 
DEBUG - 2015-10-28 16:13:58 --> Config Class Initialized
DEBUG - 2015-10-28 16:13:58 --> Hooks Class Initialized
DEBUG - 2015-10-28 16:13:58 --> Utf8 Class Initialized
DEBUG - 2015-10-28 16:13:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-28 16:13:58 --> URI Class Initialized
DEBUG - 2015-10-28 16:13:58 --> Router Class Initialized
ERROR - 2015-10-28 16:13:58 --> 404 Page Not Found --> 
