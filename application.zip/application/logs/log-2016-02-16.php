<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-16 18:40:52 --> Config Class Initialized
DEBUG - 2016-02-16 18:40:53 --> Hooks Class Initialized
DEBUG - 2016-02-16 18:40:53 --> Utf8 Class Initialized
DEBUG - 2016-02-16 18:40:53 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 18:40:53 --> URI Class Initialized
DEBUG - 2016-02-16 18:40:53 --> Router Class Initialized
DEBUG - 2016-02-16 18:40:53 --> No URI present. Default controller set.
DEBUG - 2016-02-16 18:40:54 --> Output Class Initialized
DEBUG - 2016-02-16 18:40:54 --> Security Class Initialized
DEBUG - 2016-02-16 18:40:54 --> Input Class Initialized
DEBUG - 2016-02-16 18:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-16 18:40:54 --> Language Class Initialized
DEBUG - 2016-02-16 18:40:54 --> Language Class Initialized
DEBUG - 2016-02-16 18:40:54 --> Config Class Initialized
DEBUG - 2016-02-16 18:40:54 --> Loader Class Initialized
DEBUG - 2016-02-16 18:40:54 --> Helper loaded: url_helper
DEBUG - 2016-02-16 18:40:55 --> Helper loaded: form_helper
DEBUG - 2016-02-16 18:40:55 --> Database Driver Class Initialized
DEBUG - 2016-02-16 18:40:55 --> Session Class Initialized
DEBUG - 2016-02-16 18:40:55 --> Helper loaded: string_helper
ERROR - 2016-02-16 18:40:55 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-16 18:40:55 --> Session routines successfully run
DEBUG - 2016-02-16 18:40:56 --> Form Validation Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Pagination Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Encrypt Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Email Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Controller Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Auth MX_Controller Initialized
DEBUG - 2016-02-16 18:40:56 --> Model Class Initialized
DEBUG - 2016-02-16 18:40:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-16 18:40:56 --> Model Class Initialized
DEBUG - 2016-02-16 18:40:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-16 18:40:56 --> Model Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Config Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Hooks Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Utf8 Class Initialized
DEBUG - 2016-02-16 18:40:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 18:40:56 --> URI Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Router Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Output Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Security Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Input Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-16 18:40:56 --> Language Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Language Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Config Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Loader Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Helper loaded: url_helper
DEBUG - 2016-02-16 18:40:56 --> Helper loaded: form_helper
DEBUG - 2016-02-16 18:40:56 --> Database Driver Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Session Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Helper loaded: string_helper
DEBUG - 2016-02-16 18:40:56 --> Session routines successfully run
DEBUG - 2016-02-16 18:40:56 --> Form Validation Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Pagination Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Encrypt Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Email Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Controller Class Initialized
DEBUG - 2016-02-16 18:40:56 --> Auth MX_Controller Initialized
DEBUG - 2016-02-16 18:40:56 --> Model Class Initialized
DEBUG - 2016-02-16 18:40:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-16 18:40:56 --> Model Class Initialized
DEBUG - 2016-02-16 18:40:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-16 18:40:57 --> Model Class Initialized
DEBUG - 2016-02-16 18:40:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-16 18:40:58 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-16 18:40:58 --> Final output sent to browser
DEBUG - 2016-02-16 18:40:58 --> Total execution time: 1.5565
DEBUG - 2016-02-16 18:41:00 --> Config Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Config Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Config Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Config Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Hooks Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Hooks Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Utf8 Class Initialized
DEBUG - 2016-02-16 18:41:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 18:41:00 --> URI Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Hooks Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Utf8 Class Initialized
DEBUG - 2016-02-16 18:41:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 18:41:00 --> Router Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Utf8 Class Initialized
DEBUG - 2016-02-16 18:41:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 18:41:00 --> Hooks Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Utf8 Class Initialized
DEBUG - 2016-02-16 18:41:00 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 18:41:00 --> URI Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Router Class Initialized
DEBUG - 2016-02-16 18:41:00 --> URI Class Initialized
DEBUG - 2016-02-16 18:41:00 --> URI Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Router Class Initialized
DEBUG - 2016-02-16 18:41:00 --> Router Class Initialized
ERROR - 2016-02-16 18:41:02 --> 404 Page Not Found --> 
ERROR - 2016-02-16 18:41:02 --> 404 Page Not Found --> 
ERROR - 2016-02-16 18:41:02 --> 404 Page Not Found --> 
ERROR - 2016-02-16 18:41:02 --> 404 Page Not Found --> 
DEBUG - 2016-02-16 20:32:40 --> Config Class Initialized
DEBUG - 2016-02-16 20:32:40 --> Hooks Class Initialized
DEBUG - 2016-02-16 20:32:40 --> Utf8 Class Initialized
DEBUG - 2016-02-16 20:32:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 20:32:40 --> URI Class Initialized
DEBUG - 2016-02-16 20:32:40 --> Router Class Initialized
DEBUG - 2016-02-16 20:32:40 --> No URI present. Default controller set.
DEBUG - 2016-02-16 20:32:40 --> Output Class Initialized
DEBUG - 2016-02-16 20:32:40 --> Security Class Initialized
DEBUG - 2016-02-16 20:32:40 --> Input Class Initialized
DEBUG - 2016-02-16 20:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-16 20:32:40 --> Language Class Initialized
DEBUG - 2016-02-16 20:32:41 --> Language Class Initialized
DEBUG - 2016-02-16 20:32:41 --> Config Class Initialized
DEBUG - 2016-02-16 20:32:41 --> Loader Class Initialized
DEBUG - 2016-02-16 20:32:41 --> Helper loaded: url_helper
DEBUG - 2016-02-16 20:32:41 --> Helper loaded: form_helper
DEBUG - 2016-02-16 20:32:41 --> Database Driver Class Initialized
DEBUG - 2016-02-16 20:32:41 --> Session Class Initialized
DEBUG - 2016-02-16 20:32:41 --> Helper loaded: string_helper
ERROR - 2016-02-16 20:32:41 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-16 20:32:41 --> Session routines successfully run
DEBUG - 2016-02-16 20:32:42 --> Form Validation Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Pagination Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Encrypt Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Email Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Controller Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Auth MX_Controller Initialized
DEBUG - 2016-02-16 20:32:42 --> Model Class Initialized
DEBUG - 2016-02-16 20:32:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-16 20:32:42 --> Model Class Initialized
DEBUG - 2016-02-16 20:32:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-16 20:32:42 --> Model Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Config Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Hooks Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Utf8 Class Initialized
DEBUG - 2016-02-16 20:32:42 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 20:32:42 --> URI Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Router Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Output Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Security Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Input Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-16 20:32:42 --> Language Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Language Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Config Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Loader Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Helper loaded: url_helper
DEBUG - 2016-02-16 20:32:42 --> Helper loaded: form_helper
DEBUG - 2016-02-16 20:32:42 --> Database Driver Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Session Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Helper loaded: string_helper
DEBUG - 2016-02-16 20:32:42 --> Session routines successfully run
DEBUG - 2016-02-16 20:32:42 --> Form Validation Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Pagination Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Encrypt Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Email Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Controller Class Initialized
DEBUG - 2016-02-16 20:32:42 --> Auth MX_Controller Initialized
DEBUG - 2016-02-16 20:32:42 --> Model Class Initialized
DEBUG - 2016-02-16 20:32:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-16 20:32:42 --> Model Class Initialized
DEBUG - 2016-02-16 20:32:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-16 20:32:42 --> Model Class Initialized
DEBUG - 2016-02-16 20:32:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-16 20:32:42 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-16 20:32:42 --> Final output sent to browser
DEBUG - 2016-02-16 20:32:42 --> Total execution time: 0.4883
DEBUG - 2016-02-16 20:32:44 --> Config Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Hooks Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Config Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Hooks Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Utf8 Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Utf8 Class Initialized
DEBUG - 2016-02-16 20:32:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 20:32:44 --> URI Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Router Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Config Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Hooks Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Utf8 Class Initialized
DEBUG - 2016-02-16 20:32:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 20:32:44 --> URI Class Initialized
DEBUG - 2016-02-16 20:32:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 20:32:44 --> Config Class Initialized
DEBUG - 2016-02-16 20:32:44 --> URI Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Hooks Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Utf8 Class Initialized
DEBUG - 2016-02-16 20:32:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 20:32:44 --> Router Class Initialized
DEBUG - 2016-02-16 20:32:44 --> URI Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Router Class Initialized
DEBUG - 2016-02-16 20:32:44 --> Router Class Initialized
ERROR - 2016-02-16 20:32:44 --> 404 Page Not Found --> 
ERROR - 2016-02-16 20:32:44 --> 404 Page Not Found --> 
ERROR - 2016-02-16 20:32:44 --> 404 Page Not Found --> 
ERROR - 2016-02-16 20:32:44 --> 404 Page Not Found --> 
DEBUG - 2016-02-16 21:39:26 --> Config Class Initialized
DEBUG - 2016-02-16 21:39:26 --> Hooks Class Initialized
DEBUG - 2016-02-16 21:39:27 --> Utf8 Class Initialized
DEBUG - 2016-02-16 21:39:27 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 21:39:27 --> URI Class Initialized
DEBUG - 2016-02-16 21:39:27 --> Router Class Initialized
DEBUG - 2016-02-16 21:39:27 --> No URI present. Default controller set.
DEBUG - 2016-02-16 21:39:27 --> Output Class Initialized
DEBUG - 2016-02-16 21:39:27 --> Security Class Initialized
DEBUG - 2016-02-16 21:39:27 --> Input Class Initialized
DEBUG - 2016-02-16 21:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-16 21:39:27 --> Language Class Initialized
DEBUG - 2016-02-16 21:39:27 --> Language Class Initialized
DEBUG - 2016-02-16 21:39:27 --> Config Class Initialized
DEBUG - 2016-02-16 21:39:27 --> Loader Class Initialized
DEBUG - 2016-02-16 21:39:28 --> Helper loaded: url_helper
DEBUG - 2016-02-16 21:39:28 --> Helper loaded: form_helper
DEBUG - 2016-02-16 21:39:28 --> Database Driver Class Initialized
DEBUG - 2016-02-16 21:39:28 --> Session Class Initialized
DEBUG - 2016-02-16 21:39:28 --> Helper loaded: string_helper
ERROR - 2016-02-16 21:39:28 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-16 21:39:28 --> Session routines successfully run
DEBUG - 2016-02-16 21:39:28 --> Form Validation Class Initialized
DEBUG - 2016-02-16 21:39:28 --> Pagination Class Initialized
DEBUG - 2016-02-16 21:39:28 --> Encrypt Class Initialized
DEBUG - 2016-02-16 21:39:28 --> Email Class Initialized
DEBUG - 2016-02-16 21:39:28 --> Controller Class Initialized
DEBUG - 2016-02-16 21:39:28 --> Auth MX_Controller Initialized
DEBUG - 2016-02-16 21:39:28 --> Model Class Initialized
DEBUG - 2016-02-16 21:39:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-16 21:39:28 --> Model Class Initialized
DEBUG - 2016-02-16 21:39:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-16 21:39:28 --> Model Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Config Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Hooks Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Utf8 Class Initialized
DEBUG - 2016-02-16 21:39:29 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 21:39:29 --> URI Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Router Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Output Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Security Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Input Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-16 21:39:29 --> Language Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Language Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Config Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Loader Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Helper loaded: url_helper
DEBUG - 2016-02-16 21:39:29 --> Helper loaded: form_helper
DEBUG - 2016-02-16 21:39:29 --> Database Driver Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Session Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Helper loaded: string_helper
DEBUG - 2016-02-16 21:39:29 --> Session routines successfully run
DEBUG - 2016-02-16 21:39:29 --> Form Validation Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Pagination Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Encrypt Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Email Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Controller Class Initialized
DEBUG - 2016-02-16 21:39:29 --> Auth MX_Controller Initialized
DEBUG - 2016-02-16 21:39:29 --> Model Class Initialized
DEBUG - 2016-02-16 21:39:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-16 21:39:29 --> Model Class Initialized
DEBUG - 2016-02-16 21:39:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-16 21:39:29 --> Model Class Initialized
DEBUG - 2016-02-16 21:39:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-16 21:39:29 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-16 21:39:29 --> Final output sent to browser
DEBUG - 2016-02-16 21:39:29 --> Total execution time: 0.5703
DEBUG - 2016-02-16 21:39:30 --> Config Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Hooks Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Utf8 Class Initialized
DEBUG - 2016-02-16 21:39:30 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 21:39:30 --> URI Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Router Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Config Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Hooks Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Utf8 Class Initialized
DEBUG - 2016-02-16 21:39:30 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 21:39:30 --> URI Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Router Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Config Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Hooks Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Utf8 Class Initialized
DEBUG - 2016-02-16 21:39:30 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 21:39:30 --> URI Class Initialized
DEBUG - 2016-02-16 21:39:30 --> Router Class Initialized
DEBUG - 2016-02-16 21:39:31 --> Config Class Initialized
DEBUG - 2016-02-16 21:39:31 --> Hooks Class Initialized
DEBUG - 2016-02-16 21:39:31 --> Utf8 Class Initialized
DEBUG - 2016-02-16 21:39:31 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 21:39:31 --> URI Class Initialized
DEBUG - 2016-02-16 21:39:31 --> Router Class Initialized
ERROR - 2016-02-16 21:39:31 --> 404 Page Not Found --> 
ERROR - 2016-02-16 21:39:31 --> 404 Page Not Found --> 
ERROR - 2016-02-16 21:39:31 --> 404 Page Not Found --> 
ERROR - 2016-02-16 21:39:32 --> 404 Page Not Found --> 
DEBUG - 2016-02-16 22:05:15 --> Config Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Hooks Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Utf8 Class Initialized
DEBUG - 2016-02-16 22:05:15 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 22:05:15 --> URI Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Router Class Initialized
DEBUG - 2016-02-16 22:05:15 --> No URI present. Default controller set.
DEBUG - 2016-02-16 22:05:15 --> Output Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Security Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Input Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-16 22:05:15 --> Language Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Language Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Config Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Loader Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Helper loaded: url_helper
DEBUG - 2016-02-16 22:05:15 --> Helper loaded: form_helper
DEBUG - 2016-02-16 22:05:15 --> Database Driver Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Session Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Helper loaded: string_helper
ERROR - 2016-02-16 22:05:15 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-16 22:05:15 --> Session routines successfully run
DEBUG - 2016-02-16 22:05:15 --> Form Validation Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Pagination Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Encrypt Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Email Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Controller Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Auth MX_Controller Initialized
DEBUG - 2016-02-16 22:05:15 --> Model Class Initialized
DEBUG - 2016-02-16 22:05:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-16 22:05:15 --> Model Class Initialized
DEBUG - 2016-02-16 22:05:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-16 22:05:15 --> Model Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Config Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Hooks Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Utf8 Class Initialized
DEBUG - 2016-02-16 22:05:15 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 22:05:15 --> URI Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Router Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Output Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Security Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Input Class Initialized
DEBUG - 2016-02-16 22:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-16 22:05:16 --> Language Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Language Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Config Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Loader Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Helper loaded: url_helper
DEBUG - 2016-02-16 22:05:16 --> Helper loaded: form_helper
DEBUG - 2016-02-16 22:05:16 --> Database Driver Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Session Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Helper loaded: string_helper
DEBUG - 2016-02-16 22:05:16 --> Session routines successfully run
DEBUG - 2016-02-16 22:05:16 --> Form Validation Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Pagination Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Encrypt Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Email Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Controller Class Initialized
DEBUG - 2016-02-16 22:05:16 --> Auth MX_Controller Initialized
DEBUG - 2016-02-16 22:05:16 --> Model Class Initialized
DEBUG - 2016-02-16 22:05:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-16 22:05:16 --> Model Class Initialized
DEBUG - 2016-02-16 22:05:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-16 22:05:16 --> Model Class Initialized
DEBUG - 2016-02-16 22:05:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-16 22:05:16 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-16 22:05:16 --> Final output sent to browser
DEBUG - 2016-02-16 22:05:16 --> Total execution time: 0.1407
DEBUG - 2016-02-16 22:05:17 --> Config Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Hooks Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Utf8 Class Initialized
DEBUG - 2016-02-16 22:05:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 22:05:17 --> URI Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Router Class Initialized
ERROR - 2016-02-16 22:05:17 --> 404 Page Not Found --> 
DEBUG - 2016-02-16 22:05:17 --> Config Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Hooks Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Utf8 Class Initialized
DEBUG - 2016-02-16 22:05:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 22:05:17 --> URI Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Router Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Config Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Hooks Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Utf8 Class Initialized
DEBUG - 2016-02-16 22:05:17 --> UTF-8 Support Enabled
ERROR - 2016-02-16 22:05:17 --> 404 Page Not Found --> 
DEBUG - 2016-02-16 22:05:17 --> Config Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Hooks Class Initialized
DEBUG - 2016-02-16 22:05:17 --> URI Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Utf8 Class Initialized
DEBUG - 2016-02-16 22:05:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-16 22:05:17 --> URI Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Router Class Initialized
DEBUG - 2016-02-16 22:05:17 --> Router Class Initialized
ERROR - 2016-02-16 22:05:17 --> 404 Page Not Found --> 
ERROR - 2016-02-16 22:05:17 --> 404 Page Not Found --> 
