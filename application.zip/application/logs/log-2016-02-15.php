<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-15 15:13:50 --> Config Class Initialized
DEBUG - 2016-02-15 15:13:50 --> Hooks Class Initialized
DEBUG - 2016-02-15 15:13:50 --> Utf8 Class Initialized
DEBUG - 2016-02-15 15:13:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 15:13:50 --> URI Class Initialized
DEBUG - 2016-02-15 15:13:51 --> Router Class Initialized
DEBUG - 2016-02-15 15:13:51 --> No URI present. Default controller set.
DEBUG - 2016-02-15 15:13:51 --> Output Class Initialized
DEBUG - 2016-02-15 15:13:51 --> Security Class Initialized
DEBUG - 2016-02-15 15:13:52 --> Input Class Initialized
DEBUG - 2016-02-15 15:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 15:13:52 --> Language Class Initialized
DEBUG - 2016-02-15 15:13:53 --> Language Class Initialized
DEBUG - 2016-02-15 15:13:53 --> Config Class Initialized
DEBUG - 2016-02-15 15:13:53 --> Loader Class Initialized
DEBUG - 2016-02-15 15:13:53 --> Helper loaded: url_helper
DEBUG - 2016-02-15 15:13:54 --> Helper loaded: form_helper
DEBUG - 2016-02-15 15:13:54 --> Database Driver Class Initialized
DEBUG - 2016-02-15 15:14:00 --> Session Class Initialized
DEBUG - 2016-02-15 15:14:01 --> Helper loaded: string_helper
DEBUG - 2016-02-15 15:14:01 --> A session cookie was not found.
DEBUG - 2016-02-15 15:14:01 --> Session routines successfully run
DEBUG - 2016-02-15 15:14:01 --> Form Validation Class Initialized
DEBUG - 2016-02-15 15:14:01 --> Pagination Class Initialized
DEBUG - 2016-02-15 15:14:02 --> Encrypt Class Initialized
DEBUG - 2016-02-15 15:14:02 --> Email Class Initialized
DEBUG - 2016-02-15 15:14:02 --> Controller Class Initialized
DEBUG - 2016-02-15 15:14:02 --> Auth MX_Controller Initialized
DEBUG - 2016-02-15 15:14:02 --> Model Class Initialized
DEBUG - 2016-02-15 15:14:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-15 15:14:02 --> Model Class Initialized
DEBUG - 2016-02-15 15:14:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-15 15:14:02 --> Model Class Initialized
DEBUG - 2016-02-15 16:16:32 --> Config Class Initialized
DEBUG - 2016-02-15 16:16:32 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:16:33 --> Utf8 Class Initialized
DEBUG - 2016-02-15 16:16:33 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 16:16:33 --> URI Class Initialized
DEBUG - 2016-02-15 16:16:34 --> Router Class Initialized
DEBUG - 2016-02-15 16:16:34 --> No URI present. Default controller set.
DEBUG - 2016-02-15 16:16:35 --> Output Class Initialized
DEBUG - 2016-02-15 16:16:35 --> Security Class Initialized
DEBUG - 2016-02-15 16:16:35 --> Input Class Initialized
DEBUG - 2016-02-15 16:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 16:16:35 --> Language Class Initialized
DEBUG - 2016-02-15 16:16:35 --> Language Class Initialized
DEBUG - 2016-02-15 16:16:35 --> Config Class Initialized
DEBUG - 2016-02-15 16:16:35 --> Loader Class Initialized
DEBUG - 2016-02-15 16:16:35 --> Helper loaded: url_helper
DEBUG - 2016-02-15 16:16:35 --> Helper loaded: form_helper
DEBUG - 2016-02-15 16:16:36 --> Database Driver Class Initialized
DEBUG - 2016-02-15 16:16:36 --> Session Class Initialized
DEBUG - 2016-02-15 16:16:36 --> Helper loaded: string_helper
ERROR - 2016-02-15 16:16:36 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-15 16:16:36 --> Session routines successfully run
DEBUG - 2016-02-15 16:16:36 --> Form Validation Class Initialized
DEBUG - 2016-02-15 16:16:37 --> Pagination Class Initialized
DEBUG - 2016-02-15 16:16:37 --> Encrypt Class Initialized
DEBUG - 2016-02-15 16:16:37 --> Email Class Initialized
DEBUG - 2016-02-15 16:16:37 --> Controller Class Initialized
DEBUG - 2016-02-15 16:16:37 --> Auth MX_Controller Initialized
DEBUG - 2016-02-15 16:16:37 --> Model Class Initialized
DEBUG - 2016-02-15 16:16:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-15 16:16:37 --> Model Class Initialized
DEBUG - 2016-02-15 16:16:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-15 16:16:37 --> Model Class Initialized
