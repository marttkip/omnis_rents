<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-05 14:10:09 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:10:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:10:09 --> URI Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Router Class Initialized
DEBUG - 2015-10-05 14:10:09 --> No URI present. Default controller set.
DEBUG - 2015-10-05 14:10:09 --> Output Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Security Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Input Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:10:09 --> Language Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Language Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Loader Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:10:09 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:10:09 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:10:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:10:09 --> Session Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:10:09 --> A session cookie was not found.
DEBUG - 2015-10-05 14:10:09 --> Session routines successfully run
DEBUG - 2015-10-05 14:10:09 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Email Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Controller Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Auth MX_Controller Initialized
DEBUG - 2015-10-05 14:10:09 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:10:09 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:10:09 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:10:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:10:09 --> URI Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Router Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Output Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Security Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Input Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:10:09 --> Language Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Language Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Loader Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:10:09 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:10:09 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:10:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:10:09 --> Session Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:10:09 --> Session routines successfully run
DEBUG - 2015-10-05 14:10:09 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Email Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Controller Class Initialized
DEBUG - 2015-10-05 14:10:09 --> Auth MX_Controller Initialized
DEBUG - 2015-10-05 14:10:09 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:10:09 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:10:09 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:10:09 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-10-05 14:10:09 --> Final output sent to browser
DEBUG - 2015-10-05 14:10:09 --> Total execution time: 0.1793
DEBUG - 2015-10-05 14:10:10 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:10 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:10 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:10:10 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:10:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:10:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:10:11 --> URI Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Router Class Initialized
DEBUG - 2015-10-05 14:10:11 --> URI Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Router Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:10:11 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:10:11 --> URI Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:10:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:10:11 --> URI Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Router Class Initialized
DEBUG - 2015-10-05 14:10:11 --> Router Class Initialized
ERROR - 2015-10-05 14:10:11 --> 404 Page Not Found --> 
ERROR - 2015-10-05 14:10:11 --> 404 Page Not Found --> 
ERROR - 2015-10-05 14:10:11 --> 404 Page Not Found --> 
ERROR - 2015-10-05 14:10:11 --> 404 Page Not Found --> 
DEBUG - 2015-10-05 14:10:35 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:10:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:10:35 --> URI Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Router Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Output Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Security Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Input Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:10:35 --> Language Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Language Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Loader Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:10:35 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:10:35 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:10:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:10:35 --> Session Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:10:35 --> Session routines successfully run
DEBUG - 2015-10-05 14:10:35 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Email Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Controller Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Auth MX_Controller Initialized
DEBUG - 2015-10-05 14:10:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:10:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:10:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-05 14:10:35 --> XSS Filtering completed
DEBUG - 2015-10-05 14:10:35 --> Unable to find validation rule: exists
DEBUG - 2015-10-05 14:10:35 --> XSS Filtering completed
DEBUG - 2015-10-05 14:10:36 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:10:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:10:36 --> URI Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Router Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Output Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Security Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Input Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:10:36 --> Language Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Language Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Config Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Loader Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:10:36 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:10:36 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:10:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:10:36 --> Session Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:10:36 --> Session routines successfully run
DEBUG - 2015-10-05 14:10:36 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Email Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Controller Class Initialized
DEBUG - 2015-10-05 14:10:36 --> Admin MX_Controller Initialized
DEBUG - 2015-10-05 14:10:36 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:10:36 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:10:36 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:10:36 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:10:36 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:10:36 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:10:36 --> Model Class Initialized
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:10:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:10:36 --> Final output sent to browser
DEBUG - 2015-10-05 14:10:36 --> Total execution time: 0.2394
DEBUG - 2015-10-05 14:11:25 --> Config Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:11:25 --> URI Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Router Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Output Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Security Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Input Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:11:25 --> Language Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Language Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Config Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Loader Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:11:25 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:11:25 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:11:25 --> Session Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:11:25 --> Session routines successfully run
DEBUG - 2015-10-05 14:11:25 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Email Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Controller Class Initialized
DEBUG - 2015-10-05 14:11:25 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 14:11:25 --> Model Class Initialized
DEBUG - 2015-10-05 14:11:25 --> DB Transaction Failure
ERROR - 2015-10-05 14:11:25 --> Query error: Table 'mfi.loans_plan' doesn't exist
DEBUG - 2015-10-05 14:11:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-05 14:18:19 --> Config Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:18:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:18:19 --> URI Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Router Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Output Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Security Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Input Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:18:19 --> Language Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Language Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Config Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Loader Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:18:19 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:18:19 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:18:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:18:19 --> Session Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:18:19 --> Session routines successfully run
DEBUG - 2015-10-05 14:18:19 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Email Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Controller Class Initialized
DEBUG - 2015-10-05 14:18:19 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 14:18:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:18:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:18:19 --> Final output sent to browser
DEBUG - 2015-10-05 14:18:19 --> Total execution time: 0.2766
DEBUG - 2015-10-05 14:24:07 --> Config Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:24:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:24:07 --> URI Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Router Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Output Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Security Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Input Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:24:07 --> Language Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Language Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Config Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Loader Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:24:07 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:24:07 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:24:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:24:07 --> Session Class Initialized
DEBUG - 2015-10-05 14:24:07 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:24:07 --> Session routines successfully run
DEBUG - 2015-10-05 14:24:08 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:24:08 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:24:08 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:24:08 --> Email Class Initialized
DEBUG - 2015-10-05 14:24:08 --> Controller Class Initialized
DEBUG - 2015-10-05 14:24:08 --> Individual MX_Controller Initialized
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 14:24:08 --> Model Class Initialized
DEBUG - 2015-10-05 14:24:08 --> Image Lib Class Initialized
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:24:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:24:08 --> Final output sent to browser
DEBUG - 2015-10-05 14:24:08 --> Total execution time: 0.2665
DEBUG - 2015-10-05 14:27:20 --> Config Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:27:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:27:20 --> URI Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Router Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Output Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Security Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Input Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:27:20 --> Language Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Language Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Config Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Loader Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:27:20 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:27:20 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:27:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:27:20 --> Session Class Initialized
DEBUG - 2015-10-05 14:27:20 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:27:20 --> Session routines successfully run
DEBUG - 2015-10-05 14:27:20 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:27:21 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:27:21 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:27:21 --> Email Class Initialized
DEBUG - 2015-10-05 14:27:21 --> Controller Class Initialized
DEBUG - 2015-10-05 14:27:21 --> Admin MX_Controller Initialized
DEBUG - 2015-10-05 14:27:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:27:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:27:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:27:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:27:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:27:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:27:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/admin/views/configuration.php
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:27:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:27:21 --> Final output sent to browser
DEBUG - 2015-10-05 14:27:21 --> Total execution time: 0.1966
DEBUG - 2015-10-05 14:27:24 --> Config Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:27:24 --> URI Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Router Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Output Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Security Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Input Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:27:24 --> Language Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Language Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Config Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Loader Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:27:24 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:27:24 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:27:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:27:24 --> Session Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:27:24 --> Session routines successfully run
DEBUG - 2015-10-05 14:27:24 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Email Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Controller Class Initialized
DEBUG - 2015-10-05 14:27:24 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:27:24 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:27:24 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:27:24 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:27:24 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:27:24 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:27:24 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:27:24 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:27:24 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:27:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:27:24 --> Final output sent to browser
DEBUG - 2015-10-05 14:27:24 --> Total execution time: 0.2493
DEBUG - 2015-10-05 14:27:27 --> Config Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:27:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:27:27 --> URI Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Router Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Output Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Security Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Input Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:27:27 --> Language Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Language Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Config Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Loader Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:27:27 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:27:27 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:27:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:27:27 --> Session Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:27:27 --> Session routines successfully run
DEBUG - 2015-10-05 14:27:27 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Email Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Controller Class Initialized
DEBUG - 2015-10-05 14:27:27 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:27:27 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:27:27 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:27:27 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:27:27 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:27:27 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:27:27 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:27:27 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:27:27 --> Model Class Initialized
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:27:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:27:27 --> Final output sent to browser
DEBUG - 2015-10-05 14:27:27 --> Total execution time: 0.2059
DEBUG - 2015-10-05 14:30:01 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:30:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:30:01 --> URI Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Router Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Output Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Security Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Input Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:30:01 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Loader Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:30:01 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:30:01 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:30:01 --> Session Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:30:01 --> Session routines successfully run
DEBUG - 2015-10-05 14:30:01 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Email Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Controller Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-05 14:30:01 --> XSS Filtering completed
DEBUG - 2015-10-05 14:30:01 --> XSS Filtering completed
DEBUG - 2015-10-05 14:30:01 --> XSS Filtering completed
DEBUG - 2015-10-05 14:30:01 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:30:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:30:01 --> URI Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Router Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Output Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Security Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Input Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:30:01 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Loader Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:30:01 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:30:01 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:30:01 --> Session Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:30:01 --> Session routines successfully run
DEBUG - 2015-10-05 14:30:01 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Email Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Controller Class Initialized
DEBUG - 2015-10-05 14:30:01 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:30:01 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:30:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:30:01 --> Final output sent to browser
DEBUG - 2015-10-05 14:30:01 --> Total execution time: 0.2451
DEBUG - 2015-10-05 14:30:07 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:30:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:30:07 --> URI Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Router Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Output Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Security Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Input Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:30:07 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Loader Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:30:07 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:30:07 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:30:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:30:07 --> Session Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:30:07 --> Session routines successfully run
DEBUG - 2015-10-05 14:30:07 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Email Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Controller Class Initialized
DEBUG - 2015-10-05 14:30:07 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 14:30:07 --> Model Class Initialized
ERROR - 2015-10-05 14:30:07 --> 404 Page Not Found --> microfinance/individual-payments
DEBUG - 2015-10-05 14:30:18 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:30:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:30:18 --> URI Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Router Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Output Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Security Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Input Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:30:18 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Loader Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:30:18 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:30:18 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:30:18 --> Session Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:30:18 --> Session routines successfully run
DEBUG - 2015-10-05 14:30:18 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Email Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Controller Class Initialized
DEBUG - 2015-10-05 14:30:18 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:30:18 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:30:18 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:30:18 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:30:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:30:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:30:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:30:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:30:19 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:30:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:30:19 --> Final output sent to browser
DEBUG - 2015-10-05 14:30:19 --> Total execution time: 0.2823
DEBUG - 2015-10-05 14:30:21 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:30:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:30:21 --> URI Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Router Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Output Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Security Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Input Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:30:21 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Loader Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:30:21 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:30:21 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:30:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:30:21 --> Session Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:30:21 --> Session routines successfully run
DEBUG - 2015-10-05 14:30:21 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Email Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Controller Class Initialized
DEBUG - 2015-10-05 14:30:21 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:30:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:30:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:30:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:30:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:30:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:30:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:30:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:30:21 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:30:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:30:21 --> Final output sent to browser
DEBUG - 2015-10-05 14:30:21 --> Total execution time: 0.2047
DEBUG - 2015-10-05 14:30:28 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:28 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:30:28 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:30:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:30:28 --> URI Class Initialized
DEBUG - 2015-10-05 14:30:28 --> Router Class Initialized
DEBUG - 2015-10-05 14:30:28 --> Output Class Initialized
DEBUG - 2015-10-05 14:30:28 --> Security Class Initialized
DEBUG - 2015-10-05 14:30:28 --> Input Class Initialized
DEBUG - 2015-10-05 14:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:30:29 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Loader Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:30:29 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:30:29 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:30:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:30:29 --> Session Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:30:29 --> Session routines successfully run
DEBUG - 2015-10-05 14:30:29 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Email Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Controller Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-05 14:30:29 --> XSS Filtering completed
DEBUG - 2015-10-05 14:30:29 --> XSS Filtering completed
DEBUG - 2015-10-05 14:30:29 --> XSS Filtering completed
DEBUG - 2015-10-05 14:30:29 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:30:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:30:29 --> URI Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Router Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Output Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Security Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Input Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:30:29 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Language Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Config Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Loader Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:30:29 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:30:29 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:30:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:30:29 --> Session Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:30:29 --> Session routines successfully run
DEBUG - 2015-10-05 14:30:29 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Email Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Controller Class Initialized
DEBUG - 2015-10-05 14:30:29 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:30:29 --> Model Class Initialized
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:30:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:30:29 --> Final output sent to browser
DEBUG - 2015-10-05 14:30:29 --> Total execution time: 0.2597
DEBUG - 2015-10-05 14:34:35 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:34:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:34:35 --> URI Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Router Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Output Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Security Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Input Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:34:35 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Loader Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:34:35 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:34:35 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:34:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:34:35 --> Session Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:34:35 --> Session routines successfully run
DEBUG - 2015-10-05 14:34:35 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Email Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Controller Class Initialized
DEBUG - 2015-10-05 14:34:35 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:34:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:34:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:34:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:34:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:34:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:34:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:34:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:34:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:34:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:34:35 --> Final output sent to browser
DEBUG - 2015-10-05 14:34:35 --> Total execution time: 0.2237
DEBUG - 2015-10-05 14:34:41 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:34:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:34:41 --> URI Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Router Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Output Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Security Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Input Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:34:41 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Loader Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:34:41 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:34:41 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:34:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:34:41 --> Session Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:34:41 --> Session routines successfully run
DEBUG - 2015-10-05 14:34:41 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Email Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Controller Class Initialized
DEBUG - 2015-10-05 14:34:41 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:34:41 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:34:41 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:34:41 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:34:41 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:34:41 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:34:41 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:34:41 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:34:41 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:34:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:34:41 --> Final output sent to browser
DEBUG - 2015-10-05 14:34:41 --> Total execution time: 0.2049
DEBUG - 2015-10-05 14:34:46 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:34:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:34:46 --> URI Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Router Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Output Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Security Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Input Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:34:46 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Loader Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:34:46 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:34:46 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:34:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:34:46 --> Session Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:34:46 --> Session routines successfully run
DEBUG - 2015-10-05 14:34:46 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Email Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Controller Class Initialized
DEBUG - 2015-10-05 14:34:46 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:34:46 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:34:46 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:34:46 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:34:46 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:34:46 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:34:46 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:34:46 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:34:46 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:34:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:34:46 --> Final output sent to browser
DEBUG - 2015-10-05 14:34:46 --> Total execution time: 0.2059
DEBUG - 2015-10-05 14:34:51 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:34:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:34:51 --> URI Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Router Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Output Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Security Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Input Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:34:51 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Loader Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:34:51 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:34:51 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:34:51 --> Session Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:34:51 --> Session routines successfully run
DEBUG - 2015-10-05 14:34:51 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Email Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Controller Class Initialized
DEBUG - 2015-10-05 14:34:51 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:34:51 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:34:51 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:34:51 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:34:51 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:34:51 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:34:51 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:34:51 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:34:51 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:52 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-10-05 14:34:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:34:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:34:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:34:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:34:52 --> Final output sent to browser
DEBUG - 2015-10-05 14:34:52 --> Total execution time: 0.2018
DEBUG - 2015-10-05 14:34:56 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:34:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:34:56 --> URI Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Router Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Output Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Security Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Input Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:34:56 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Loader Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:34:56 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:34:56 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:34:56 --> Session Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:34:56 --> Session routines successfully run
DEBUG - 2015-10-05 14:34:56 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Email Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Controller Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-05 14:34:56 --> XSS Filtering completed
DEBUG - 2015-10-05 14:34:56 --> XSS Filtering completed
DEBUG - 2015-10-05 14:34:56 --> XSS Filtering completed
DEBUG - 2015-10-05 14:34:56 --> XSS Filtering completed
DEBUG - 2015-10-05 14:34:56 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:34:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:34:56 --> URI Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Router Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Output Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Security Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Input Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:34:56 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Language Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Config Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Loader Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:34:56 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:34:56 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:34:56 --> Session Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:34:56 --> Session routines successfully run
DEBUG - 2015-10-05 14:34:56 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Email Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Controller Class Initialized
DEBUG - 2015-10-05 14:34:56 --> Sections MX_Controller Initialized
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:34:56 --> Model Class Initialized
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-05 14:34:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-05 14:34:56 --> Final output sent to browser
DEBUG - 2015-10-05 14:34:56 --> Total execution time: 0.2075
DEBUG - 2015-10-05 14:35:03 --> Config Class Initialized
DEBUG - 2015-10-05 14:35:03 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:35:03 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:35:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:35:03 --> URI Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Router Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Output Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Security Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Input Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:35:04 --> Language Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Language Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Config Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Loader Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:35:04 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:35:04 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:35:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:35:04 --> Session Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:35:04 --> Session routines successfully run
DEBUG - 2015-10-05 14:35:04 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Email Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Controller Class Initialized
DEBUG - 2015-10-05 14:35:04 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
DEBUG - 2015-10-05 14:35:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 14:35:04 --> Model Class Initialized
ERROR - 2015-10-05 14:35:04 --> 404 Page Not Found --> microfinance/individual-payments
DEBUG - 2015-10-05 14:41:07 --> Config Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:41:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:41:07 --> URI Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Router Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Output Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Security Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Input Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:41:07 --> Language Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Language Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Config Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Loader Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:41:07 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:41:07 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:41:07 --> Session Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:41:07 --> Session routines successfully run
DEBUG - 2015-10-05 14:41:07 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Email Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Controller Class Initialized
DEBUG - 2015-10-05 14:41:07 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
DEBUG - 2015-10-05 14:41:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 14:41:07 --> Model Class Initialized
ERROR - 2015-10-05 14:41:07 --> 404 Page Not Found --> microfinance/payments
DEBUG - 2015-10-05 14:52:55 --> Config Class Initialized
DEBUG - 2015-10-05 14:52:55 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:52:55 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:52:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:52:55 --> URI Class Initialized
DEBUG - 2015-10-05 14:52:55 --> Router Class Initialized
DEBUG - 2015-10-05 14:52:55 --> Output Class Initialized
DEBUG - 2015-10-05 14:52:55 --> Security Class Initialized
DEBUG - 2015-10-05 14:52:55 --> Input Class Initialized
DEBUG - 2015-10-05 14:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:52:55 --> Language Class Initialized
DEBUG - 2015-10-05 14:53:15 --> Config Class Initialized
DEBUG - 2015-10-05 14:53:15 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:53:15 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:53:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:53:15 --> URI Class Initialized
DEBUG - 2015-10-05 14:53:15 --> Router Class Initialized
DEBUG - 2015-10-05 14:53:16 --> Output Class Initialized
DEBUG - 2015-10-05 14:53:16 --> Security Class Initialized
DEBUG - 2015-10-05 14:53:16 --> Input Class Initialized
DEBUG - 2015-10-05 14:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:53:16 --> Language Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Config Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:53:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:53:35 --> URI Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Router Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Output Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Security Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Input Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:53:35 --> Language Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Language Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Config Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Loader Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:53:35 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:53:35 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:53:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:53:35 --> Session Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:53:35 --> Session routines successfully run
DEBUG - 2015-10-05 14:53:35 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Email Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Controller Class Initialized
DEBUG - 2015-10-05 14:53:35 --> Payments MX_Controller Initialized
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
DEBUG - 2015-10-05 14:53:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 14:53:35 --> Model Class Initialized
ERROR - 2015-10-05 14:53:35 --> 404 Page Not Found --> payments/individual_payments
DEBUG - 2015-10-05 14:58:38 --> Config Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Hooks Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Utf8 Class Initialized
DEBUG - 2015-10-05 14:58:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 14:58:38 --> URI Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Router Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Output Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Security Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Input Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 14:58:38 --> Language Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Language Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Config Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Loader Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Helper loaded: url_helper
DEBUG - 2015-10-05 14:58:38 --> Helper loaded: form_helper
DEBUG - 2015-10-05 14:58:38 --> Database Driver Class Initialized
ERROR - 2015-10-05 14:58:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 14:58:38 --> Session Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Helper loaded: string_helper
DEBUG - 2015-10-05 14:58:38 --> Session routines successfully run
DEBUG - 2015-10-05 14:58:38 --> Form Validation Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Pagination Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Encrypt Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Email Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Controller Class Initialized
DEBUG - 2015-10-05 14:58:38 --> Payments MX_Controller Initialized
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
DEBUG - 2015-10-05 14:58:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 14:58:38 --> Model Class Initialized
ERROR - 2015-10-05 14:58:38 --> 404 Page Not Found --> payments/individual_payments
DEBUG - 2015-10-05 15:07:15 --> Config Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Hooks Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Utf8 Class Initialized
DEBUG - 2015-10-05 15:07:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 15:07:15 --> URI Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Router Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Output Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Security Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Input Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 15:07:15 --> Language Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Language Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Config Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Loader Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Helper loaded: url_helper
DEBUG - 2015-10-05 15:07:15 --> Helper loaded: form_helper
DEBUG - 2015-10-05 15:07:15 --> Database Driver Class Initialized
ERROR - 2015-10-05 15:07:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 15:07:15 --> Session Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Helper loaded: string_helper
DEBUG - 2015-10-05 15:07:15 --> Session routines successfully run
DEBUG - 2015-10-05 15:07:15 --> Form Validation Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Pagination Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Encrypt Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Email Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Controller Class Initialized
DEBUG - 2015-10-05 15:07:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 15:07:15 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Config Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Hooks Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Utf8 Class Initialized
DEBUG - 2015-10-05 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 15:07:25 --> URI Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Router Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Output Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Security Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Input Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 15:07:25 --> Language Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Language Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Config Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Loader Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Helper loaded: url_helper
DEBUG - 2015-10-05 15:07:25 --> Helper loaded: form_helper
DEBUG - 2015-10-05 15:07:25 --> Database Driver Class Initialized
ERROR - 2015-10-05 15:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 15:07:25 --> Session Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Helper loaded: string_helper
DEBUG - 2015-10-05 15:07:25 --> Session routines successfully run
DEBUG - 2015-10-05 15:07:25 --> Form Validation Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Pagination Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Encrypt Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Email Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Controller Class Initialized
DEBUG - 2015-10-05 15:07:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
DEBUG - 2015-10-05 15:07:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-05 15:07:25 --> Model Class Initialized
ERROR - 2015-10-05 15:07:25 --> 404 Page Not Found --> payments/individual_payments
DEBUG - 2015-10-05 15:13:10 --> Config Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Hooks Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Utf8 Class Initialized
DEBUG - 2015-10-05 15:13:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 15:13:10 --> URI Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Router Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Output Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Security Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Input Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 15:13:10 --> Language Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Language Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Config Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Loader Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Helper loaded: url_helper
DEBUG - 2015-10-05 15:13:10 --> Helper loaded: form_helper
DEBUG - 2015-10-05 15:13:10 --> Database Driver Class Initialized
ERROR - 2015-10-05 15:13:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 15:13:10 --> Session Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Helper loaded: string_helper
DEBUG - 2015-10-05 15:13:10 --> Session routines successfully run
DEBUG - 2015-10-05 15:13:10 --> Form Validation Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Pagination Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Encrypt Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Email Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Controller Class Initialized
DEBUG - 2015-10-05 15:13:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
DEBUG - 2015-10-05 15:13:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-05 15:13:10 --> Model Class Initialized
ERROR - 2015-10-05 15:13:10 --> 404 Page Not Found --> payments/individual_payments
DEBUG - 2015-10-05 15:19:37 --> Config Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Hooks Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Utf8 Class Initialized
DEBUG - 2015-10-05 15:19:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 15:19:37 --> URI Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Router Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Output Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Security Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Input Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 15:19:37 --> Language Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Language Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Config Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Loader Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Helper loaded: url_helper
DEBUG - 2015-10-05 15:19:37 --> Helper loaded: form_helper
DEBUG - 2015-10-05 15:19:37 --> Database Driver Class Initialized
ERROR - 2015-10-05 15:19:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 15:19:37 --> Session Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Helper loaded: string_helper
DEBUG - 2015-10-05 15:19:37 --> Session routines successfully run
DEBUG - 2015-10-05 15:19:37 --> Form Validation Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Pagination Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Encrypt Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Email Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Controller Class Initialized
DEBUG - 2015-10-05 15:19:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-05 15:19:37 --> Model Class Initialized
DEBUG - 2015-10-05 15:19:37 --> DB Transaction Failure
ERROR - 2015-10-05 15:19:37 --> Query error: Unknown column 'id' in 'order clause'
DEBUG - 2015-10-05 15:19:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-05 15:21:55 --> Config Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Hooks Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Utf8 Class Initialized
DEBUG - 2015-10-05 15:21:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-05 15:21:55 --> URI Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Router Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Output Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Security Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Input Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-05 15:21:55 --> Language Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Language Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Config Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Loader Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Helper loaded: url_helper
DEBUG - 2015-10-05 15:21:55 --> Helper loaded: form_helper
DEBUG - 2015-10-05 15:21:55 --> Database Driver Class Initialized
ERROR - 2015-10-05 15:21:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-05 15:21:55 --> Session Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Helper loaded: string_helper
DEBUG - 2015-10-05 15:21:55 --> Session routines successfully run
DEBUG - 2015-10-05 15:21:55 --> Form Validation Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Pagination Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Encrypt Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Email Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Controller Class Initialized
DEBUG - 2015-10-05 15:21:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-05 15:21:55 --> Model Class Initialized
DEBUG - 2015-10-05 15:21:55 --> DB Transaction Failure
ERROR - 2015-10-05 15:21:55 --> Query error: Unknown table 'loans_plan'
DEBUG - 2015-10-05 15:21:55 --> Language file loaded: language/english/db_lang.php
