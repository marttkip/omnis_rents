<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-06 13:38:13 --> Config Class Initialized
DEBUG - 2015-12-06 13:38:13 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:38:13 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:38:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:38:13 --> URI Class Initialized
DEBUG - 2015-12-06 13:38:14 --> Router Class Initialized
DEBUG - 2015-12-06 13:39:32 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:32 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:32 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:32 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:32 --> Router Class Initialized
DEBUG - 2015-12-06 13:39:32 --> Output Class Initialized
DEBUG - 2015-12-06 13:39:32 --> Security Class Initialized
DEBUG - 2015-12-06 13:39:33 --> Input Class Initialized
DEBUG - 2015-12-06 13:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 13:39:33 --> Language Class Initialized
DEBUG - 2015-12-06 13:39:33 --> Language Class Initialized
DEBUG - 2015-12-06 13:39:33 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:33 --> Loader Class Initialized
DEBUG - 2015-12-06 13:39:33 --> Helper loaded: url_helper
DEBUG - 2015-12-06 13:39:33 --> Helper loaded: form_helper
DEBUG - 2015-12-06 13:39:33 --> Database Driver Class Initialized
DEBUG - 2015-12-06 13:39:36 --> Session Class Initialized
DEBUG - 2015-12-06 13:39:36 --> Helper loaded: string_helper
DEBUG - 2015-12-06 13:39:36 --> A session cookie was not found.
DEBUG - 2015-12-06 13:39:36 --> Session routines successfully run
DEBUG - 2015-12-06 13:39:36 --> Form Validation Class Initialized
DEBUG - 2015-12-06 13:39:36 --> Pagination Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Encrypt Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Email Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Controller Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Sections MX_Controller Initialized
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:37 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Router Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Output Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Security Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Input Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 13:39:37 --> Language Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Language Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Loader Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Helper loaded: url_helper
DEBUG - 2015-12-06 13:39:37 --> Helper loaded: form_helper
DEBUG - 2015-12-06 13:39:37 --> Database Driver Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Session Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Helper loaded: string_helper
DEBUG - 2015-12-06 13:39:37 --> Session routines successfully run
DEBUG - 2015-12-06 13:39:37 --> Form Validation Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Pagination Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Encrypt Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Email Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Controller Class Initialized
DEBUG - 2015-12-06 13:39:37 --> Auth MX_Controller Initialized
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 13:39:37 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 13:39:38 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-06 13:39:38 --> Final output sent to browser
DEBUG - 2015-12-06 13:39:38 --> Total execution time: 1.0151
DEBUG - 2015-12-06 13:39:42 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:42 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:42 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:42 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:42 --> Router Class Initialized
ERROR - 2015-12-06 13:39:43 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 13:39:43 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:43 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:43 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:43 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:43 --> Router Class Initialized
ERROR - 2015-12-06 13:39:43 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 13:39:43 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:44 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:44 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:44 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:44 --> Router Class Initialized
ERROR - 2015-12-06 13:39:44 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 13:39:44 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:44 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:44 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:44 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:44 --> Router Class Initialized
ERROR - 2015-12-06 13:39:44 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 13:39:51 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:51 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Router Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Output Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Security Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Input Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 13:39:51 --> Language Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Language Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Loader Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Helper loaded: url_helper
DEBUG - 2015-12-06 13:39:51 --> Helper loaded: form_helper
DEBUG - 2015-12-06 13:39:51 --> Database Driver Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Session Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Helper loaded: string_helper
DEBUG - 2015-12-06 13:39:51 --> Session routines successfully run
DEBUG - 2015-12-06 13:39:51 --> Form Validation Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Pagination Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Encrypt Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Email Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Controller Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Auth MX_Controller Initialized
DEBUG - 2015-12-06 13:39:51 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 13:39:51 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 13:39:51 --> Model Class Initialized
DEBUG - 2015-12-06 13:39:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-06 13:39:51 --> XSS Filtering completed
DEBUG - 2015-12-06 13:39:51 --> Unable to find validation rule: exists
DEBUG - 2015-12-06 13:39:51 --> XSS Filtering completed
DEBUG - 2015-12-06 13:39:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 13:39:52 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-06 13:39:52 --> Final output sent to browser
DEBUG - 2015-12-06 13:39:52 --> Total execution time: 0.8877
DEBUG - 2015-12-06 13:39:53 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:53 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Router Class Initialized
ERROR - 2015-12-06 13:39:53 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 13:39:53 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:53 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Router Class Initialized
ERROR - 2015-12-06 13:39:53 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 13:39:53 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:39:53 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Router Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Config Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:39:53 --> UTF-8 Support Enabled
ERROR - 2015-12-06 13:39:53 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 13:39:53 --> URI Class Initialized
DEBUG - 2015-12-06 13:39:53 --> Router Class Initialized
ERROR - 2015-12-06 13:39:53 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 13:40:05 --> Config Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:40:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:40:05 --> URI Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Router Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Output Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Security Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Input Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 13:40:05 --> Language Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Language Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Config Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Loader Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Helper loaded: url_helper
DEBUG - 2015-12-06 13:40:05 --> Helper loaded: form_helper
DEBUG - 2015-12-06 13:40:05 --> Database Driver Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Session Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Helper loaded: string_helper
DEBUG - 2015-12-06 13:40:05 --> Session routines successfully run
DEBUG - 2015-12-06 13:40:05 --> Form Validation Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Pagination Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Encrypt Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Email Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Controller Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Auth MX_Controller Initialized
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-06 13:40:05 --> XSS Filtering completed
DEBUG - 2015-12-06 13:40:05 --> Unable to find validation rule: exists
DEBUG - 2015-12-06 13:40:05 --> XSS Filtering completed
DEBUG - 2015-12-06 13:40:05 --> Config Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Hooks Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Utf8 Class Initialized
DEBUG - 2015-12-06 13:40:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 13:40:05 --> URI Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Router Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Output Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Security Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Input Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 13:40:05 --> Language Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Language Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Config Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Loader Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Helper loaded: url_helper
DEBUG - 2015-12-06 13:40:05 --> Helper loaded: form_helper
DEBUG - 2015-12-06 13:40:05 --> Database Driver Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Session Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Helper loaded: string_helper
DEBUG - 2015-12-06 13:40:05 --> Session routines successfully run
DEBUG - 2015-12-06 13:40:05 --> Form Validation Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Pagination Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Encrypt Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Email Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Controller Class Initialized
DEBUG - 2015-12-06 13:40:05 --> Admin MX_Controller Initialized
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-06 13:40:05 --> Model Class Initialized
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-06 13:40:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 13:40:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-06 13:40:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-06 13:40:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-06 13:40:06 --> Final output sent to browser
DEBUG - 2015-12-06 13:40:06 --> Total execution time: 0.3945
DEBUG - 2015-12-06 14:13:19 --> Config Class Initialized
DEBUG - 2015-12-06 14:13:19 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:13:19 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:13:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:13:19 --> URI Class Initialized
DEBUG - 2015-12-06 14:13:19 --> Router Class Initialized
ERROR - 2015-12-06 14:13:19 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:13:31 --> Config Class Initialized
DEBUG - 2015-12-06 14:13:31 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:13:31 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:13:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:13:31 --> URI Class Initialized
DEBUG - 2015-12-06 14:13:31 --> Router Class Initialized
ERROR - 2015-12-06 14:13:31 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:14:26 --> Config Class Initialized
DEBUG - 2015-12-06 14:14:26 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:14:26 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:14:26 --> URI Class Initialized
DEBUG - 2015-12-06 14:14:26 --> Router Class Initialized
ERROR - 2015-12-06 14:14:26 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:14:28 --> Config Class Initialized
DEBUG - 2015-12-06 14:14:28 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:14:28 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:14:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:14:28 --> URI Class Initialized
DEBUG - 2015-12-06 14:14:28 --> Router Class Initialized
ERROR - 2015-12-06 14:14:28 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:14:29 --> Config Class Initialized
DEBUG - 2015-12-06 14:14:29 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:14:29 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:14:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:14:29 --> URI Class Initialized
DEBUG - 2015-12-06 14:14:29 --> Router Class Initialized
ERROR - 2015-12-06 14:14:29 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:15:51 --> Config Class Initialized
DEBUG - 2015-12-06 14:15:51 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:15:51 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:15:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:15:51 --> URI Class Initialized
DEBUG - 2015-12-06 14:15:51 --> Router Class Initialized
DEBUG - 2015-12-06 14:15:51 --> Output Class Initialized
DEBUG - 2015-12-06 14:15:51 --> Security Class Initialized
DEBUG - 2015-12-06 14:15:51 --> Input Class Initialized
DEBUG - 2015-12-06 14:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:15:51 --> Language Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Language Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Config Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Loader Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:15:52 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:15:52 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Session Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:15:52 --> Session routines successfully run
DEBUG - 2015-12-06 14:15:52 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Email Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Controller Class Initialized
DEBUG - 2015-12-06 14:15:52 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:21:04 --> Config Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:21:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:21:04 --> URI Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Router Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Output Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Security Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Input Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:21:04 --> Language Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Language Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Config Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Loader Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:21:04 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:21:04 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Session Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:21:04 --> Session routines successfully run
DEBUG - 2015-12-06 14:21:04 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Email Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Controller Class Initialized
DEBUG - 2015-12-06 14:21:04 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:21:25 --> Config Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:21:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:21:25 --> URI Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Router Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Output Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Security Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Input Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:21:25 --> Language Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Language Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Config Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Loader Class Initialized
DEBUG - 2015-12-06 14:21:25 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:21:25 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:21:26 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:21:26 --> Session Class Initialized
DEBUG - 2015-12-06 14:21:26 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:21:26 --> Session routines successfully run
DEBUG - 2015-12-06 14:21:26 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:21:26 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:21:26 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:21:26 --> Email Class Initialized
DEBUG - 2015-12-06 14:21:26 --> Controller Class Initialized
DEBUG - 2015-12-06 14:21:26 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:21:50 --> Config Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:21:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:21:50 --> URI Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Router Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Output Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Security Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Input Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:21:50 --> Language Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Language Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Config Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Loader Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:21:50 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:21:50 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Session Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:21:50 --> Session routines successfully run
DEBUG - 2015-12-06 14:21:50 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Email Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Controller Class Initialized
DEBUG - 2015-12-06 14:21:50 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:21:50 --> Model Class Initialized
DEBUG - 2015-12-06 14:21:50 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-06 14:21:50 --> Model Class Initialized
DEBUG - 2015-12-06 14:21:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:21:50 --> Model Class Initialized
ERROR - 2015-12-06 14:21:50 --> Severity: Notice  --> Undefined property: CI::$users_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2015-12-06 14:23:37 --> Config Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:23:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:23:37 --> URI Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Router Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Output Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Security Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Input Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:23:37 --> Language Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Language Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Config Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Loader Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:23:37 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:23:37 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Session Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:23:37 --> Session routines successfully run
DEBUG - 2015-12-06 14:23:37 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Email Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Controller Class Initialized
DEBUG - 2015-12-06 14:23:37 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:23:37 --> Model Class Initialized
DEBUG - 2015-12-06 14:23:37 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-06 14:23:37 --> Model Class Initialized
DEBUG - 2015-12-06 14:23:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:23:37 --> Model Class Initialized
DEBUG - 2015-12-06 14:23:37 --> DB Transaction Failure
ERROR - 2015-12-06 14:23:37 --> Query error: Table 'mfi.messaging' doesn't exist
DEBUG - 2015-12-06 14:23:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-06 14:24:08 --> Config Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:24:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:24:08 --> URI Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Router Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Output Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Security Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Input Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:24:08 --> Language Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Language Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Config Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Loader Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:24:08 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:24:08 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Session Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:24:08 --> Session routines successfully run
DEBUG - 2015-12-06 14:24:08 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Email Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Controller Class Initialized
DEBUG - 2015-12-06 14:24:08 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:24:08 --> Model Class Initialized
DEBUG - 2015-12-06 14:24:08 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-06 14:24:08 --> Model Class Initialized
DEBUG - 2015-12-06 14:24:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:24:08 --> Model Class Initialized
ERROR - 2015-12-06 14:24:08 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\messaging\views\sms\unsent_messages.php 111
DEBUG - 2015-12-06 14:24:08 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-06 14:24:54 --> Config Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:24:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:24:54 --> URI Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Router Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Output Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Security Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Input Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:24:54 --> Language Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Language Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Config Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Loader Class Initialized
DEBUG - 2015-12-06 14:24:54 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:24:54 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:24:54 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:24:55 --> Session Class Initialized
DEBUG - 2015-12-06 14:24:55 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:24:55 --> Session routines successfully run
DEBUG - 2015-12-06 14:24:55 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:24:55 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:24:55 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:24:55 --> Email Class Initialized
DEBUG - 2015-12-06 14:24:55 --> Controller Class Initialized
DEBUG - 2015-12-06 14:24:55 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:24:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:24:55 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-06 14:24:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:24:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:24:55 --> Model Class Initialized
ERROR - 2015-12-06 14:24:55 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\messaging\views\sms\unsent_messages.php 111
DEBUG - 2015-12-06 14:24:55 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
ERROR - 2015-12-06 14:24:55 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\includes\header.php 4
DEBUG - 2015-12-06 14:24:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:24:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
ERROR - 2015-12-06 14:24:55 --> Severity: Notice  --> Undefined property: CI::$sections_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2015-12-06 14:25:30 --> Config Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:25:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:25:30 --> URI Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Router Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Output Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Security Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Input Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:25:30 --> Language Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Language Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Config Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Loader Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:25:30 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:25:30 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Session Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:25:30 --> Session routines successfully run
DEBUG - 2015-12-06 14:25:30 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Email Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Controller Class Initialized
DEBUG - 2015-12-06 14:25:30 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:25:30 --> Model Class Initialized
DEBUG - 2015-12-06 14:25:30 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-06 14:25:30 --> Model Class Initialized
DEBUG - 2015-12-06 14:25:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:25:30 --> Model Class Initialized
DEBUG - 2015-12-06 14:25:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 14:25:30 --> Model Class Initialized
ERROR - 2015-12-06 14:25:30 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\messaging\views\sms\unsent_messages.php 111
DEBUG - 2015-12-06 14:25:30 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
ERROR - 2015-12-06 14:25:30 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\includes\header.php 4
DEBUG - 2015-12-06 14:25:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:25:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
ERROR - 2015-12-06 14:25:30 --> Severity: Notice  --> Undefined property: CI::$admin_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2015-12-06 14:25:46 --> Config Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:25:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:25:46 --> URI Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Router Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Output Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Security Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Input Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:25:46 --> Language Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Language Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Config Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Loader Class Initialized
DEBUG - 2015-12-06 14:25:46 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:25:46 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:25:47 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:25:47 --> Session Class Initialized
DEBUG - 2015-12-06 14:25:47 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:25:47 --> Session routines successfully run
DEBUG - 2015-12-06 14:25:47 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:25:47 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:25:47 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:25:47 --> Email Class Initialized
DEBUG - 2015-12-06 14:25:47 --> Controller Class Initialized
DEBUG - 2015-12-06 14:25:47 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:25:47 --> Model Class Initialized
DEBUG - 2015-12-06 14:25:47 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-06 14:25:47 --> Model Class Initialized
DEBUG - 2015-12-06 14:25:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:25:47 --> Model Class Initialized
DEBUG - 2015-12-06 14:25:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 14:25:47 --> Model Class Initialized
DEBUG - 2015-12-06 14:25:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-06 14:25:47 --> Model Class Initialized
ERROR - 2015-12-06 14:25:47 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\messaging\views\sms\unsent_messages.php 111
DEBUG - 2015-12-06 14:25:47 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
ERROR - 2015-12-06 14:25:47 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\includes\header.php 4
DEBUG - 2015-12-06 14:25:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:25:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
ERROR - 2015-12-06 14:25:47 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\includes\sidebar.php 37
ERROR - 2015-12-06 14:25:47 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\includes\sidebar.php 58
ERROR - 2015-12-06 14:25:47 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\includes\sidebar.php 58
ERROR - 2015-12-06 14:25:47 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\includes\sidebar.php 58
ERROR - 2015-12-06 14:25:47 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\includes\sidebar.php 58
DEBUG - 2015-12-06 14:25:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
ERROR - 2015-12-06 14:25:47 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\templates\general_page.php 32
ERROR - 2015-12-06 14:25:47 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\admin\views\templates\general_page.php 36
DEBUG - 2015-12-06 14:25:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-06 14:25:47 --> Final output sent to browser
DEBUG - 2015-12-06 14:25:47 --> Total execution time: 0.2793
DEBUG - 2015-12-06 14:27:29 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:29 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Router Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Output Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Security Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Input Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:27:29 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Loader Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:27:29 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:27:29 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Session Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:27:29 --> Session routines successfully run
DEBUG - 2015-12-06 14:27:29 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Email Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Controller Class Initialized
DEBUG - 2015-12-06 14:27:29 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:27:29 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:29 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-06 14:27:29 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:27:29 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 14:27:29 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-06 14:27:29 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:29 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-06 14:27:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:27:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-06 14:27:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-06 14:27:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-06 14:27:29 --> Final output sent to browser
DEBUG - 2015-12-06 14:27:29 --> Total execution time: 0.3449
DEBUG - 2015-12-06 14:27:46 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:46 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Router Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Output Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Security Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Input Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:27:46 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Loader Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:27:46 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:27:46 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Session Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:27:46 --> Session routines successfully run
DEBUG - 2015-12-06 14:27:46 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Email Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Controller Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Auth MX_Controller Initialized
DEBUG - 2015-12-06 14:27:46 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 14:27:46 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:27:46 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:46 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Router Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Output Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Security Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Input Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:27:46 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Loader Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:27:46 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:27:46 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Session Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:27:46 --> A session cookie was not found.
DEBUG - 2015-12-06 14:27:46 --> Session routines successfully run
DEBUG - 2015-12-06 14:27:46 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Email Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Controller Class Initialized
DEBUG - 2015-12-06 14:27:46 --> Auth MX_Controller Initialized
DEBUG - 2015-12-06 14:27:46 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 14:27:46 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:27:46 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:27:46 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-06 14:27:46 --> Final output sent to browser
DEBUG - 2015-12-06 14:27:46 --> Total execution time: 0.2025
DEBUG - 2015-12-06 14:27:47 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:47 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:47 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Router Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:47 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Router Class Initialized
ERROR - 2015-12-06 14:27:47 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:27:47 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:47 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Router Class Initialized
ERROR - 2015-12-06 14:27:47 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:27:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:47 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:47 --> Router Class Initialized
ERROR - 2015-12-06 14:27:47 --> 404 Page Not Found --> 
ERROR - 2015-12-06 14:27:47 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:27:49 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:49 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Router Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Output Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Security Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Input Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:27:49 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Loader Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:27:49 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:27:49 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Session Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:27:49 --> Session routines successfully run
DEBUG - 2015-12-06 14:27:49 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Email Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Controller Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Auth MX_Controller Initialized
DEBUG - 2015-12-06 14:27:49 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 14:27:49 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:27:49 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-06 14:27:49 --> XSS Filtering completed
DEBUG - 2015-12-06 14:27:49 --> Unable to find validation rule: exists
DEBUG - 2015-12-06 14:27:49 --> XSS Filtering completed
DEBUG - 2015-12-06 14:27:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:27:49 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-06 14:27:49 --> Final output sent to browser
DEBUG - 2015-12-06 14:27:49 --> Total execution time: 0.4564
DEBUG - 2015-12-06 14:27:49 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:49 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:49 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:49 --> Router Class Initialized
DEBUG - 2015-12-06 14:27:49 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:50 --> Router Class Initialized
DEBUG - 2015-12-06 14:27:50 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:50 --> Hooks Class Initialized
ERROR - 2015-12-06 14:27:50 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:27:50 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:50 --> URI Class Initialized
ERROR - 2015-12-06 14:27:50 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:27:50 --> Router Class Initialized
ERROR - 2015-12-06 14:27:50 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:27:50 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:50 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:50 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:50 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:50 --> Router Class Initialized
ERROR - 2015-12-06 14:27:50 --> 404 Page Not Found --> 
DEBUG - 2015-12-06 14:27:55 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:55 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Router Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Output Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Security Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Input Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:27:55 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Loader Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:27:55 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:27:55 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Session Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:27:55 --> Session routines successfully run
DEBUG - 2015-12-06 14:27:55 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Email Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Controller Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Auth MX_Controller Initialized
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-06 14:27:55 --> XSS Filtering completed
DEBUG - 2015-12-06 14:27:55 --> Unable to find validation rule: exists
DEBUG - 2015-12-06 14:27:55 --> XSS Filtering completed
DEBUG - 2015-12-06 14:27:55 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:27:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:27:55 --> URI Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Router Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Output Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Security Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Input Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:27:55 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Language Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Config Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Loader Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:27:55 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:27:55 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Session Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:27:55 --> Session routines successfully run
DEBUG - 2015-12-06 14:27:55 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Email Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Controller Class Initialized
DEBUG - 2015-12-06 14:27:55 --> Admin MX_Controller Initialized
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-06 14:27:55 --> Model Class Initialized
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-06 14:27:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-06 14:27:55 --> Final output sent to browser
DEBUG - 2015-12-06 14:27:55 --> Total execution time: 0.3421
DEBUG - 2015-12-06 14:28:06 --> Config Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:28:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:28:06 --> URI Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Router Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Output Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Security Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Input Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:28:06 --> Language Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Language Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Config Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Loader Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:28:06 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:28:06 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Session Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:28:06 --> Session routines successfully run
DEBUG - 2015-12-06 14:28:06 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Email Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Controller Class Initialized
DEBUG - 2015-12-06 14:28:06 --> Sections MX_Controller Initialized
DEBUG - 2015-12-06 14:28:06 --> Model Class Initialized
DEBUG - 2015-12-06 14:28:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-06 14:28:06 --> Model Class Initialized
DEBUG - 2015-12-06 14:28:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 14:28:06 --> Model Class Initialized
DEBUG - 2015-12-06 14:28:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:28:06 --> Model Class Initialized
DEBUG - 2015-12-06 14:28:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-06 14:28:06 --> Model Class Initialized
DEBUG - 2015-12-06 14:28:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 14:28:06 --> Model Class Initialized
DEBUG - 2015-12-06 14:28:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-06 14:28:06 --> Model Class Initialized
DEBUG - 2015-12-06 14:28:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-06 14:28:06 --> Model Class Initialized
DEBUG - 2015-12-06 14:28:07 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-06 14:28:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:28:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-06 14:28:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-06 14:28:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-06 14:28:07 --> Final output sent to browser
DEBUG - 2015-12-06 14:28:07 --> Total execution time: 0.4019
DEBUG - 2015-12-06 14:29:26 --> Config Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:29:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:29:26 --> URI Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Router Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Output Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Security Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Input Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:29:26 --> Language Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Language Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Config Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Loader Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:29:26 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:29:26 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Session Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:29:26 --> Session routines successfully run
DEBUG - 2015-12-06 14:29:26 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Email Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Controller Class Initialized
DEBUG - 2015-12-06 14:29:26 --> Sections MX_Controller Initialized
DEBUG - 2015-12-06 14:29:26 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-06 14:29:26 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-06 14:29:26 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:29:26 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-06 14:29:26 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 14:29:26 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-06 14:29:26 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-06 14:29:26 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-06 14:29:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-06 14:29:26 --> Final output sent to browser
DEBUG - 2015-12-06 14:29:26 --> Total execution time: 0.3505
DEBUG - 2015-12-06 14:29:30 --> Config Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:29:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:29:30 --> URI Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Router Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Output Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Security Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Input Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:29:30 --> Language Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Language Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Config Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Loader Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:29:30 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:29:30 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Session Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:29:30 --> Session routines successfully run
DEBUG - 2015-12-06 14:29:30 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Email Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Controller Class Initialized
DEBUG - 2015-12-06 14:29:30 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:29:30 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:30 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-06 14:29:30 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:29:30 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 14:29:30 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-06 14:29:30 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:30 --> File loaded: application/modules/messaging/views/sms/sent_messages.php
DEBUG - 2015-12-06 14:29:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:29:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-06 14:29:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-06 14:29:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-06 14:29:30 --> Final output sent to browser
DEBUG - 2015-12-06 14:29:30 --> Total execution time: 0.2544
DEBUG - 2015-12-06 14:29:34 --> Config Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Hooks Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Utf8 Class Initialized
DEBUG - 2015-12-06 14:29:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-06 14:29:34 --> URI Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Router Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Output Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Security Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Input Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-06 14:29:34 --> Language Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Language Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Config Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Loader Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Helper loaded: url_helper
DEBUG - 2015-12-06 14:29:34 --> Helper loaded: form_helper
DEBUG - 2015-12-06 14:29:34 --> Database Driver Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Session Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Helper loaded: string_helper
DEBUG - 2015-12-06 14:29:34 --> Session routines successfully run
DEBUG - 2015-12-06 14:29:34 --> Form Validation Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Pagination Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Encrypt Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Email Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Controller Class Initialized
DEBUG - 2015-12-06 14:29:34 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-06 14:29:34 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:34 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-06 14:29:34 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-06 14:29:34 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-06 14:29:34 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-06 14:29:34 --> Model Class Initialized
DEBUG - 2015-12-06 14:29:34 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-06 14:29:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-06 14:29:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-06 14:29:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-06 14:29:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-06 14:29:34 --> Final output sent to browser
DEBUG - 2015-12-06 14:29:34 --> Total execution time: 0.2251
