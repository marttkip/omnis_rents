<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-09-29 00:01:26 --> Config Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:01:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:01:26 --> URI Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Router Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Output Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Security Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Input Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:01:26 --> Language Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Language Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Config Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Loader Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:01:26 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:01:26 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:01:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:01:26 --> Session Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:01:26 --> Session routines successfully run
DEBUG - 2015-09-29 00:01:26 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Email Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Controller Class Initialized
DEBUG - 2015-09-29 00:01:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:01:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Config Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:01:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:01:35 --> URI Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Router Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Output Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Security Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Input Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:01:35 --> Language Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Language Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Config Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Loader Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:01:35 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:01:35 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:01:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:01:35 --> Session Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:01:35 --> Session routines successfully run
DEBUG - 2015-09-29 00:01:35 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Email Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Controller Class Initialized
DEBUG - 2015-09-29 00:01:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:01:35 --> Model Class Initialized
ERROR - 2015-09-29 00:01:35 --> Severity: Notice  --> Undefined variable: minimum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 174
ERROR - 2015-09-29 00:01:35 --> Severity: Notice  --> Undefined variable: maximum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 181
ERROR - 2015-09-29 00:01:35 --> Severity: Notice  --> Undefined variable: custom_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 188
ERROR - 2015-09-29 00:01:35 --> Severity: Notice  --> Undefined variable: minimum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 196
ERROR - 2015-09-29 00:01:35 --> Severity: Notice  --> Undefined variable: maximum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 203
ERROR - 2015-09-29 00:01:35 --> Severity: Notice  --> Undefined variable: custom_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 210
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:01:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:01:35 --> Final output sent to browser
DEBUG - 2015-09-29 00:01:35 --> Total execution time: 0.1448
DEBUG - 2015-09-29 00:02:43 --> Config Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:02:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:02:43 --> URI Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Router Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Output Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Security Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Input Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:02:43 --> Language Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Language Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Config Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Loader Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:02:43 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:02:43 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:02:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:02:43 --> Session Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:02:43 --> Session routines successfully run
DEBUG - 2015-09-29 00:02:43 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Email Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Controller Class Initialized
DEBUG - 2015-09-29 00:02:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:02:43 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Config Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:02:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:02:50 --> URI Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Router Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Output Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Security Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Input Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:02:50 --> Language Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Language Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Config Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Loader Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:02:50 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:02:50 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:02:50 --> Session Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:02:50 --> Session routines successfully run
DEBUG - 2015-09-29 00:02:50 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Email Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Controller Class Initialized
DEBUG - 2015-09-29 00:02:50 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:02:50 --> Model Class Initialized
ERROR - 2015-09-29 00:02:50 --> Severity: Notice  --> Undefined variable: minimum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 176
ERROR - 2015-09-29 00:02:50 --> Severity: Notice  --> Undefined variable: maximum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 183
ERROR - 2015-09-29 00:02:50 --> Severity: Notice  --> Undefined variable: custom_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 190
ERROR - 2015-09-29 00:02:50 --> Severity: Notice  --> Undefined variable: minimum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 198
ERROR - 2015-09-29 00:02:50 --> Severity: Notice  --> Undefined variable: maximum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 205
ERROR - 2015-09-29 00:02:50 --> Severity: Notice  --> Undefined variable: custom_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 212
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:02:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:02:50 --> Final output sent to browser
DEBUG - 2015-09-29 00:02:50 --> Total execution time: 0.1564
DEBUG - 2015-09-29 00:06:14 --> Config Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:06:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:06:14 --> URI Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Router Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Output Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Security Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Input Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:06:14 --> Language Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Language Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Config Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Loader Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:06:14 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:06:14 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:06:14 --> Session Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:06:14 --> Session routines successfully run
DEBUG - 2015-09-29 00:06:14 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Email Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Controller Class Initialized
DEBUG - 2015-09-29 00:06:14 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:06:14 --> Model Class Initialized
ERROR - 2015-09-29 00:06:14 --> Severity: Notice  --> Undefined variable: minimum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 184
ERROR - 2015-09-29 00:06:14 --> Severity: Notice  --> Undefined variable: maximum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 191
ERROR - 2015-09-29 00:06:14 --> Severity: Notice  --> Undefined variable: custom_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 198
ERROR - 2015-09-29 00:06:14 --> Severity: Notice  --> Undefined variable: minimum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 206
ERROR - 2015-09-29 00:06:14 --> Severity: Notice  --> Undefined variable: maximum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 213
ERROR - 2015-09-29 00:06:14 --> Severity: Notice  --> Undefined variable: custom_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 220
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:06:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:06:14 --> Final output sent to browser
DEBUG - 2015-09-29 00:06:14 --> Total execution time: 0.1600
DEBUG - 2015-09-29 00:06:39 --> Config Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:06:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:06:39 --> URI Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Router Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Output Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Security Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Input Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:06:39 --> Language Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Language Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Config Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Loader Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:06:39 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:06:39 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:06:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:06:39 --> Session Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:06:39 --> Session routines successfully run
DEBUG - 2015-09-29 00:06:39 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Email Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Controller Class Initialized
DEBUG - 2015-09-29 00:06:39 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:06:39 --> Model Class Initialized
ERROR - 2015-09-29 00:06:39 --> Severity: Notice  --> Undefined variable: minimum_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 184
ERROR - 2015-09-29 00:06:39 --> Severity: Notice  --> Undefined variable: custom_number_of_installments C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 198
ERROR - 2015-09-29 00:06:39 --> Severity: Notice  --> Undefined variable: minimum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 206
ERROR - 2015-09-29 00:06:39 --> Severity: Notice  --> Undefined variable: maximum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 213
ERROR - 2015-09-29 00:06:39 --> Severity: Notice  --> Undefined variable: custom_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 220
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:06:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:06:39 --> Final output sent to browser
DEBUG - 2015-09-29 00:06:39 --> Total execution time: 0.1580
DEBUG - 2015-09-29 00:07:22 --> Config Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:07:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:07:22 --> URI Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Router Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Output Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Security Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Input Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:07:22 --> Language Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Language Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Config Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Loader Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:07:22 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:07:22 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:07:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:07:22 --> Session Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:07:22 --> Session routines successfully run
DEBUG - 2015-09-29 00:07:22 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Email Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Controller Class Initialized
DEBUG - 2015-09-29 00:07:22 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:07:22 --> Model Class Initialized
ERROR - 2015-09-29 00:07:22 --> Severity: Notice  --> Undefined variable: minimum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 212
ERROR - 2015-09-29 00:07:22 --> Severity: Notice  --> Undefined variable: maximum_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 219
ERROR - 2015-09-29 00:07:22 --> Severity: Notice  --> Undefined variable: custom_late_fee_on_total_loan C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 226
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:07:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:07:22 --> Final output sent to browser
DEBUG - 2015-09-29 00:07:22 --> Total execution time: 0.1403
DEBUG - 2015-09-29 00:08:50 --> Config Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:08:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:08:50 --> URI Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Router Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Output Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Security Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Input Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:08:50 --> Language Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Language Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Config Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Loader Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:08:50 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:08:50 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:08:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:08:50 --> Session Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:08:50 --> Session routines successfully run
DEBUG - 2015-09-29 00:08:50 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Email Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Controller Class Initialized
DEBUG - 2015-09-29 00:08:50 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:08:50 --> Model Class Initialized
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:08:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:08:50 --> Final output sent to browser
DEBUG - 2015-09-29 00:08:50 --> Total execution time: 0.1569
DEBUG - 2015-09-29 00:21:28 --> Config Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:21:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:21:28 --> URI Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Router Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Output Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Security Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Input Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:21:28 --> Language Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Language Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Config Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Loader Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:21:28 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:21:28 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:21:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:21:28 --> Session Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:21:28 --> Session routines successfully run
DEBUG - 2015-09-29 00:21:28 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Email Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Controller Class Initialized
DEBUG - 2015-09-29 00:21:28 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:21:28 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Config Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:21:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:21:44 --> URI Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Router Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Output Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Security Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Input Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:21:44 --> Language Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Language Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Config Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Loader Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:21:44 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:21:44 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:21:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:21:44 --> Session Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:21:44 --> Session routines successfully run
DEBUG - 2015-09-29 00:21:44 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Email Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Controller Class Initialized
DEBUG - 2015-09-29 00:21:44 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:21:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:21:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:21:44 --> Final output sent to browser
DEBUG - 2015-09-29 00:21:44 --> Total execution time: 0.1240
DEBUG - 2015-09-29 00:23:44 --> Config Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:23:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:23:44 --> URI Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Router Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Output Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Security Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Input Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:23:44 --> Language Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Language Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Config Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Loader Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:23:44 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:23:44 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:23:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:23:44 --> Session Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:23:44 --> Session routines successfully run
DEBUG - 2015-09-29 00:23:44 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Email Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Controller Class Initialized
DEBUG - 2015-09-29 00:23:44 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:23:44 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:23:45 --> Model Class Initialized
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:23:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:23:45 --> Final output sent to browser
DEBUG - 2015-09-29 00:23:45 --> Total execution time: 0.1566
DEBUG - 2015-09-29 00:25:26 --> Config Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:25:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:25:26 --> URI Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Router Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Output Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Security Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Input Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:25:26 --> Language Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Language Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Config Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Loader Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:25:26 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:25:26 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:25:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:25:26 --> Session Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:25:26 --> Session routines successfully run
DEBUG - 2015-09-29 00:25:26 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Email Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Controller Class Initialized
DEBUG - 2015-09-29 00:25:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:25:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:25:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:25:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:25:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:25:26 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:25:27 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:25:27 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:25:27 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:25:27 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:25:27 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:25:27 --> Model Class Initialized
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:25:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:25:27 --> Final output sent to browser
DEBUG - 2015-09-29 00:25:27 --> Total execution time: 0.1382
DEBUG - 2015-09-29 00:38:31 --> Config Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:38:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:38:31 --> URI Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Router Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Output Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Security Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Input Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:38:31 --> Language Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Language Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Config Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Loader Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:38:31 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:38:31 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:38:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:38:31 --> Session Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:38:31 --> Session routines successfully run
DEBUG - 2015-09-29 00:38:31 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Email Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Controller Class Initialized
DEBUG - 2015-09-29 00:38:31 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:38:31 --> Model Class Initialized
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:38:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:38:31 --> Final output sent to browser
DEBUG - 2015-09-29 00:38:31 --> Total execution time: 0.1278
DEBUG - 2015-09-29 00:42:34 --> Config Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Hooks Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Utf8 Class Initialized
DEBUG - 2015-09-29 00:42:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 00:42:34 --> URI Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Router Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Output Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Security Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Input Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 00:42:34 --> Language Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Language Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Config Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Loader Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Helper loaded: url_helper
DEBUG - 2015-09-29 00:42:34 --> Helper loaded: form_helper
DEBUG - 2015-09-29 00:42:34 --> Database Driver Class Initialized
ERROR - 2015-09-29 00:42:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 00:42:34 --> Session Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Helper loaded: string_helper
DEBUG - 2015-09-29 00:42:34 --> Session routines successfully run
DEBUG - 2015-09-29 00:42:34 --> Form Validation Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Pagination Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Encrypt Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Email Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Controller Class Initialized
DEBUG - 2015-09-29 00:42:34 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 00:42:34 --> Model Class Initialized
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 00:42:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 00:42:34 --> Final output sent to browser
DEBUG - 2015-09-29 00:42:34 --> Total execution time: 0.1409
DEBUG - 2015-09-29 01:03:47 --> Config Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Hooks Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Utf8 Class Initialized
DEBUG - 2015-09-29 01:03:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 01:03:47 --> URI Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Router Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Output Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Security Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Input Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 01:03:47 --> Language Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Language Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Config Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Loader Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Helper loaded: url_helper
DEBUG - 2015-09-29 01:03:47 --> Helper loaded: form_helper
DEBUG - 2015-09-29 01:03:47 --> Database Driver Class Initialized
ERROR - 2015-09-29 01:03:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 01:03:47 --> Session Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Helper loaded: string_helper
DEBUG - 2015-09-29 01:03:47 --> Session routines successfully run
DEBUG - 2015-09-29 01:03:47 --> Form Validation Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Pagination Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Encrypt Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Email Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Controller Class Initialized
DEBUG - 2015-09-29 01:03:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 01:03:47 --> Model Class Initialized
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 01:03:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 01:03:47 --> Final output sent to browser
DEBUG - 2015-09-29 01:03:47 --> Total execution time: 0.2553
DEBUG - 2015-09-29 12:08:37 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:37 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Router Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Output Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Security Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Input Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 12:08:37 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Loader Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Helper loaded: url_helper
DEBUG - 2015-09-29 12:08:37 --> Helper loaded: form_helper
DEBUG - 2015-09-29 12:08:37 --> Database Driver Class Initialized
ERROR - 2015-09-29 12:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-29 12:08:37 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 12:08:37 --> Session Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Helper loaded: string_helper
DEBUG - 2015-09-29 12:08:37 --> A session cookie was not found.
DEBUG - 2015-09-29 12:08:37 --> Session routines successfully run
DEBUG - 2015-09-29 12:08:37 --> Form Validation Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Pagination Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Encrypt Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Email Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Controller Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:37 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Router Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Output Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Security Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Input Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 12:08:37 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Loader Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Helper loaded: url_helper
DEBUG - 2015-09-29 12:08:37 --> Helper loaded: form_helper
DEBUG - 2015-09-29 12:08:37 --> Database Driver Class Initialized
ERROR - 2015-09-29 12:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 12:08:37 --> Session Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Helper loaded: string_helper
DEBUG - 2015-09-29 12:08:37 --> Session routines successfully run
DEBUG - 2015-09-29 12:08:37 --> Form Validation Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Pagination Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Encrypt Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Email Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Controller Class Initialized
DEBUG - 2015-09-29 12:08:37 --> Auth MX_Controller Initialized
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 12:08:37 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 12:08:37 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-29 12:08:37 --> Final output sent to browser
DEBUG - 2015-09-29 12:08:37 --> Total execution time: 0.1825
DEBUG - 2015-09-29 12:08:39 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:39 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:39 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Router Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Router Class Initialized
DEBUG - 2015-09-29 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:39 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Router Class Initialized
ERROR - 2015-09-29 12:08:39 --> 404 Page Not Found --> 
ERROR - 2015-09-29 12:08:39 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 12:08:39 --> Config Class Initialized
ERROR - 2015-09-29 12:08:39 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 12:08:39 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:39 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:39 --> Router Class Initialized
ERROR - 2015-09-29 12:08:39 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 12:08:47 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:47 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Router Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Output Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Security Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Input Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 12:08:47 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Loader Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Helper loaded: url_helper
DEBUG - 2015-09-29 12:08:47 --> Helper loaded: form_helper
DEBUG - 2015-09-29 12:08:47 --> Database Driver Class Initialized
ERROR - 2015-09-29 12:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 12:08:47 --> Session Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Helper loaded: string_helper
DEBUG - 2015-09-29 12:08:47 --> Session routines successfully run
DEBUG - 2015-09-29 12:08:47 --> Form Validation Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Pagination Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Encrypt Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Email Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Controller Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Auth MX_Controller Initialized
DEBUG - 2015-09-29 12:08:47 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 12:08:47 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 12:08:47 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 12:08:47 --> XSS Filtering completed
DEBUG - 2015-09-29 12:08:47 --> Unable to find validation rule: exists
DEBUG - 2015-09-29 12:08:47 --> XSS Filtering completed
DEBUG - 2015-09-29 12:08:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 12:08:47 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-29 12:08:47 --> Final output sent to browser
DEBUG - 2015-09-29 12:08:47 --> Total execution time: 0.2148
DEBUG - 2015-09-29 12:08:48 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:48 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:48 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Router Class Initialized
DEBUG - 2015-09-29 12:08:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:48 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:48 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:48 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Router Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Router Class Initialized
ERROR - 2015-09-29 12:08:48 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 12:08:48 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:48 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:48 --> Router Class Initialized
ERROR - 2015-09-29 12:08:48 --> 404 Page Not Found --> 
ERROR - 2015-09-29 12:08:48 --> 404 Page Not Found --> 
ERROR - 2015-09-29 12:08:48 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 12:08:57 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:57 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Router Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Output Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Security Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Input Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 12:08:57 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Loader Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Helper loaded: url_helper
DEBUG - 2015-09-29 12:08:57 --> Helper loaded: form_helper
DEBUG - 2015-09-29 12:08:57 --> Database Driver Class Initialized
ERROR - 2015-09-29 12:08:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-29 12:08:57 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 12:08:57 --> Session Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Helper loaded: string_helper
DEBUG - 2015-09-29 12:08:57 --> Session routines successfully run
DEBUG - 2015-09-29 12:08:57 --> Form Validation Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Pagination Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Encrypt Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Email Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Controller Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Auth MX_Controller Initialized
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 12:08:57 --> XSS Filtering completed
DEBUG - 2015-09-29 12:08:57 --> Unable to find validation rule: exists
DEBUG - 2015-09-29 12:08:57 --> XSS Filtering completed
DEBUG - 2015-09-29 12:08:57 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:08:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:08:57 --> URI Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Router Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Output Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Security Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Input Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 12:08:57 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Language Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Config Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Loader Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Helper loaded: url_helper
DEBUG - 2015-09-29 12:08:57 --> Helper loaded: form_helper
DEBUG - 2015-09-29 12:08:57 --> Database Driver Class Initialized
ERROR - 2015-09-29 12:08:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 12:08:57 --> Session Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Helper loaded: string_helper
DEBUG - 2015-09-29 12:08:57 --> Session routines successfully run
DEBUG - 2015-09-29 12:08:57 --> Form Validation Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Pagination Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Encrypt Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Email Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Controller Class Initialized
DEBUG - 2015-09-29 12:08:57 --> Admin MX_Controller Initialized
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-29 12:08:57 --> Model Class Initialized
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 12:08:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 12:08:57 --> Final output sent to browser
DEBUG - 2015-09-29 12:08:57 --> Total execution time: 0.2102
DEBUG - 2015-09-29 12:09:56 --> Config Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:09:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:09:56 --> URI Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Router Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Output Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Security Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Input Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 12:09:56 --> Language Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Language Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Config Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Loader Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Helper loaded: url_helper
DEBUG - 2015-09-29 12:09:56 --> Helper loaded: form_helper
DEBUG - 2015-09-29 12:09:56 --> Database Driver Class Initialized
ERROR - 2015-09-29 12:09:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 12:09:56 --> Session Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Helper loaded: string_helper
DEBUG - 2015-09-29 12:09:56 --> Session routines successfully run
DEBUG - 2015-09-29 12:09:56 --> Form Validation Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Pagination Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Encrypt Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Email Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Controller Class Initialized
DEBUG - 2015-09-29 12:09:56 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 12:09:56 --> Model Class Initialized
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 12:09:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 12:09:56 --> Final output sent to browser
DEBUG - 2015-09-29 12:09:56 --> Total execution time: 0.2340
DEBUG - 2015-09-29 12:10:12 --> Config Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:10:12 --> URI Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Router Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Output Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Security Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Input Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 12:10:12 --> Language Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Language Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Config Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Loader Class Initialized
DEBUG - 2015-09-29 12:10:12 --> Helper loaded: url_helper
DEBUG - 2015-09-29 12:10:12 --> Helper loaded: form_helper
DEBUG - 2015-09-29 12:10:13 --> Database Driver Class Initialized
ERROR - 2015-09-29 12:10:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 12:10:13 --> Session Class Initialized
DEBUG - 2015-09-29 12:10:13 --> Helper loaded: string_helper
DEBUG - 2015-09-29 12:10:13 --> Session routines successfully run
DEBUG - 2015-09-29 12:10:13 --> Form Validation Class Initialized
DEBUG - 2015-09-29 12:10:13 --> Pagination Class Initialized
DEBUG - 2015-09-29 12:10:13 --> Encrypt Class Initialized
DEBUG - 2015-09-29 12:10:13 --> Email Class Initialized
DEBUG - 2015-09-29 12:10:13 --> Controller Class Initialized
DEBUG - 2015-09-29 12:10:13 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 12:10:13 --> Model Class Initialized
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 12:10:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 12:10:13 --> Final output sent to browser
DEBUG - 2015-09-29 12:10:13 --> Total execution time: 0.2405
DEBUG - 2015-09-29 12:13:48 --> Config Class Initialized
DEBUG - 2015-09-29 12:13:48 --> Hooks Class Initialized
DEBUG - 2015-09-29 12:13:48 --> Utf8 Class Initialized
DEBUG - 2015-09-29 12:13:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 12:13:48 --> URI Class Initialized
DEBUG - 2015-09-29 12:13:48 --> Router Class Initialized
ERROR - 2015-09-29 12:13:48 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 13:01:14 --> Config Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:01:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:01:14 --> URI Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Router Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Output Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Security Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Input Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:01:14 --> Language Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Language Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Config Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Loader Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:01:14 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:01:14 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:01:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:01:14 --> Session Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:01:14 --> Session routines successfully run
DEBUG - 2015-09-29 13:01:14 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Email Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Controller Class Initialized
DEBUG - 2015-09-29 13:01:14 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:01:14 --> Model Class Initialized
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:01:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:01:14 --> Final output sent to browser
DEBUG - 2015-09-29 13:01:14 --> Total execution time: 0.3223
DEBUG - 2015-09-29 13:02:41 --> Config Class Initialized
DEBUG - 2015-09-29 13:02:41 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:02:41 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:02:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:02:41 --> URI Class Initialized
DEBUG - 2015-09-29 13:02:41 --> Router Class Initialized
ERROR - 2015-09-29 13:02:41 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 13:20:36 --> Config Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:20:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:20:36 --> URI Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Router Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Output Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Security Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Input Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:20:36 --> Language Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Language Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Config Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Loader Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:20:36 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:20:36 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:20:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-29 13:20:36 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:20:36 --> Session Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:20:36 --> Session routines successfully run
DEBUG - 2015-09-29 13:20:36 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Email Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Controller Class Initialized
DEBUG - 2015-09-29 13:20:36 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:20:36 --> Model Class Initialized
DEBUG - 2015-09-29 13:20:36 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:20:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:20:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:20:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:20:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:20:37 --> Final output sent to browser
DEBUG - 2015-09-29 13:20:37 --> Total execution time: 0.2358
DEBUG - 2015-09-29 13:25:39 --> Config Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:25:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:25:39 --> URI Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Router Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Output Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Security Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Input Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:25:39 --> Language Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Language Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Config Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Loader Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:25:39 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:25:39 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:25:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-29 13:25:39 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:25:39 --> Session Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:25:39 --> Session routines successfully run
DEBUG - 2015-09-29 13:25:39 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Email Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Controller Class Initialized
DEBUG - 2015-09-29 13:25:39 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:25:39 --> Model Class Initialized
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:25:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:25:39 --> Final output sent to browser
DEBUG - 2015-09-29 13:25:39 --> Total execution time: 0.2477
DEBUG - 2015-09-29 13:28:57 --> Config Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:28:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:28:57 --> URI Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Router Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Output Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Security Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Input Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:28:57 --> Language Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Language Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Config Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Loader Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:28:57 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:28:57 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:28:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:28:57 --> Session Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:28:57 --> Session routines successfully run
DEBUG - 2015-09-29 13:28:57 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Email Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Controller Class Initialized
DEBUG - 2015-09-29 13:28:57 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:28:57 --> Model Class Initialized
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:28:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:28:57 --> Final output sent to browser
DEBUG - 2015-09-29 13:28:57 --> Total execution time: 0.3182
DEBUG - 2015-09-29 13:29:17 --> Config Class Initialized
DEBUG - 2015-09-29 13:29:17 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:29:17 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:29:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:29:17 --> URI Class Initialized
DEBUG - 2015-09-29 13:29:17 --> Router Class Initialized
ERROR - 2015-09-29 13:29:17 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 13:34:29 --> Config Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:34:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:34:29 --> URI Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Router Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Output Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Security Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Input Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:34:29 --> Language Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Language Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Config Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Loader Class Initialized
DEBUG - 2015-09-29 13:34:29 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:34:30 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:34:30 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:34:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:34:30 --> Session Class Initialized
DEBUG - 2015-09-29 13:34:30 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:34:30 --> Session routines successfully run
DEBUG - 2015-09-29 13:34:30 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:34:30 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:34:30 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:34:30 --> Email Class Initialized
DEBUG - 2015-09-29 13:34:30 --> Controller Class Initialized
DEBUG - 2015-09-29 13:34:30 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:34:30 --> Model Class Initialized
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:34:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:34:30 --> Final output sent to browser
DEBUG - 2015-09-29 13:34:30 --> Total execution time: 0.2804
DEBUG - 2015-09-29 13:34:32 --> Config Class Initialized
DEBUG - 2015-09-29 13:34:32 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:34:32 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:34:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:34:32 --> URI Class Initialized
DEBUG - 2015-09-29 13:34:32 --> Router Class Initialized
ERROR - 2015-09-29 13:34:32 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 13:38:25 --> Config Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:38:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:38:25 --> URI Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Router Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Output Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Security Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Input Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:38:25 --> Language Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Language Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Config Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Loader Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:38:25 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:38:25 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:38:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:38:25 --> Session Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:38:25 --> Session routines successfully run
DEBUG - 2015-09-29 13:38:25 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Email Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Controller Class Initialized
DEBUG - 2015-09-29 13:38:25 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:38:25 --> Model Class Initialized
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:38:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:38:25 --> Final output sent to browser
DEBUG - 2015-09-29 13:38:25 --> Total execution time: 0.2389
DEBUG - 2015-09-29 13:38:28 --> Config Class Initialized
DEBUG - 2015-09-29 13:38:28 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:38:28 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:38:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:38:28 --> URI Class Initialized
DEBUG - 2015-09-29 13:38:28 --> Router Class Initialized
ERROR - 2015-09-29 13:38:28 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 13:43:05 --> Config Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:43:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:43:05 --> URI Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Router Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Output Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Security Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Input Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:43:05 --> Language Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Language Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Config Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Loader Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:43:05 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:43:05 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:43:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-29 13:43:05 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:43:05 --> Session Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:43:05 --> Session routines successfully run
DEBUG - 2015-09-29 13:43:05 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Email Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Controller Class Initialized
DEBUG - 2015-09-29 13:43:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:43:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:43:05 --> Final output sent to browser
DEBUG - 2015-09-29 13:43:05 --> Total execution time: 0.2620
DEBUG - 2015-09-29 13:43:08 --> Config Class Initialized
DEBUG - 2015-09-29 13:43:08 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:43:08 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:43:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:43:08 --> URI Class Initialized
DEBUG - 2015-09-29 13:43:08 --> Router Class Initialized
ERROR - 2015-09-29 13:43:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 13:43:35 --> Config Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:43:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:43:35 --> URI Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Router Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Output Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Security Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Input Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:43:35 --> Language Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Language Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Config Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Loader Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:43:35 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:43:35 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:43:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:43:35 --> Session Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:43:35 --> Session routines successfully run
DEBUG - 2015-09-29 13:43:35 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Email Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Controller Class Initialized
DEBUG - 2015-09-29 13:43:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:43:35 --> Model Class Initialized
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:43:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:43:35 --> Final output sent to browser
DEBUG - 2015-09-29 13:43:35 --> Total execution time: 0.2279
DEBUG - 2015-09-29 13:43:38 --> Config Class Initialized
DEBUG - 2015-09-29 13:43:38 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:43:38 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:43:38 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:43:38 --> URI Class Initialized
DEBUG - 2015-09-29 13:43:38 --> Router Class Initialized
ERROR - 2015-09-29 13:43:38 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 13:46:08 --> Config Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:46:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:46:08 --> URI Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Router Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Output Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Security Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Input Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:46:08 --> Language Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Language Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Config Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Loader Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:46:08 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:46:08 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:46:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-29 13:46:08 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:46:08 --> Session Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:46:08 --> Session routines successfully run
DEBUG - 2015-09-29 13:46:08 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Email Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Controller Class Initialized
DEBUG - 2015-09-29 13:46:08 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:46:09 --> Model Class Initialized
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:46:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:46:09 --> Final output sent to browser
DEBUG - 2015-09-29 13:46:09 --> Total execution time: 0.3059
DEBUG - 2015-09-29 13:46:11 --> Config Class Initialized
DEBUG - 2015-09-29 13:46:11 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:46:11 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:46:11 --> URI Class Initialized
DEBUG - 2015-09-29 13:46:11 --> Router Class Initialized
ERROR - 2015-09-29 13:46:11 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 13:49:46 --> Config Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:49:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:49:46 --> URI Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Router Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Output Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Security Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Input Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 13:49:46 --> Language Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Language Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Config Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Loader Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Helper loaded: url_helper
DEBUG - 2015-09-29 13:49:46 --> Helper loaded: form_helper
DEBUG - 2015-09-29 13:49:46 --> Database Driver Class Initialized
ERROR - 2015-09-29 13:49:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 13:49:46 --> Session Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Helper loaded: string_helper
DEBUG - 2015-09-29 13:49:46 --> Session routines successfully run
DEBUG - 2015-09-29 13:49:46 --> Form Validation Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Pagination Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Encrypt Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Email Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Controller Class Initialized
DEBUG - 2015-09-29 13:49:46 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 13:49:46 --> Model Class Initialized
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 13:49:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 13:49:46 --> Final output sent to browser
DEBUG - 2015-09-29 13:49:46 --> Total execution time: 0.3098
DEBUG - 2015-09-29 13:49:49 --> Config Class Initialized
DEBUG - 2015-09-29 13:49:49 --> Hooks Class Initialized
DEBUG - 2015-09-29 13:49:49 --> Utf8 Class Initialized
DEBUG - 2015-09-29 13:49:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 13:49:49 --> URI Class Initialized
DEBUG - 2015-09-29 13:49:49 --> Router Class Initialized
ERROR - 2015-09-29 13:49:49 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:20:58 --> Config Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:20:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:20:58 --> URI Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Router Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Output Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Security Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Input Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:20:58 --> Language Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Language Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Config Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Loader Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:20:58 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:20:58 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:20:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:20:58 --> Session Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:20:58 --> Session routines successfully run
DEBUG - 2015-09-29 14:20:58 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Email Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Controller Class Initialized
DEBUG - 2015-09-29 14:20:58 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
DEBUG - 2015-09-29 14:20:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:20:58 --> Model Class Initialized
ERROR - 2015-09-29 14:20:58 --> Severity: Notice  --> Undefined variable: loans_plan_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 95
ERROR - 2015-09-29 14:20:58 --> Severity: Notice  --> Undefined variable: loans_plan_min_opening_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 103
ERROR - 2015-09-29 14:20:58 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 111
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 119
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 127
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 135
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 138
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 174
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 181
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 188
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 195
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 202
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 209
ERROR - 2015-09-29 14:20:59 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 216
DEBUG - 2015-09-29 14:20:59 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:20:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:20:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:20:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:20:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:20:59 --> Final output sent to browser
DEBUG - 2015-09-29 14:20:59 --> Total execution time: 0.3753
DEBUG - 2015-09-29 14:21:01 --> Config Class Initialized
DEBUG - 2015-09-29 14:21:01 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:21:01 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:21:01 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:21:01 --> URI Class Initialized
DEBUG - 2015-09-29 14:21:01 --> Router Class Initialized
ERROR - 2015-09-29 14:21:01 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:22:24 --> Config Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:22:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:22:24 --> URI Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Router Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Output Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Security Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Input Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:22:24 --> Language Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Language Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Config Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Loader Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:22:24 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:22:24 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:22:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:22:24 --> Session Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:22:24 --> Session routines successfully run
DEBUG - 2015-09-29 14:22:24 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Email Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Controller Class Initialized
DEBUG - 2015-09-29 14:22:24 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:22:24 --> Model Class Initialized
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 111
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 119
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 127
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 135
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 138
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 174
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 181
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 188
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 195
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 202
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 209
ERROR - 2015-09-29 14:22:24 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 216
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:22:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:22:24 --> Final output sent to browser
DEBUG - 2015-09-29 14:22:24 --> Total execution time: 0.2812
DEBUG - 2015-09-29 14:22:27 --> Config Class Initialized
DEBUG - 2015-09-29 14:22:27 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:22:27 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:22:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:22:27 --> URI Class Initialized
DEBUG - 2015-09-29 14:22:27 --> Router Class Initialized
ERROR - 2015-09-29 14:22:27 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:23:48 --> Config Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:23:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:23:48 --> URI Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Router Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Output Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Security Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Input Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:23:48 --> Language Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Language Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Config Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Loader Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:23:48 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:23:48 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:23:48 --> Session Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:23:48 --> Session routines successfully run
DEBUG - 2015-09-29 14:23:48 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Email Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Controller Class Initialized
DEBUG - 2015-09-29 14:23:48 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:23:48 --> Model Class Initialized
ERROR - 2015-09-29 14:23:48 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 174
ERROR - 2015-09-29 14:23:48 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 181
ERROR - 2015-09-29 14:23:48 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 188
ERROR - 2015-09-29 14:23:48 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 195
ERROR - 2015-09-29 14:23:48 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 202
ERROR - 2015-09-29 14:23:48 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 209
ERROR - 2015-09-29 14:23:48 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\add_loans_plan.php 216
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:23:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:23:48 --> Final output sent to browser
DEBUG - 2015-09-29 14:23:48 --> Total execution time: 0.3378
DEBUG - 2015-09-29 14:23:51 --> Config Class Initialized
DEBUG - 2015-09-29 14:23:51 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:23:51 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:23:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:23:51 --> URI Class Initialized
DEBUG - 2015-09-29 14:23:51 --> Router Class Initialized
ERROR - 2015-09-29 14:23:51 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:25:25 --> Config Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:25:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:25:25 --> URI Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Router Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Output Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Security Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Input Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:25:25 --> Language Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Language Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Config Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Loader Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:25:25 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:25:25 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:25:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:25:25 --> Session Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:25:25 --> Session routines successfully run
DEBUG - 2015-09-29 14:25:25 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Email Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Controller Class Initialized
DEBUG - 2015-09-29 14:25:25 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:25:25 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:25:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:25:25 --> Final output sent to browser
DEBUG - 2015-09-29 14:25:25 --> Total execution time: 0.2883
DEBUG - 2015-09-29 14:25:28 --> Config Class Initialized
DEBUG - 2015-09-29 14:25:28 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:25:28 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:25:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:25:28 --> URI Class Initialized
DEBUG - 2015-09-29 14:25:28 --> Router Class Initialized
ERROR - 2015-09-29 14:25:28 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:25:34 --> Config Class Initialized
DEBUG - 2015-09-29 14:25:34 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:25:34 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:25:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:25:34 --> URI Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Router Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Output Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Security Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Input Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:25:35 --> Language Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Language Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Config Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Loader Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:25:35 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:25:35 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:25:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:25:35 --> Session Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:25:35 --> Session routines successfully run
DEBUG - 2015-09-29 14:25:35 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Email Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Controller Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:25:35 --> Model Class Initialized
DEBUG - 2015-09-29 14:25:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:25:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:25:35 --> Final output sent to browser
DEBUG - 2015-09-29 14:25:35 --> Total execution time: 0.2395
DEBUG - 2015-09-29 14:25:37 --> Config Class Initialized
DEBUG - 2015-09-29 14:25:37 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:25:37 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:25:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:25:37 --> URI Class Initialized
DEBUG - 2015-09-29 14:25:37 --> Router Class Initialized
ERROR - 2015-09-29 14:25:37 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:27:20 --> Config Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:27:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:27:20 --> URI Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Router Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Output Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Security Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Input Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:27:20 --> Language Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Language Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Config Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Loader Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:27:20 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:27:20 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:27:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:27:20 --> Session Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:27:20 --> Session routines successfully run
DEBUG - 2015-09-29 14:27:20 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Email Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Controller Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:27:20 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 14:27:20 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:27:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:27:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:27:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:27:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:27:21 --> Final output sent to browser
DEBUG - 2015-09-29 14:27:21 --> Total execution time: 0.2439
DEBUG - 2015-09-29 14:27:23 --> Config Class Initialized
DEBUG - 2015-09-29 14:27:23 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:27:23 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:27:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:27:23 --> URI Class Initialized
DEBUG - 2015-09-29 14:27:23 --> Router Class Initialized
ERROR - 2015-09-29 14:27:23 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:27:32 --> Config Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:27:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:27:32 --> URI Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Router Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Output Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Security Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Input Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:27:32 --> Language Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Language Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Config Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Loader Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:27:32 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:27:32 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:27:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:27:32 --> Session Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:27:32 --> Session routines successfully run
DEBUG - 2015-09-29 14:27:32 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Email Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Controller Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:27:32 --> Model Class Initialized
DEBUG - 2015-09-29 14:27:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:27:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:27:32 --> Final output sent to browser
DEBUG - 2015-09-29 14:27:32 --> Total execution time: 0.2418
DEBUG - 2015-09-29 14:27:35 --> Config Class Initialized
DEBUG - 2015-09-29 14:27:35 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:27:35 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:27:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:27:35 --> URI Class Initialized
DEBUG - 2015-09-29 14:27:35 --> Router Class Initialized
ERROR - 2015-09-29 14:27:35 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:29:30 --> Config Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:29:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:29:30 --> URI Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Router Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Output Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Security Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Input Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:29:30 --> Language Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Language Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Config Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Loader Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:29:30 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:29:30 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:29:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:29:30 --> Session Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:29:30 --> Session routines successfully run
DEBUG - 2015-09-29 14:29:30 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Email Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Controller Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:29:30 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:29:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:29:30 --> Final output sent to browser
DEBUG - 2015-09-29 14:29:30 --> Total execution time: 0.2288
DEBUG - 2015-09-29 14:29:33 --> Config Class Initialized
DEBUG - 2015-09-29 14:29:33 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:29:33 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:29:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:29:33 --> URI Class Initialized
DEBUG - 2015-09-29 14:29:33 --> Router Class Initialized
ERROR - 2015-09-29 14:29:33 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:29:48 --> Config Class Initialized
DEBUG - 2015-09-29 14:29:48 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:29:48 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:29:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:29:48 --> URI Class Initialized
DEBUG - 2015-09-29 14:29:48 --> Router Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Output Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Security Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Input Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:29:49 --> Language Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Language Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Config Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Loader Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:29:49 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:29:49 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:29:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:29:49 --> Session Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:29:49 --> Session routines successfully run
DEBUG - 2015-09-29 14:29:49 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Email Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Controller Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:29:49 --> Model Class Initialized
DEBUG - 2015-09-29 14:29:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:29:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:29:49 --> Final output sent to browser
DEBUG - 2015-09-29 14:29:49 --> Total execution time: 0.2726
DEBUG - 2015-09-29 14:29:52 --> Config Class Initialized
DEBUG - 2015-09-29 14:29:52 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:29:52 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:29:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:29:52 --> URI Class Initialized
DEBUG - 2015-09-29 14:29:52 --> Router Class Initialized
ERROR - 2015-09-29 14:29:52 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:30:03 --> Config Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:30:03 --> URI Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Router Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Output Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Security Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Input Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:30:03 --> Language Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Language Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Config Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Loader Class Initialized
DEBUG - 2015-09-29 14:30:03 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:30:03 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:30:04 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:30:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:30:04 --> Session Class Initialized
DEBUG - 2015-09-29 14:30:04 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:30:04 --> Session routines successfully run
DEBUG - 2015-09-29 14:30:04 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:30:04 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:30:04 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:30:04 --> Email Class Initialized
DEBUG - 2015-09-29 14:30:04 --> Controller Class Initialized
DEBUG - 2015-09-29 14:30:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:30:04 --> Model Class Initialized
DEBUG - 2015-09-29 14:30:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:30:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:30:04 --> Final output sent to browser
DEBUG - 2015-09-29 14:30:04 --> Total execution time: 0.2463
DEBUG - 2015-09-29 14:30:06 --> Config Class Initialized
DEBUG - 2015-09-29 14:30:06 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:30:06 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:30:06 --> URI Class Initialized
DEBUG - 2015-09-29 14:30:06 --> Router Class Initialized
ERROR - 2015-09-29 14:30:06 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:33:54 --> Config Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:33:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:33:54 --> URI Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Router Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Output Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Security Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Input Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:33:54 --> Language Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Language Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Config Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Loader Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:33:54 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:33:54 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:33:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:33:54 --> Session Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:33:54 --> Session routines successfully run
DEBUG - 2015-09-29 14:33:54 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Email Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Controller Class Initialized
DEBUG - 2015-09-29 14:33:54 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:33:54 --> Model Class Initialized
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:33:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:33:54 --> Final output sent to browser
DEBUG - 2015-09-29 14:33:54 --> Total execution time: 0.2284
DEBUG - 2015-09-29 14:33:56 --> Config Class Initialized
DEBUG - 2015-09-29 14:33:56 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:33:56 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:33:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:33:56 --> URI Class Initialized
DEBUG - 2015-09-29 14:33:56 --> Router Class Initialized
ERROR - 2015-09-29 14:33:56 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 14:51:37 --> Config Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:51:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:51:37 --> URI Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Router Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Output Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Security Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Input Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:51:37 --> Language Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Language Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Config Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Loader Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:51:37 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:51:37 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:51:37 --> Session Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:51:37 --> Session routines successfully run
DEBUG - 2015-09-29 14:51:37 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Email Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Controller Class Initialized
DEBUG - 2015-09-29 14:51:37 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:51:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:51:37 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Config Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:53:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:53:51 --> URI Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Router Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Output Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Security Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Input Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:53:51 --> Language Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Language Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Config Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Loader Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:53:51 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:53:51 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:53:51 --> Session Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:53:51 --> Session routines successfully run
DEBUG - 2015-09-29 14:53:51 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Email Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Controller Class Initialized
DEBUG - 2015-09-29 14:53:51 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:53:51 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:53:51 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:53:51 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:53:51 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:53:51 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:53:51 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:53:51 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:53:51 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:53:52 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:53:52 --> Model Class Initialized
DEBUG - 2015-09-29 14:53:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:53:52 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Config Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:54:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:54:28 --> URI Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Router Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Output Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Security Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Input Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:54:28 --> Language Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Language Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Config Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Loader Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:54:28 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:54:28 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:54:28 --> Session Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:54:28 --> Session routines successfully run
DEBUG - 2015-09-29 14:54:28 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Email Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Controller Class Initialized
DEBUG - 2015-09-29 14:54:28 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:54:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:54:28 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Config Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:55:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:55:23 --> URI Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Router Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Output Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Security Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Input Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 14:55:23 --> Language Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Language Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Config Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Loader Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Helper loaded: url_helper
DEBUG - 2015-09-29 14:55:23 --> Helper loaded: form_helper
DEBUG - 2015-09-29 14:55:23 --> Database Driver Class Initialized
ERROR - 2015-09-29 14:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 14:55:23 --> Session Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Helper loaded: string_helper
DEBUG - 2015-09-29 14:55:23 --> Session routines successfully run
DEBUG - 2015-09-29 14:55:23 --> Form Validation Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Pagination Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Encrypt Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Email Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Controller Class Initialized
DEBUG - 2015-09-29 14:55:23 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 14:55:23 --> Model Class Initialized
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 14:55:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 14:55:23 --> Final output sent to browser
DEBUG - 2015-09-29 14:55:23 --> Total execution time: 0.2649
DEBUG - 2015-09-29 14:55:25 --> Config Class Initialized
DEBUG - 2015-09-29 14:55:25 --> Hooks Class Initialized
DEBUG - 2015-09-29 14:55:25 --> Utf8 Class Initialized
DEBUG - 2015-09-29 14:55:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 14:55:25 --> URI Class Initialized
DEBUG - 2015-09-29 14:55:25 --> Router Class Initialized
ERROR - 2015-09-29 14:55:25 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:19:18 --> Config Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:19:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:19:18 --> URI Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Router Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Output Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Security Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Input Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:19:18 --> Language Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Language Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Config Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Loader Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:19:18 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:19:18 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:19:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:19:18 --> Session Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:19:18 --> Session routines successfully run
DEBUG - 2015-09-29 15:19:18 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Email Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Controller Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:19:18 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:19:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:19:18 --> Final output sent to browser
DEBUG - 2015-09-29 15:19:18 --> Total execution time: 0.2487
DEBUG - 2015-09-29 15:19:21 --> Config Class Initialized
DEBUG - 2015-09-29 15:19:21 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:19:21 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:19:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:19:21 --> URI Class Initialized
DEBUG - 2015-09-29 15:19:21 --> Router Class Initialized
ERROR - 2015-09-29 15:19:21 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:19:41 --> Config Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:19:41 --> URI Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Router Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Output Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Security Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Input Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:19:41 --> Language Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Language Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Config Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Loader Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:19:41 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:19:41 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:19:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:19:41 --> Session Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:19:41 --> Session routines successfully run
DEBUG - 2015-09-29 15:19:41 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Email Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Controller Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:19:41 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:19:41 --> DB Transaction Failure
ERROR - 2015-09-29 15:19:41 --> Query error: Unknown column 'loans_plan_min_opening_balance' in 'field list'
DEBUG - 2015-09-29 15:19:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-29 15:19:45 --> Config Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:19:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:19:45 --> URI Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Router Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Output Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Security Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Input Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:19:45 --> Language Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Language Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Config Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Loader Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:19:45 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:19:45 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:19:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:19:45 --> Session Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:19:45 --> Session routines successfully run
DEBUG - 2015-09-29 15:19:45 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Email Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Controller Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:19:45 --> Model Class Initialized
DEBUG - 2015-09-29 15:19:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:19:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:19:45 --> Final output sent to browser
DEBUG - 2015-09-29 15:19:45 --> Total execution time: 0.2809
DEBUG - 2015-09-29 15:19:48 --> Config Class Initialized
DEBUG - 2015-09-29 15:19:48 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:19:48 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:19:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:19:48 --> URI Class Initialized
DEBUG - 2015-09-29 15:19:48 --> Router Class Initialized
ERROR - 2015-09-29 15:19:48 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:20:43 --> Config Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:20:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:20:43 --> URI Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Router Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Output Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Security Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Input Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:20:43 --> Language Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Language Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Config Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Loader Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:20:43 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:20:43 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:20:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:20:43 --> Session Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:20:43 --> Session routines successfully run
DEBUG - 2015-09-29 15:20:43 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Email Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Controller Class Initialized
DEBUG - 2015-09-29 15:20:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:20:43 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:20:43 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:20:43 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:20:43 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:20:43 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:20:43 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:20:44 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:20:44 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:20:44 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:20:44 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:20:44 --> Model Class Initialized
DEBUG - 2015-09-29 15:20:44 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:20:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:20:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:20:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:20:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:20:44 --> Final output sent to browser
DEBUG - 2015-09-29 15:20:44 --> Total execution time: 0.2495
DEBUG - 2015-09-29 15:23:40 --> Config Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:23:40 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:23:40 --> URI Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Router Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Output Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Security Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Input Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:23:40 --> Language Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Language Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Config Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Loader Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:23:40 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:23:40 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:23:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:23:40 --> Session Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:23:40 --> Session routines successfully run
DEBUG - 2015-09-29 15:23:40 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Email Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Controller Class Initialized
DEBUG - 2015-09-29 15:23:40 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:23:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:23:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:23:40 --> Final output sent to browser
DEBUG - 2015-09-29 15:23:40 --> Total execution time: 0.2395
DEBUG - 2015-09-29 15:23:46 --> Config Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:23:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:23:46 --> URI Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Router Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Output Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Security Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Input Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:23:46 --> Language Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Language Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Config Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Loader Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:23:46 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:23:46 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:23:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:23:46 --> Session Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:23:46 --> Session routines successfully run
DEBUG - 2015-09-29 15:23:46 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Email Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Controller Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:23:46 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:23:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:23:46 --> Final output sent to browser
DEBUG - 2015-09-29 15:23:46 --> Total execution time: 0.2441
DEBUG - 2015-09-29 15:23:55 --> Config Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:23:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:23:55 --> URI Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Router Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Output Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Security Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Input Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:23:55 --> Language Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Language Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Config Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Loader Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:23:55 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:23:55 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:23:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:23:55 --> Session Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:23:55 --> Session routines successfully run
DEBUG - 2015-09-29 15:23:55 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Email Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Controller Class Initialized
DEBUG - 2015-09-29 15:23:55 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:23:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:23:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:23:55 --> Final output sent to browser
DEBUG - 2015-09-29 15:23:55 --> Total execution time: 0.2204
DEBUG - 2015-09-29 15:25:24 --> Config Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:25:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:25:24 --> URI Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Router Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Output Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Security Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Input Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:25:24 --> Language Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Language Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Config Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Loader Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:25:24 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:25:24 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:25:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:25:24 --> Session Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:25:24 --> Session routines successfully run
DEBUG - 2015-09-29 15:25:24 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Email Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Controller Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 15:25:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:25:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:25:24 --> Final output sent to browser
DEBUG - 2015-09-29 15:25:24 --> Total execution time: 0.2762
DEBUG - 2015-09-29 15:28:55 --> Config Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:28:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:28:55 --> URI Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Router Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Output Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Security Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Input Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:28:55 --> Language Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Language Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Config Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Loader Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:28:55 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:28:55 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:28:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:28:55 --> Session Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:28:55 --> Session routines successfully run
DEBUG - 2015-09-29 15:28:55 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Email Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Controller Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:28:55 --> Model Class Initialized
DEBUG - 2015-09-29 15:28:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:28:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:28:55 --> Final output sent to browser
DEBUG - 2015-09-29 15:28:55 --> Total execution time: 0.2427
DEBUG - 2015-09-29 15:29:08 --> Config Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:29:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:29:08 --> URI Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Router Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Output Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Security Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Input Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:29:08 --> Language Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Language Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Config Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Loader Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:29:08 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:29:08 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:29:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:29:08 --> Session Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:29:08 --> Session routines successfully run
DEBUG - 2015-09-29 15:29:08 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Email Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Controller Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:29:08 --> Model Class Initialized
DEBUG - 2015-09-29 15:29:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:29:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:29:08 --> Final output sent to browser
DEBUG - 2015-09-29 15:29:08 --> Total execution time: 0.2363
DEBUG - 2015-09-29 15:30:35 --> Config Class Initialized
DEBUG - 2015-09-29 15:30:35 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:30:35 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:30:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:30:35 --> URI Class Initialized
DEBUG - 2015-09-29 15:30:35 --> Router Class Initialized
ERROR - 2015-09-29 15:30:35 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:31:40 --> Config Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:31:40 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:31:40 --> URI Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Router Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Output Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Security Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Input Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:31:40 --> Language Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Language Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Config Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Loader Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:31:40 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:31:40 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:31:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:31:40 --> Session Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:31:40 --> Session routines successfully run
DEBUG - 2015-09-29 15:31:40 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Email Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Controller Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:31:40 --> Model Class Initialized
DEBUG - 2015-09-29 15:31:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:31:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:31:40 --> Final output sent to browser
DEBUG - 2015-09-29 15:31:40 --> Total execution time: 0.2462
DEBUG - 2015-09-29 15:31:43 --> Config Class Initialized
DEBUG - 2015-09-29 15:31:43 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:31:43 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:31:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:31:43 --> URI Class Initialized
DEBUG - 2015-09-29 15:31:43 --> Router Class Initialized
ERROR - 2015-09-29 15:31:43 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:42:27 --> Config Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:42:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:42:27 --> URI Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Router Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Output Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Security Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Input Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:42:27 --> Language Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Language Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Config Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Loader Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:42:27 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:42:27 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:42:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:42:27 --> Session Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:42:27 --> Session routines successfully run
DEBUG - 2015-09-29 15:42:27 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Email Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Controller Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:42:27 --> Model Class Initialized
DEBUG - 2015-09-29 15:42:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:42:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:42:27 --> Final output sent to browser
DEBUG - 2015-09-29 15:42:27 --> Total execution time: 0.2434
DEBUG - 2015-09-29 15:42:30 --> Config Class Initialized
DEBUG - 2015-09-29 15:42:30 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:42:30 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:42:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:42:30 --> URI Class Initialized
DEBUG - 2015-09-29 15:42:30 --> Router Class Initialized
ERROR - 2015-09-29 15:42:30 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:43:04 --> Config Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:43:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:43:04 --> URI Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Router Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Output Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Security Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Input Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:43:04 --> Language Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Language Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Config Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Loader Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:43:04 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:43:04 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:43:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:43:04 --> Session Class Initialized
DEBUG - 2015-09-29 15:43:04 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:43:04 --> Session routines successfully run
DEBUG - 2015-09-29 15:43:04 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:43:05 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:43:05 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:43:05 --> Email Class Initialized
DEBUG - 2015-09-29 15:43:05 --> Controller Class Initialized
DEBUG - 2015-09-29 15:43:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:43:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:43:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:43:05 --> Final output sent to browser
DEBUG - 2015-09-29 15:43:05 --> Total execution time: 0.2322
DEBUG - 2015-09-29 15:43:07 --> Config Class Initialized
DEBUG - 2015-09-29 15:43:07 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:43:07 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:43:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:43:07 --> URI Class Initialized
DEBUG - 2015-09-29 15:43:07 --> Router Class Initialized
ERROR - 2015-09-29 15:43:07 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:45:07 --> Config Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:45:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:45:07 --> URI Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Router Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Output Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Security Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Input Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:45:07 --> Language Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Language Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Config Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Loader Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:45:07 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:45:07 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:45:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:45:07 --> Session Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:45:07 --> Session routines successfully run
DEBUG - 2015-09-29 15:45:07 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Email Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Controller Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:45:07 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:45:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:45:07 --> Final output sent to browser
DEBUG - 2015-09-29 15:45:07 --> Total execution time: 0.2497
DEBUG - 2015-09-29 15:45:10 --> Config Class Initialized
DEBUG - 2015-09-29 15:45:10 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:45:10 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:45:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:45:10 --> URI Class Initialized
DEBUG - 2015-09-29 15:45:10 --> Router Class Initialized
ERROR - 2015-09-29 15:45:10 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:45:25 --> Config Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:45:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:45:25 --> URI Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Router Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Output Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Security Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Input Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:45:25 --> Language Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Language Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Config Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Loader Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:45:25 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:45:25 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:45:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:45:25 --> Session Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:45:25 --> Session routines successfully run
DEBUG - 2015-09-29 15:45:25 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Email Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Controller Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:45:25 --> Model Class Initialized
DEBUG - 2015-09-29 15:45:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:45:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:45:25 --> Final output sent to browser
DEBUG - 2015-09-29 15:45:25 --> Total execution time: 0.2497
DEBUG - 2015-09-29 15:45:28 --> Config Class Initialized
DEBUG - 2015-09-29 15:45:28 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:45:28 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:45:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:45:28 --> URI Class Initialized
DEBUG - 2015-09-29 15:45:28 --> Router Class Initialized
ERROR - 2015-09-29 15:45:28 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:47:28 --> Config Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:47:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:47:28 --> URI Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Router Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Output Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Security Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Input Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:47:28 --> Language Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Language Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Config Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Loader Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:47:28 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:47:28 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:47:28 --> Session Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:47:28 --> Session routines successfully run
DEBUG - 2015-09-29 15:47:28 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Email Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Controller Class Initialized
DEBUG - 2015-09-29 15:47:28 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:47:28 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:47:28 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:47:28 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:47:28 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:47:29 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:47:29 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:47:29 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:47:29 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:47:29 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:47:29 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:47:29 --> Model Class Initialized
DEBUG - 2015-09-29 15:47:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:47:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:47:29 --> Final output sent to browser
DEBUG - 2015-09-29 15:47:29 --> Total execution time: 0.2613
DEBUG - 2015-09-29 15:47:31 --> Config Class Initialized
DEBUG - 2015-09-29 15:47:31 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:47:31 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:47:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:47:31 --> URI Class Initialized
DEBUG - 2015-09-29 15:47:31 --> Router Class Initialized
ERROR - 2015-09-29 15:47:31 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:49:35 --> Config Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:49:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:49:35 --> URI Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Router Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Output Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Security Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Input Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:49:35 --> Language Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Language Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Config Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Loader Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:49:35 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:49:35 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:49:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:49:35 --> Session Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:49:35 --> Session routines successfully run
DEBUG - 2015-09-29 15:49:35 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Email Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Controller Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:49:35 --> Model Class Initialized
DEBUG - 2015-09-29 15:49:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:49:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:49:35 --> Final output sent to browser
DEBUG - 2015-09-29 15:49:35 --> Total execution time: 0.3163
DEBUG - 2015-09-29 15:49:38 --> Config Class Initialized
DEBUG - 2015-09-29 15:49:38 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:49:38 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:49:38 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:49:38 --> URI Class Initialized
DEBUG - 2015-09-29 15:49:38 --> Router Class Initialized
ERROR - 2015-09-29 15:49:38 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:52:17 --> Config Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:52:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:52:17 --> URI Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Router Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Output Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Security Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Input Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:52:17 --> Language Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Language Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Config Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Loader Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:52:17 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:52:17 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:52:17 --> Session Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:52:17 --> Session routines successfully run
DEBUG - 2015-09-29 15:52:17 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Email Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Controller Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:52:17 --> Model Class Initialized
DEBUG - 2015-09-29 15:52:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:52:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:52:17 --> Final output sent to browser
DEBUG - 2015-09-29 15:52:17 --> Total execution time: 0.2348
DEBUG - 2015-09-29 15:52:20 --> Config Class Initialized
DEBUG - 2015-09-29 15:52:20 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:52:20 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:52:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:52:20 --> URI Class Initialized
DEBUG - 2015-09-29 15:52:20 --> Router Class Initialized
ERROR - 2015-09-29 15:52:20 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:54:30 --> Config Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:54:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:54:30 --> URI Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Router Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Output Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Security Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Input Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:54:30 --> Language Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Language Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Config Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Loader Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:54:30 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:54:30 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:54:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:54:30 --> Session Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:54:30 --> Session routines successfully run
DEBUG - 2015-09-29 15:54:30 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Email Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Controller Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:54:30 --> Model Class Initialized
DEBUG - 2015-09-29 15:54:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:54:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:54:30 --> Final output sent to browser
DEBUG - 2015-09-29 15:54:30 --> Total execution time: 0.2352
DEBUG - 2015-09-29 15:54:33 --> Config Class Initialized
DEBUG - 2015-09-29 15:54:33 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:54:33 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:54:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:54:33 --> URI Class Initialized
DEBUG - 2015-09-29 15:54:33 --> Router Class Initialized
ERROR - 2015-09-29 15:54:33 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:55:06 --> Config Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:55:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:55:06 --> URI Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Router Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Output Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Security Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Input Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:55:06 --> Language Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Language Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Config Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Loader Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:55:06 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:55:06 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:55:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:55:06 --> Session Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:55:06 --> Session routines successfully run
DEBUG - 2015-09-29 15:55:06 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Email Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Controller Class Initialized
DEBUG - 2015-09-29 15:55:06 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:55:06 --> Model Class Initialized
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:55:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:55:06 --> Final output sent to browser
DEBUG - 2015-09-29 15:55:06 --> Total execution time: 0.2151
DEBUG - 2015-09-29 15:55:09 --> Config Class Initialized
DEBUG - 2015-09-29 15:55:09 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:55:09 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:55:09 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:55:09 --> URI Class Initialized
DEBUG - 2015-09-29 15:55:09 --> Router Class Initialized
ERROR - 2015-09-29 15:55:09 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:59:04 --> Config Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:59:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:59:04 --> URI Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Router Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Output Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Security Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Input Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:59:04 --> Language Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Language Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Config Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Loader Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:59:04 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:59:04 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:59:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:59:04 --> Session Class Initialized
DEBUG - 2015-09-29 15:59:04 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:59:04 --> Session routines successfully run
DEBUG - 2015-09-29 15:59:04 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:59:05 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:59:05 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:59:05 --> Email Class Initialized
DEBUG - 2015-09-29 15:59:05 --> Controller Class Initialized
DEBUG - 2015-09-29 15:59:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:59:05 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:59:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:59:05 --> Final output sent to browser
DEBUG - 2015-09-29 15:59:05 --> Total execution time: 0.2276
DEBUG - 2015-09-29 15:59:07 --> Config Class Initialized
DEBUG - 2015-09-29 15:59:07 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:59:07 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:59:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:59:07 --> URI Class Initialized
DEBUG - 2015-09-29 15:59:07 --> Router Class Initialized
ERROR - 2015-09-29 15:59:07 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 15:59:11 --> Config Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:59:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:59:11 --> URI Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Router Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Output Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Security Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Input Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 15:59:11 --> Language Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Language Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Config Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Loader Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Helper loaded: url_helper
DEBUG - 2015-09-29 15:59:11 --> Helper loaded: form_helper
DEBUG - 2015-09-29 15:59:11 --> Database Driver Class Initialized
ERROR - 2015-09-29 15:59:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 15:59:11 --> Session Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Helper loaded: string_helper
DEBUG - 2015-09-29 15:59:11 --> Session routines successfully run
DEBUG - 2015-09-29 15:59:11 --> Form Validation Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Pagination Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Encrypt Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Email Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Controller Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 15:59:11 --> Model Class Initialized
DEBUG - 2015-09-29 15:59:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 15:59:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 15:59:11 --> Final output sent to browser
DEBUG - 2015-09-29 15:59:11 --> Total execution time: 0.2434
DEBUG - 2015-09-29 15:59:14 --> Config Class Initialized
DEBUG - 2015-09-29 15:59:14 --> Hooks Class Initialized
DEBUG - 2015-09-29 15:59:14 --> Utf8 Class Initialized
DEBUG - 2015-09-29 15:59:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 15:59:14 --> URI Class Initialized
DEBUG - 2015-09-29 15:59:14 --> Router Class Initialized
ERROR - 2015-09-29 15:59:14 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:08:10 --> Config Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:08:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:08:10 --> URI Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Router Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Output Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Security Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Input Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:08:10 --> Language Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Language Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Config Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Loader Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:08:10 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:08:10 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:08:10 --> Session Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:08:10 --> Session routines successfully run
DEBUG - 2015-09-29 16:08:10 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Email Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Controller Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:08:10 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:08:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:08:10 --> Final output sent to browser
DEBUG - 2015-09-29 16:08:10 --> Total execution time: 0.2629
DEBUG - 2015-09-29 16:08:13 --> Config Class Initialized
DEBUG - 2015-09-29 16:08:13 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:08:13 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:08:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:08:13 --> URI Class Initialized
DEBUG - 2015-09-29 16:08:13 --> Router Class Initialized
ERROR - 2015-09-29 16:08:13 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:08:24 --> Config Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:08:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:08:24 --> URI Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Router Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Output Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Security Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Input Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:08:24 --> Language Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Language Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Config Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Loader Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:08:24 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:08:24 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:08:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:08:24 --> Session Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:08:24 --> Session routines successfully run
DEBUG - 2015-09-29 16:08:24 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Email Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Controller Class Initialized
DEBUG - 2015-09-29 16:08:24 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:08:24 --> Model Class Initialized
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:08:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:08:24 --> Final output sent to browser
DEBUG - 2015-09-29 16:08:24 --> Total execution time: 0.2140
DEBUG - 2015-09-29 16:08:26 --> Config Class Initialized
DEBUG - 2015-09-29 16:08:26 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:08:26 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:08:26 --> URI Class Initialized
DEBUG - 2015-09-29 16:08:26 --> Router Class Initialized
ERROR - 2015-09-29 16:08:26 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:16:29 --> Config Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:16:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:16:29 --> URI Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Router Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Output Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Security Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Input Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:16:29 --> Language Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Language Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Config Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Loader Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:16:29 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:16:29 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:16:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:16:29 --> Session Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:16:29 --> Session routines successfully run
DEBUG - 2015-09-29 16:16:29 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Email Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Controller Class Initialized
DEBUG - 2015-09-29 16:16:29 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:16:29 --> Model Class Initialized
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:16:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:16:29 --> Final output sent to browser
DEBUG - 2015-09-29 16:16:29 --> Total execution time: 0.2438
DEBUG - 2015-09-29 16:16:31 --> Config Class Initialized
DEBUG - 2015-09-29 16:16:31 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:16:31 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:16:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:16:31 --> URI Class Initialized
DEBUG - 2015-09-29 16:16:31 --> Router Class Initialized
ERROR - 2015-09-29 16:16:31 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:27:33 --> Config Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:27:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:27:33 --> URI Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Router Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Output Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Security Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Input Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:27:33 --> Language Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Language Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Config Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Loader Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:27:33 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:27:33 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:27:33 --> Session Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:27:33 --> Session routines successfully run
DEBUG - 2015-09-29 16:27:33 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Email Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Controller Class Initialized
DEBUG - 2015-09-29 16:27:33 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:27:33 --> Model Class Initialized
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:27:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:27:33 --> Final output sent to browser
DEBUG - 2015-09-29 16:27:33 --> Total execution time: 0.2998
DEBUG - 2015-09-29 16:27:36 --> Config Class Initialized
DEBUG - 2015-09-29 16:27:36 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:27:36 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:27:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:27:36 --> URI Class Initialized
DEBUG - 2015-09-29 16:27:36 --> Router Class Initialized
ERROR - 2015-09-29 16:27:36 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:29:41 --> Config Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:29:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:29:41 --> URI Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Router Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Output Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Security Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Input Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:29:41 --> Language Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Language Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Config Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Loader Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:29:41 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:29:41 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:29:41 --> Session Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:29:41 --> Session routines successfully run
DEBUG - 2015-09-29 16:29:41 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Email Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Controller Class Initialized
DEBUG - 2015-09-29 16:29:41 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:29:42 --> Model Class Initialized
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:29:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:29:42 --> Final output sent to browser
DEBUG - 2015-09-29 16:29:42 --> Total execution time: 0.4356
DEBUG - 2015-09-29 16:29:44 --> Config Class Initialized
DEBUG - 2015-09-29 16:29:44 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:29:44 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:29:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:29:44 --> URI Class Initialized
DEBUG - 2015-09-29 16:29:44 --> Router Class Initialized
ERROR - 2015-09-29 16:29:44 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:34:10 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:10 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:34:10 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:34:10 --> URI Class Initialized
DEBUG - 2015-09-29 16:34:10 --> Router Class Initialized
DEBUG - 2015-09-29 16:34:10 --> Output Class Initialized
DEBUG - 2015-09-29 16:34:10 --> Security Class Initialized
DEBUG - 2015-09-29 16:34:10 --> Input Class Initialized
DEBUG - 2015-09-29 16:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:34:10 --> Language Class Initialized
DEBUG - 2015-09-29 16:34:10 --> Language Class Initialized
DEBUG - 2015-09-29 16:34:10 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:11 --> Loader Class Initialized
DEBUG - 2015-09-29 16:34:11 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:34:11 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:34:11 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:34:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:34:11 --> Session Class Initialized
DEBUG - 2015-09-29 16:34:11 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:34:11 --> Session routines successfully run
DEBUG - 2015-09-29 16:34:11 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:34:11 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:34:11 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:34:11 --> Email Class Initialized
DEBUG - 2015-09-29 16:34:11 --> Controller Class Initialized
DEBUG - 2015-09-29 16:34:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:34:11 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:34:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:34:11 --> Final output sent to browser
DEBUG - 2015-09-29 16:34:11 --> Total execution time: 0.3796
DEBUG - 2015-09-29 16:34:14 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:14 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:34:14 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:34:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:34:14 --> URI Class Initialized
DEBUG - 2015-09-29 16:34:14 --> Router Class Initialized
ERROR - 2015-09-29 16:34:14 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:34:17 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:34:17 --> URI Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Router Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Output Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Security Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Input Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:34:17 --> Language Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Language Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Loader Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:34:17 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:34:17 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:34:17 --> Session Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:34:17 --> Session routines successfully run
DEBUG - 2015-09-29 16:34:17 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Email Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Controller Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:34:17 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:34:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:34:17 --> Final output sent to browser
DEBUG - 2015-09-29 16:34:17 --> Total execution time: 0.2252
DEBUG - 2015-09-29 16:34:19 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:19 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:34:19 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:34:19 --> URI Class Initialized
DEBUG - 2015-09-29 16:34:19 --> Router Class Initialized
ERROR - 2015-09-29 16:34:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:34:30 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:30 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:34:30 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:34:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:34:30 --> URI Class Initialized
DEBUG - 2015-09-29 16:34:30 --> Router Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Output Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Security Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Input Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:34:31 --> Language Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Language Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Loader Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:34:31 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:34:31 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:34:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:34:31 --> Session Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:34:31 --> Session routines successfully run
DEBUG - 2015-09-29 16:34:31 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Email Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Controller Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:34:31 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:34:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:34:31 --> Final output sent to browser
DEBUG - 2015-09-29 16:34:31 --> Total execution time: 0.2424
DEBUG - 2015-09-29 16:34:33 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:33 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:34:33 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:34:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:34:33 --> URI Class Initialized
DEBUG - 2015-09-29 16:34:33 --> Router Class Initialized
ERROR - 2015-09-29 16:34:33 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:34:41 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:34:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:34:41 --> URI Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Router Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Output Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Security Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Input Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:34:41 --> Language Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Language Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Loader Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:34:41 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:34:41 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:34:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:34:41 --> Session Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:34:41 --> Session routines successfully run
DEBUG - 2015-09-29 16:34:41 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Email Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Controller Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:34:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:34:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:34:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:34:41 --> Final output sent to browser
DEBUG - 2015-09-29 16:34:41 --> Total execution time: 0.2431
DEBUG - 2015-09-29 16:34:43 --> Config Class Initialized
DEBUG - 2015-09-29 16:34:43 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:34:43 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:34:43 --> URI Class Initialized
DEBUG - 2015-09-29 16:34:43 --> Router Class Initialized
ERROR - 2015-09-29 16:34:43 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:38:22 --> Config Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:38:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:38:22 --> URI Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Router Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Output Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Security Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Input Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:38:22 --> Language Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Language Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Config Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Loader Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:38:22 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:38:22 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:38:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:38:22 --> Session Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:38:22 --> Session routines successfully run
DEBUG - 2015-09-29 16:38:22 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Email Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Controller Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:38:22 --> Model Class Initialized
DEBUG - 2015-09-29 16:38:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:38:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:38:22 --> Final output sent to browser
DEBUG - 2015-09-29 16:38:22 --> Total execution time: 0.2283
DEBUG - 2015-09-29 16:38:25 --> Config Class Initialized
DEBUG - 2015-09-29 16:38:25 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:38:25 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:38:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:38:25 --> URI Class Initialized
DEBUG - 2015-09-29 16:38:25 --> Router Class Initialized
ERROR - 2015-09-29 16:38:25 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:39:34 --> Config Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:39:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:39:34 --> URI Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Router Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Output Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Security Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Input Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:39:34 --> Language Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Language Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Config Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Loader Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:39:34 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:39:34 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:39:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:39:34 --> Session Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:39:34 --> Session routines successfully run
DEBUG - 2015-09-29 16:39:34 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Email Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Controller Class Initialized
DEBUG - 2015-09-29 16:39:34 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:39:34 --> Model Class Initialized
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:39:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:39:34 --> Final output sent to browser
DEBUG - 2015-09-29 16:39:34 --> Total execution time: 0.2083
DEBUG - 2015-09-29 16:39:36 --> Config Class Initialized
DEBUG - 2015-09-29 16:39:36 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:39:36 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:39:36 --> URI Class Initialized
DEBUG - 2015-09-29 16:39:36 --> Router Class Initialized
ERROR - 2015-09-29 16:39:36 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:51:41 --> Config Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:51:41 --> URI Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Router Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Output Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Security Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Input Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:51:41 --> Language Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Language Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Config Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Loader Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:51:41 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:51:41 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:51:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:51:41 --> Session Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:51:41 --> Session routines successfully run
DEBUG - 2015-09-29 16:51:41 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Email Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Controller Class Initialized
DEBUG - 2015-09-29 16:51:41 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:51:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:51:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:51:42 --> Final output sent to browser
DEBUG - 2015-09-29 16:51:42 --> Total execution time: 0.2290
DEBUG - 2015-09-29 16:51:44 --> Config Class Initialized
DEBUG - 2015-09-29 16:51:44 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:51:44 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:51:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:51:44 --> URI Class Initialized
DEBUG - 2015-09-29 16:51:44 --> Router Class Initialized
ERROR - 2015-09-29 16:51:44 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 16:52:04 --> Config Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:52:04 --> URI Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Router Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Output Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Security Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Input Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 16:52:04 --> Language Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Language Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Config Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Loader Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Helper loaded: url_helper
DEBUG - 2015-09-29 16:52:04 --> Helper loaded: form_helper
DEBUG - 2015-09-29 16:52:04 --> Database Driver Class Initialized
ERROR - 2015-09-29 16:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 16:52:04 --> Session Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Helper loaded: string_helper
DEBUG - 2015-09-29 16:52:04 --> Session routines successfully run
DEBUG - 2015-09-29 16:52:04 --> Form Validation Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Pagination Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Encrypt Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Email Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Controller Class Initialized
DEBUG - 2015-09-29 16:52:04 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 16:52:04 --> Model Class Initialized
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 16:52:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 16:52:04 --> Final output sent to browser
DEBUG - 2015-09-29 16:52:04 --> Total execution time: 0.2242
DEBUG - 2015-09-29 16:52:07 --> Config Class Initialized
DEBUG - 2015-09-29 16:52:07 --> Hooks Class Initialized
DEBUG - 2015-09-29 16:52:07 --> Utf8 Class Initialized
DEBUG - 2015-09-29 16:52:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 16:52:07 --> URI Class Initialized
DEBUG - 2015-09-29 16:52:07 --> Router Class Initialized
ERROR - 2015-09-29 16:52:07 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 17:55:43 --> Config Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Hooks Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Utf8 Class Initialized
DEBUG - 2015-09-29 17:55:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 17:55:43 --> URI Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Router Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Output Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Security Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Input Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 17:55:43 --> Language Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Language Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Config Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Loader Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Helper loaded: url_helper
DEBUG - 2015-09-29 17:55:43 --> Helper loaded: form_helper
DEBUG - 2015-09-29 17:55:43 --> Database Driver Class Initialized
ERROR - 2015-09-29 17:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 17:55:43 --> Session Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Helper loaded: string_helper
DEBUG - 2015-09-29 17:55:43 --> Session routines successfully run
DEBUG - 2015-09-29 17:55:43 --> Form Validation Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Pagination Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Encrypt Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Email Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Controller Class Initialized
DEBUG - 2015-09-29 17:55:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 17:55:43 --> Model Class Initialized
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 17:55:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 17:55:44 --> Final output sent to browser
DEBUG - 2015-09-29 17:55:44 --> Total execution time: 0.1452
DEBUG - 2015-09-29 18:01:51 --> Config Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:01:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:01:51 --> URI Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Router Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Output Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Security Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Input Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:01:51 --> Language Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Language Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Config Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Loader Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:01:51 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:01:51 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:01:51 --> Session Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:01:51 --> Session routines successfully run
DEBUG - 2015-09-29 18:01:51 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Email Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Controller Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:01:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:01:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:01:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:01:51 --> Final output sent to browser
DEBUG - 2015-09-29 18:01:51 --> Total execution time: 0.1642
DEBUG - 2015-09-29 18:03:30 --> Config Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:03:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:03:30 --> URI Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Router Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Output Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Security Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Input Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:03:30 --> Language Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Language Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Config Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Loader Class Initialized
DEBUG - 2015-09-29 18:03:30 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:03:30 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:03:30 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:03:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:03:31 --> Session Class Initialized
DEBUG - 2015-09-29 18:03:31 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:03:31 --> Session routines successfully run
DEBUG - 2015-09-29 18:03:31 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:03:31 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:03:31 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:03:31 --> Email Class Initialized
DEBUG - 2015-09-29 18:03:31 --> Controller Class Initialized
DEBUG - 2015-09-29 18:03:31 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:03:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:03:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 18:03:31 --> Unable to find validation rule: alpha_numeric_spaces
DEBUG - 2015-09-29 18:06:34 --> Config Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:06:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:06:34 --> URI Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Router Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Output Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Security Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Input Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:06:34 --> Language Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Language Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Config Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Loader Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:06:34 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:06:34 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:06:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:06:34 --> Session Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:06:34 --> Session routines successfully run
DEBUG - 2015-09-29 18:06:34 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Email Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Controller Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:06:34 --> Model Class Initialized
DEBUG - 2015-09-29 18:06:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 18:06:34 --> Unable to find validation rule: alpha_numeric_spaces
DEBUG - 2015-09-29 18:07:26 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:26 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:07:26 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:07:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:07:26 --> URI Class Initialized
DEBUG - 2015-09-29 18:07:26 --> Router Class Initialized
DEBUG - 2015-09-29 18:07:26 --> Output Class Initialized
DEBUG - 2015-09-29 18:07:26 --> Security Class Initialized
DEBUG - 2015-09-29 18:07:26 --> Input Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:07:27 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Loader Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:07:27 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:07:27 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:07:27 --> Session Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:07:27 --> Session routines successfully run
DEBUG - 2015-09-29 18:07:27 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Email Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Controller Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 18:07:27 --> Unable to find validation rule: alpha_numeric_spaces
DEBUG - 2015-09-29 18:07:27 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:07:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:07:27 --> URI Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Router Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Output Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Security Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Input Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:07:27 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Loader Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:07:27 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:07:27 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:07:27 --> Session Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:07:27 --> Session routines successfully run
DEBUG - 2015-09-29 18:07:27 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Email Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Controller Class Initialized
DEBUG - 2015-09-29 18:07:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:07:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:07:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:07:27 --> Final output sent to browser
DEBUG - 2015-09-29 18:07:27 --> Total execution time: 0.1286
DEBUG - 2015-09-29 18:07:43 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:07:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:07:43 --> URI Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Router Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Output Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Security Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Input Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:07:43 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Loader Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:07:43 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:07:43 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:07:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:07:43 --> Session Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:07:43 --> Session routines successfully run
DEBUG - 2015-09-29 18:07:43 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Email Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Controller Class Initialized
DEBUG - 2015-09-29 18:07:43 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:07:43 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:07:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:07:43 --> Final output sent to browser
DEBUG - 2015-09-29 18:07:43 --> Total execution time: 0.1304
DEBUG - 2015-09-29 18:07:46 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:07:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:07:46 --> URI Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Router Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Output Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Security Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Input Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:07:46 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Loader Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:07:46 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:07:46 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:07:46 --> Session Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:07:46 --> Session routines successfully run
DEBUG - 2015-09-29 18:07:46 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Email Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Controller Class Initialized
DEBUG - 2015-09-29 18:07:46 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:07:46 --> Model Class Initialized
ERROR - 2015-09-29 18:07:46 --> 404 Page Not Found --> microfinance/edit-savings_plan
DEBUG - 2015-09-29 18:07:51 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:07:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:07:51 --> URI Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Router Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Output Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Security Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Input Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:07:51 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Loader Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:07:51 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:07:51 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:07:51 --> Session Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:07:51 --> Session routines successfully run
DEBUG - 2015-09-29 18:07:51 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Email Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Controller Class Initialized
DEBUG - 2015-09-29 18:07:51 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:07:51 --> Model Class Initialized
ERROR - 2015-09-29 18:07:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-29 18:07:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-29 18:07:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-29 18:07:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-29 18:07:51 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/microfinance/views/savings_plan/add_savings_plan.php
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:07:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:07:51 --> Final output sent to browser
DEBUG - 2015-09-29 18:07:51 --> Total execution time: 0.1351
DEBUG - 2015-09-29 18:07:58 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:07:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:07:58 --> URI Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Router Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Output Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Security Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Input Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:07:58 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Language Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Config Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Loader Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:07:58 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:07:58 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:07:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:07:58 --> Session Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:07:58 --> Session routines successfully run
DEBUG - 2015-09-29 18:07:58 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Email Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Controller Class Initialized
DEBUG - 2015-09-29 18:07:58 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:07:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:07:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:07:58 --> Final output sent to browser
DEBUG - 2015-09-29 18:07:58 --> Total execution time: 0.1296
DEBUG - 2015-09-29 18:24:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:24:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:24:57 --> URI Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Router Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Output Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Security Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Input Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:24:57 --> Language Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Language Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Loader Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:24:57 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:24:57 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:24:57 --> Session Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:24:57 --> Session routines successfully run
DEBUG - 2015-09-29 18:24:57 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Email Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Controller Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Auth MX_Controller Initialized
DEBUG - 2015-09-29 18:24:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:24:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:24:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:24:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:24:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:24:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:24:57 --> URI Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Router Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Output Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Security Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Input Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:24:57 --> Language Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Language Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Loader Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:24:57 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:24:57 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:24:57 --> Session Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:24:57 --> A session cookie was not found.
DEBUG - 2015-09-29 18:24:57 --> Session routines successfully run
DEBUG - 2015-09-29 18:24:57 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Email Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Controller Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Auth MX_Controller Initialized
DEBUG - 2015-09-29 18:24:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:24:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:24:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:24:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:24:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:24:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:24:57 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-29 18:24:57 --> Final output sent to browser
DEBUG - 2015-09-29 18:24:57 --> Total execution time: 0.0963
DEBUG - 2015-09-29 18:24:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:24:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:24:57 --> URI Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:24:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:24:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:24:57 --> URI Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Router Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:24:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:24:57 --> Router Class Initialized
DEBUG - 2015-09-29 18:24:57 --> URI Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Router Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:24:57 --> Hooks Class Initialized
ERROR - 2015-09-29 18:24:57 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 18:24:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:24:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:24:57 --> URI Class Initialized
ERROR - 2015-09-29 18:24:57 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 18:24:57 --> Router Class Initialized
ERROR - 2015-09-29 18:24:57 --> 404 Page Not Found --> 
ERROR - 2015-09-29 18:24:57 --> 404 Page Not Found --> 
DEBUG - 2015-09-29 18:25:13 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:25:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:25:13 --> URI Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Router Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Output Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Security Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Input Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:25:13 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Loader Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:25:13 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:25:13 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:25:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:25:13 --> Session Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:25:13 --> Session routines successfully run
DEBUG - 2015-09-29 18:25:13 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Email Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Controller Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Auth MX_Controller Initialized
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 18:25:13 --> XSS Filtering completed
DEBUG - 2015-09-29 18:25:13 --> Unable to find validation rule: exists
DEBUG - 2015-09-29 18:25:13 --> XSS Filtering completed
DEBUG - 2015-09-29 18:25:13 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:25:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:25:13 --> URI Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Router Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Output Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Security Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Input Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:25:13 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Loader Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:25:13 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:25:13 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:25:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:25:13 --> Session Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:25:13 --> Session routines successfully run
DEBUG - 2015-09-29 18:25:13 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Email Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Controller Class Initialized
DEBUG - 2015-09-29 18:25:13 --> Admin MX_Controller Initialized
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-29 18:25:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:25:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:25:13 --> Final output sent to browser
DEBUG - 2015-09-29 18:25:13 --> Total execution time: 0.1390
DEBUG - 2015-09-29 18:25:20 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:25:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:25:20 --> URI Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Router Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Output Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Security Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Input Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:25:20 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Loader Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:25:20 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:25:20 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:25:20 --> Session Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:25:20 --> Session routines successfully run
DEBUG - 2015-09-29 18:25:20 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Email Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Controller Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Branches MX_Controller Initialized
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:25:20 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:20 --> Image Lib Class Initialized
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/views/branches/all_branches.php
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:25:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:25:20 --> Final output sent to browser
DEBUG - 2015-09-29 18:25:20 --> Total execution time: 0.1252
DEBUG - 2015-09-29 18:25:24 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:25:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:25:24 --> URI Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Router Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Output Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Security Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Input Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:25:24 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Loader Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:25:24 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:25:24 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:25:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:25:24 --> Session Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:25:24 --> Session routines successfully run
DEBUG - 2015-09-29 18:25:24 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Email Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Controller Class Initialized
DEBUG - 2015-09-29 18:25:24 --> Admin MX_Controller Initialized
DEBUG - 2015-09-29 18:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-29 18:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-29 18:25:24 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/admin/views/configuration.php
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:25:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:25:24 --> Final output sent to browser
DEBUG - 2015-09-29 18:25:24 --> Total execution time: 0.1098
DEBUG - 2015-09-29 18:25:31 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:25:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:25:31 --> URI Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Router Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Output Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Security Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Input Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:25:31 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Loader Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:25:31 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:25:31 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:25:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:25:31 --> Session Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:25:31 --> Session routines successfully run
DEBUG - 2015-09-29 18:25:31 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Email Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Controller Class Initialized
DEBUG - 2015-09-29 18:25:31 --> Sections MX_Controller Initialized
DEBUG - 2015-09-29 18:25:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:25:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:25:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:25:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-29 18:25:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:25:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-29 18:25:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:25:31 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:25:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:25:31 --> Final output sent to browser
DEBUG - 2015-09-29 18:25:31 --> Total execution time: 0.1247
DEBUG - 2015-09-29 18:25:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:25:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:25:57 --> URI Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Router Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Output Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Security Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Input Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:25:57 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Language Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Loader Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:25:57 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:25:57 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:25:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:25:57 --> Session Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:25:57 --> Session routines successfully run
DEBUG - 2015-09-29 18:25:57 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Email Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Controller Class Initialized
DEBUG - 2015-09-29 18:25:57 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
DEBUG - 2015-09-29 18:25:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:25:57 --> Model Class Initialized
ERROR - 2015-09-29 18:25:57 --> 404 Page Not Found --> microfinance/deposits
DEBUG - 2015-09-29 18:26:05 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:26:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:26:05 --> URI Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Router Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Output Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Security Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Input Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:26:05 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Loader Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:26:05 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:26:05 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:26:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:26:05 --> Session Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:26:05 --> Session routines successfully run
DEBUG - 2015-09-29 18:26:05 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Email Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Controller Class Initialized
DEBUG - 2015-09-29 18:26:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:26:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:26:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:26:05 --> Final output sent to browser
DEBUG - 2015-09-29 18:26:05 --> Total execution time: 0.1579
DEBUG - 2015-09-29 18:26:09 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:26:09 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:26:09 --> URI Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Router Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Output Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Security Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Input Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:26:09 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Loader Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:26:09 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:26:09 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:26:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:26:09 --> Session Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:26:09 --> Session routines successfully run
DEBUG - 2015-09-29 18:26:09 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Email Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Controller Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Individual MX_Controller Initialized
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:26:09 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:09 --> Image Lib Class Initialized
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:26:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:26:09 --> Final output sent to browser
DEBUG - 2015-09-29 18:26:09 --> Total execution time: 0.1353
DEBUG - 2015-09-29 18:26:13 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:26:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:26:13 --> URI Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Router Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Output Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Security Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Input Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:26:13 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Loader Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:26:13 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:26:13 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:26:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:26:13 --> Session Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:26:13 --> Session routines successfully run
DEBUG - 2015-09-29 18:26:13 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Email Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Controller Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Individual MX_Controller Initialized
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:26:13 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:13 --> Image Lib Class Initialized
DEBUG - 2015-09-29 18:26:13 --> DB Transaction Failure
ERROR - 2015-09-29 18:26:13 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-09-29 18:26:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-29 18:26:17 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:26:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:26:17 --> URI Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Router Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Output Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Security Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Input Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:26:17 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Loader Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:26:17 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:26:17 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:26:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:26:17 --> Session Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:26:17 --> Session routines successfully run
DEBUG - 2015-09-29 18:26:17 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Email Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Controller Class Initialized
DEBUG - 2015-09-29 18:26:17 --> Individual MX_Controller Initialized
DEBUG - 2015-09-29 18:26:17 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:26:17 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:26:17 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:26:17 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:26:17 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:26:17 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:26:17 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:26:18 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:26:18 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:26:18 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:26:18 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:18 --> Image Lib Class Initialized
DEBUG - 2015-09-29 18:26:18 --> DB Transaction Failure
ERROR - 2015-09-29 18:26:18 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-09-29 18:26:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-29 18:26:30 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:26:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:26:30 --> URI Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Router Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Output Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Security Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Input Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:26:30 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Loader Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:26:30 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:26:30 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:26:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:26:30 --> Session Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:26:30 --> Session routines successfully run
DEBUG - 2015-09-29 18:26:30 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Email Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Controller Class Initialized
DEBUG - 2015-09-29 18:26:30 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:26:30 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:26:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:26:30 --> Final output sent to browser
DEBUG - 2015-09-29 18:26:30 --> Total execution time: 0.1311
DEBUG - 2015-09-29 18:26:32 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:26:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:26:32 --> URI Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Router Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Output Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Security Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Input Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:26:32 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Loader Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:26:32 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:26:32 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:26:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:26:32 --> Session Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:26:32 --> Session routines successfully run
DEBUG - 2015-09-29 18:26:32 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Email Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Controller Class Initialized
DEBUG - 2015-09-29 18:26:32 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:26:32 --> Model Class Initialized
ERROR - 2015-09-29 18:26:32 --> 404 Page Not Found --> microfinance/edit-savings_plan
DEBUG - 2015-09-29 18:26:36 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:26:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:26:36 --> URI Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Router Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Output Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Security Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Input Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:26:36 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Loader Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:26:36 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:26:36 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:26:36 --> Session Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:26:36 --> Session routines successfully run
DEBUG - 2015-09-29 18:26:36 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Email Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Controller Class Initialized
DEBUG - 2015-09-29 18:26:36 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:26:36 --> Model Class Initialized
ERROR - 2015-09-29 18:26:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-29 18:26:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-29 18:26:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-29 18:26:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-29 18:26:36 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/microfinance/views/savings_plan/add_savings_plan.php
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:26:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:26:36 --> Final output sent to browser
DEBUG - 2015-09-29 18:26:36 --> Total execution time: 0.1336
DEBUG - 2015-09-29 18:26:51 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:26:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:26:51 --> URI Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Router Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Output Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Security Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Input Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:26:51 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Language Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Config Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Loader Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:26:51 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:26:51 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:26:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:26:51 --> Session Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:26:51 --> Session routines successfully run
DEBUG - 2015-09-29 18:26:51 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Email Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Controller Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Individual MX_Controller Initialized
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:26:51 --> Model Class Initialized
DEBUG - 2015-09-29 18:26:51 --> Image Lib Class Initialized
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:26:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:26:51 --> Final output sent to browser
DEBUG - 2015-09-29 18:26:51 --> Total execution time: 0.1581
DEBUG - 2015-09-29 18:27:05 --> Config Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:27:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:27:05 --> URI Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Router Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Output Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Security Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Input Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:27:05 --> Language Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Language Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Config Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Loader Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:27:05 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:27:05 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:27:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:27:05 --> Session Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:27:05 --> Session routines successfully run
DEBUG - 2015-09-29 18:27:05 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Email Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Controller Class Initialized
DEBUG - 2015-09-29 18:27:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:27:05 --> Model Class Initialized
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:27:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:27:05 --> Final output sent to browser
DEBUG - 2015-09-29 18:27:05 --> Total execution time: 0.1407
DEBUG - 2015-09-29 18:29:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:29:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:29:57 --> URI Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Router Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Output Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Security Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Input Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:29:57 --> Language Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Language Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Config Class Initialized
DEBUG - 2015-09-29 18:29:57 --> Loader Class Initialized
DEBUG - 2015-09-29 18:29:58 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:29:58 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:29:58 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:29:58 --> Session Class Initialized
DEBUG - 2015-09-29 18:29:58 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:29:58 --> Session routines successfully run
DEBUG - 2015-09-29 18:29:58 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:29:58 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:29:58 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:29:58 --> Email Class Initialized
DEBUG - 2015-09-29 18:29:58 --> Controller Class Initialized
DEBUG - 2015-09-29 18:29:58 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:29:58 --> Model Class Initialized
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:29:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:29:58 --> Final output sent to browser
DEBUG - 2015-09-29 18:29:58 --> Total execution time: 0.1291
DEBUG - 2015-09-29 18:30:23 --> Config Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:30:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:30:23 --> URI Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Router Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Output Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Security Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Input Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:30:23 --> Language Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Language Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Config Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Loader Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:30:23 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:30:23 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:30:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:30:23 --> Session Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:30:23 --> Session routines successfully run
DEBUG - 2015-09-29 18:30:23 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Email Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Controller Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Individual MX_Controller Initialized
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:30:23 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:23 --> Image Lib Class Initialized
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:30:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:30:23 --> Final output sent to browser
DEBUG - 2015-09-29 18:30:23 --> Total execution time: 0.1349
DEBUG - 2015-09-29 18:30:27 --> Config Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:30:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:30:27 --> URI Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Router Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Output Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Security Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Input Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:30:27 --> Language Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Language Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Config Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Loader Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:30:27 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:30:27 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:30:27 --> Session Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:30:27 --> Session routines successfully run
DEBUG - 2015-09-29 18:30:27 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Email Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Controller Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Individual MX_Controller Initialized
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:30:27 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:27 --> Image Lib Class Initialized
DEBUG - 2015-09-29 18:30:27 --> DB Transaction Failure
ERROR - 2015-09-29 18:30:27 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-09-29 18:30:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-29 18:30:32 --> Config Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:30:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:30:32 --> URI Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Router Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Output Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Security Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Input Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:30:32 --> Language Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Language Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Config Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Loader Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:30:32 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:30:32 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:30:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:30:32 --> Session Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:30:32 --> Session routines successfully run
DEBUG - 2015-09-29 18:30:32 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Email Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Controller Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Individual MX_Controller Initialized
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:30:32 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:32 --> Image Lib Class Initialized
DEBUG - 2015-09-29 18:30:32 --> DB Transaction Failure
ERROR - 2015-09-29 18:30:32 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-09-29 18:30:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-29 18:30:34 --> Config Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:30:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:30:34 --> URI Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Router Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Output Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Security Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Input Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:30:34 --> Language Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Language Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Config Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Loader Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:30:34 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:30:34 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:30:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:30:34 --> Session Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:30:34 --> Session routines successfully run
DEBUG - 2015-09-29 18:30:34 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Email Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Controller Class Initialized
DEBUG - 2015-09-29 18:30:34 --> Individual MX_Controller Initialized
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:30:35 --> Model Class Initialized
DEBUG - 2015-09-29 18:30:35 --> Image Lib Class Initialized
DEBUG - 2015-09-29 18:30:35 --> DB Transaction Failure
ERROR - 2015-09-29 18:30:35 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-09-29 18:30:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-29 18:31:06 --> Config Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Hooks Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Utf8 Class Initialized
DEBUG - 2015-09-29 18:31:06 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 18:31:06 --> URI Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Router Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Output Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Security Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Input Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 18:31:06 --> Language Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Language Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Config Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Loader Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Helper loaded: url_helper
DEBUG - 2015-09-29 18:31:06 --> Helper loaded: form_helper
DEBUG - 2015-09-29 18:31:06 --> Database Driver Class Initialized
ERROR - 2015-09-29 18:31:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-29 18:31:06 --> Session Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Helper loaded: string_helper
DEBUG - 2015-09-29 18:31:06 --> Session routines successfully run
DEBUG - 2015-09-29 18:31:06 --> Form Validation Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Pagination Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Encrypt Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Email Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Controller Class Initialized
DEBUG - 2015-09-29 18:31:06 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-29 18:31:06 --> Model Class Initialized
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-29 18:31:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-29 18:31:06 --> Final output sent to browser
DEBUG - 2015-09-29 18:31:06 --> Total execution time: 0.1324
