<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-04 16:57:22 --> Config Class Initialized
DEBUG - 2015-12-04 16:57:22 --> Hooks Class Initialized
DEBUG - 2015-12-04 16:57:22 --> Utf8 Class Initialized
DEBUG - 2015-12-04 16:57:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 16:57:22 --> URI Class Initialized
DEBUG - 2015-12-04 16:57:22 --> Router Class Initialized
ERROR - 2015-12-04 16:57:22 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 16:58:07 --> Config Class Initialized
DEBUG - 2015-12-04 16:58:07 --> Hooks Class Initialized
DEBUG - 2015-12-04 16:58:07 --> Utf8 Class Initialized
DEBUG - 2015-12-04 16:58:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 16:58:07 --> URI Class Initialized
DEBUG - 2015-12-04 16:58:07 --> Router Class Initialized
ERROR - 2015-12-04 16:58:07 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 16:58:09 --> Config Class Initialized
DEBUG - 2015-12-04 16:58:09 --> Hooks Class Initialized
DEBUG - 2015-12-04 16:58:09 --> Utf8 Class Initialized
DEBUG - 2015-12-04 16:58:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 16:58:09 --> URI Class Initialized
DEBUG - 2015-12-04 16:58:09 --> Router Class Initialized
ERROR - 2015-12-04 16:58:09 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 16:59:06 --> Config Class Initialized
DEBUG - 2015-12-04 16:59:06 --> Hooks Class Initialized
DEBUG - 2015-12-04 16:59:06 --> Utf8 Class Initialized
DEBUG - 2015-12-04 16:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 16:59:06 --> URI Class Initialized
DEBUG - 2015-12-04 16:59:06 --> Router Class Initialized
ERROR - 2015-12-04 16:59:06 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 16:59:08 --> Config Class Initialized
DEBUG - 2015-12-04 16:59:08 --> Hooks Class Initialized
DEBUG - 2015-12-04 16:59:08 --> Utf8 Class Initialized
DEBUG - 2015-12-04 16:59:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 16:59:08 --> URI Class Initialized
DEBUG - 2015-12-04 16:59:08 --> Router Class Initialized
ERROR - 2015-12-04 16:59:08 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 16:59:13 --> Config Class Initialized
DEBUG - 2015-12-04 16:59:13 --> Hooks Class Initialized
DEBUG - 2015-12-04 16:59:13 --> Utf8 Class Initialized
DEBUG - 2015-12-04 16:59:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 16:59:13 --> URI Class Initialized
DEBUG - 2015-12-04 16:59:13 --> Router Class Initialized
ERROR - 2015-12-04 16:59:13 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:00:15 --> Config Class Initialized
DEBUG - 2015-12-04 17:00:15 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:00:15 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:00:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:00:15 --> URI Class Initialized
DEBUG - 2015-12-04 17:00:15 --> Router Class Initialized
ERROR - 2015-12-04 17:00:15 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:01:03 --> Config Class Initialized
DEBUG - 2015-12-04 17:01:03 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:01:03 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:01:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:01:03 --> URI Class Initialized
DEBUG - 2015-12-04 17:01:03 --> Router Class Initialized
ERROR - 2015-12-04 17:01:03 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:01:21 --> Config Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:01:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:01:21 --> URI Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Router Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Output Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Security Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Input Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 17:01:21 --> Language Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Language Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Config Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Loader Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Helper loaded: url_helper
DEBUG - 2015-12-04 17:01:21 --> Helper loaded: form_helper
DEBUG - 2015-12-04 17:01:21 --> Database Driver Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Session Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Helper loaded: string_helper
DEBUG - 2015-12-04 17:01:21 --> Session routines successfully run
DEBUG - 2015-12-04 17:01:21 --> Form Validation Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Pagination Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Encrypt Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Email Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Controller Class Initialized
DEBUG - 2015-12-04 17:01:21 --> Individual MX_Controller Initialized
DEBUG - 2015-12-04 17:01:21 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 17:01:21 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Config Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:01:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:01:22 --> URI Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Router Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Output Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Security Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Input Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 17:01:22 --> Language Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Language Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Config Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Loader Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Helper loaded: url_helper
DEBUG - 2015-12-04 17:01:22 --> Helper loaded: form_helper
DEBUG - 2015-12-04 17:01:22 --> Database Driver Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Session Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Helper loaded: string_helper
DEBUG - 2015-12-04 17:01:22 --> Session routines successfully run
DEBUG - 2015-12-04 17:01:22 --> Form Validation Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Pagination Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Encrypt Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Email Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Controller Class Initialized
DEBUG - 2015-12-04 17:01:22 --> Auth MX_Controller Initialized
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 17:01:22 --> Model Class Initialized
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 17:01:22 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-04 17:01:22 --> Final output sent to browser
DEBUG - 2015-12-04 17:01:22 --> Total execution time: 0.2751
DEBUG - 2015-12-04 17:01:25 --> Config Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Config Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:01:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:01:25 --> URI Class Initialized
DEBUG - 2015-12-04 17:01:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:01:25 --> URI Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Router Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Config Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Router Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Config Class Initialized
ERROR - 2015-12-04 17:01:25 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:01:25 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:01:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:01:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:01:25 --> URI Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Router Class Initialized
ERROR - 2015-12-04 17:01:25 --> 404 Page Not Found --> 
ERROR - 2015-12-04 17:01:25 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:01:25 --> URI Class Initialized
DEBUG - 2015-12-04 17:01:25 --> Router Class Initialized
ERROR - 2015-12-04 17:01:25 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:01:28 --> Config Class Initialized
DEBUG - 2015-12-04 17:01:28 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:01:28 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:01:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:01:28 --> URI Class Initialized
DEBUG - 2015-12-04 17:01:28 --> Router Class Initialized
ERROR - 2015-12-04 17:01:28 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:08 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:08 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:08 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:08 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:08 --> Router Class Initialized
ERROR - 2015-12-04 17:02:08 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:13 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:13 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:13 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:13 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:13 --> Router Class Initialized
ERROR - 2015-12-04 17:02:13 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:27 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:27 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:27 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:27 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:27 --> Router Class Initialized
ERROR - 2015-12-04 17:02:27 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:28 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:28 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:28 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:28 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:28 --> Router Class Initialized
ERROR - 2015-12-04 17:02:28 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:29 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:29 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:29 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:29 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:29 --> Router Class Initialized
ERROR - 2015-12-04 17:02:29 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:29 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:29 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:29 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:29 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:29 --> Router Class Initialized
ERROR - 2015-12-04 17:02:29 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:30 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:30 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Router Class Initialized
ERROR - 2015-12-04 17:02:30 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:30 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:30 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Router Class Initialized
ERROR - 2015-12-04 17:02:30 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:30 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:30 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Router Class Initialized
ERROR - 2015-12-04 17:02:30 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:30 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:30 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:30 --> Router Class Initialized
ERROR - 2015-12-04 17:02:30 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:31 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:31 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:31 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:31 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:31 --> Router Class Initialized
ERROR - 2015-12-04 17:02:31 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:31 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:31 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:31 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:31 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:31 --> Router Class Initialized
ERROR - 2015-12-04 17:02:31 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:52 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:52 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:52 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:52 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:52 --> Router Class Initialized
ERROR - 2015-12-04 17:02:52 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:02:55 --> Config Class Initialized
DEBUG - 2015-12-04 17:02:55 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:02:55 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:02:55 --> URI Class Initialized
DEBUG - 2015-12-04 17:02:55 --> Router Class Initialized
ERROR - 2015-12-04 17:02:55 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:03:34 --> Config Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:03:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:03:34 --> URI Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Router Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Output Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Security Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Input Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 17:03:34 --> Language Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Language Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Config Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Loader Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Helper loaded: url_helper
DEBUG - 2015-12-04 17:03:34 --> Helper loaded: form_helper
DEBUG - 2015-12-04 17:03:34 --> Database Driver Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Session Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Helper loaded: string_helper
DEBUG - 2015-12-04 17:03:34 --> Session routines successfully run
DEBUG - 2015-12-04 17:03:34 --> Form Validation Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Pagination Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Encrypt Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Email Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Controller Class Initialized
DEBUG - 2015-12-04 17:03:34 --> Auth MX_Controller Initialized
DEBUG - 2015-12-04 17:03:34 --> Model Class Initialized
DEBUG - 2015-12-04 17:03:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 17:03:34 --> Model Class Initialized
DEBUG - 2015-12-04 17:03:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 17:03:34 --> Model Class Initialized
DEBUG - 2015-12-04 17:03:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 17:03:34 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-04 17:03:34 --> Final output sent to browser
DEBUG - 2015-12-04 17:03:34 --> Total execution time: 0.1532
DEBUG - 2015-12-04 17:03:54 --> Config Class Initialized
DEBUG - 2015-12-04 17:03:54 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:03:54 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:03:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:03:54 --> URI Class Initialized
DEBUG - 2015-12-04 17:03:54 --> Config Class Initialized
DEBUG - 2015-12-04 17:03:54 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:03:55 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:03:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:03:55 --> URI Class Initialized
DEBUG - 2015-12-04 17:03:55 --> Router Class Initialized
DEBUG - 2015-12-04 17:03:55 --> Router Class Initialized
ERROR - 2015-12-04 17:03:55 --> 404 Page Not Found --> 
ERROR - 2015-12-04 17:03:55 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:03:55 --> Config Class Initialized
DEBUG - 2015-12-04 17:03:55 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:03:55 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:03:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:03:55 --> URI Class Initialized
DEBUG - 2015-12-04 17:03:55 --> Config Class Initialized
DEBUG - 2015-12-04 17:03:55 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:03:55 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:03:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:03:55 --> URI Class Initialized
DEBUG - 2015-12-04 17:03:55 --> Router Class Initialized
ERROR - 2015-12-04 17:03:55 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:03:55 --> Router Class Initialized
ERROR - 2015-12-04 17:03:55 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:04:07 --> Config Class Initialized
DEBUG - 2015-12-04 17:04:07 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:04:07 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:04:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:04:07 --> URI Class Initialized
DEBUG - 2015-12-04 17:04:07 --> Router Class Initialized
ERROR - 2015-12-04 17:04:07 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:04:23 --> Config Class Initialized
DEBUG - 2015-12-04 17:04:23 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:04:23 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:04:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:04:23 --> URI Class Initialized
DEBUG - 2015-12-04 17:04:23 --> Router Class Initialized
ERROR - 2015-12-04 17:04:23 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:07:42 --> Config Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:07:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:07:42 --> URI Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Router Class Initialized
DEBUG - 2015-12-04 17:07:42 --> No URI present. Default controller set.
DEBUG - 2015-12-04 17:07:42 --> Output Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Security Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Input Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 17:07:42 --> Language Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Language Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Config Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Loader Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Helper loaded: url_helper
DEBUG - 2015-12-04 17:07:42 --> Helper loaded: form_helper
DEBUG - 2015-12-04 17:07:42 --> Database Driver Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Session Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Helper loaded: string_helper
DEBUG - 2015-12-04 17:07:42 --> Session routines successfully run
DEBUG - 2015-12-04 17:07:42 --> Form Validation Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Pagination Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Encrypt Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Email Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Controller Class Initialized
DEBUG - 2015-12-04 17:07:42 --> Auth MX_Controller Initialized
DEBUG - 2015-12-04 17:07:42 --> Model Class Initialized
DEBUG - 2015-12-04 17:07:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 17:07:42 --> Model Class Initialized
DEBUG - 2015-12-04 17:07:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 17:07:42 --> Model Class Initialized
DEBUG - 2015-12-04 17:24:36 --> Config Class Initialized
DEBUG - 2015-12-04 17:24:36 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:24:36 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:24:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:24:36 --> URI Class Initialized
DEBUG - 2015-12-04 17:24:36 --> Router Class Initialized
DEBUG - 2015-12-04 17:24:37 --> No URI present. Default controller set.
DEBUG - 2015-12-04 17:24:37 --> Output Class Initialized
DEBUG - 2015-12-04 17:24:37 --> Security Class Initialized
DEBUG - 2015-12-04 17:24:37 --> Input Class Initialized
DEBUG - 2015-12-04 17:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 17:24:37 --> Language Class Initialized
DEBUG - 2015-12-04 17:24:37 --> Language Class Initialized
DEBUG - 2015-12-04 17:24:37 --> Config Class Initialized
DEBUG - 2015-12-04 17:24:37 --> Loader Class Initialized
DEBUG - 2015-12-04 17:24:37 --> Helper loaded: url_helper
DEBUG - 2015-12-04 17:24:37 --> Helper loaded: form_helper
DEBUG - 2015-12-04 17:24:38 --> Database Driver Class Initialized
DEBUG - 2015-12-04 17:24:38 --> Session Class Initialized
DEBUG - 2015-12-04 17:24:38 --> Helper loaded: string_helper
ERROR - 2015-12-04 17:24:38 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-12-04 17:24:38 --> Session routines successfully run
DEBUG - 2015-12-04 17:24:39 --> Form Validation Class Initialized
DEBUG - 2015-12-04 17:24:39 --> Pagination Class Initialized
DEBUG - 2015-12-04 17:24:39 --> Encrypt Class Initialized
DEBUG - 2015-12-04 17:24:39 --> Email Class Initialized
DEBUG - 2015-12-04 17:24:39 --> Controller Class Initialized
DEBUG - 2015-12-04 17:24:39 --> Auth MX_Controller Initialized
DEBUG - 2015-12-04 17:24:39 --> Model Class Initialized
DEBUG - 2015-12-04 17:24:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 17:24:39 --> Model Class Initialized
DEBUG - 2015-12-04 17:24:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 17:24:39 --> Model Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Config Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:26:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:26:53 --> URI Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Router Class Initialized
DEBUG - 2015-12-04 17:26:53 --> No URI present. Default controller set.
DEBUG - 2015-12-04 17:26:53 --> Output Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Security Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Input Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 17:26:53 --> Language Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Language Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Config Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Loader Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Helper loaded: url_helper
DEBUG - 2015-12-04 17:26:53 --> Helper loaded: form_helper
DEBUG - 2015-12-04 17:26:53 --> Database Driver Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Session Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Helper loaded: string_helper
DEBUG - 2015-12-04 17:26:53 --> Session routines successfully run
DEBUG - 2015-12-04 17:26:53 --> Form Validation Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Pagination Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Encrypt Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Email Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Controller Class Initialized
DEBUG - 2015-12-04 17:26:53 --> Auth MX_Controller Initialized
DEBUG - 2015-12-04 17:26:53 --> Model Class Initialized
DEBUG - 2015-12-04 17:26:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 17:26:53 --> Model Class Initialized
DEBUG - 2015-12-04 17:26:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 17:26:53 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:47 --> Config Class Initialized
DEBUG - 2015-12-04 17:37:47 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:37:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:37:48 --> URI Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Router Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Output Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Security Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Input Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 17:37:48 --> Language Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Language Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Config Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Loader Class Initialized
DEBUG - 2015-12-04 17:37:48 --> Helper loaded: url_helper
DEBUG - 2015-12-04 17:37:48 --> Helper loaded: form_helper
DEBUG - 2015-12-04 17:37:49 --> Database Driver Class Initialized
DEBUG - 2015-12-04 17:37:49 --> Session Class Initialized
DEBUG - 2015-12-04 17:37:51 --> Helper loaded: string_helper
DEBUG - 2015-12-04 17:37:51 --> A session cookie was not found.
DEBUG - 2015-12-04 17:37:51 --> Session routines successfully run
DEBUG - 2015-12-04 17:37:51 --> Form Validation Class Initialized
DEBUG - 2015-12-04 17:37:51 --> Pagination Class Initialized
DEBUG - 2015-12-04 17:37:51 --> Encrypt Class Initialized
DEBUG - 2015-12-04 17:37:52 --> Email Class Initialized
DEBUG - 2015-12-04 17:37:52 --> Controller Class Initialized
DEBUG - 2015-12-04 17:37:52 --> Admin MX_Controller Initialized
DEBUG - 2015-12-04 17:37:52 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 17:37:52 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 17:37:52 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 17:37:52 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 17:37:52 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 17:37:52 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 17:37:53 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:54 --> Config Class Initialized
DEBUG - 2015-12-04 17:37:54 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:37:54 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:37:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:37:54 --> URI Class Initialized
DEBUG - 2015-12-04 17:37:54 --> Router Class Initialized
DEBUG - 2015-12-04 17:37:54 --> Output Class Initialized
DEBUG - 2015-12-04 17:37:54 --> Security Class Initialized
DEBUG - 2015-12-04 17:37:54 --> Input Class Initialized
DEBUG - 2015-12-04 17:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 17:37:54 --> Language Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Language Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Config Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Loader Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Helper loaded: url_helper
DEBUG - 2015-12-04 17:37:55 --> Helper loaded: form_helper
DEBUG - 2015-12-04 17:37:55 --> Database Driver Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Session Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Helper loaded: string_helper
DEBUG - 2015-12-04 17:37:55 --> Session routines successfully run
DEBUG - 2015-12-04 17:37:55 --> Form Validation Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Pagination Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Encrypt Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Email Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Controller Class Initialized
DEBUG - 2015-12-04 17:37:55 --> Auth MX_Controller Initialized
DEBUG - 2015-12-04 17:37:55 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 17:37:55 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 17:37:55 --> Model Class Initialized
DEBUG - 2015-12-04 17:37:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 17:37:56 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-04 17:37:56 --> Final output sent to browser
DEBUG - 2015-12-04 17:37:56 --> Total execution time: 1.8428
DEBUG - 2015-12-04 17:37:56 --> Config Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:37:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:37:56 --> URI Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Router Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Output Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Security Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Input Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 17:37:56 --> Language Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Language Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Config Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Loader Class Initialized
DEBUG - 2015-12-04 17:37:56 --> Helper loaded: url_helper
DEBUG - 2015-12-04 17:37:56 --> Helper loaded: form_helper
DEBUG - 2015-12-04 17:37:56 --> Database Driver Class Initialized
DEBUG - 2015-12-04 17:38:09 --> Session Class Initialized
DEBUG - 2015-12-04 17:38:09 --> Helper loaded: string_helper
DEBUG - 2015-12-04 17:38:09 --> Session routines successfully run
DEBUG - 2015-12-04 17:38:09 --> Form Validation Class Initialized
DEBUG - 2015-12-04 17:38:09 --> Pagination Class Initialized
DEBUG - 2015-12-04 17:38:09 --> Encrypt Class Initialized
DEBUG - 2015-12-04 17:38:09 --> Email Class Initialized
DEBUG - 2015-12-04 17:38:09 --> Controller Class Initialized
DEBUG - 2015-12-04 17:38:09 --> Auth MX_Controller Initialized
DEBUG - 2015-12-04 17:38:09 --> Model Class Initialized
DEBUG - 2015-12-04 17:38:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 17:38:09 --> Model Class Initialized
DEBUG - 2015-12-04 17:38:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 17:38:09 --> Model Class Initialized
DEBUG - 2015-12-04 17:38:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 17:38:09 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-04 17:38:09 --> Final output sent to browser
DEBUG - 2015-12-04 17:38:09 --> Total execution time: 12.4173
DEBUG - 2015-12-04 17:38:11 --> Config Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Config Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:38:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:38:11 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:38:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:38:11 --> URI Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Router Class Initialized
DEBUG - 2015-12-04 17:38:11 --> URI Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Config Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:38:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:38:11 --> URI Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Router Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Router Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Config Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:38:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:38:11 --> URI Class Initialized
DEBUG - 2015-12-04 17:38:11 --> Router Class Initialized
ERROR - 2015-12-04 17:38:11 --> 404 Page Not Found --> 
ERROR - 2015-12-04 17:38:11 --> 404 Page Not Found --> 
ERROR - 2015-12-04 17:38:11 --> 404 Page Not Found --> 
ERROR - 2015-12-04 17:38:11 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:38:17 --> Config Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:38:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:38:17 --> URI Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Router Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Config Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:38:17 --> UTF-8 Support Enabled
ERROR - 2015-12-04 17:38:17 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:38:17 --> Config Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:38:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:38:17 --> URI Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Router Class Initialized
DEBUG - 2015-12-04 17:38:17 --> URI Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Router Class Initialized
ERROR - 2015-12-04 17:38:17 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 17:38:17 --> Config Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Hooks Class Initialized
DEBUG - 2015-12-04 17:38:17 --> Utf8 Class Initialized
DEBUG - 2015-12-04 17:38:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 17:38:17 --> URI Class Initialized
DEBUG - 2015-12-04 17:38:18 --> Router Class Initialized
ERROR - 2015-12-04 17:38:18 --> 404 Page Not Found --> 
ERROR - 2015-12-04 17:38:18 --> 404 Page Not Found --> 
DEBUG - 2015-12-04 18:51:19 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:20 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:51:20 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:51:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:51:20 --> URI Class Initialized
DEBUG - 2015-12-04 18:51:20 --> Router Class Initialized
DEBUG - 2015-12-04 18:51:20 --> Output Class Initialized
DEBUG - 2015-12-04 18:51:20 --> Security Class Initialized
DEBUG - 2015-12-04 18:51:20 --> Input Class Initialized
DEBUG - 2015-12-04 18:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:51:20 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:20 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:20 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:21 --> Loader Class Initialized
DEBUG - 2015-12-04 18:51:21 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:51:21 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:51:21 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:51:22 --> Session Class Initialized
DEBUG - 2015-12-04 18:51:22 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:51:22 --> Session routines successfully run
DEBUG - 2015-12-04 18:51:22 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:51:22 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:51:22 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:51:22 --> Email Class Initialized
DEBUG - 2015-12-04 18:51:22 --> Controller Class Initialized
DEBUG - 2015-12-04 18:51:22 --> Auth MX_Controller Initialized
DEBUG - 2015-12-04 18:51:22 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:51:22 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:51:22 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-04 18:51:22 --> XSS Filtering completed
DEBUG - 2015-12-04 18:51:22 --> Unable to find validation rule: exists
DEBUG - 2015-12-04 18:51:22 --> XSS Filtering completed
DEBUG - 2015-12-04 18:51:24 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:24 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:51:24 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:51:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:51:24 --> URI Class Initialized
DEBUG - 2015-12-04 18:51:24 --> Router Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Output Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Security Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Input Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:51:25 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Loader Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:51:25 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:51:25 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Session Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:51:25 --> Session routines successfully run
DEBUG - 2015-12-04 18:51:25 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Email Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Controller Class Initialized
DEBUG - 2015-12-04 18:51:25 --> Admin MX_Controller Initialized
DEBUG - 2015-12-04 18:51:25 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:51:25 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:51:25 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:51:25 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:51:25 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:51:25 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:51:25 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:25 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-04 18:51:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 18:51:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-04 18:51:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-04 18:51:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-04 18:51:26 --> Final output sent to browser
DEBUG - 2015-12-04 18:51:26 --> Total execution time: 2.1640
DEBUG - 2015-12-04 18:51:44 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:44 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:51:44 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:51:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:51:44 --> URI Class Initialized
DEBUG - 2015-12-04 18:51:44 --> Router Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Output Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Security Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Input Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:51:45 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Loader Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:51:45 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:51:45 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Session Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:51:45 --> Session routines successfully run
DEBUG - 2015-12-04 18:51:45 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Email Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Controller Class Initialized
DEBUG - 2015-12-04 18:51:45 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:51:45 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:51:45 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:51:45 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:51:45 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:51:45 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:51:45 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:51:45 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:51:45 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-04 18:51:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-04 18:51:45 --> Final output sent to browser
DEBUG - 2015-12-04 18:51:45 --> Total execution time: 0.9676
DEBUG - 2015-12-04 18:51:56 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:51:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:51:56 --> URI Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Router Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Output Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Security Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Input Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:51:56 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Loader Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:51:56 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:51:56 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Session Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:51:56 --> Session routines successfully run
DEBUG - 2015-12-04 18:51:56 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Email Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Controller Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:51:56 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:51:56 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:51:56 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:51:56 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:51:56 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:51:56 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:51:56 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:51:56 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:51:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:51:56 --> URI Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Router Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Output Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Security Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Input Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:51:56 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Language Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Config Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Loader Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:51:56 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:51:56 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Session Class Initialized
DEBUG - 2015-12-04 18:51:56 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:51:56 --> Session routines successfully run
DEBUG - 2015-12-04 18:51:57 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:51:57 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:51:57 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:51:57 --> Email Class Initialized
DEBUG - 2015-12-04 18:51:57 --> Controller Class Initialized
DEBUG - 2015-12-04 18:51:57 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:51:57 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:51:57 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:51:57 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:51:57 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:51:57 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:51:57 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:51:57 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:51:57 --> Model Class Initialized
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-04 18:51:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-04 18:51:57 --> Final output sent to browser
DEBUG - 2015-12-04 18:51:57 --> Total execution time: 0.3368
DEBUG - 2015-12-04 18:52:04 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:04 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:04 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:04 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:04 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:52:04 --> Session routines successfully run
DEBUG - 2015-12-04 18:52:04 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Email Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Controller Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:04 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:04 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:04 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:04 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:52:04 --> Session routines successfully run
DEBUG - 2015-12-04 18:52:04 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Email Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Controller Class Initialized
DEBUG - 2015-12-04 18:52:04 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:52:04 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-04 18:52:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-04 18:52:04 --> Final output sent to browser
DEBUG - 2015-12-04 18:52:04 --> Total execution time: 0.2196
DEBUG - 2015-12-04 18:52:12 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:12 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:12 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:12 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:12 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:52:12 --> Session routines successfully run
DEBUG - 2015-12-04 18:52:12 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Email Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Controller Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:12 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:12 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:12 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:12 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:52:12 --> Session routines successfully run
DEBUG - 2015-12-04 18:52:12 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Email Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Controller Class Initialized
DEBUG - 2015-12-04 18:52:12 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:52:12 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-04 18:52:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-04 18:52:12 --> Final output sent to browser
DEBUG - 2015-12-04 18:52:12 --> Total execution time: 0.2524
DEBUG - 2015-12-04 18:52:23 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:23 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:23 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:23 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:23 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:52:23 --> Session routines successfully run
DEBUG - 2015-12-04 18:52:23 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Email Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Controller Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:23 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:23 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:23 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:23 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:52:23 --> Session routines successfully run
DEBUG - 2015-12-04 18:52:23 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Email Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Controller Class Initialized
DEBUG - 2015-12-04 18:52:23 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:52:23 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-04 18:52:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-04 18:52:23 --> Final output sent to browser
DEBUG - 2015-12-04 18:52:23 --> Total execution time: 0.2371
DEBUG - 2015-12-04 18:52:34 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:34 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:34 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:34 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:34 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:52:34 --> Session routines successfully run
DEBUG - 2015-12-04 18:52:34 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Email Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Controller Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:34 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:34 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:34 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:34 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:52:34 --> Session routines successfully run
DEBUG - 2015-12-04 18:52:34 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Email Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Controller Class Initialized
DEBUG - 2015-12-04 18:52:34 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:52:34 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-04 18:52:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-04 18:52:34 --> Final output sent to browser
DEBUG - 2015-12-04 18:52:34 --> Total execution time: 0.2264
DEBUG - 2015-12-04 18:52:50 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:50 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:50 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:50 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:50 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:52:50 --> Session routines successfully run
DEBUG - 2015-12-04 18:52:50 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Email Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Controller Class Initialized
DEBUG - 2015-12-04 18:52:50 --> Accounts MX_Controller Initialized
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:52:50 --> Model Class Initialized
DEBUG - 2015-12-04 18:52:50 --> DB Transaction Failure
ERROR - 2015-12-04 18:52:50 --> Query error: Table 'mfi.visit' doesn't exist
DEBUG - 2015-12-04 18:52:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-04 18:52:59 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:52:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:52:59 --> URI Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Router Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Output Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Security Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Input Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:52:59 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Language Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Config Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Loader Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:52:59 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:52:59 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Session Class Initialized
DEBUG - 2015-12-04 18:52:59 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:53:00 --> Session routines successfully run
DEBUG - 2015-12-04 18:53:00 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Email Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Controller Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Config Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Hooks Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Utf8 Class Initialized
DEBUG - 2015-12-04 18:53:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-04 18:53:00 --> URI Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Router Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Output Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Security Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Input Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-04 18:53:00 --> Language Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Language Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Config Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Loader Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Helper loaded: url_helper
DEBUG - 2015-12-04 18:53:00 --> Helper loaded: form_helper
DEBUG - 2015-12-04 18:53:00 --> Database Driver Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Session Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Helper loaded: string_helper
DEBUG - 2015-12-04 18:53:00 --> Session routines successfully run
DEBUG - 2015-12-04 18:53:00 --> Form Validation Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Pagination Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Encrypt Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Email Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Controller Class Initialized
DEBUG - 2015-12-04 18:53:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-04 18:53:00 --> Model Class Initialized
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-04 18:53:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-04 18:53:00 --> Final output sent to browser
DEBUG - 2015-12-04 18:53:00 --> Total execution time: 0.2599
