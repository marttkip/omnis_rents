<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-08 12:11:46 --> Config Class Initialized
DEBUG - 2015-12-08 12:11:46 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:11:46 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:11:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:11:46 --> URI Class Initialized
DEBUG - 2015-12-08 12:11:47 --> Router Class Initialized
DEBUG - 2015-12-08 12:11:47 --> No URI present. Default controller set.
DEBUG - 2015-12-08 12:11:47 --> Output Class Initialized
DEBUG - 2015-12-08 12:11:47 --> Security Class Initialized
DEBUG - 2015-12-08 12:11:47 --> Input Class Initialized
DEBUG - 2015-12-08 12:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:11:47 --> Language Class Initialized
DEBUG - 2015-12-08 12:11:49 --> Language Class Initialized
DEBUG - 2015-12-08 12:11:49 --> Config Class Initialized
DEBUG - 2015-12-08 12:11:49 --> Loader Class Initialized
DEBUG - 2015-12-08 12:11:49 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:11:49 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:11:50 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:11:52 --> Session Class Initialized
DEBUG - 2015-12-08 12:11:52 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:11:52 --> A session cookie was not found.
DEBUG - 2015-12-08 12:11:52 --> Session routines successfully run
DEBUG - 2015-12-08 12:11:52 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:11:52 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:11:53 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:11:53 --> Email Class Initialized
DEBUG - 2015-12-08 12:11:53 --> Controller Class Initialized
DEBUG - 2015-12-08 12:11:53 --> Auth MX_Controller Initialized
DEBUG - 2015-12-08 12:11:53 --> Model Class Initialized
DEBUG - 2015-12-08 12:11:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:11:53 --> Model Class Initialized
DEBUG - 2015-12-08 12:11:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:11:53 --> Model Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Config Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:11:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:11:54 --> URI Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Router Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Output Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Security Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Input Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:11:54 --> Language Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Language Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Config Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Loader Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:11:54 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:11:54 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Session Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:11:54 --> Session routines successfully run
DEBUG - 2015-12-08 12:11:54 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Email Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Controller Class Initialized
DEBUG - 2015-12-08 12:11:54 --> Auth MX_Controller Initialized
DEBUG - 2015-12-08 12:11:54 --> Model Class Initialized
DEBUG - 2015-12-08 12:11:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:11:54 --> Model Class Initialized
DEBUG - 2015-12-08 12:11:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:11:54 --> Model Class Initialized
DEBUG - 2015-12-08 12:11:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:11:55 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-08 12:11:55 --> Final output sent to browser
DEBUG - 2015-12-08 12:11:55 --> Total execution time: 1.6042
DEBUG - 2015-12-08 12:12:04 --> Config Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Config Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:12:04 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:12:04 --> URI Class Initialized
DEBUG - 2015-12-08 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:12:04 --> URI Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Router Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Router Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Config Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:12:04 --> URI Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Router Class Initialized
ERROR - 2015-12-08 12:12:04 --> 404 Page Not Found --> 
ERROR - 2015-12-08 12:12:04 --> 404 Page Not Found --> 
DEBUG - 2015-12-08 12:12:04 --> Config Class Initialized
ERROR - 2015-12-08 12:12:04 --> 404 Page Not Found --> 
DEBUG - 2015-12-08 12:12:04 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:12:04 --> URI Class Initialized
DEBUG - 2015-12-08 12:12:04 --> Router Class Initialized
ERROR - 2015-12-08 12:12:04 --> 404 Page Not Found --> 
DEBUG - 2015-12-08 12:13:31 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:13:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:13:31 --> URI Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Router Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Output Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Security Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Input Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:13:31 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Loader Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:13:31 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:13:31 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Session Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:13:31 --> Session routines successfully run
DEBUG - 2015-12-08 12:13:31 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Email Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Controller Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Auth MX_Controller Initialized
DEBUG - 2015-12-08 12:13:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:13:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:13:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-08 12:13:31 --> XSS Filtering completed
DEBUG - 2015-12-08 12:13:31 --> Unable to find validation rule: exists
DEBUG - 2015-12-08 12:13:31 --> XSS Filtering completed
DEBUG - 2015-12-08 12:13:31 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:13:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:13:31 --> URI Class Initialized
DEBUG - 2015-12-08 12:13:31 --> Router Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Output Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Security Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Input Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:13:32 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Loader Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:13:32 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:13:32 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Session Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:13:32 --> Session routines successfully run
DEBUG - 2015-12-08 12:13:32 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Email Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Controller Class Initialized
DEBUG - 2015-12-08 12:13:32 --> Admin MX_Controller Initialized
DEBUG - 2015-12-08 12:13:32 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:13:32 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:13:32 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:13:32 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:13:32 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:13:32 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:13:32 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:13:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:13:32 --> Final output sent to browser
DEBUG - 2015-12-08 12:13:32 --> Total execution time: 0.7695
DEBUG - 2015-12-08 12:13:38 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:38 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:13:38 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:13:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:13:38 --> URI Class Initialized
DEBUG - 2015-12-08 12:13:38 --> Router Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Output Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Security Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Input Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:13:39 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Loader Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:13:39 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:13:39 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Session Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:13:39 --> Session routines successfully run
DEBUG - 2015-12-08 12:13:39 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Email Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Controller Class Initialized
DEBUG - 2015-12-08 12:13:39 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-08 12:13:39 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-08 12:13:39 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:13:39 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:13:39 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:13:39 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:13:39 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-08 12:13:39 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:13:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:13:39 --> Final output sent to browser
DEBUG - 2015-12-08 12:13:39 --> Total execution time: 1.0374
DEBUG - 2015-12-08 12:13:44 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:13:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:13:44 --> URI Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Router Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Output Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Security Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Input Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:13:44 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Loader Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:13:44 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:13:44 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Session Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:13:44 --> Session routines successfully run
DEBUG - 2015-12-08 12:13:44 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Email Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Controller Class Initialized
DEBUG - 2015-12-08 12:13:44 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-08 12:13:44 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-08 12:13:44 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:13:44 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:13:44 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:13:44 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:13:44 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-08 12:13:44 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/messaging/views/sms/sent_messages.php
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:13:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:13:44 --> Final output sent to browser
DEBUG - 2015-12-08 12:13:44 --> Total execution time: 0.2783
DEBUG - 2015-12-08 12:13:49 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:13:49 --> URI Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Router Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Output Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Security Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Input Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:13:49 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Language Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Config Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Loader Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:13:49 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:13:49 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Session Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:13:49 --> Session routines successfully run
DEBUG - 2015-12-08 12:13:49 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Email Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Controller Class Initialized
DEBUG - 2015-12-08 12:13:49 --> Messaging MX_Controller Initialized
DEBUG - 2015-12-08 12:13:49 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2015-12-08 12:13:49 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:13:49 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:13:49 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:13:49 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:13:49 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-08 12:13:49 --> Model Class Initialized
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:13:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:13:49 --> Final output sent to browser
DEBUG - 2015-12-08 12:13:49 --> Total execution time: 0.2208
DEBUG - 2015-12-08 12:14:56 --> Config Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:14:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:14:56 --> URI Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Router Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Output Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Security Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Input Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:14:56 --> Language Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Language Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Config Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Loader Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:14:56 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:14:56 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Session Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:14:56 --> Session routines successfully run
DEBUG - 2015-12-08 12:14:56 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Email Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Controller Class Initialized
DEBUG - 2015-12-08 12:14:56 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:14:56 --> Model Class Initialized
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:14:56 --> Model Class Initialized
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:14:56 --> Model Class Initialized
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:14:56 --> Model Class Initialized
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:14:56 --> Model Class Initialized
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:14:56 --> Model Class Initialized
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:14:56 --> Model Class Initialized
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:14:56 --> Model Class Initialized
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:14:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:14:56 --> Final output sent to browser
DEBUG - 2015-12-08 12:14:56 --> Total execution time: 0.3871
DEBUG - 2015-12-08 12:15:23 --> Config Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:15:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:15:23 --> URI Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Router Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Output Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Security Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Input Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:15:23 --> Language Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Language Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Config Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Loader Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:15:23 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:15:23 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Session Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:15:23 --> Session routines successfully run
DEBUG - 2015-12-08 12:15:23 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Email Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Controller Class Initialized
DEBUG - 2015-12-08 12:15:23 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:15:23 --> Model Class Initialized
DEBUG - 2015-12-08 12:15:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:15:23 --> Model Class Initialized
DEBUG - 2015-12-08 12:15:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:15:23 --> Model Class Initialized
DEBUG - 2015-12-08 12:15:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:15:23 --> Model Class Initialized
DEBUG - 2015-12-08 12:15:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:15:23 --> Model Class Initialized
DEBUG - 2015-12-08 12:15:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:15:23 --> Model Class Initialized
DEBUG - 2015-12-08 12:15:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:15:23 --> Model Class Initialized
DEBUG - 2015-12-08 12:15:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:15:23 --> Model Class Initialized
DEBUG - 2015-12-08 12:15:23 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-08 12:15:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:15:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:15:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:15:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:15:24 --> Final output sent to browser
DEBUG - 2015-12-08 12:15:24 --> Total execution time: 0.2212
DEBUG - 2015-12-08 12:16:57 --> Config Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:16:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:16:57 --> URI Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Router Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Output Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Security Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Input Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:16:57 --> Language Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Language Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Config Class Initialized
DEBUG - 2015-12-08 12:16:57 --> Loader Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:16:58 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:16:58 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Session Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:16:58 --> Session routines successfully run
DEBUG - 2015-12-08 12:16:58 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Email Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Controller Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-08 12:16:58 --> XSS Filtering completed
DEBUG - 2015-12-08 12:16:58 --> XSS Filtering completed
DEBUG - 2015-12-08 12:16:58 --> XSS Filtering completed
DEBUG - 2015-12-08 12:16:58 --> XSS Filtering completed
DEBUG - 2015-12-08 12:16:58 --> XSS Filtering completed
DEBUG - 2015-12-08 12:16:58 --> Config Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:16:58 --> URI Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Router Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Output Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Security Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Input Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:16:58 --> Language Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Language Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Config Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Loader Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:16:58 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:16:58 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Session Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:16:58 --> Session routines successfully run
DEBUG - 2015-12-08 12:16:58 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Email Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Controller Class Initialized
DEBUG - 2015-12-08 12:16:58 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:16:58 --> Model Class Initialized
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:16:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:16:58 --> Final output sent to browser
DEBUG - 2015-12-08 12:16:58 --> Total execution time: 0.3289
DEBUG - 2015-12-08 12:17:07 --> Config Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:17:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:17:07 --> URI Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Router Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Output Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Security Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Input Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:17:07 --> Language Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Language Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Config Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Loader Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:17:07 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:17:07 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Session Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:17:07 --> Session routines successfully run
DEBUG - 2015-12-08 12:17:07 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Email Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Controller Class Initialized
DEBUG - 2015-12-08 12:17:07 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:17:07 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:17:07 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:17:07 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:17:07 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:17:07 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:17:07 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:17:07 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:17:07 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:17:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:17:07 --> Final output sent to browser
DEBUG - 2015-12-08 12:17:07 --> Total execution time: 0.1941
DEBUG - 2015-12-08 12:17:30 --> Config Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:17:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:17:30 --> URI Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Router Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Output Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Security Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Input Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:17:30 --> Language Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Language Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Config Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Loader Class Initialized
DEBUG - 2015-12-08 12:17:30 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:17:30 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:17:31 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Session Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:17:31 --> Session routines successfully run
DEBUG - 2015-12-08 12:17:31 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Email Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Controller Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-08 12:17:31 --> XSS Filtering completed
DEBUG - 2015-12-08 12:17:31 --> XSS Filtering completed
DEBUG - 2015-12-08 12:17:31 --> XSS Filtering completed
DEBUG - 2015-12-08 12:17:31 --> XSS Filtering completed
DEBUG - 2015-12-08 12:17:31 --> XSS Filtering completed
DEBUG - 2015-12-08 12:17:31 --> Config Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:17:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:17:31 --> URI Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Router Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Output Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Security Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Input Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:17:31 --> Language Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Language Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Config Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Loader Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:17:31 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:17:31 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Session Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:17:31 --> Session routines successfully run
DEBUG - 2015-12-08 12:17:31 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Email Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Controller Class Initialized
DEBUG - 2015-12-08 12:17:31 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:17:31 --> Model Class Initialized
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:17:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:17:31 --> Final output sent to browser
DEBUG - 2015-12-08 12:17:31 --> Total execution time: 0.2173
DEBUG - 2015-12-08 12:27:19 --> Config Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:27:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:27:19 --> URI Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Router Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Output Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Security Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Input Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:27:19 --> Language Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Language Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Config Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Loader Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:27:19 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:27:19 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Session Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:27:19 --> Session routines successfully run
DEBUG - 2015-12-08 12:27:19 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Email Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Controller Class Initialized
DEBUG - 2015-12-08 12:27:19 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:27:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:27:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:27:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:27:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:27:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:27:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:27:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:27:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:27:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:27:19 --> Final output sent to browser
DEBUG - 2015-12-08 12:27:19 --> Total execution time: 0.2122
DEBUG - 2015-12-08 12:32:59 --> Config Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:32:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:32:59 --> URI Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Router Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Output Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Security Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Input Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:32:59 --> Language Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Language Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Config Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Loader Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:32:59 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:32:59 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Session Class Initialized
DEBUG - 2015-12-08 12:32:59 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:32:59 --> Session routines successfully run
DEBUG - 2015-12-08 12:33:00 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Email Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Controller Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-08 12:33:00 --> XSS Filtering completed
DEBUG - 2015-12-08 12:33:00 --> XSS Filtering completed
DEBUG - 2015-12-08 12:33:00 --> XSS Filtering completed
DEBUG - 2015-12-08 12:33:00 --> XSS Filtering completed
DEBUG - 2015-12-08 12:33:00 --> XSS Filtering completed
DEBUG - 2015-12-08 12:33:00 --> Config Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:33:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:33:00 --> URI Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Router Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Output Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Security Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Input Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:33:00 --> Language Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Language Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Config Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Loader Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:33:00 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:33:00 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Session Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:33:00 --> Session routines successfully run
DEBUG - 2015-12-08 12:33:00 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Email Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Controller Class Initialized
DEBUG - 2015-12-08 12:33:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:33:00 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:33:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:33:00 --> Final output sent to browser
DEBUG - 2015-12-08 12:33:00 --> Total execution time: 0.2287
DEBUG - 2015-12-08 12:33:11 --> Config Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:33:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:33:11 --> URI Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Router Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Output Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Security Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Input Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:33:11 --> Language Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Language Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Config Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Loader Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:33:11 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:33:11 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Session Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:33:11 --> Session routines successfully run
DEBUG - 2015-12-08 12:33:11 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Email Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Controller Class Initialized
DEBUG - 2015-12-08 12:33:11 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-08 12:33:11 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:11 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-08 12:33:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:33:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:33:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:33:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:33:12 --> Final output sent to browser
DEBUG - 2015-12-08 12:33:12 --> Total execution time: 0.5648
DEBUG - 2015-12-08 12:33:18 --> Config Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Hooks Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Utf8 Class Initialized
DEBUG - 2015-12-08 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 12:33:18 --> URI Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Router Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Output Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Security Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Input Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 12:33:18 --> Language Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Language Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Config Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Loader Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Helper loaded: url_helper
DEBUG - 2015-12-08 12:33:18 --> Helper loaded: form_helper
DEBUG - 2015-12-08 12:33:18 --> Database Driver Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Session Class Initialized
DEBUG - 2015-12-08 12:33:18 --> Helper loaded: string_helper
DEBUG - 2015-12-08 12:33:18 --> Session routines successfully run
DEBUG - 2015-12-08 12:33:18 --> Form Validation Class Initialized
DEBUG - 2015-12-08 12:33:19 --> Pagination Class Initialized
DEBUG - 2015-12-08 12:33:19 --> Encrypt Class Initialized
DEBUG - 2015-12-08 12:33:19 --> Email Class Initialized
DEBUG - 2015-12-08 12:33:19 --> Controller Class Initialized
DEBUG - 2015-12-08 12:33:19 --> Branches MX_Controller Initialized
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-08 12:33:19 --> Model Class Initialized
DEBUG - 2015-12-08 12:33:19 --> Image Lib Class Initialized
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/views/branches/all_branches.php
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 12:33:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 12:33:19 --> Final output sent to browser
DEBUG - 2015-12-08 12:33:19 --> Total execution time: 0.4595
DEBUG - 2015-12-08 13:05:02 --> Config Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Hooks Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Utf8 Class Initialized
DEBUG - 2015-12-08 13:05:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 13:05:02 --> URI Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Router Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Output Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Security Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Input Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 13:05:02 --> Language Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Language Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Config Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Loader Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Helper loaded: url_helper
DEBUG - 2015-12-08 13:05:02 --> Helper loaded: form_helper
DEBUG - 2015-12-08 13:05:02 --> Database Driver Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Session Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Helper loaded: string_helper
DEBUG - 2015-12-08 13:05:02 --> Session routines successfully run
DEBUG - 2015-12-08 13:05:02 --> Form Validation Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Pagination Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Encrypt Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Email Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Controller Class Initialized
DEBUG - 2015-12-08 13:05:02 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 13:05:02 --> Model Class Initialized
DEBUG - 2015-12-08 13:05:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 13:05:02 --> Model Class Initialized
DEBUG - 2015-12-08 13:05:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 13:05:02 --> Model Class Initialized
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 13:05:03 --> Model Class Initialized
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 13:05:03 --> Model Class Initialized
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 13:05:03 --> Model Class Initialized
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 13:05:03 --> Model Class Initialized
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 13:05:03 --> Model Class Initialized
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 13:05:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 13:05:03 --> Final output sent to browser
DEBUG - 2015-12-08 13:05:03 --> Total execution time: 1.2293
DEBUG - 2015-12-08 13:41:43 --> Config Class Initialized
DEBUG - 2015-12-08 13:41:43 --> Hooks Class Initialized
DEBUG - 2015-12-08 13:41:43 --> Utf8 Class Initialized
DEBUG - 2015-12-08 13:41:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 13:41:43 --> URI Class Initialized
DEBUG - 2015-12-08 13:41:43 --> Router Class Initialized
DEBUG - 2015-12-08 13:41:44 --> Output Class Initialized
DEBUG - 2015-12-08 13:41:44 --> Security Class Initialized
DEBUG - 2015-12-08 13:41:44 --> Input Class Initialized
DEBUG - 2015-12-08 13:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 13:41:44 --> Language Class Initialized
DEBUG - 2015-12-08 13:41:44 --> Language Class Initialized
DEBUG - 2015-12-08 13:41:44 --> Config Class Initialized
DEBUG - 2015-12-08 13:41:44 --> Loader Class Initialized
DEBUG - 2015-12-08 13:41:44 --> Helper loaded: url_helper
DEBUG - 2015-12-08 13:41:44 --> Helper loaded: form_helper
DEBUG - 2015-12-08 13:41:45 --> Database Driver Class Initialized
DEBUG - 2015-12-08 13:41:45 --> Session Class Initialized
DEBUG - 2015-12-08 13:41:45 --> Helper loaded: string_helper
DEBUG - 2015-12-08 13:41:45 --> Session routines successfully run
DEBUG - 2015-12-08 13:41:45 --> Form Validation Class Initialized
DEBUG - 2015-12-08 13:41:45 --> Pagination Class Initialized
DEBUG - 2015-12-08 13:41:45 --> Encrypt Class Initialized
DEBUG - 2015-12-08 13:41:45 --> Email Class Initialized
DEBUG - 2015-12-08 13:41:45 --> Controller Class Initialized
DEBUG - 2015-12-08 13:41:45 --> Sections MX_Controller Initialized
DEBUG - 2015-12-08 13:41:45 --> Model Class Initialized
DEBUG - 2015-12-08 13:41:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-08 13:41:45 --> Model Class Initialized
DEBUG - 2015-12-08 13:41:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-08 13:41:45 --> Model Class Initialized
DEBUG - 2015-12-08 13:41:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-08 13:41:45 --> Model Class Initialized
DEBUG - 2015-12-08 13:41:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-08 13:41:45 --> Model Class Initialized
DEBUG - 2015-12-08 13:41:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-08 13:41:45 --> Model Class Initialized
DEBUG - 2015-12-08 13:41:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-08 13:41:45 --> Model Class Initialized
DEBUG - 2015-12-08 13:41:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-08 13:41:45 --> Model Class Initialized
DEBUG - 2015-12-08 13:41:46 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-08 13:41:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-08 13:41:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-08 13:41:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-08 13:41:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-08 13:41:46 --> Final output sent to browser
DEBUG - 2015-12-08 13:41:46 --> Total execution time: 3.9965
