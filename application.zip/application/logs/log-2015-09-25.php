<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-09-25 05:36:29 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:36:29 --> URI Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Router Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Output Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Security Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Input Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:36:29 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Loader Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:36:29 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:36:29 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:36:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-25 05:36:29 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:36:29 --> Session Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:36:29 --> A session cookie was not found.
DEBUG - 2015-09-25 05:36:29 --> Session routines successfully run
DEBUG - 2015-09-25 05:36:29 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Email Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Controller Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:36:29 --> URI Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Router Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Output Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Security Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Input Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:36:29 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Loader Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:36:29 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:36:29 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:36:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:36:29 --> Session Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:36:29 --> Session routines successfully run
DEBUG - 2015-09-25 05:36:29 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Email Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Controller Class Initialized
DEBUG - 2015-09-25 05:36:29 --> Auth MX_Controller Initialized
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:36:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 05:36:29 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-25 05:36:29 --> Final output sent to browser
DEBUG - 2015-09-25 05:36:29 --> Total execution time: 0.1044
DEBUG - 2015-09-25 05:36:30 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:36:30 --> URI Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Router Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:36:30 --> URI Class Initialized
DEBUG - 2015-09-25 05:36:30 --> URI Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Router Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Router Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:36:30 --> URI Class Initialized
DEBUG - 2015-09-25 05:36:30 --> Router Class Initialized
ERROR - 2015-09-25 05:36:30 --> 404 Page Not Found --> 
ERROR - 2015-09-25 05:36:30 --> 404 Page Not Found --> 
ERROR - 2015-09-25 05:36:30 --> 404 Page Not Found --> 
ERROR - 2015-09-25 05:36:30 --> 404 Page Not Found --> 
DEBUG - 2015-09-25 05:36:46 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:36:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:36:46 --> URI Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Router Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Output Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Security Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Input Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:36:46 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Loader Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:36:46 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:36:46 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:36:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-25 05:36:46 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:36:46 --> Session Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:36:46 --> Session routines successfully run
DEBUG - 2015-09-25 05:36:46 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Email Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Controller Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Auth MX_Controller Initialized
DEBUG - 2015-09-25 05:36:46 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:36:46 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:36:46 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-25 05:36:46 --> XSS Filtering completed
DEBUG - 2015-09-25 05:36:46 --> Unable to find validation rule: exists
DEBUG - 2015-09-25 05:36:46 --> XSS Filtering completed
DEBUG - 2015-09-25 05:36:46 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:36:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:36:46 --> URI Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Router Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Output Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Security Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Input Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:36:46 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Loader Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:36:46 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:36:46 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:36:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:36:46 --> Session Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:36:46 --> Session routines successfully run
DEBUG - 2015-09-25 05:36:46 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Email Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Controller Class Initialized
DEBUG - 2015-09-25 05:36:46 --> Admin MX_Controller Initialized
DEBUG - 2015-09-25 05:36:46 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:36:46 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:36:46 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:36:47 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-25 05:36:47 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:36:47 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-25 05:36:47 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:47 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-09-25 05:36:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 05:36:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 05:36:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 05:36:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 05:36:47 --> Final output sent to browser
DEBUG - 2015-09-25 05:36:47 --> Total execution time: 0.1296
DEBUG - 2015-09-25 05:36:52 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:36:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:36:52 --> URI Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Router Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Output Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Security Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Input Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:36:52 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Language Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Config Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Loader Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:36:52 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:36:52 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:36:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-25 05:36:52 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:36:52 --> Session Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:36:52 --> Session routines successfully run
DEBUG - 2015-09-25 05:36:52 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Email Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Controller Class Initialized
DEBUG - 2015-09-25 05:36:52 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:36:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:36:52 --> Model Class Initialized
ERROR - 2015-09-25 05:36:52 --> Severity: Notice  --> Undefined variable: where C:\wamp\www\mfi\application\modules\microfinance\controllers\loans_plan.php 25
DEBUG - 2015-09-25 05:36:52 --> DB Transaction Failure
ERROR - 2015-09-25 05:36:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` IS NULL' at line 3
DEBUG - 2015-09-25 05:36:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 05:48:29 --> Config Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:48:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:48:29 --> URI Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Router Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Output Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Security Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Input Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:48:29 --> Language Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Language Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Config Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Loader Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:48:29 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:48:29 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:48:29 --> Session Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:48:29 --> Session routines successfully run
DEBUG - 2015-09-25 05:48:29 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Email Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Controller Class Initialized
DEBUG - 2015-09-25 05:48:29 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:48:29 --> Model Class Initialized
DEBUG - 2015-09-25 05:48:29 --> DB Transaction Failure
ERROR - 2015-09-25 05:48:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 3
DEBUG - 2015-09-25 05:48:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 05:49:05 --> Config Class Initialized
DEBUG - 2015-09-25 05:49:05 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:49:05 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:49:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:49:05 --> URI Class Initialized
DEBUG - 2015-09-25 05:49:05 --> Router Class Initialized
DEBUG - 2015-09-25 05:49:05 --> Output Class Initialized
DEBUG - 2015-09-25 05:49:05 --> Security Class Initialized
DEBUG - 2015-09-25 05:49:05 --> Input Class Initialized
DEBUG - 2015-09-25 05:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:49:05 --> Language Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Config Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:49:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:49:36 --> URI Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Router Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Output Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Security Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Input Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:49:36 --> Language Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Language Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Config Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Loader Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:49:36 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:49:36 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:49:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:49:36 --> Session Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:49:36 --> Session routines successfully run
DEBUG - 2015-09-25 05:49:36 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Email Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Controller Class Initialized
DEBUG - 2015-09-25 05:49:36 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:49:36 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:36 --> DB Transaction Failure
ERROR - 2015-09-25 05:49:36 --> Query error: Unknown column 'loans_plan.loans_plan_status=1' in 'where clause'
DEBUG - 2015-09-25 05:49:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 05:49:52 --> Config Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:49:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:49:52 --> URI Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Router Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Output Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Security Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Input Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:49:52 --> Language Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Language Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Config Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Loader Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:49:52 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:49:52 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:49:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:49:52 --> Session Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:49:52 --> Session routines successfully run
DEBUG - 2015-09-25 05:49:52 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Email Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Controller Class Initialized
DEBUG - 2015-09-25 05:49:52 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:49:52 --> Model Class Initialized
DEBUG - 2015-09-25 05:49:52 --> DB Transaction Failure
ERROR - 2015-09-25 05:49:52 --> Query error: Unknown column 'loans_plan.loan_plan_status=1' in 'where clause'
DEBUG - 2015-09-25 05:49:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 05:50:05 --> Config Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:50:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:50:05 --> URI Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Router Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Output Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Security Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Input Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:50:05 --> Language Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Language Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Config Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Loader Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:50:05 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:50:05 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:50:05 --> Session Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:50:05 --> Session routines successfully run
DEBUG - 2015-09-25 05:50:05 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Email Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Controller Class Initialized
DEBUG - 2015-09-25 05:50:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:50:05 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:05 --> DB Transaction Failure
ERROR - 2015-09-25 05:50:05 --> Query error: Unknown column 'loan_plan_status=1' in 'where clause'
DEBUG - 2015-09-25 05:50:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 05:50:57 --> Config Class Initialized
DEBUG - 2015-09-25 05:50:57 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:50:57 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:50:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:50:57 --> URI Class Initialized
DEBUG - 2015-09-25 05:50:57 --> Router Class Initialized
DEBUG - 2015-09-25 05:50:57 --> Output Class Initialized
DEBUG - 2015-09-25 05:50:57 --> Security Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Input Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:50:58 --> Language Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Language Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Config Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Loader Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:50:58 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:50:58 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:50:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:50:58 --> Session Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:50:58 --> Session routines successfully run
DEBUG - 2015-09-25 05:50:58 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Email Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Controller Class Initialized
DEBUG - 2015-09-25 05:50:58 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:50:58 --> Model Class Initialized
DEBUG - 2015-09-25 05:50:58 --> DB Transaction Failure
ERROR - 2015-09-25 05:50:58 --> Query error: Unknown column 'loans_plan.loan_plan_status=1' in 'where clause'
DEBUG - 2015-09-25 05:50:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 05:55:54 --> Config Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:55:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:55:54 --> URI Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Router Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Output Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Security Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Input Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:55:54 --> Language Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Language Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Config Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Loader Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:55:54 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:55:54 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:55:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:55:54 --> Session Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:55:54 --> Session routines successfully run
DEBUG - 2015-09-25 05:55:54 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Email Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Controller Class Initialized
DEBUG - 2015-09-25 05:55:54 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:55:54 --> Model Class Initialized
DEBUG - 2015-09-25 05:55:54 --> File loaded: application/modules/microfinance/models/loan_plan_model.php
DEBUG - 2015-09-25 05:56:31 --> Config Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:56:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:56:31 --> URI Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Router Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Output Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Security Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Input Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:56:31 --> Language Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Language Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Config Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Loader Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:56:31 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:56:31 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:56:31 --> Session Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:56:31 --> Session routines successfully run
DEBUG - 2015-09-25 05:56:31 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Email Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Controller Class Initialized
DEBUG - 2015-09-25 05:56:31 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 05:56:31 --> Model Class Initialized
DEBUG - 2015-09-25 05:56:31 --> DB Transaction Failure
ERROR - 2015-09-25 05:56:31 --> Query error: Unknown column 'loans_plan.loan_plan_status=1' in 'where clause'
DEBUG - 2015-09-25 05:56:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 05:58:11 --> Config Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Hooks Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Utf8 Class Initialized
DEBUG - 2015-09-25 05:58:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 05:58:11 --> URI Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Router Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Output Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Security Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Input Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 05:58:11 --> Language Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Language Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Config Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Loader Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Helper loaded: url_helper
DEBUG - 2015-09-25 05:58:11 --> Helper loaded: form_helper
DEBUG - 2015-09-25 05:58:11 --> Database Driver Class Initialized
ERROR - 2015-09-25 05:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 05:58:11 --> Session Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Helper loaded: string_helper
DEBUG - 2015-09-25 05:58:11 --> Session routines successfully run
DEBUG - 2015-09-25 05:58:11 --> Form Validation Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Pagination Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Encrypt Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Email Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Controller Class Initialized
DEBUG - 2015-09-25 05:58:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-09-25 05:58:11 --> DB Transaction Failure
ERROR - 2015-09-25 05:58:11 --> Query error: Unknown column 'loan_plan_status=1' in 'where clause'
DEBUG - 2015-09-25 05:58:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 06:00:07 --> Config Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:00:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:00:07 --> URI Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Router Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Output Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Security Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Input Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:00:07 --> Language Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Language Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Config Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Loader Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:00:07 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:00:07 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:00:07 --> Session Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:00:07 --> Session routines successfully run
DEBUG - 2015-09-25 06:00:07 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Email Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Controller Class Initialized
DEBUG - 2015-09-25 06:00:07 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:00:07 --> Model Class Initialized
DEBUG - 2015-09-25 06:00:07 --> DB Transaction Failure
ERROR - 2015-09-25 06:00:07 --> Query error: Unknown column 'loan_plan_status=1' in 'where clause'
DEBUG - 2015-09-25 06:00:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 06:02:10 --> Config Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:02:10 --> URI Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Router Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Output Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Security Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Input Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:02:10 --> Language Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Language Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Config Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Loader Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:02:10 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:02:10 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:02:10 --> Session Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:02:10 --> Session routines successfully run
DEBUG - 2015-09-25 06:02:10 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Email Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Controller Class Initialized
DEBUG - 2015-09-25 06:02:10 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:02:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:02:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:02:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:02:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:02:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:02:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:02:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:02:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:02:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:02:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:02:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:11 --> DB Transaction Failure
ERROR - 2015-09-25 06:02:11 --> Query error: Unknown column 'loan_plan_status=1' in 'where clause'
DEBUG - 2015-09-25 06:02:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 06:02:13 --> Config Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:02:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:02:13 --> URI Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Router Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Output Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Security Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Input Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:02:13 --> Language Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Language Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Config Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Loader Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:02:13 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:02:13 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:02:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:02:13 --> Session Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:02:13 --> Session routines successfully run
DEBUG - 2015-09-25 06:02:13 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Email Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Controller Class Initialized
DEBUG - 2015-09-25 06:02:13 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:02:13 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:13 --> DB Transaction Failure
ERROR - 2015-09-25 06:02:13 --> Query error: Unknown column 'loan_plan_status=1' in 'where clause'
DEBUG - 2015-09-25 06:02:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 06:02:37 --> Config Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:02:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:02:37 --> URI Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Router Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Output Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Security Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Input Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:02:37 --> Language Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Language Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Config Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Loader Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:02:37 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:02:37 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:02:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:02:37 --> Session Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:02:37 --> Session routines successfully run
DEBUG - 2015-09-25 06:02:37 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Email Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Controller Class Initialized
DEBUG - 2015-09-25 06:02:37 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:02:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:02:37 --> DB Transaction Failure
ERROR - 2015-09-25 06:02:37 --> Query error: Unknown column 'loans_plan_name' in 'order clause'
DEBUG - 2015-09-25 06:02:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 06:07:57 --> Config Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:07:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:07:57 --> URI Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Router Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Output Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Security Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Input Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:07:57 --> Language Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Language Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Config Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Loader Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:07:57 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:07:57 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:07:57 --> Session Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:07:57 --> Session routines successfully run
DEBUG - 2015-09-25 06:07:57 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Email Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Controller Class Initialized
DEBUG - 2015-09-25 06:07:57 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:07:57 --> Model Class Initialized
DEBUG - 2015-09-25 06:07:57 --> DB Transaction Failure
ERROR - 2015-09-25 06:07:57 --> Query error: Unknown column 'loan_plan_status' in 'where clause'
DEBUG - 2015-09-25 06:07:57 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-25 06:08:11 --> Config Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:08:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:08:11 --> URI Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Router Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Output Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Security Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Input Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:08:11 --> Language Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Language Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Config Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Loader Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:08:11 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:08:11 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:08:11 --> Session Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:08:11 --> Session routines successfully run
DEBUG - 2015-09-25 06:08:11 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Email Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Controller Class Initialized
DEBUG - 2015-09-25 06:08:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:08:11 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Config Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:08:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:08:56 --> URI Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Router Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Output Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Security Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Input Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:08:56 --> Language Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Language Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Config Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Loader Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:08:56 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:08:56 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:08:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:08:56 --> Session Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:08:56 --> Session routines successfully run
DEBUG - 2015-09-25 06:08:56 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Email Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Controller Class Initialized
DEBUG - 2015-09-25 06:08:56 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:08:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:08:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Config Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:10:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:10:53 --> URI Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Router Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Output Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Security Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Input Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:10:53 --> Language Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Language Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Config Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Loader Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:10:53 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:10:53 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:10:53 --> Session Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:10:53 --> Session routines successfully run
DEBUG - 2015-09-25 06:10:53 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Email Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Controller Class Initialized
DEBUG - 2015-09-25 06:10:53 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:10:53 --> Model Class Initialized
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:10:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:10:53 --> Final output sent to browser
DEBUG - 2015-09-25 06:10:53 --> Total execution time: 0.1533
DEBUG - 2015-09-25 06:11:10 --> Config Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:11:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:11:10 --> URI Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Router Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Output Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Security Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Input Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:11:10 --> Language Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Language Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Config Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Loader Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:11:10 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:11:10 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:11:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-25 06:11:10 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:11:10 --> Session Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:11:10 --> Session routines successfully run
DEBUG - 2015-09-25 06:11:10 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Email Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Controller Class Initialized
DEBUG - 2015-09-25 06:11:10 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:11:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:11:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:11:10 --> Final output sent to browser
DEBUG - 2015-09-25 06:11:10 --> Total execution time: 0.1376
DEBUG - 2015-09-25 06:11:15 --> Config Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:11:15 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:11:15 --> URI Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Router Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Output Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Security Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Input Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:11:15 --> Language Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Language Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Config Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Loader Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:11:15 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:11:15 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:11:15 --> Session Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:11:15 --> Session routines successfully run
DEBUG - 2015-09-25 06:11:15 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Email Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Controller Class Initialized
DEBUG - 2015-09-25 06:11:15 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:11:15 --> Model Class Initialized
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:11:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:11:15 --> Final output sent to browser
DEBUG - 2015-09-25 06:11:15 --> Total execution time: 0.1330
DEBUG - 2015-09-25 06:12:34 --> Config Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:12:34 --> URI Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Router Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Output Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Security Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Input Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:12:34 --> Language Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Language Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Config Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Loader Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:12:34 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:12:34 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:12:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:12:34 --> Session Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:12:34 --> Session routines successfully run
DEBUG - 2015-09-25 06:12:34 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Email Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Controller Class Initialized
DEBUG - 2015-09-25 06:12:34 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
DEBUG - 2015-09-25 06:12:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:12:34 --> Model Class Initialized
ERROR - 2015-09-25 06:12:34 --> 404 Page Not Found --> microfinance/add-loans-plan
DEBUG - 2015-09-25 06:18:22 --> Config Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:18:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:18:22 --> URI Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Router Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Output Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Security Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Input Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:18:22 --> Language Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Language Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Config Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Loader Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:18:22 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:18:22 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:18:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-25 06:18:22 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:18:22 --> Session Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:18:22 --> Session routines successfully run
DEBUG - 2015-09-25 06:18:22 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Email Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Controller Class Initialized
DEBUG - 2015-09-25 06:18:22 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:18:22 --> Model Class Initialized
ERROR - 2015-09-25 06:18:22 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_opening_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 45
ERROR - 2015-09-25 06:18:22 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 46
ERROR - 2015-09-25 06:18:22 --> Severity: Notice  --> Undefined property: stdClass::$charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 47
ERROR - 2015-09-25 06:18:22 --> Severity: Notice  --> Undefined property: stdClass::$compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 48
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:18:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:18:22 --> Final output sent to browser
DEBUG - 2015-09-25 06:18:22 --> Total execution time: 0.1653
DEBUG - 2015-09-25 06:20:44 --> Config Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:20:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:20:44 --> URI Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Router Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Output Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Security Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Input Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:20:44 --> Language Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Language Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Config Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Loader Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:20:44 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:20:44 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:20:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-25 06:20:44 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:20:44 --> Session Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:20:44 --> Session routines successfully run
DEBUG - 2015-09-25 06:20:44 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Email Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Controller Class Initialized
DEBUG - 2015-09-25 06:20:44 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:20:44 --> Model Class Initialized
ERROR - 2015-09-25 06:20:44 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_opening_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 45
ERROR - 2015-09-25 06:20:44 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 46
ERROR - 2015-09-25 06:20:44 --> Severity: Notice  --> Undefined property: stdClass::$charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 47
ERROR - 2015-09-25 06:20:44 --> Severity: Notice  --> Undefined property: stdClass::$compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 48
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:20:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:20:44 --> Final output sent to browser
DEBUG - 2015-09-25 06:20:44 --> Total execution time: 0.1457
DEBUG - 2015-09-25 06:20:56 --> Config Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:20:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:20:56 --> URI Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Router Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Output Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Security Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Input Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:20:56 --> Language Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Language Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Config Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Loader Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:20:56 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:20:56 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:20:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:20:56 --> Session Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:20:56 --> Session routines successfully run
DEBUG - 2015-09-25 06:20:56 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Email Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Controller Class Initialized
DEBUG - 2015-09-25 06:20:56 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:20:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:20:56 --> Model Class Initialized
ERROR - 2015-09-25 06:20:56 --> 404 Page Not Found --> loans_plan/loans_plan_installment_type
DEBUG - 2015-09-25 06:22:49 --> Config Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:22:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:22:49 --> URI Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Router Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Output Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Security Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Input Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:22:49 --> Language Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Language Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Config Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Loader Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:22:49 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:22:49 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:22:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:22:49 --> Session Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:22:49 --> Session routines successfully run
DEBUG - 2015-09-25 06:22:49 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Email Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Controller Class Initialized
DEBUG - 2015-09-25 06:22:49 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:22:49 --> Model Class Initialized
ERROR - 2015-09-25 06:22:50 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_opening_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 45
ERROR - 2015-09-25 06:22:50 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 46
ERROR - 2015-09-25 06:22:50 --> Severity: Notice  --> Undefined property: stdClass::$charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 47
ERROR - 2015-09-25 06:22:50 --> Severity: Notice  --> Undefined property: stdClass::$compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 48
DEBUG - 2015-09-25 06:22:50 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:22:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:22:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:22:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:22:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:22:50 --> Final output sent to browser
DEBUG - 2015-09-25 06:22:50 --> Total execution time: 0.2666
DEBUG - 2015-09-25 06:22:55 --> Config Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:22:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:22:55 --> URI Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Router Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Output Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Security Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Input Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:22:55 --> Language Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Language Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Config Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Loader Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:22:55 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:22:55 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:22:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:22:55 --> Session Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:22:55 --> Session routines successfully run
DEBUG - 2015-09-25 06:22:55 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Email Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Controller Class Initialized
DEBUG - 2015-09-25 06:22:55 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
DEBUG - 2015-09-25 06:22:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:22:55 --> Model Class Initialized
ERROR - 2015-09-25 06:22:55 --> 404 Page Not Found --> microfinance/loans
DEBUG - 2015-09-25 06:23:18 --> Config Class Initialized
DEBUG - 2015-09-25 06:23:18 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:23:18 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:23:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:23:18 --> URI Class Initialized
DEBUG - 2015-09-25 06:23:18 --> Router Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Output Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Security Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Input Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:23:19 --> Language Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Language Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Config Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Loader Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:23:19 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:23:19 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:23:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:23:19 --> Session Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:23:19 --> Session routines successfully run
DEBUG - 2015-09-25 06:23:19 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Email Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Controller Class Initialized
DEBUG - 2015-09-25 06:23:19 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
DEBUG - 2015-09-25 06:23:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:23:19 --> Model Class Initialized
ERROR - 2015-09-25 06:23:19 --> 404 Page Not Found --> microfinance/edit-loans_plan
DEBUG - 2015-09-25 06:26:36 --> Config Class Initialized
DEBUG - 2015-09-25 06:26:36 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:26:36 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:26:36 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:26:37 --> URI Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Router Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Output Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Security Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Input Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:26:37 --> Language Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Language Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Config Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Loader Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:26:37 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:26:37 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:26:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:26:37 --> Session Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:26:37 --> Session routines successfully run
DEBUG - 2015-09-25 06:26:37 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Email Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Controller Class Initialized
DEBUG - 2015-09-25 06:26:37 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:26:37 --> Model Class Initialized
ERROR - 2015-09-25 06:26:37 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_opening_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 46
ERROR - 2015-09-25 06:26:37 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 47
ERROR - 2015-09-25 06:26:37 --> Severity: Notice  --> Undefined property: stdClass::$charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 48
ERROR - 2015-09-25 06:26:37 --> Severity: Notice  --> Undefined property: stdClass::$compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 49
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:26:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:26:37 --> Final output sent to browser
DEBUG - 2015-09-25 06:26:37 --> Total execution time: 0.5338
DEBUG - 2015-09-25 06:27:16 --> Config Class Initialized
DEBUG - 2015-09-25 06:27:16 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:27:16 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:27:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:27:16 --> URI Class Initialized
DEBUG - 2015-09-25 06:27:16 --> Router Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Output Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Security Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Input Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:27:17 --> Language Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Language Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Config Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Loader Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:27:17 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:27:17 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:27:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:27:17 --> Session Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:27:17 --> Session routines successfully run
DEBUG - 2015-09-25 06:27:17 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Email Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Controller Class Initialized
DEBUG - 2015-09-25 06:27:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:27:17 --> Model Class Initialized
ERROR - 2015-09-25 06:27:17 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_opening_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 45
ERROR - 2015-09-25 06:27:17 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 46
ERROR - 2015-09-25 06:27:17 --> Severity: Notice  --> Undefined property: stdClass::$charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 47
ERROR - 2015-09-25 06:27:17 --> Severity: Notice  --> Undefined property: stdClass::$compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 48
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:27:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:27:17 --> Final output sent to browser
DEBUG - 2015-09-25 06:27:17 --> Total execution time: 0.3379
DEBUG - 2015-09-25 06:30:21 --> Config Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:30:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:30:21 --> URI Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Router Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Output Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Security Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Input Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:30:21 --> Language Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Language Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Config Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Loader Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:30:21 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:30:21 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:30:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:30:21 --> Session Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:30:21 --> Session routines successfully run
DEBUG - 2015-09-25 06:30:21 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Email Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Controller Class Initialized
DEBUG - 2015-09-25 06:30:21 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:30:21 --> Model Class Initialized
ERROR - 2015-09-25 06:30:21 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_opening_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 45
ERROR - 2015-09-25 06:30:21 --> Severity: Notice  --> Undefined property: stdClass::$loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 46
ERROR - 2015-09-25 06:30:21 --> Severity: Notice  --> Undefined property: stdClass::$charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 47
ERROR - 2015-09-25 06:30:21 --> Severity: Notice  --> Undefined property: stdClass::$compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 48
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:30:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:30:21 --> Final output sent to browser
DEBUG - 2015-09-25 06:30:21 --> Total execution time: 0.2448
DEBUG - 2015-09-25 06:32:32 --> Config Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:32:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:32:32 --> URI Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Router Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Output Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Security Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Input Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:32:32 --> Language Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Language Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Config Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Loader Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:32:32 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:32:32 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:32:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:32:32 --> Session Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:32:32 --> Session routines successfully run
DEBUG - 2015-09-25 06:32:32 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Email Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Controller Class Initialized
DEBUG - 2015-09-25 06:32:32 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:32:32 --> Model Class Initialized
ERROR - 2015-09-25 06:32:32 --> Severity: Notice  --> Undefined variable: charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 50
ERROR - 2015-09-25 06:32:32 --> Severity: Notice  --> Undefined variable: loans_plan_min_opening_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 78
ERROR - 2015-09-25 06:32:32 --> Severity: Notice  --> Undefined variable: loans_plan_min_account_balance C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 79
ERROR - 2015-09-25 06:32:32 --> Severity: Notice  --> Undefined variable: compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 80
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:32:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:32:32 --> Final output sent to browser
DEBUG - 2015-09-25 06:32:32 --> Total execution time: 0.3610
DEBUG - 2015-09-25 06:33:09 --> Config Class Initialized
DEBUG - 2015-09-25 06:33:09 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:33:09 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:33:09 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:33:09 --> URI Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Router Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Output Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Security Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Input Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:33:10 --> Language Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Language Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Config Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Loader Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:33:10 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:33:10 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:33:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:33:10 --> Session Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:33:10 --> Session routines successfully run
DEBUG - 2015-09-25 06:33:10 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Email Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Controller Class Initialized
DEBUG - 2015-09-25 06:33:10 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:33:10 --> Model Class Initialized
ERROR - 2015-09-25 06:33:10 --> Severity: Notice  --> Undefined variable: charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 50
ERROR - 2015-09-25 06:33:10 --> Severity: Notice  --> Undefined variable: compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 80
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:33:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:33:10 --> Final output sent to browser
DEBUG - 2015-09-25 06:33:10 --> Total execution time: 0.3801
DEBUG - 2015-09-25 06:33:54 --> Config Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:33:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:33:54 --> URI Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Router Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Output Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Security Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Input Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:33:54 --> Language Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Language Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Config Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Loader Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:33:54 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:33:54 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:33:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:33:54 --> Session Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:33:54 --> Session routines successfully run
DEBUG - 2015-09-25 06:33:54 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Email Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Controller Class Initialized
DEBUG - 2015-09-25 06:33:54 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:33:54 --> Model Class Initialized
ERROR - 2015-09-25 06:33:54 --> Severity: Notice  --> Undefined variable: charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 50
ERROR - 2015-09-25 06:33:54 --> Severity: Notice  --> Undefined variable: loans_plan_installment_type C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 78
ERROR - 2015-09-25 06:33:54 --> Severity: Notice  --> Undefined variable: compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 81
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:33:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:33:54 --> Final output sent to browser
DEBUG - 2015-09-25 06:33:54 --> Total execution time: 0.3229
DEBUG - 2015-09-25 06:34:55 --> Config Class Initialized
DEBUG - 2015-09-25 06:34:55 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:34:55 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:34:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:34:55 --> URI Class Initialized
DEBUG - 2015-09-25 06:34:55 --> Router Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Output Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Security Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Input Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:34:56 --> Language Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Language Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Config Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Loader Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:34:56 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:34:56 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:34:56 --> Session Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:34:56 --> Session routines successfully run
DEBUG - 2015-09-25 06:34:56 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Email Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Controller Class Initialized
DEBUG - 2015-09-25 06:34:56 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:34:56 --> Model Class Initialized
ERROR - 2015-09-25 06:34:56 --> Severity: Notice  --> Undefined variable: charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 50
ERROR - 2015-09-25 06:34:56 --> Severity: Notice  --> Undefined variable: compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 81
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:34:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:34:56 --> Final output sent to browser
DEBUG - 2015-09-25 06:34:56 --> Total execution time: 0.3191
DEBUG - 2015-09-25 06:35:52 --> Config Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:35:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:35:52 --> URI Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Router Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Output Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Security Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Input Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:35:52 --> Language Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Language Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Config Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Loader Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:35:52 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:35:52 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:35:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:35:52 --> Session Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:35:52 --> Session routines successfully run
DEBUG - 2015-09-25 06:35:52 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Email Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Controller Class Initialized
DEBUG - 2015-09-25 06:35:52 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:35:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:35:52 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Config Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:36:02 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:36:02 --> URI Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Router Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Output Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Security Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Input Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:36:02 --> Language Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Language Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Config Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Loader Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:36:02 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:36:02 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:36:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:36:02 --> Session Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:36:02 --> Session routines successfully run
DEBUG - 2015-09-25 06:36:02 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Email Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Controller Class Initialized
DEBUG - 2015-09-25 06:36:02 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:36:02 --> Model Class Initialized
ERROR - 2015-09-25 06:36:02 --> Severity: Notice  --> Undefined variable: charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 50
ERROR - 2015-09-25 06:36:02 --> Severity: Notice  --> Undefined variable: compounding_period_name C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 81
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:36:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:36:02 --> Final output sent to browser
DEBUG - 2015-09-25 06:36:02 --> Total execution time: 0.2415
DEBUG - 2015-09-25 06:36:14 --> Config Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:36:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:36:14 --> URI Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Router Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Output Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Security Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Input Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:36:14 --> Language Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Language Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Config Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Loader Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:36:14 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:36:14 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:36:14 --> Session Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:36:14 --> Session routines successfully run
DEBUG - 2015-09-25 06:36:14 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Email Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Controller Class Initialized
DEBUG - 2015-09-25 06:36:14 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:36:14 --> Model Class Initialized
ERROR - 2015-09-25 06:36:14 --> Severity: Notice  --> Undefined variable: charge_withdrawal C:\wamp\www\mfi\application\modules\microfinance\views\loans_plan\all_loans_plan.php 50
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:36:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:36:14 --> Final output sent to browser
DEBUG - 2015-09-25 06:36:14 --> Total execution time: 0.2666
DEBUG - 2015-09-25 06:36:27 --> Config Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:36:27 --> URI Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Router Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Output Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Security Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Input Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:36:27 --> Language Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Language Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Config Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Loader Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:36:27 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:36:27 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:36:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:36:27 --> Session Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:36:27 --> Session routines successfully run
DEBUG - 2015-09-25 06:36:27 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Email Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Controller Class Initialized
DEBUG - 2015-09-25 06:36:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:36:27 --> Model Class Initialized
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:36:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:36:27 --> Final output sent to browser
DEBUG - 2015-09-25 06:36:27 --> Total execution time: 0.2709
DEBUG - 2015-09-25 06:37:02 --> Config Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:37:02 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:37:02 --> URI Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Router Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Output Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Security Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Input Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:37:02 --> Language Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Language Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Config Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Loader Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:37:02 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:37:02 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:37:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:37:02 --> Session Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:37:02 --> Session routines successfully run
DEBUG - 2015-09-25 06:37:02 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Email Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Controller Class Initialized
DEBUG - 2015-09-25 06:37:02 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:37:02 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Config Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Hooks Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Utf8 Class Initialized
DEBUG - 2015-09-25 06:37:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 06:37:11 --> URI Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Router Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Output Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Security Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Input Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 06:37:11 --> Language Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Language Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Config Class Initialized
DEBUG - 2015-09-25 06:37:11 --> Loader Class Initialized
DEBUG - 2015-09-25 06:37:12 --> Helper loaded: url_helper
DEBUG - 2015-09-25 06:37:12 --> Helper loaded: form_helper
DEBUG - 2015-09-25 06:37:12 --> Database Driver Class Initialized
ERROR - 2015-09-25 06:37:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 06:37:12 --> Session Class Initialized
DEBUG - 2015-09-25 06:37:12 --> Helper loaded: string_helper
DEBUG - 2015-09-25 06:37:12 --> Session routines successfully run
DEBUG - 2015-09-25 06:37:12 --> Form Validation Class Initialized
DEBUG - 2015-09-25 06:37:12 --> Pagination Class Initialized
DEBUG - 2015-09-25 06:37:12 --> Encrypt Class Initialized
DEBUG - 2015-09-25 06:37:12 --> Email Class Initialized
DEBUG - 2015-09-25 06:37:12 --> Controller Class Initialized
DEBUG - 2015-09-25 06:37:12 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 06:37:12 --> Model Class Initialized
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 06:37:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 06:37:12 --> Final output sent to browser
DEBUG - 2015-09-25 06:37:12 --> Total execution time: 0.2515
DEBUG - 2015-09-25 07:10:54 --> Config Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Hooks Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Utf8 Class Initialized
DEBUG - 2015-09-25 07:10:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 07:10:54 --> URI Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Router Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Output Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Security Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Input Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 07:10:54 --> Language Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Language Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Config Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Loader Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Helper loaded: url_helper
DEBUG - 2015-09-25 07:10:54 --> Helper loaded: form_helper
DEBUG - 2015-09-25 07:10:54 --> Database Driver Class Initialized
ERROR - 2015-09-25 07:10:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 07:10:54 --> Session Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Helper loaded: string_helper
DEBUG - 2015-09-25 07:10:54 --> Session routines successfully run
DEBUG - 2015-09-25 07:10:54 --> Form Validation Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Pagination Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Encrypt Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Email Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Controller Class Initialized
DEBUG - 2015-09-25 07:10:54 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 07:10:54 --> Model Class Initialized
ERROR - 2015-09-25 07:10:54 --> 404 Page Not Found --> microfinance/edit-loans_plan
DEBUG - 2015-09-25 07:10:59 --> Config Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Hooks Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Utf8 Class Initialized
DEBUG - 2015-09-25 07:10:59 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 07:10:59 --> URI Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Router Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Output Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Security Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Input Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 07:10:59 --> Language Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Language Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Config Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Loader Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Helper loaded: url_helper
DEBUG - 2015-09-25 07:10:59 --> Helper loaded: form_helper
DEBUG - 2015-09-25 07:10:59 --> Database Driver Class Initialized
ERROR - 2015-09-25 07:10:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 07:10:59 --> Session Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Helper loaded: string_helper
DEBUG - 2015-09-25 07:10:59 --> Session routines successfully run
DEBUG - 2015-09-25 07:10:59 --> Form Validation Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Pagination Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Encrypt Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Email Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Controller Class Initialized
DEBUG - 2015-09-25 07:10:59 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
DEBUG - 2015-09-25 07:10:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 07:10:59 --> Model Class Initialized
ERROR - 2015-09-25 07:10:59 --> 404 Page Not Found --> microfinance/deactivate-loans-plan
DEBUG - 2015-09-25 07:11:11 --> Config Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Hooks Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Utf8 Class Initialized
DEBUG - 2015-09-25 07:11:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 07:11:11 --> URI Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Router Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Output Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Security Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Input Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 07:11:11 --> Language Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Language Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Config Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Loader Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Helper loaded: url_helper
DEBUG - 2015-09-25 07:11:11 --> Helper loaded: form_helper
DEBUG - 2015-09-25 07:11:11 --> Database Driver Class Initialized
ERROR - 2015-09-25 07:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 07:11:11 --> Session Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Helper loaded: string_helper
DEBUG - 2015-09-25 07:11:11 --> Session routines successfully run
DEBUG - 2015-09-25 07:11:11 --> Form Validation Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Pagination Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Encrypt Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Email Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Controller Class Initialized
DEBUG - 2015-09-25 07:11:11 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
DEBUG - 2015-09-25 07:11:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 07:11:11 --> Model Class Initialized
ERROR - 2015-09-25 07:11:11 --> 404 Page Not Found --> microfinance/add-loans-plan
DEBUG - 2015-09-25 07:12:12 --> Config Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Hooks Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Utf8 Class Initialized
DEBUG - 2015-09-25 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 07:12:12 --> URI Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Router Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Output Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Security Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Input Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 07:12:12 --> Language Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Language Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Config Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Loader Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Helper loaded: url_helper
DEBUG - 2015-09-25 07:12:12 --> Helper loaded: form_helper
DEBUG - 2015-09-25 07:12:12 --> Database Driver Class Initialized
ERROR - 2015-09-25 07:12:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 07:12:12 --> Session Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Helper loaded: string_helper
DEBUG - 2015-09-25 07:12:12 --> Session routines successfully run
DEBUG - 2015-09-25 07:12:12 --> Form Validation Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Pagination Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Encrypt Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Email Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Controller Class Initialized
DEBUG - 2015-09-25 07:12:12 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 07:12:12 --> Model Class Initialized
ERROR - 2015-09-25 07:12:12 --> 404 Page Not Found --> microfinance/deposits
DEBUG - 2015-09-25 07:12:18 --> Config Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Hooks Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Utf8 Class Initialized
DEBUG - 2015-09-25 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 07:12:18 --> URI Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Router Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Output Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Security Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Input Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 07:12:18 --> Language Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Language Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Config Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Loader Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Helper loaded: url_helper
DEBUG - 2015-09-25 07:12:18 --> Helper loaded: form_helper
DEBUG - 2015-09-25 07:12:18 --> Database Driver Class Initialized
ERROR - 2015-09-25 07:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 07:12:18 --> Session Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Helper loaded: string_helper
DEBUG - 2015-09-25 07:12:18 --> Session routines successfully run
DEBUG - 2015-09-25 07:12:18 --> Form Validation Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Pagination Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Encrypt Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Email Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Controller Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Individual MX_Controller Initialized
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 07:12:18 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:18 --> Image Lib Class Initialized
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 07:12:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 07:12:18 --> Final output sent to browser
DEBUG - 2015-09-25 07:12:18 --> Total execution time: 0.1548
DEBUG - 2015-09-25 07:12:44 --> Config Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Hooks Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Utf8 Class Initialized
DEBUG - 2015-09-25 07:12:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-25 07:12:44 --> URI Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Router Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Output Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Security Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Input Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-25 07:12:44 --> Language Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Language Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Config Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Loader Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Helper loaded: url_helper
DEBUG - 2015-09-25 07:12:44 --> Helper loaded: form_helper
DEBUG - 2015-09-25 07:12:44 --> Database Driver Class Initialized
ERROR - 2015-09-25 07:12:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-25 07:12:44 --> Session Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Helper loaded: string_helper
DEBUG - 2015-09-25 07:12:44 --> Session routines successfully run
DEBUG - 2015-09-25 07:12:44 --> Form Validation Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Pagination Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Encrypt Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Email Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Controller Class Initialized
DEBUG - 2015-09-25 07:12:44 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-25 07:12:44 --> Model Class Initialized
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-25 07:12:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-25 07:12:44 --> Final output sent to browser
DEBUG - 2015-09-25 07:12:44 --> Total execution time: 0.1364
