<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-01 10:50:28 --> Config Class Initialized
DEBUG - 2015-12-01 10:50:28 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:50:28 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:50:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:50:29 --> URI Class Initialized
DEBUG - 2015-12-01 10:50:30 --> Router Class Initialized
DEBUG - 2015-12-01 10:50:30 --> No URI present. Default controller set.
DEBUG - 2015-12-01 10:50:30 --> Output Class Initialized
DEBUG - 2015-12-01 10:50:30 --> Security Class Initialized
DEBUG - 2015-12-01 10:50:30 --> Input Class Initialized
DEBUG - 2015-12-01 10:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:50:30 --> Language Class Initialized
DEBUG - 2015-12-01 10:50:31 --> Language Class Initialized
DEBUG - 2015-12-01 10:50:31 --> Config Class Initialized
DEBUG - 2015-12-01 10:50:31 --> Loader Class Initialized
DEBUG - 2015-12-01 10:50:31 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:50:32 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:50:34 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:50:36 --> Session Class Initialized
DEBUG - 2015-12-01 10:50:36 --> Helper loaded: string_helper
DEBUG - 2015-12-01 10:50:36 --> A session cookie was not found.
DEBUG - 2015-12-01 10:50:36 --> Session routines successfully run
DEBUG - 2015-12-01 10:50:37 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:50:37 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:50:37 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:50:37 --> Email Class Initialized
DEBUG - 2015-12-01 10:50:37 --> Controller Class Initialized
DEBUG - 2015-12-01 10:50:37 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 10:50:37 --> Model Class Initialized
DEBUG - 2015-12-01 10:50:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:50:37 --> Model Class Initialized
DEBUG - 2015-12-01 10:50:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:50:37 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:51:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:51:03 --> URI Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Router Class Initialized
DEBUG - 2015-12-01 10:51:03 --> No URI present. Default controller set.
DEBUG - 2015-12-01 10:51:03 --> Output Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Security Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Input Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:51:03 --> Language Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Language Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Loader Class Initialized
DEBUG - 2015-12-01 10:51:03 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:51:03 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:51:03 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Session Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Helper loaded: string_helper
ERROR - 2015-12-01 10:51:08 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-12-01 10:51:08 --> Session routines successfully run
DEBUG - 2015-12-01 10:51:08 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Email Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Controller Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 10:51:08 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:51:08 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:51:08 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:51:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:51:08 --> URI Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Router Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Output Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Security Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Input Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:51:08 --> Language Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Language Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Loader Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:51:08 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:51:08 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Session Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Helper loaded: string_helper
DEBUG - 2015-12-01 10:51:08 --> Session routines successfully run
DEBUG - 2015-12-01 10:51:08 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Email Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Controller Class Initialized
DEBUG - 2015-12-01 10:51:08 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 10:51:08 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:51:08 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:51:08 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 10:51:09 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-01 10:51:09 --> Final output sent to browser
DEBUG - 2015-12-01 10:51:09 --> Total execution time: 0.7652
DEBUG - 2015-12-01 10:51:13 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:51:13 --> URI Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Router Class Initialized
ERROR - 2015-12-01 10:51:13 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 10:51:13 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:51:13 --> URI Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Router Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:51:13 --> URI Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Router Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:51:13 --> URI Class Initialized
DEBUG - 2015-12-01 10:51:13 --> Router Class Initialized
ERROR - 2015-12-01 10:51:13 --> 404 Page Not Found --> 
ERROR - 2015-12-01 10:51:13 --> 404 Page Not Found --> 
ERROR - 2015-12-01 10:51:14 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 10:51:21 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:51:21 --> URI Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Router Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Output Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Security Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Input Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:51:21 --> Language Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Language Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Loader Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:51:21 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:51:21 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Session Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Helper loaded: string_helper
DEBUG - 2015-12-01 10:51:21 --> Session routines successfully run
DEBUG - 2015-12-01 10:51:21 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Email Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Controller Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 10:51:21 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:51:21 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:51:21 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 10:51:21 --> XSS Filtering completed
DEBUG - 2015-12-01 10:51:21 --> Unable to find validation rule: exists
DEBUG - 2015-12-01 10:51:21 --> XSS Filtering completed
DEBUG - 2015-12-01 10:51:21 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:51:21 --> URI Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Router Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Output Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Security Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Input Class Initialized
DEBUG - 2015-12-01 10:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:51:21 --> Language Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Language Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Config Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Loader Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:51:22 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:51:22 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Session Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Helper loaded: string_helper
DEBUG - 2015-12-01 10:51:22 --> Session routines successfully run
DEBUG - 2015-12-01 10:51:22 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Email Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Controller Class Initialized
DEBUG - 2015-12-01 10:51:22 --> Admin MX_Controller Initialized
DEBUG - 2015-12-01 10:51:22 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 10:51:22 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:51:22 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:51:22 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 10:51:22 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 10:51:22 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 10:51:22 --> Model Class Initialized
DEBUG - 2015-12-01 10:51:22 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-01 10:51:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 10:51:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 10:51:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 10:51:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 10:51:23 --> Final output sent to browser
DEBUG - 2015-12-01 10:51:23 --> Total execution time: 1.6539
DEBUG - 2015-12-01 10:52:54 --> Config Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:52:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:52:54 --> URI Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Router Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Output Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Security Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Input Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:52:54 --> Language Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Language Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Config Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Loader Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:52:54 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:52:54 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:52:54 --> Session Class Initialized
DEBUG - 2015-12-01 10:52:55 --> Helper loaded: string_helper
DEBUG - 2015-12-01 10:52:55 --> Session routines successfully run
DEBUG - 2015-12-01 10:52:55 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:52:55 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:52:55 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:52:55 --> Email Class Initialized
DEBUG - 2015-12-01 10:52:55 --> Controller Class Initialized
DEBUG - 2015-12-01 10:52:55 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 10:52:55 --> Model Class Initialized
DEBUG - 2015-12-01 10:52:56 --> Image Lib Class Initialized
DEBUG - 2015-12-01 10:52:56 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 10:52:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 10:52:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 10:52:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 10:52:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 10:52:56 --> Final output sent to browser
DEBUG - 2015-12-01 10:52:56 --> Total execution time: 2.0018
DEBUG - 2015-12-01 10:53:11 --> Config Class Initialized
DEBUG - 2015-12-01 10:53:11 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:53:11 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:53:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:53:11 --> URI Class Initialized
DEBUG - 2015-12-01 10:53:11 --> Router Class Initialized
DEBUG - 2015-12-01 10:53:11 --> Output Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Security Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Input Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:53:12 --> Language Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Language Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Config Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Loader Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:53:12 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:53:12 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Session Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Helper loaded: string_helper
DEBUG - 2015-12-01 10:53:12 --> Session routines successfully run
DEBUG - 2015-12-01 10:53:12 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Email Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Controller Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 10:53:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:53:12 --> Image Lib Class Initialized
DEBUG - 2015-12-01 10:53:13 --> File loaded: application/modules/microfinance/views/individual/add_individual.php
DEBUG - 2015-12-01 10:53:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 10:53:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 10:53:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 10:53:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 10:53:13 --> Final output sent to browser
DEBUG - 2015-12-01 10:53:13 --> Total execution time: 1.5073
DEBUG - 2015-12-01 10:53:55 --> Config Class Initialized
DEBUG - 2015-12-01 10:53:56 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:53:56 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:53:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:53:57 --> URI Class Initialized
DEBUG - 2015-12-01 10:53:58 --> Router Class Initialized
DEBUG - 2015-12-01 10:54:01 --> Output Class Initialized
DEBUG - 2015-12-01 10:54:02 --> Security Class Initialized
DEBUG - 2015-12-01 10:54:02 --> Input Class Initialized
DEBUG - 2015-12-01 10:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:54:03 --> Language Class Initialized
DEBUG - 2015-12-01 10:54:06 --> Language Class Initialized
DEBUG - 2015-12-01 10:54:06 --> Config Class Initialized
DEBUG - 2015-12-01 10:54:07 --> Loader Class Initialized
DEBUG - 2015-12-01 10:54:08 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:54:09 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:54:11 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:54:11 --> Session Class Initialized
DEBUG - 2015-12-01 10:54:11 --> Helper loaded: string_helper
DEBUG - 2015-12-01 10:54:11 --> Session routines successfully run
DEBUG - 2015-12-01 10:54:12 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:54:12 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:54:12 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:54:12 --> Email Class Initialized
DEBUG - 2015-12-01 10:54:12 --> Controller Class Initialized
DEBUG - 2015-12-01 10:54:12 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 10:54:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:54:12 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:54:13 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 10:54:13 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 10:54:13 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 10:54:13 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 10:54:13 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 10:54:13 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 10:54:13 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 10:54:14 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 10:54:14 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 10:54:14 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:14 --> Image Lib Class Initialized
DEBUG - 2015-12-01 10:54:14 --> Config Class Initialized
DEBUG - 2015-12-01 10:54:14 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:54:14 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:54:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:54:14 --> URI Class Initialized
DEBUG - 2015-12-01 10:54:14 --> Router Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Output Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Security Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 10:54:15 --> Input Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:54:15 --> Language Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Language Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Config Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Loader Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:54:15 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:54:15 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Session Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Helper loaded: string_helper
DEBUG - 2015-12-01 10:54:15 --> Session routines successfully run
DEBUG - 2015-12-01 10:54:15 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Email Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Controller Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 10:54:15 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:15 --> Image Lib Class Initialized
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 10:54:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 10:54:15 --> Final output sent to browser
DEBUG - 2015-12-01 10:54:15 --> Total execution time: 1.0604
DEBUG - 2015-12-01 10:54:16 --> Final output sent to browser
DEBUG - 2015-12-01 10:54:16 --> Total execution time: 22.3939
DEBUG - 2015-12-01 10:54:20 --> Config Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Hooks Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Utf8 Class Initialized
DEBUG - 2015-12-01 10:54:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 10:54:20 --> URI Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Router Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Output Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Security Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Input Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 10:54:20 --> Language Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Language Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Config Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Loader Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Helper loaded: url_helper
DEBUG - 2015-12-01 10:54:20 --> Helper loaded: form_helper
DEBUG - 2015-12-01 10:54:20 --> Database Driver Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Session Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Helper loaded: string_helper
DEBUG - 2015-12-01 10:54:20 --> Session routines successfully run
DEBUG - 2015-12-01 10:54:20 --> Form Validation Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Pagination Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Encrypt Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Email Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Controller Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 10:54:20 --> Model Class Initialized
DEBUG - 2015-12-01 10:54:20 --> Image Lib Class Initialized
DEBUG - 2015-12-01 10:54:21 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 10:54:21 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 10:54:22 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 10:54:22 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 10:54:22 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 10:54:22 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 10:54:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 10:54:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 10:54:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 10:54:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 10:54:22 --> Final output sent to browser
DEBUG - 2015-12-01 10:54:22 --> Total execution time: 2.2299
DEBUG - 2015-12-01 11:01:44 --> Config Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:01:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:01:44 --> URI Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Router Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Output Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Security Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Input Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:01:44 --> Language Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Language Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Config Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Loader Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:01:44 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:01:44 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Session Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:01:44 --> Session routines successfully run
DEBUG - 2015-12-01 11:01:44 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Email Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Controller Class Initialized
DEBUG - 2015-12-01 11:01:44 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:01:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:01:45 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:01:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:01:45 --> Final output sent to browser
DEBUG - 2015-12-01 11:01:45 --> Total execution time: 1.5729
DEBUG - 2015-12-01 11:02:40 --> Config Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:02:40 --> URI Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Router Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Output Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Security Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Input Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:02:40 --> Language Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Language Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Config Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Loader Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:02:40 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:02:40 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Session Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:02:40 --> Session routines successfully run
DEBUG - 2015-12-01 11:02:40 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Email Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Controller Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:02:40 --> Model Class Initialized
DEBUG - 2015-12-01 11:02:40 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:02:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:02:40 --> Final output sent to browser
DEBUG - 2015-12-01 11:02:40 --> Total execution time: 0.5625
DEBUG - 2015-12-01 11:06:26 --> Config Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:06:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:06:26 --> URI Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Router Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Output Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Security Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Input Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:06:26 --> Language Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Language Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Config Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Loader Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:06:26 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:06:26 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Session Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:06:26 --> Session routines successfully run
DEBUG - 2015-12-01 11:06:26 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Email Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Controller Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:06:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:26 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:06:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:06:26 --> Final output sent to browser
DEBUG - 2015-12-01 11:06:26 --> Total execution time: 0.3960
DEBUG - 2015-12-01 11:06:35 --> Config Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:06:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:06:35 --> URI Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Router Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Output Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Security Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Input Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:06:35 --> Language Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Language Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Config Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Loader Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:06:35 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:06:35 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Session Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:06:35 --> Session routines successfully run
DEBUG - 2015-12-01 11:06:35 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Email Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Controller Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:06:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:06:35 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:06:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:06:35 --> Final output sent to browser
DEBUG - 2015-12-01 11:06:35 --> Total execution time: 0.5595
DEBUG - 2015-12-01 11:07:31 --> Config Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:07:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:07:31 --> URI Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Router Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Output Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Security Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Input Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:07:31 --> Language Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Language Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Config Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Loader Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:07:31 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:07:31 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Session Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:07:31 --> Session routines successfully run
DEBUG - 2015-12-01 11:07:31 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Email Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Controller Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:07:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:07:31 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:07:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:07:31 --> Final output sent to browser
DEBUG - 2015-12-01 11:07:31 --> Total execution time: 0.3210
DEBUG - 2015-12-01 11:08:00 --> Config Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:08:00 --> URI Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Router Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Output Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Security Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Input Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:08:00 --> Language Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Language Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Config Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Loader Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:08:00 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:08:00 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Session Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:08:00 --> Session routines successfully run
DEBUG - 2015-12-01 11:08:00 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Email Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Controller Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:08:00 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:00 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:08:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:08:00 --> Final output sent to browser
DEBUG - 2015-12-01 11:08:00 --> Total execution time: 0.3612
DEBUG - 2015-12-01 11:08:42 --> Config Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:08:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:08:42 --> URI Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Router Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Output Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Security Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Input Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:08:42 --> Language Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Language Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Config Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Loader Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:08:42 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:08:42 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Session Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:08:42 --> Session routines successfully run
DEBUG - 2015-12-01 11:08:42 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Email Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Controller Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:08:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:08:42 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:08:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:08:42 --> Final output sent to browser
DEBUG - 2015-12-01 11:08:42 --> Total execution time: 0.3684
DEBUG - 2015-12-01 11:13:48 --> Config Class Initialized
DEBUG - 2015-12-01 11:13:48 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:13:48 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:13:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:13:48 --> URI Class Initialized
DEBUG - 2015-12-01 11:13:48 --> Router Class Initialized
DEBUG - 2015-12-01 11:13:48 --> Output Class Initialized
DEBUG - 2015-12-01 11:13:48 --> Security Class Initialized
DEBUG - 2015-12-01 11:13:48 --> Input Class Initialized
DEBUG - 2015-12-01 11:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:13:48 --> Language Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Language Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Config Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Loader Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:13:49 --> Config Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:13:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:13:49 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:13:49 --> URI Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Router Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Output Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Security Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Input Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:13:49 --> Language Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Language Class Initialized
DEBUG - 2015-12-01 11:13:49 --> Config Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Session Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:13:50 --> Session routines successfully run
DEBUG - 2015-12-01 11:13:50 --> Loader Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:13:50 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:13:50 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Email Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Controller Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:13:50 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Session Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:13:50 --> Session routines successfully run
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:13:50 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Email Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Controller Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:13:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Model Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:13:50 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:13:51 --> Final output sent to browser
DEBUG - 2015-12-01 11:13:51 --> Total execution time: 3.5930
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:13:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:13:51 --> Final output sent to browser
DEBUG - 2015-12-01 11:13:51 --> Total execution time: 2.6415
DEBUG - 2015-12-01 11:19:15 --> Config Class Initialized
DEBUG - 2015-12-01 11:19:15 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:19:15 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:19:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:19:15 --> URI Class Initialized
DEBUG - 2015-12-01 11:19:15 --> Router Class Initialized
DEBUG - 2015-12-01 11:19:16 --> Output Class Initialized
DEBUG - 2015-12-01 11:19:16 --> Security Class Initialized
DEBUG - 2015-12-01 11:19:16 --> Input Class Initialized
DEBUG - 2015-12-01 11:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:19:16 --> Language Class Initialized
DEBUG - 2015-12-01 11:19:16 --> Language Class Initialized
DEBUG - 2015-12-01 11:19:16 --> Config Class Initialized
DEBUG - 2015-12-01 11:19:16 --> Loader Class Initialized
DEBUG - 2015-12-01 11:19:17 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:19:17 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:19:17 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:19:18 --> Session Class Initialized
DEBUG - 2015-12-01 11:19:18 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:19:18 --> Session routines successfully run
DEBUG - 2015-12-01 11:19:18 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:19:18 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:19:18 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:19:18 --> Email Class Initialized
DEBUG - 2015-12-01 11:19:18 --> Controller Class Initialized
DEBUG - 2015-12-01 11:19:18 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:19:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:19:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:19:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:19:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:19:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:19:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:19:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:19:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:19:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:19:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:19:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:19:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:19:19 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:19:19 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:19:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:19:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:19:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:19:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:19:20 --> Final output sent to browser
DEBUG - 2015-12-01 11:19:20 --> Total execution time: 5.3817
DEBUG - 2015-12-01 11:20:29 --> Config Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:20:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:20:29 --> URI Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Router Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Output Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Security Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Input Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:20:29 --> Language Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Language Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Config Class Initialized
DEBUG - 2015-12-01 11:20:29 --> Loader Class Initialized
DEBUG - 2015-12-01 11:20:30 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:20:30 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:20:30 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:20:30 --> Session Class Initialized
DEBUG - 2015-12-01 11:20:30 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:20:30 --> Session routines successfully run
DEBUG - 2015-12-01 11:20:30 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:20:30 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:20:30 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:20:30 --> Email Class Initialized
DEBUG - 2015-12-01 11:20:30 --> Controller Class Initialized
DEBUG - 2015-12-01 11:20:30 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:20:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:30 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:20:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:20:30 --> Final output sent to browser
DEBUG - 2015-12-01 11:20:30 --> Total execution time: 1.3983
DEBUG - 2015-12-01 11:20:53 --> Config Class Initialized
DEBUG - 2015-12-01 11:20:53 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:20:53 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:20:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:20:53 --> URI Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Router Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Output Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Security Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Input Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:20:54 --> Language Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Language Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Config Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Loader Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:20:54 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:20:54 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Session Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:20:54 --> Session routines successfully run
DEBUG - 2015-12-01 11:20:54 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Email Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Controller Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:20:54 --> Model Class Initialized
DEBUG - 2015-12-01 11:20:54 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:20:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:20:54 --> Final output sent to browser
DEBUG - 2015-12-01 11:20:54 --> Total execution time: 0.4256
DEBUG - 2015-12-01 11:21:13 --> Config Class Initialized
DEBUG - 2015-12-01 11:21:13 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:21:13 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:21:13 --> URI Class Initialized
DEBUG - 2015-12-01 11:21:13 --> Router Class Initialized
ERROR - 2015-12-01 11:21:13 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 11:21:23 --> Config Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:21:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:21:23 --> URI Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Router Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Output Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Security Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Input Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:21:23 --> Language Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Language Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Config Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Loader Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:21:23 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:21:23 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Session Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:21:23 --> Session routines successfully run
DEBUG - 2015-12-01 11:21:23 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Email Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Controller Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:21:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:21:23 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:21:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:21:23 --> Final output sent to browser
DEBUG - 2015-12-01 11:21:23 --> Total execution time: 0.4216
DEBUG - 2015-12-01 11:27:59 --> Config Class Initialized
DEBUG - 2015-12-01 11:27:59 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:27:59 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:27:59 --> URI Class Initialized
DEBUG - 2015-12-01 11:28:00 --> Router Class Initialized
DEBUG - 2015-12-01 11:28:00 --> Output Class Initialized
DEBUG - 2015-12-01 11:28:00 --> Security Class Initialized
DEBUG - 2015-12-01 11:28:00 --> Input Class Initialized
DEBUG - 2015-12-01 11:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:28:01 --> Language Class Initialized
DEBUG - 2015-12-01 11:28:01 --> Language Class Initialized
DEBUG - 2015-12-01 11:28:01 --> Config Class Initialized
DEBUG - 2015-12-01 11:28:01 --> Loader Class Initialized
DEBUG - 2015-12-01 11:28:02 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:28:02 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:28:02 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:28:02 --> Session Class Initialized
DEBUG - 2015-12-01 11:28:03 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:28:03 --> Session routines successfully run
DEBUG - 2015-12-01 11:28:03 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:28:03 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:28:03 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:28:03 --> Email Class Initialized
DEBUG - 2015-12-01 11:28:03 --> Controller Class Initialized
DEBUG - 2015-12-01 11:28:03 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:28:03 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:28:03 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:28:03 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:28:03 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:28:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:28:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:28:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:28:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:28:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:28:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:28:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:28:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:28:04 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:28:04 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:28:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:28:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:28:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:28:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:28:05 --> Final output sent to browser
DEBUG - 2015-12-01 11:28:05 --> Total execution time: 6.0595
DEBUG - 2015-12-01 11:29:39 --> Config Class Initialized
DEBUG - 2015-12-01 11:29:39 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:29:39 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:29:39 --> URI Class Initialized
DEBUG - 2015-12-01 11:29:40 --> Router Class Initialized
DEBUG - 2015-12-01 11:29:40 --> Output Class Initialized
DEBUG - 2015-12-01 11:29:40 --> Security Class Initialized
DEBUG - 2015-12-01 11:29:40 --> Input Class Initialized
DEBUG - 2015-12-01 11:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:29:40 --> Language Class Initialized
DEBUG - 2015-12-01 11:29:40 --> Language Class Initialized
DEBUG - 2015-12-01 11:29:40 --> Config Class Initialized
DEBUG - 2015-12-01 11:29:40 --> Loader Class Initialized
DEBUG - 2015-12-01 11:29:40 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:29:40 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:29:41 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:29:41 --> Session Class Initialized
DEBUG - 2015-12-01 11:29:41 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:29:41 --> Session routines successfully run
DEBUG - 2015-12-01 11:29:41 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:29:41 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:29:41 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:29:41 --> Email Class Initialized
DEBUG - 2015-12-01 11:29:41 --> Controller Class Initialized
DEBUG - 2015-12-01 11:29:41 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:29:41 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:29:41 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:29:41 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:29:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:29:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:29:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:29:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:29:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:29:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:29:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:29:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:29:42 --> Model Class Initialized
DEBUG - 2015-12-01 11:29:42 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:29:42 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:29:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:29:43 --> Final output sent to browser
DEBUG - 2015-12-01 11:29:43 --> Total execution time: 4.5352
DEBUG - 2015-12-01 11:31:20 --> Config Class Initialized
DEBUG - 2015-12-01 11:31:20 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:31:20 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:31:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:31:20 --> URI Class Initialized
DEBUG - 2015-12-01 11:31:21 --> Router Class Initialized
DEBUG - 2015-12-01 11:31:21 --> Output Class Initialized
DEBUG - 2015-12-01 11:31:21 --> Security Class Initialized
DEBUG - 2015-12-01 11:31:21 --> Input Class Initialized
DEBUG - 2015-12-01 11:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:31:21 --> Language Class Initialized
DEBUG - 2015-12-01 11:31:21 --> Language Class Initialized
DEBUG - 2015-12-01 11:31:21 --> Config Class Initialized
DEBUG - 2015-12-01 11:31:21 --> Loader Class Initialized
DEBUG - 2015-12-01 11:31:21 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:31:22 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:31:23 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:31:24 --> Session Class Initialized
DEBUG - 2015-12-01 11:31:24 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:31:24 --> Session routines successfully run
DEBUG - 2015-12-01 11:31:24 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:31:25 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:31:25 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:31:25 --> Email Class Initialized
DEBUG - 2015-12-01 11:31:25 --> Controller Class Initialized
DEBUG - 2015-12-01 11:31:25 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:31:25 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:31:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:31:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:31:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:31:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:31:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:31:26 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:31:27 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:31:27 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:31:27 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:31:27 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:31:28 --> Model Class Initialized
DEBUG - 2015-12-01 11:31:28 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:31:28 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:31:30 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:31:30 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:31:30 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:31:30 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:31:30 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:31:30 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:31:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:31:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:31:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:31:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:31:31 --> Final output sent to browser
DEBUG - 2015-12-01 11:31:31 --> Total execution time: 10.9653
DEBUG - 2015-12-01 11:32:22 --> Config Class Initialized
DEBUG - 2015-12-01 11:32:22 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:32:22 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:32:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:32:22 --> URI Class Initialized
DEBUG - 2015-12-01 11:32:23 --> Router Class Initialized
DEBUG - 2015-12-01 11:32:25 --> Output Class Initialized
DEBUG - 2015-12-01 11:32:25 --> Security Class Initialized
DEBUG - 2015-12-01 11:32:25 --> Input Class Initialized
DEBUG - 2015-12-01 11:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:32:25 --> Language Class Initialized
DEBUG - 2015-12-01 11:32:26 --> Language Class Initialized
DEBUG - 2015-12-01 11:32:26 --> Config Class Initialized
DEBUG - 2015-12-01 11:32:26 --> Loader Class Initialized
DEBUG - 2015-12-01 11:32:26 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:32:27 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:32:28 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:32:28 --> Session Class Initialized
DEBUG - 2015-12-01 11:32:29 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:32:29 --> Session routines successfully run
DEBUG - 2015-12-01 11:32:29 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:32:29 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:32:30 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:32:30 --> Email Class Initialized
DEBUG - 2015-12-01 11:32:30 --> Controller Class Initialized
DEBUG - 2015-12-01 11:32:30 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:32:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:32:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:32:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:32:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:32:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:32:31 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:32:32 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:32:32 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:32:32 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:32:32 --> Model Class Initialized
DEBUG - 2015-12-01 11:32:33 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:32:35 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:32:35 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:32:35 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:32:35 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:32:35 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:32:35 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:32:35 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:32:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:32:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:32:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:32:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:32:38 --> Final output sent to browser
DEBUG - 2015-12-01 11:32:38 --> Total execution time: 17.5017
DEBUG - 2015-12-01 11:38:39 --> Config Class Initialized
DEBUG - 2015-12-01 11:38:40 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:38:40 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:38:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:38:40 --> URI Class Initialized
DEBUG - 2015-12-01 11:38:40 --> Router Class Initialized
DEBUG - 2015-12-01 11:38:40 --> Output Class Initialized
DEBUG - 2015-12-01 11:38:41 --> Security Class Initialized
DEBUG - 2015-12-01 11:38:41 --> Input Class Initialized
DEBUG - 2015-12-01 11:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:38:41 --> Language Class Initialized
DEBUG - 2015-12-01 11:38:42 --> Language Class Initialized
DEBUG - 2015-12-01 11:38:42 --> Config Class Initialized
DEBUG - 2015-12-01 11:38:42 --> Loader Class Initialized
DEBUG - 2015-12-01 11:38:42 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:38:42 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:38:42 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:38:43 --> Session Class Initialized
DEBUG - 2015-12-01 11:38:43 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:38:43 --> Session routines successfully run
DEBUG - 2015-12-01 11:38:43 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:38:43 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:38:43 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:38:43 --> Email Class Initialized
DEBUG - 2015-12-01 11:38:43 --> Controller Class Initialized
DEBUG - 2015-12-01 11:38:43 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:38:43 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:38:43 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:38:43 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:38:44 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:38:44 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:38:44 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:38:44 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:38:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:38:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:38:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:38:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:38:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:38:45 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:38:45 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:38:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:38:46 --> Final output sent to browser
DEBUG - 2015-12-01 11:38:46 --> Total execution time: 6.9012
DEBUG - 2015-12-01 11:39:15 --> Config Class Initialized
DEBUG - 2015-12-01 11:39:15 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:39:15 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:39:15 --> URI Class Initialized
DEBUG - 2015-12-01 11:39:16 --> Router Class Initialized
DEBUG - 2015-12-01 11:39:16 --> Output Class Initialized
DEBUG - 2015-12-01 11:39:17 --> Security Class Initialized
DEBUG - 2015-12-01 11:39:17 --> Input Class Initialized
DEBUG - 2015-12-01 11:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:39:17 --> Language Class Initialized
DEBUG - 2015-12-01 11:39:18 --> Language Class Initialized
DEBUG - 2015-12-01 11:39:18 --> Config Class Initialized
DEBUG - 2015-12-01 11:39:18 --> Loader Class Initialized
DEBUG - 2015-12-01 11:39:18 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:39:18 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:39:19 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:39:19 --> Session Class Initialized
DEBUG - 2015-12-01 11:39:19 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:39:19 --> Session routines successfully run
DEBUG - 2015-12-01 11:39:19 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:39:19 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:39:19 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:39:19 --> Email Class Initialized
DEBUG - 2015-12-01 11:39:19 --> Controller Class Initialized
DEBUG - 2015-12-01 11:39:19 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:39:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:39:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:39:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:39:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:39:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:39:21 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:39:21 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:39:21 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:39:21 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:39:21 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:39:21 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:39:21 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:21 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:39:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:39:22 --> Final output sent to browser
DEBUG - 2015-12-01 11:39:22 --> Total execution time: 7.2178
DEBUG - 2015-12-01 11:39:56 --> Config Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:39:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:39:57 --> URI Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Router Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Output Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Security Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Input Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:39:57 --> Language Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Language Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Config Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Loader Class Initialized
DEBUG - 2015-12-01 11:39:57 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:39:57 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:39:58 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:39:58 --> Session Class Initialized
DEBUG - 2015-12-01 11:39:58 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:39:58 --> Session routines successfully run
DEBUG - 2015-12-01 11:39:58 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:39:58 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:39:58 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:39:58 --> Email Class Initialized
DEBUG - 2015-12-01 11:39:58 --> Controller Class Initialized
DEBUG - 2015-12-01 11:39:58 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:39:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:39:58 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:39:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:39:59 --> Final output sent to browser
DEBUG - 2015-12-01 11:39:59 --> Total execution time: 2.6898
DEBUG - 2015-12-01 11:40:17 --> Config Class Initialized
DEBUG - 2015-12-01 11:40:17 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:40:17 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:40:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:40:17 --> URI Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Router Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Output Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Security Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Input Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:40:18 --> Language Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Language Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Config Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Loader Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:40:18 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:40:18 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Session Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:40:18 --> Session routines successfully run
DEBUG - 2015-12-01 11:40:18 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Email Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Controller Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:40:18 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:18 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:40:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:40:19 --> Final output sent to browser
DEBUG - 2015-12-01 11:40:19 --> Total execution time: 1.5879
DEBUG - 2015-12-01 11:40:43 --> Config Class Initialized
DEBUG - 2015-12-01 11:40:43 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:40:43 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:40:43 --> URI Class Initialized
DEBUG - 2015-12-01 11:40:43 --> Router Class Initialized
DEBUG - 2015-12-01 11:40:43 --> Output Class Initialized
DEBUG - 2015-12-01 11:40:43 --> Security Class Initialized
DEBUG - 2015-12-01 11:40:43 --> Input Class Initialized
DEBUG - 2015-12-01 11:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:40:43 --> Language Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Language Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Config Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Loader Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:40:44 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:40:44 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Session Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:40:44 --> Session routines successfully run
DEBUG - 2015-12-01 11:40:44 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Email Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Controller Class Initialized
DEBUG - 2015-12-01 11:40:44 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:40:45 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:45 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:40:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:40:45 --> Final output sent to browser
DEBUG - 2015-12-01 11:40:45 --> Total execution time: 2.5187
DEBUG - 2015-12-01 11:40:56 --> Config Class Initialized
DEBUG - 2015-12-01 11:40:56 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:40:56 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:40:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:40:56 --> URI Class Initialized
DEBUG - 2015-12-01 11:40:56 --> Router Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Output Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Security Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Input Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:40:57 --> Language Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Language Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Config Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Loader Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:40:57 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:40:57 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Session Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:40:57 --> Session routines successfully run
DEBUG - 2015-12-01 11:40:57 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Email Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Controller Class Initialized
DEBUG - 2015-12-01 11:40:57 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:40:57 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:40:57 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:40:57 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:40:57 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:40:57 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:40:57 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:40:57 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:40:57 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:40:57 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:40:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:40:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:40:58 --> Model Class Initialized
DEBUG - 2015-12-01 11:40:58 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:40:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:40:58 --> Final output sent to browser
DEBUG - 2015-12-01 11:40:58 --> Total execution time: 2.0024
DEBUG - 2015-12-01 11:41:37 --> Config Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:41:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:41:38 --> URI Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Router Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Output Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Security Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Input Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:41:38 --> Language Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Language Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Config Class Initialized
DEBUG - 2015-12-01 11:41:38 --> Loader Class Initialized
DEBUG - 2015-12-01 11:41:39 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:41:39 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:41:39 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:41:39 --> Session Class Initialized
DEBUG - 2015-12-01 11:41:39 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:41:39 --> Session routines successfully run
DEBUG - 2015-12-01 11:41:39 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:41:39 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:41:39 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:41:39 --> Email Class Initialized
DEBUG - 2015-12-01 11:41:39 --> Controller Class Initialized
DEBUG - 2015-12-01 11:41:39 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:41:39 --> Model Class Initialized
DEBUG - 2015-12-01 11:41:39 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:41:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:41:40 --> Final output sent to browser
DEBUG - 2015-12-01 11:41:40 --> Total execution time: 2.4675
DEBUG - 2015-12-01 11:42:08 --> Config Class Initialized
DEBUG - 2015-12-01 11:42:09 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:42:09 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:42:09 --> URI Class Initialized
DEBUG - 2015-12-01 11:42:10 --> Router Class Initialized
DEBUG - 2015-12-01 11:42:10 --> Output Class Initialized
DEBUG - 2015-12-01 11:42:11 --> Security Class Initialized
DEBUG - 2015-12-01 11:42:11 --> Input Class Initialized
DEBUG - 2015-12-01 11:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:42:11 --> Language Class Initialized
DEBUG - 2015-12-01 11:42:11 --> Language Class Initialized
DEBUG - 2015-12-01 11:42:11 --> Config Class Initialized
DEBUG - 2015-12-01 11:42:12 --> Loader Class Initialized
DEBUG - 2015-12-01 11:42:12 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:42:13 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:42:14 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:42:14 --> Session Class Initialized
DEBUG - 2015-12-01 11:42:14 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:42:14 --> Session routines successfully run
DEBUG - 2015-12-01 11:42:14 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:42:14 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:42:14 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:42:15 --> Email Class Initialized
DEBUG - 2015-12-01 11:42:15 --> Controller Class Initialized
DEBUG - 2015-12-01 11:42:15 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:42:15 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:42:15 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:42:15 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:42:15 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:42:15 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:42:15 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:42:15 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:42:15 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:42:16 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:42:16 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:42:16 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:42:16 --> Model Class Initialized
DEBUG - 2015-12-01 11:42:16 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:42:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:42:17 --> Final output sent to browser
DEBUG - 2015-12-01 11:42:17 --> Total execution time: 13.4970
DEBUG - 2015-12-01 11:43:47 --> Config Class Initialized
DEBUG - 2015-12-01 11:43:48 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:43:48 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:43:49 --> URI Class Initialized
DEBUG - 2015-12-01 11:43:50 --> Router Class Initialized
DEBUG - 2015-12-01 11:43:51 --> Output Class Initialized
DEBUG - 2015-12-01 11:43:51 --> Security Class Initialized
DEBUG - 2015-12-01 11:43:52 --> Input Class Initialized
DEBUG - 2015-12-01 11:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:43:52 --> Language Class Initialized
DEBUG - 2015-12-01 11:43:53 --> Language Class Initialized
DEBUG - 2015-12-01 11:43:53 --> Config Class Initialized
DEBUG - 2015-12-01 11:43:53 --> Loader Class Initialized
DEBUG - 2015-12-01 11:43:54 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:43:54 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:43:57 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:43:58 --> Session Class Initialized
DEBUG - 2015-12-01 11:43:58 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:43:58 --> Session routines successfully run
DEBUG - 2015-12-01 11:43:59 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:44:00 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:44:00 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:44:01 --> Email Class Initialized
DEBUG - 2015-12-01 11:44:01 --> Controller Class Initialized
DEBUG - 2015-12-01 11:44:01 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:44:01 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:44:01 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:44:01 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:44:02 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:44:03 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:44:03 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:44:03 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:44:03 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:44:03 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:44:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:44:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:44:04 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:04 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:44:05 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:44:05 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:44:05 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:44:05 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:44:05 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:44:05 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:44:05 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:44:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:44:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:44:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:44:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:44:07 --> Final output sent to browser
DEBUG - 2015-12-01 11:44:07 --> Total execution time: 20.7144
DEBUG - 2015-12-01 11:44:46 --> Config Class Initialized
DEBUG - 2015-12-01 11:44:46 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:44:46 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:44:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:44:46 --> URI Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Router Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Output Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Security Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Input Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:44:47 --> Language Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Language Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Config Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Loader Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:44:47 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:44:47 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Session Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:44:47 --> Session routines successfully run
DEBUG - 2015-12-01 11:44:47 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Email Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Controller Class Initialized
DEBUG - 2015-12-01 11:44:47 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:44:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:44:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:44:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:44:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:44:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:44:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:44:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:44:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:44:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:44:48 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:44:48 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:44:48 --> Model Class Initialized
DEBUG - 2015-12-01 11:44:48 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:44:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:44:48 --> Final output sent to browser
DEBUG - 2015-12-01 11:44:48 --> Total execution time: 2.0250
DEBUG - 2015-12-01 11:45:13 --> Config Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:45:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:45:13 --> URI Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Router Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Output Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Security Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Input Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:45:13 --> Language Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Language Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Config Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Loader Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:45:13 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:45:13 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Session Class Initialized
DEBUG - 2015-12-01 11:45:13 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:45:13 --> Session routines successfully run
DEBUG - 2015-12-01 11:45:13 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:45:14 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:45:14 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:45:14 --> Email Class Initialized
DEBUG - 2015-12-01 11:45:14 --> Controller Class Initialized
DEBUG - 2015-12-01 11:45:14 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:45:14 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:14 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:45:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:45:14 --> Final output sent to browser
DEBUG - 2015-12-01 11:45:14 --> Total execution time: 1.8708
DEBUG - 2015-12-01 11:45:44 --> Config Class Initialized
DEBUG - 2015-12-01 11:45:45 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:45:45 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:45:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:45:45 --> URI Class Initialized
DEBUG - 2015-12-01 11:45:45 --> Router Class Initialized
DEBUG - 2015-12-01 11:45:45 --> Output Class Initialized
DEBUG - 2015-12-01 11:45:45 --> Security Class Initialized
DEBUG - 2015-12-01 11:45:45 --> Input Class Initialized
DEBUG - 2015-12-01 11:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:45:45 --> Language Class Initialized
DEBUG - 2015-12-01 11:45:46 --> Language Class Initialized
DEBUG - 2015-12-01 11:45:46 --> Config Class Initialized
DEBUG - 2015-12-01 11:45:46 --> Loader Class Initialized
DEBUG - 2015-12-01 11:45:46 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:45:46 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:45:46 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:45:46 --> Session Class Initialized
DEBUG - 2015-12-01 11:45:46 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:45:46 --> Session routines successfully run
DEBUG - 2015-12-01 11:45:46 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:45:46 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:45:46 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:45:47 --> Email Class Initialized
DEBUG - 2015-12-01 11:45:47 --> Controller Class Initialized
DEBUG - 2015-12-01 11:45:47 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:45:47 --> Model Class Initialized
DEBUG - 2015-12-01 11:45:47 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:45:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:45:47 --> Final output sent to browser
DEBUG - 2015-12-01 11:45:47 --> Total execution time: 2.7823
DEBUG - 2015-12-01 11:46:19 --> Config Class Initialized
DEBUG - 2015-12-01 11:46:19 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:46:19 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:46:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:46:19 --> URI Class Initialized
DEBUG - 2015-12-01 11:46:20 --> Router Class Initialized
DEBUG - 2015-12-01 11:46:20 --> Output Class Initialized
DEBUG - 2015-12-01 11:46:20 --> Security Class Initialized
DEBUG - 2015-12-01 11:46:20 --> Input Class Initialized
DEBUG - 2015-12-01 11:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:46:20 --> Language Class Initialized
DEBUG - 2015-12-01 11:46:21 --> Language Class Initialized
DEBUG - 2015-12-01 11:46:21 --> Config Class Initialized
DEBUG - 2015-12-01 11:46:21 --> Loader Class Initialized
DEBUG - 2015-12-01 11:46:21 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:46:21 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:46:21 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:46:22 --> Session Class Initialized
DEBUG - 2015-12-01 11:46:22 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:46:22 --> Session routines successfully run
DEBUG - 2015-12-01 11:46:22 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:46:22 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:46:22 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:46:22 --> Email Class Initialized
DEBUG - 2015-12-01 11:46:22 --> Controller Class Initialized
DEBUG - 2015-12-01 11:46:22 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:46:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:46:23 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:23 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:46:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:46:23 --> Final output sent to browser
DEBUG - 2015-12-01 11:46:23 --> Total execution time: 4.3798
DEBUG - 2015-12-01 11:46:58 --> Config Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:46:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:46:58 --> URI Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Router Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Output Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Security Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Input Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:46:58 --> Language Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Language Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Config Class Initialized
DEBUG - 2015-12-01 11:46:58 --> Loader Class Initialized
DEBUG - 2015-12-01 11:46:59 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:46:59 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:46:59 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:46:59 --> Session Class Initialized
DEBUG - 2015-12-01 11:46:59 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:46:59 --> Session routines successfully run
DEBUG - 2015-12-01 11:46:59 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:46:59 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:46:59 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:46:59 --> Email Class Initialized
DEBUG - 2015-12-01 11:46:59 --> Controller Class Initialized
DEBUG - 2015-12-01 11:46:59 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:46:59 --> Model Class Initialized
DEBUG - 2015-12-01 11:46:59 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:46:59 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:47:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:47:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:47:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:47:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:47:00 --> Final output sent to browser
DEBUG - 2015-12-01 11:47:00 --> Total execution time: 1.9562
DEBUG - 2015-12-01 11:47:19 --> Config Class Initialized
DEBUG - 2015-12-01 11:47:19 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:47:19 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:47:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:47:19 --> URI Class Initialized
DEBUG - 2015-12-01 11:47:19 --> Router Class Initialized
DEBUG - 2015-12-01 11:47:19 --> Output Class Initialized
DEBUG - 2015-12-01 11:47:19 --> Security Class Initialized
DEBUG - 2015-12-01 11:47:19 --> Input Class Initialized
DEBUG - 2015-12-01 11:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:47:20 --> Language Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Language Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Config Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Loader Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:47:20 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:47:20 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Session Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:47:20 --> Session routines successfully run
DEBUG - 2015-12-01 11:47:20 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Email Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Controller Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:47:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:47:20 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:47:20 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:47:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:47:21 --> Final output sent to browser
DEBUG - 2015-12-01 11:47:21 --> Total execution time: 1.7005
DEBUG - 2015-12-01 11:50:18 --> Config Class Initialized
DEBUG - 2015-12-01 11:50:18 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:50:18 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:50:18 --> URI Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Router Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Output Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Security Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Input Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:50:19 --> Language Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Language Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Config Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Loader Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:50:19 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:50:19 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Session Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:50:19 --> Session routines successfully run
DEBUG - 2015-12-01 11:50:19 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Email Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Controller Class Initialized
DEBUG - 2015-12-01 11:50:19 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:50:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:50:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:50:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:50:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:50:19 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:50:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:50:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:50:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:50:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:50:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:50:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:50:20 --> Model Class Initialized
DEBUG - 2015-12-01 11:50:20 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:50:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:50:20 --> Final output sent to browser
DEBUG - 2015-12-01 11:50:20 --> Total execution time: 2.0849
DEBUG - 2015-12-01 11:55:34 --> Config Class Initialized
DEBUG - 2015-12-01 11:55:34 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:55:34 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:55:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:55:34 --> URI Class Initialized
DEBUG - 2015-12-01 11:55:34 --> Router Class Initialized
DEBUG - 2015-12-01 11:55:34 --> Output Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Security Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Input Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:55:35 --> Language Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Language Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Config Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Loader Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:55:35 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:55:35 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Session Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:55:35 --> Session routines successfully run
DEBUG - 2015-12-01 11:55:35 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Email Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Controller Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:55:35 --> Model Class Initialized
DEBUG - 2015-12-01 11:55:35 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:55:35 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:55:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:55:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:55:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:55:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:55:36 --> Final output sent to browser
DEBUG - 2015-12-01 11:55:36 --> Total execution time: 1.5762
DEBUG - 2015-12-01 11:56:22 --> Config Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:56:22 --> URI Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Router Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Output Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Security Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Input Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:56:22 --> Language Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Language Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Config Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Loader Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:56:22 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:56:22 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Session Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:56:22 --> Session routines successfully run
DEBUG - 2015-12-01 11:56:22 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Email Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Controller Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:56:22 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:22 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:56:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:56:22 --> Final output sent to browser
DEBUG - 2015-12-01 11:56:22 --> Total execution time: 0.2915
DEBUG - 2015-12-01 11:56:36 --> Config Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:56:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:56:36 --> URI Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Router Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Output Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Security Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Input Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:56:36 --> Language Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Language Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Config Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Loader Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:56:36 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:56:36 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Session Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:56:36 --> Session routines successfully run
DEBUG - 2015-12-01 11:56:36 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Email Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Controller Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:56:36 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:36 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:56:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:56:37 --> Final output sent to browser
DEBUG - 2015-12-01 11:56:37 --> Total execution time: 0.4198
DEBUG - 2015-12-01 11:56:55 --> Config Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:56:55 --> URI Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Router Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Output Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Security Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Input Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:56:55 --> Language Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Language Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Config Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Loader Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:56:55 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:56:55 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Session Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:56:55 --> Session routines successfully run
DEBUG - 2015-12-01 11:56:55 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Email Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Controller Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:56:55 --> Model Class Initialized
DEBUG - 2015-12-01 11:56:55 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:56:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:56:55 --> Final output sent to browser
DEBUG - 2015-12-01 11:56:55 --> Total execution time: 0.2928
DEBUG - 2015-12-01 11:58:49 --> Config Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Hooks Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Utf8 Class Initialized
DEBUG - 2015-12-01 11:58:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 11:58:49 --> URI Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Router Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Output Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Security Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Input Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 11:58:49 --> Language Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Language Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Config Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Loader Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Helper loaded: url_helper
DEBUG - 2015-12-01 11:58:49 --> Helper loaded: form_helper
DEBUG - 2015-12-01 11:58:49 --> Database Driver Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Session Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Helper loaded: string_helper
DEBUG - 2015-12-01 11:58:49 --> Session routines successfully run
DEBUG - 2015-12-01 11:58:49 --> Form Validation Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Pagination Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Encrypt Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Email Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Controller Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 11:58:49 --> Model Class Initialized
DEBUG - 2015-12-01 11:58:49 --> Image Lib Class Initialized
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 11:58:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 11:58:49 --> Final output sent to browser
DEBUG - 2015-12-01 11:58:49 --> Total execution time: 0.3192
DEBUG - 2015-12-01 12:00:49 --> Config Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Hooks Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Utf8 Class Initialized
DEBUG - 2015-12-01 12:00:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 12:00:49 --> URI Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Router Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Output Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Security Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Input Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 12:00:49 --> Language Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Language Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Config Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Loader Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Helper loaded: url_helper
DEBUG - 2015-12-01 12:00:49 --> Helper loaded: form_helper
DEBUG - 2015-12-01 12:00:49 --> Database Driver Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Session Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Helper loaded: string_helper
DEBUG - 2015-12-01 12:00:49 --> Session routines successfully run
DEBUG - 2015-12-01 12:00:49 --> Form Validation Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Pagination Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Encrypt Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Email Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Controller Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 12:00:49 --> Model Class Initialized
DEBUG - 2015-12-01 12:00:49 --> Image Lib Class Initialized
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 12:00:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 12:00:49 --> Final output sent to browser
DEBUG - 2015-12-01 12:00:49 --> Total execution time: 0.2944
DEBUG - 2015-12-01 12:01:20 --> Config Class Initialized
DEBUG - 2015-12-01 12:01:20 --> Hooks Class Initialized
DEBUG - 2015-12-01 12:01:20 --> Utf8 Class Initialized
DEBUG - 2015-12-01 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 12:01:20 --> URI Class Initialized
DEBUG - 2015-12-01 12:01:20 --> Router Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Output Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Security Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Input Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 12:01:21 --> Language Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Language Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Config Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Loader Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Helper loaded: url_helper
DEBUG - 2015-12-01 12:01:21 --> Helper loaded: form_helper
DEBUG - 2015-12-01 12:01:21 --> Database Driver Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Session Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Helper loaded: string_helper
DEBUG - 2015-12-01 12:01:21 --> Session routines successfully run
DEBUG - 2015-12-01 12:01:21 --> Form Validation Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Pagination Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Encrypt Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Email Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Controller Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 12:01:21 --> Model Class Initialized
DEBUG - 2015-12-01 12:01:21 --> Image Lib Class Initialized
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 12:01:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 12:01:21 --> Final output sent to browser
DEBUG - 2015-12-01 12:01:21 --> Total execution time: 0.2847
DEBUG - 2015-12-01 13:32:28 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:28 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:32:28 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:32:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:32:28 --> URI Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Router Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Output Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Security Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Input Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:32:29 --> Language Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Language Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Loader Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:32:29 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:32:29 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Session Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Helper loaded: string_helper
ERROR - 2015-12-01 13:32:29 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-12-01 13:32:29 --> Session routines successfully run
DEBUG - 2015-12-01 13:32:29 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Email Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Controller Class Initialized
DEBUG - 2015-12-01 13:32:29 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 13:32:29 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:32:29 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:32:30 --> URI Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Router Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Output Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Security Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Input Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:32:30 --> Language Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Language Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Loader Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:32:30 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:32:30 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Session Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Helper loaded: string_helper
DEBUG - 2015-12-01 13:32:30 --> Session routines successfully run
DEBUG - 2015-12-01 13:32:30 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Email Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Controller Class Initialized
DEBUG - 2015-12-01 13:32:30 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:32:30 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 13:32:30 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-01 13:32:30 --> Final output sent to browser
DEBUG - 2015-12-01 13:32:30 --> Total execution time: 0.3381
DEBUG - 2015-12-01 13:32:31 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:32:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:32:31 --> URI Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:32:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:32:31 --> URI Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Router Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Router Class Initialized
DEBUG - 2015-12-01 13:32:31 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:32:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:32:31 --> URI Class Initialized
DEBUG - 2015-12-01 13:32:31 --> UTF-8 Support Enabled
ERROR - 2015-12-01 13:32:31 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 13:32:31 --> Router Class Initialized
DEBUG - 2015-12-01 13:32:31 --> URI Class Initialized
ERROR - 2015-12-01 13:32:31 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 13:32:31 --> Router Class Initialized
ERROR - 2015-12-01 13:32:31 --> 404 Page Not Found --> 
ERROR - 2015-12-01 13:32:31 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 13:32:33 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:32:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:32:33 --> URI Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Router Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Output Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Security Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Input Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:32:33 --> Language Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Language Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Loader Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:32:33 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:32:33 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Session Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Helper loaded: string_helper
DEBUG - 2015-12-01 13:32:33 --> Session routines successfully run
DEBUG - 2015-12-01 13:32:33 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Email Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Controller Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 13:32:33 --> XSS Filtering completed
DEBUG - 2015-12-01 13:32:33 --> Unable to find validation rule: exists
DEBUG - 2015-12-01 13:32:33 --> XSS Filtering completed
DEBUG - 2015-12-01 13:32:33 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:32:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:32:33 --> URI Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Router Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Output Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Security Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Input Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:32:33 --> Language Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Language Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Config Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Loader Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:32:33 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:32:33 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Session Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Helper loaded: string_helper
DEBUG - 2015-12-01 13:32:33 --> Session routines successfully run
DEBUG - 2015-12-01 13:32:33 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Email Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Controller Class Initialized
DEBUG - 2015-12-01 13:32:33 --> Admin MX_Controller Initialized
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 13:32:33 --> Model Class Initialized
DEBUG - 2015-12-01 13:32:33 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-01 13:32:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 13:32:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 13:32:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 13:32:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 13:32:34 --> Final output sent to browser
DEBUG - 2015-12-01 13:32:34 --> Total execution time: 0.4361
DEBUG - 2015-12-01 13:35:58 --> Config Class Initialized
DEBUG - 2015-12-01 13:35:58 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:35:58 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:35:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:35:58 --> URI Class Initialized
DEBUG - 2015-12-01 13:35:58 --> Router Class Initialized
DEBUG - 2015-12-01 13:35:58 --> Output Class Initialized
DEBUG - 2015-12-01 13:35:58 --> Security Class Initialized
DEBUG - 2015-12-01 13:35:58 --> Input Class Initialized
DEBUG - 2015-12-01 13:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:35:59 --> Language Class Initialized
DEBUG - 2015-12-01 13:35:59 --> Language Class Initialized
DEBUG - 2015-12-01 13:35:59 --> Config Class Initialized
DEBUG - 2015-12-01 13:35:59 --> Loader Class Initialized
DEBUG - 2015-12-01 13:35:59 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:35:59 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:35:59 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:36:00 --> Session Class Initialized
DEBUG - 2015-12-01 13:36:00 --> Helper loaded: string_helper
DEBUG - 2015-12-01 13:36:00 --> Session routines successfully run
DEBUG - 2015-12-01 13:36:00 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:36:00 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:36:00 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:36:00 --> Email Class Initialized
DEBUG - 2015-12-01 13:36:00 --> Controller Class Initialized
DEBUG - 2015-12-01 13:36:00 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 13:36:00 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:01 --> Image Lib Class Initialized
DEBUG - 2015-12-01 13:36:01 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 13:36:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 13:36:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 13:36:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 13:36:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 13:36:01 --> Final output sent to browser
DEBUG - 2015-12-01 13:36:01 --> Total execution time: 3.6388
DEBUG - 2015-12-01 13:36:04 --> Config Class Initialized
DEBUG - 2015-12-01 13:36:04 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:36:04 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:36:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:36:04 --> URI Class Initialized
DEBUG - 2015-12-01 13:36:04 --> Router Class Initialized
DEBUG - 2015-12-01 13:36:04 --> Output Class Initialized
DEBUG - 2015-12-01 13:36:04 --> Security Class Initialized
DEBUG - 2015-12-01 13:36:04 --> Input Class Initialized
DEBUG - 2015-12-01 13:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:36:04 --> Language Class Initialized
DEBUG - 2015-12-01 13:36:04 --> Language Class Initialized
DEBUG - 2015-12-01 13:36:04 --> Config Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Loader Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:36:05 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:36:05 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Session Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Helper loaded: string_helper
DEBUG - 2015-12-01 13:36:05 --> Session routines successfully run
DEBUG - 2015-12-01 13:36:05 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Email Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Controller Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 13:36:05 --> Model Class Initialized
DEBUG - 2015-12-01 13:36:05 --> Image Lib Class Initialized
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 13:36:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 13:36:05 --> Final output sent to browser
DEBUG - 2015-12-01 13:36:05 --> Total execution time: 0.5972
DEBUG - 2015-12-01 13:39:30 --> Config Class Initialized
DEBUG - 2015-12-01 13:39:31 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:39:31 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:39:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:39:31 --> URI Class Initialized
DEBUG - 2015-12-01 13:39:31 --> Router Class Initialized
DEBUG - 2015-12-01 13:39:32 --> Output Class Initialized
DEBUG - 2015-12-01 13:39:33 --> Security Class Initialized
DEBUG - 2015-12-01 13:39:33 --> Input Class Initialized
DEBUG - 2015-12-01 13:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:39:34 --> Language Class Initialized
DEBUG - 2015-12-01 13:39:36 --> Language Class Initialized
DEBUG - 2015-12-01 13:39:37 --> Config Class Initialized
DEBUG - 2015-12-01 13:39:37 --> Loader Class Initialized
DEBUG - 2015-12-01 13:39:37 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:39:37 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:39:38 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:39:38 --> Session Class Initialized
DEBUG - 2015-12-01 13:39:38 --> Helper loaded: string_helper
DEBUG - 2015-12-01 13:39:38 --> Session routines successfully run
DEBUG - 2015-12-01 13:39:38 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:39:38 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:39:38 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:39:38 --> Email Class Initialized
DEBUG - 2015-12-01 13:39:38 --> Controller Class Initialized
DEBUG - 2015-12-01 13:39:38 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 13:39:38 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 13:39:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 13:39:40 --> Model Class Initialized
DEBUG - 2015-12-01 13:39:40 --> Image Lib Class Initialized
DEBUG - 2015-12-01 13:39:40 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 13:39:40 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 13:39:40 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 13:39:40 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 13:39:40 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 13:39:40 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 13:39:40 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 13:39:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 13:39:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 13:39:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 13:39:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 13:39:41 --> Final output sent to browser
DEBUG - 2015-12-01 13:39:41 --> Total execution time: 12.5187
DEBUG - 2015-12-01 13:40:39 --> Config Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:40:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:40:39 --> URI Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Router Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Output Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Security Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Input Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:40:39 --> Language Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Language Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Config Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Loader Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:40:39 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:40:39 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Session Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Helper loaded: string_helper
DEBUG - 2015-12-01 13:40:39 --> Session routines successfully run
DEBUG - 2015-12-01 13:40:39 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Email Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Controller Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 13:40:39 --> Model Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Image Lib Class Initialized
DEBUG - 2015-12-01 13:40:39 --> Upload Class Initialized
DEBUG - 2015-12-01 13:40:41 --> DB Transaction Failure
ERROR - 2015-12-01 13:40:41 --> Query error: Unknown column 'individual_id' in 'field list'
DEBUG - 2015-12-01 13:40:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-01 13:41:24 --> Config Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:41:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:41:24 --> URI Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Router Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Output Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Security Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Input Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:41:24 --> Language Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Language Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Config Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Loader Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:41:24 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:41:24 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Session Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Helper loaded: string_helper
DEBUG - 2015-12-01 13:41:24 --> Session routines successfully run
DEBUG - 2015-12-01 13:41:24 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Email Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Controller Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 13:41:24 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:24 --> Image Lib Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Upload Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Config Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Hooks Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Utf8 Class Initialized
DEBUG - 2015-12-01 13:41:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 13:41:25 --> URI Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Router Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Output Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Security Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Input Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 13:41:25 --> Language Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Language Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Config Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Loader Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Helper loaded: url_helper
DEBUG - 2015-12-01 13:41:25 --> Helper loaded: form_helper
DEBUG - 2015-12-01 13:41:25 --> Database Driver Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Session Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Helper loaded: string_helper
DEBUG - 2015-12-01 13:41:25 --> Session routines successfully run
DEBUG - 2015-12-01 13:41:25 --> Form Validation Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Pagination Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Encrypt Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Email Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Controller Class Initialized
DEBUG - 2015-12-01 13:41:25 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 13:41:25 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 13:41:26 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 13:41:26 --> Model Class Initialized
DEBUG - 2015-12-01 13:41:26 --> Image Lib Class Initialized
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 13:41:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 13:41:26 --> Final output sent to browser
DEBUG - 2015-12-01 13:41:26 --> Total execution time: 0.4469
DEBUG - 2015-12-01 14:03:05 --> Config Class Initialized
DEBUG - 2015-12-01 14:03:05 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:03:05 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:03:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:03:05 --> URI Class Initialized
DEBUG - 2015-12-01 14:03:05 --> Router Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Output Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Security Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Input Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:03:06 --> Language Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Language Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Config Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Loader Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:03:06 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:03:06 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Session Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:03:06 --> Session routines successfully run
DEBUG - 2015-12-01 14:03:06 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Email Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Controller Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:03:06 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:06 --> Image Lib Class Initialized
ERROR - 2015-12-01 14:03:06 --> Severity: Notice  --> Undefined property: stdClass::$ducument_status C:\xampp\htdocs\mfi\application\modules\microfinance\views\individual\edit\about.php 437
ERROR - 2015-12-01 14:03:06 --> Severity: Notice  --> Undefined variable: individual_savings_id C:\xampp\htdocs\mfi\application\modules\microfinance\views\individual\edit\about.php 460
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:03:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:03:06 --> Final output sent to browser
DEBUG - 2015-12-01 14:03:06 --> Total execution time: 0.8181
DEBUG - 2015-12-01 14:03:47 --> Config Class Initialized
DEBUG - 2015-12-01 14:03:47 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:03:47 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:03:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:03:47 --> URI Class Initialized
DEBUG - 2015-12-01 14:03:47 --> Router Class Initialized
DEBUG - 2015-12-01 14:03:47 --> Output Class Initialized
DEBUG - 2015-12-01 14:03:47 --> Security Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Input Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:03:48 --> Language Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Language Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Config Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Loader Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:03:48 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:03:48 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Session Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:03:48 --> Session routines successfully run
DEBUG - 2015-12-01 14:03:48 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Email Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Controller Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:03:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:03:48 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:03:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:03:48 --> Final output sent to browser
DEBUG - 2015-12-01 14:03:48 --> Total execution time: 0.5746
DEBUG - 2015-12-01 14:04:09 --> Config Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:04:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:04:09 --> URI Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Router Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Output Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Security Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Input Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:04:09 --> Language Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Language Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Config Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Loader Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:04:09 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:04:09 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Session Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:04:09 --> Session routines successfully run
DEBUG - 2015-12-01 14:04:09 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Email Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Controller Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:04:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:09 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:04:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:04:09 --> Final output sent to browser
DEBUG - 2015-12-01 14:04:09 --> Total execution time: 0.3020
DEBUG - 2015-12-01 14:04:46 --> Config Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:04:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:04:46 --> URI Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Router Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Output Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Security Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Input Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:04:46 --> Language Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Language Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Config Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Loader Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:04:46 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:04:46 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Session Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:04:46 --> Session routines successfully run
DEBUG - 2015-12-01 14:04:46 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Email Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Controller Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:04:46 --> Model Class Initialized
DEBUG - 2015-12-01 14:04:46 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:04:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:04:46 --> Final output sent to browser
DEBUG - 2015-12-01 14:04:46 --> Total execution time: 0.3753
DEBUG - 2015-12-01 14:18:14 --> Config Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:18:14 --> URI Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Router Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Output Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Security Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Input Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:18:14 --> Language Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Language Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Config Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Loader Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:18:14 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:18:14 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Session Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:18:14 --> Session routines successfully run
DEBUG - 2015-12-01 14:18:14 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Email Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Controller Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:18:14 --> Model Class Initialized
DEBUG - 2015-12-01 14:18:14 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:18:15 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:18:15 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:18:15 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
ERROR - 2015-12-01 14:18:15 --> Severity: Notice  --> Undefined variable: individual_other_documents C:\xampp\htdocs\mfi\application\modules\microfinance\views\individual\edit\uploads.php 43
DEBUG - 2015-12-01 14:20:42 --> Config Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:20:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:20:42 --> URI Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Router Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Output Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Security Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Input Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:20:42 --> Language Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Language Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Config Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Loader Class Initialized
DEBUG - 2015-12-01 14:20:42 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:20:42 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:20:42 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:20:43 --> Session Class Initialized
DEBUG - 2015-12-01 14:20:43 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:20:43 --> Session routines successfully run
DEBUG - 2015-12-01 14:20:43 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:20:43 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:20:43 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:20:43 --> Email Class Initialized
DEBUG - 2015-12-01 14:20:43 --> Controller Class Initialized
DEBUG - 2015-12-01 14:20:43 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:20:43 --> Model Class Initialized
DEBUG - 2015-12-01 14:20:43 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:20:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:20:43 --> Final output sent to browser
DEBUG - 2015-12-01 14:20:43 --> Total execution time: 1.2697
DEBUG - 2015-12-01 14:34:46 --> Config Class Initialized
DEBUG - 2015-12-01 14:34:46 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:34:46 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:34:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:34:46 --> URI Class Initialized
DEBUG - 2015-12-01 14:34:46 --> Router Class Initialized
DEBUG - 2015-12-01 14:34:47 --> Output Class Initialized
DEBUG - 2015-12-01 14:34:47 --> Security Class Initialized
DEBUG - 2015-12-01 14:34:47 --> Input Class Initialized
DEBUG - 2015-12-01 14:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:34:47 --> Language Class Initialized
DEBUG - 2015-12-01 14:34:47 --> Language Class Initialized
DEBUG - 2015-12-01 14:34:47 --> Config Class Initialized
DEBUG - 2015-12-01 14:34:47 --> Loader Class Initialized
DEBUG - 2015-12-01 14:34:47 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:34:47 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:34:47 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:34:48 --> Session Class Initialized
DEBUG - 2015-12-01 14:34:48 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:34:48 --> Session routines successfully run
DEBUG - 2015-12-01 14:34:48 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:34:48 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:34:48 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:34:48 --> Email Class Initialized
DEBUG - 2015-12-01 14:34:48 --> Controller Class Initialized
DEBUG - 2015-12-01 14:34:48 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:34:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:34:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:34:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:34:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:34:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:34:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:34:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:34:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:34:48 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:34:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:34:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:34:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:34:49 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:34:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:34:49 --> Final output sent to browser
DEBUG - 2015-12-01 14:34:49 --> Total execution time: 3.6041
DEBUG - 2015-12-01 14:44:47 --> Config Class Initialized
DEBUG - 2015-12-01 14:44:47 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:44:47 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:44:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:44:47 --> URI Class Initialized
DEBUG - 2015-12-01 14:44:47 --> Router Class Initialized
DEBUG - 2015-12-01 14:44:47 --> Output Class Initialized
DEBUG - 2015-12-01 14:44:47 --> Security Class Initialized
DEBUG - 2015-12-01 14:44:48 --> Input Class Initialized
DEBUG - 2015-12-01 14:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:44:48 --> Language Class Initialized
DEBUG - 2015-12-01 14:44:48 --> Language Class Initialized
DEBUG - 2015-12-01 14:44:48 --> Config Class Initialized
DEBUG - 2015-12-01 14:44:48 --> Loader Class Initialized
DEBUG - 2015-12-01 14:44:48 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:44:48 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:44:49 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:44:49 --> Session Class Initialized
DEBUG - 2015-12-01 14:44:49 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:44:49 --> Session routines successfully run
DEBUG - 2015-12-01 14:44:49 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:44:49 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:44:49 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:44:49 --> Email Class Initialized
DEBUG - 2015-12-01 14:44:49 --> Controller Class Initialized
DEBUG - 2015-12-01 14:44:49 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:44:49 --> Model Class Initialized
DEBUG - 2015-12-01 14:44:49 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:44:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:44:50 --> Final output sent to browser
DEBUG - 2015-12-01 14:44:50 --> Total execution time: 3.2544
DEBUG - 2015-12-01 14:47:20 --> Config Class Initialized
DEBUG - 2015-12-01 14:47:20 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:47:20 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:47:20 --> URI Class Initialized
DEBUG - 2015-12-01 14:47:20 --> Router Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Output Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Security Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Input Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:47:21 --> Language Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Language Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Config Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Loader Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:47:21 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:47:21 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Session Class Initialized
DEBUG - 2015-12-01 14:47:21 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:47:21 --> Session routines successfully run
DEBUG - 2015-12-01 14:47:22 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:47:22 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:47:22 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:47:22 --> Email Class Initialized
DEBUG - 2015-12-01 14:47:22 --> Controller Class Initialized
DEBUG - 2015-12-01 14:47:22 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:47:22 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:23 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:47:23 --> Upload Class Initialized
DEBUG - 2015-12-01 14:47:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 14:47:24 --> Config Class Initialized
DEBUG - 2015-12-01 14:47:24 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:47:24 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:47:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:47:24 --> URI Class Initialized
DEBUG - 2015-12-01 14:47:24 --> Router Class Initialized
DEBUG - 2015-12-01 14:47:24 --> Output Class Initialized
DEBUG - 2015-12-01 14:47:24 --> Security Class Initialized
DEBUG - 2015-12-01 14:47:24 --> Input Class Initialized
DEBUG - 2015-12-01 14:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:47:25 --> Language Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Language Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Config Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Loader Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:47:25 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:47:25 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Session Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:47:25 --> Session routines successfully run
DEBUG - 2015-12-01 14:47:25 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Email Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Controller Class Initialized
DEBUG - 2015-12-01 14:47:25 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:47:25 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:47:25 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:47:25 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:47:25 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:47:26 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:47:26 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:47:26 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:47:26 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:47:26 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:47:26 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:47:26 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:47:26 --> Model Class Initialized
DEBUG - 2015-12-01 14:47:26 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:47:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:47:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:47:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:47:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:47:27 --> Final output sent to browser
DEBUG - 2015-12-01 14:47:27 --> Total execution time: 2.9362
DEBUG - 2015-12-01 14:48:30 --> Config Class Initialized
DEBUG - 2015-12-01 14:48:30 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:48:30 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:48:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:48:30 --> URI Class Initialized
DEBUG - 2015-12-01 14:48:30 --> Router Class Initialized
DEBUG - 2015-12-01 14:48:31 --> Output Class Initialized
DEBUG - 2015-12-01 14:48:31 --> Security Class Initialized
DEBUG - 2015-12-01 14:48:31 --> Input Class Initialized
DEBUG - 2015-12-01 14:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:48:31 --> Language Class Initialized
DEBUG - 2015-12-01 14:48:31 --> Language Class Initialized
DEBUG - 2015-12-01 14:48:31 --> Config Class Initialized
DEBUG - 2015-12-01 14:48:31 --> Loader Class Initialized
DEBUG - 2015-12-01 14:48:31 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:48:31 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:48:32 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:48:32 --> Session Class Initialized
DEBUG - 2015-12-01 14:48:32 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:48:32 --> Session routines successfully run
DEBUG - 2015-12-01 14:48:32 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:48:32 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:48:32 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:48:32 --> Email Class Initialized
DEBUG - 2015-12-01 14:48:32 --> Controller Class Initialized
DEBUG - 2015-12-01 14:48:32 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:48:32 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:48:32 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:48:32 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:48:32 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:48:32 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:48:32 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:48:32 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:48:32 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:48:32 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:48:33 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:48:33 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:48:33 --> Model Class Initialized
DEBUG - 2015-12-01 14:48:33 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:48:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:48:33 --> Final output sent to browser
DEBUG - 2015-12-01 14:48:33 --> Total execution time: 3.8919
DEBUG - 2015-12-01 14:49:07 --> Config Class Initialized
DEBUG - 2015-12-01 14:49:08 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:49:08 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:49:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:49:08 --> URI Class Initialized
DEBUG - 2015-12-01 14:49:08 --> Router Class Initialized
DEBUG - 2015-12-01 14:49:08 --> Output Class Initialized
DEBUG - 2015-12-01 14:49:08 --> Security Class Initialized
DEBUG - 2015-12-01 14:49:08 --> Input Class Initialized
DEBUG - 2015-12-01 14:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:49:08 --> Language Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Language Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Config Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Loader Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:49:09 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:49:09 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Session Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:49:09 --> Session routines successfully run
DEBUG - 2015-12-01 14:49:09 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Email Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Controller Class Initialized
DEBUG - 2015-12-01 14:49:09 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:49:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:49:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:49:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:49:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:49:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:49:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:49:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:49:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:49:09 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:49:10 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:49:10 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:49:10 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:10 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:49:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:49:10 --> Final output sent to browser
DEBUG - 2015-12-01 14:49:10 --> Total execution time: 2.8562
DEBUG - 2015-12-01 14:49:43 --> Config Class Initialized
DEBUG - 2015-12-01 14:49:44 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:49:44 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:49:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:49:44 --> URI Class Initialized
DEBUG - 2015-12-01 14:49:44 --> Router Class Initialized
DEBUG - 2015-12-01 14:49:44 --> Output Class Initialized
DEBUG - 2015-12-01 14:49:45 --> Security Class Initialized
DEBUG - 2015-12-01 14:49:45 --> Input Class Initialized
DEBUG - 2015-12-01 14:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:49:45 --> Language Class Initialized
DEBUG - 2015-12-01 14:49:45 --> Language Class Initialized
DEBUG - 2015-12-01 14:49:45 --> Config Class Initialized
DEBUG - 2015-12-01 14:49:45 --> Loader Class Initialized
DEBUG - 2015-12-01 14:49:45 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:49:45 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:49:46 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:49:46 --> Session Class Initialized
DEBUG - 2015-12-01 14:49:46 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:49:46 --> Session routines successfully run
DEBUG - 2015-12-01 14:49:46 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:49:46 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:49:46 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:49:46 --> Email Class Initialized
DEBUG - 2015-12-01 14:49:46 --> Controller Class Initialized
DEBUG - 2015-12-01 14:49:46 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:49:47 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:48 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:49:48 --> Upload Class Initialized
DEBUG - 2015-12-01 14:49:49 --> Language file loaded: language/english/upload_lang.php
ERROR - 2015-12-01 14:49:49 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2015-12-01 14:49:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 14:49:49 --> Config Class Initialized
DEBUG - 2015-12-01 14:49:49 --> Hooks Class Initialized
DEBUG - 2015-12-01 14:49:49 --> Utf8 Class Initialized
DEBUG - 2015-12-01 14:49:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 14:49:49 --> URI Class Initialized
DEBUG - 2015-12-01 14:49:49 --> Router Class Initialized
DEBUG - 2015-12-01 14:49:50 --> Output Class Initialized
DEBUG - 2015-12-01 14:49:50 --> Security Class Initialized
DEBUG - 2015-12-01 14:49:50 --> Input Class Initialized
DEBUG - 2015-12-01 14:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 14:49:50 --> Language Class Initialized
DEBUG - 2015-12-01 14:49:51 --> Language Class Initialized
DEBUG - 2015-12-01 14:49:51 --> Config Class Initialized
DEBUG - 2015-12-01 14:49:51 --> Loader Class Initialized
DEBUG - 2015-12-01 14:49:51 --> Helper loaded: url_helper
DEBUG - 2015-12-01 14:49:51 --> Helper loaded: form_helper
DEBUG - 2015-12-01 14:49:51 --> Database Driver Class Initialized
DEBUG - 2015-12-01 14:49:51 --> Session Class Initialized
DEBUG - 2015-12-01 14:49:51 --> Helper loaded: string_helper
DEBUG - 2015-12-01 14:49:51 --> Session routines successfully run
DEBUG - 2015-12-01 14:49:51 --> Form Validation Class Initialized
DEBUG - 2015-12-01 14:49:51 --> Pagination Class Initialized
DEBUG - 2015-12-01 14:49:51 --> Encrypt Class Initialized
DEBUG - 2015-12-01 14:49:52 --> Email Class Initialized
DEBUG - 2015-12-01 14:49:52 --> Controller Class Initialized
DEBUG - 2015-12-01 14:49:52 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 14:49:52 --> Model Class Initialized
DEBUG - 2015-12-01 14:49:52 --> Image Lib Class Initialized
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 14:49:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 14:49:53 --> Final output sent to browser
DEBUG - 2015-12-01 14:49:53 --> Total execution time: 4.0657
DEBUG - 2015-12-01 15:57:10 --> Config Class Initialized
DEBUG - 2015-12-01 15:57:10 --> Hooks Class Initialized
DEBUG - 2015-12-01 15:57:10 --> Utf8 Class Initialized
DEBUG - 2015-12-01 15:57:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 15:57:10 --> URI Class Initialized
DEBUG - 2015-12-01 15:57:10 --> Router Class Initialized
ERROR - 2015-12-01 15:57:11 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 15:57:16 --> Config Class Initialized
DEBUG - 2015-12-01 15:57:16 --> Hooks Class Initialized
DEBUG - 2015-12-01 15:57:16 --> Utf8 Class Initialized
DEBUG - 2015-12-01 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 15:57:16 --> URI Class Initialized
DEBUG - 2015-12-01 15:57:16 --> Router Class Initialized
ERROR - 2015-12-01 15:57:16 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 15:57:21 --> Config Class Initialized
DEBUG - 2015-12-01 15:57:21 --> Hooks Class Initialized
DEBUG - 2015-12-01 15:57:21 --> Utf8 Class Initialized
DEBUG - 2015-12-01 15:57:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 15:57:21 --> URI Class Initialized
DEBUG - 2015-12-01 15:57:21 --> Router Class Initialized
ERROR - 2015-12-01 15:57:21 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 16:03:07 --> Config Class Initialized
DEBUG - 2015-12-01 16:03:07 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:03:07 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:03:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:03:07 --> URI Class Initialized
DEBUG - 2015-12-01 16:03:07 --> Router Class Initialized
DEBUG - 2015-12-01 16:03:07 --> Output Class Initialized
DEBUG - 2015-12-01 16:03:07 --> Security Class Initialized
DEBUG - 2015-12-01 16:03:07 --> Input Class Initialized
DEBUG - 2015-12-01 16:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:03:07 --> Language Class Initialized
DEBUG - 2015-12-01 16:03:07 --> Language Class Initialized
DEBUG - 2015-12-01 16:03:07 --> Config Class Initialized
DEBUG - 2015-12-01 16:03:08 --> Loader Class Initialized
DEBUG - 2015-12-01 16:03:08 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:03:08 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:03:08 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:03:08 --> Session Class Initialized
DEBUG - 2015-12-01 16:03:08 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:03:08 --> Session routines successfully run
DEBUG - 2015-12-01 16:03:08 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:03:08 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:03:08 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:03:08 --> Email Class Initialized
DEBUG - 2015-12-01 16:03:08 --> Controller Class Initialized
DEBUG - 2015-12-01 16:03:08 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 16:03:08 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 16:03:09 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 16:03:09 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:09 --> Image Lib Class Initialized
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:03:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:03:09 --> Final output sent to browser
DEBUG - 2015-12-01 16:03:09 --> Total execution time: 2.7745
DEBUG - 2015-12-01 16:03:24 --> Config Class Initialized
DEBUG - 2015-12-01 16:03:24 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:03:24 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:03:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:03:24 --> URI Class Initialized
DEBUG - 2015-12-01 16:03:24 --> Router Class Initialized
ERROR - 2015-12-01 16:03:24 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 16:03:35 --> Config Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:03:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:03:35 --> URI Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Router Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Output Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Security Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Input Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:03:35 --> Language Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Language Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Config Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Loader Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:03:35 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:03:35 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Session Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:03:35 --> Session routines successfully run
DEBUG - 2015-12-01 16:03:35 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Email Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Controller Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 16:03:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:03:35 --> Image Lib Class Initialized
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:03:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:03:36 --> Final output sent to browser
DEBUG - 2015-12-01 16:03:36 --> Total execution time: 0.6418
DEBUG - 2015-12-01 16:12:19 --> Config Class Initialized
DEBUG - 2015-12-01 16:12:20 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:12:20 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:12:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:12:20 --> URI Class Initialized
DEBUG - 2015-12-01 16:12:20 --> Router Class Initialized
DEBUG - 2015-12-01 16:12:20 --> Output Class Initialized
DEBUG - 2015-12-01 16:12:20 --> Security Class Initialized
DEBUG - 2015-12-01 16:12:20 --> Input Class Initialized
DEBUG - 2015-12-01 16:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:12:21 --> Language Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Language Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Config Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Loader Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:12:21 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:12:21 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Session Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:12:21 --> Session routines successfully run
DEBUG - 2015-12-01 16:12:21 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Email Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Controller Class Initialized
DEBUG - 2015-12-01 16:12:21 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 16:12:21 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:12:21 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:12:21 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:12:21 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:12:22 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 16:12:22 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:12:22 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 16:12:22 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 16:12:22 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 16:12:22 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 16:12:22 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 16:12:22 --> Model Class Initialized
DEBUG - 2015-12-01 16:12:22 --> Image Lib Class Initialized
DEBUG - 2015-12-01 16:12:23 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
ERROR - 2015-12-01 16:12:23 --> Severity: Notice  --> Undefined property: stdClass::$share_percentage C:\xampp\htdocs\mfi\application\modules\microfinance\views\individual\edit\emergency.php 32
DEBUG - 2015-12-01 16:12:23 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 16:12:23 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 16:12:23 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 16:12:23 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 16:12:23 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 16:12:23 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 16:12:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:12:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:12:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:12:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:12:24 --> Final output sent to browser
DEBUG - 2015-12-01 16:12:24 --> Total execution time: 4.6881
DEBUG - 2015-12-01 16:17:05 --> Config Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:17:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:17:06 --> URI Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Router Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Output Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Security Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Input Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:17:06 --> Language Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Language Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Config Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Loader Class Initialized
DEBUG - 2015-12-01 16:17:06 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:17:06 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:17:07 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:17:07 --> Session Class Initialized
DEBUG - 2015-12-01 16:17:07 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:17:07 --> Session routines successfully run
DEBUG - 2015-12-01 16:17:07 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:17:07 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:17:07 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:17:07 --> Email Class Initialized
DEBUG - 2015-12-01 16:17:07 --> Controller Class Initialized
DEBUG - 2015-12-01 16:17:07 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 16:17:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:17:07 --> Image Lib Class Initialized
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 16:17:07 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 16:17:08 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 16:17:08 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 16:17:08 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 16:17:08 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 16:17:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:17:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:17:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:17:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:17:08 --> Final output sent to browser
DEBUG - 2015-12-01 16:17:08 --> Total execution time: 2.4352
DEBUG - 2015-12-01 16:35:25 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:26 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:35:26 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:35:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:35:26 --> URI Class Initialized
DEBUG - 2015-12-01 16:35:26 --> Router Class Initialized
DEBUG - 2015-12-01 16:35:26 --> Output Class Initialized
DEBUG - 2015-12-01 16:35:26 --> Security Class Initialized
DEBUG - 2015-12-01 16:35:26 --> Input Class Initialized
DEBUG - 2015-12-01 16:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:35:26 --> Language Class Initialized
DEBUG - 2015-12-01 16:35:27 --> Language Class Initialized
DEBUG - 2015-12-01 16:35:27 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:27 --> Loader Class Initialized
DEBUG - 2015-12-01 16:35:27 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:35:27 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:35:27 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:35:27 --> Session Class Initialized
DEBUG - 2015-12-01 16:35:27 --> Helper loaded: string_helper
ERROR - 2015-12-01 16:35:27 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-12-01 16:35:27 --> Session routines successfully run
DEBUG - 2015-12-01 16:35:28 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:35:28 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:35:28 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:35:28 --> Email Class Initialized
DEBUG - 2015-12-01 16:35:28 --> Controller Class Initialized
DEBUG - 2015-12-01 16:35:28 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 16:35:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:29 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:29 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:35:29 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:35:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:35:29 --> URI Class Initialized
DEBUG - 2015-12-01 16:35:30 --> Router Class Initialized
DEBUG - 2015-12-01 16:35:30 --> Output Class Initialized
DEBUG - 2015-12-01 16:35:30 --> Security Class Initialized
DEBUG - 2015-12-01 16:35:30 --> Input Class Initialized
DEBUG - 2015-12-01 16:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:35:30 --> Language Class Initialized
DEBUG - 2015-12-01 16:35:30 --> Language Class Initialized
DEBUG - 2015-12-01 16:35:30 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:30 --> Loader Class Initialized
DEBUG - 2015-12-01 16:35:30 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:35:30 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:35:31 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:35:31 --> Session Class Initialized
DEBUG - 2015-12-01 16:35:31 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:35:31 --> Session routines successfully run
DEBUG - 2015-12-01 16:35:31 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:35:31 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:35:31 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:35:31 --> Email Class Initialized
DEBUG - 2015-12-01 16:35:31 --> Controller Class Initialized
DEBUG - 2015-12-01 16:35:31 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-01 16:35:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:35:32 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-01 16:35:32 --> Final output sent to browser
DEBUG - 2015-12-01 16:35:32 --> Total execution time: 3.0381
DEBUG - 2015-12-01 16:35:41 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:41 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:35:41 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:41 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:35:41 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:41 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:35:41 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:35:41 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:35:41 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:35:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:35:41 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:41 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:35:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:35:42 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:35:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:35:42 --> URI Class Initialized
DEBUG - 2015-12-01 16:35:42 --> URI Class Initialized
DEBUG - 2015-12-01 16:35:42 --> URI Class Initialized
DEBUG - 2015-12-01 16:35:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:35:42 --> URI Class Initialized
DEBUG - 2015-12-01 16:35:42 --> Router Class Initialized
DEBUG - 2015-12-01 16:35:42 --> Router Class Initialized
DEBUG - 2015-12-01 16:35:42 --> Router Class Initialized
DEBUG - 2015-12-01 16:35:42 --> Router Class Initialized
ERROR - 2015-12-01 16:35:42 --> 404 Page Not Found --> 
ERROR - 2015-12-01 16:35:42 --> 404 Page Not Found --> 
ERROR - 2015-12-01 16:35:42 --> 404 Page Not Found --> 
ERROR - 2015-12-01 16:35:42 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 16:35:58 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:58 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:35:58 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:35:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:35:58 --> URI Class Initialized
DEBUG - 2015-12-01 16:35:59 --> Router Class Initialized
DEBUG - 2015-12-01 16:35:59 --> Output Class Initialized
DEBUG - 2015-12-01 16:35:59 --> Security Class Initialized
DEBUG - 2015-12-01 16:35:59 --> Input Class Initialized
DEBUG - 2015-12-01 16:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:35:59 --> Language Class Initialized
DEBUG - 2015-12-01 16:35:59 --> Language Class Initialized
DEBUG - 2015-12-01 16:35:59 --> Config Class Initialized
DEBUG - 2015-12-01 16:35:59 --> Loader Class Initialized
DEBUG - 2015-12-01 16:35:59 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:35:59 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:35:59 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:36:02 --> Session Class Initialized
DEBUG - 2015-12-01 16:36:02 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:36:02 --> Session routines successfully run
DEBUG - 2015-12-01 16:36:02 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:36:02 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:36:02 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:36:02 --> Email Class Initialized
DEBUG - 2015-12-01 16:36:02 --> Controller Class Initialized
DEBUG - 2015-12-01 16:36:02 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 16:36:02 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:36:02 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:36:02 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 16:36:02 --> XSS Filtering completed
DEBUG - 2015-12-01 16:36:02 --> Unable to find validation rule: exists
DEBUG - 2015-12-01 16:36:02 --> XSS Filtering completed
DEBUG - 2015-12-01 16:36:03 --> Config Class Initialized
DEBUG - 2015-12-01 16:36:03 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:36:03 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:36:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:36:03 --> URI Class Initialized
DEBUG - 2015-12-01 16:36:03 --> Router Class Initialized
DEBUG - 2015-12-01 16:36:04 --> Output Class Initialized
DEBUG - 2015-12-01 16:36:04 --> Security Class Initialized
DEBUG - 2015-12-01 16:36:04 --> Input Class Initialized
DEBUG - 2015-12-01 16:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:36:04 --> Language Class Initialized
DEBUG - 2015-12-01 16:36:04 --> Language Class Initialized
DEBUG - 2015-12-01 16:36:04 --> Config Class Initialized
DEBUG - 2015-12-01 16:36:05 --> Loader Class Initialized
DEBUG - 2015-12-01 16:36:05 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:36:05 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:36:06 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:36:06 --> Session Class Initialized
DEBUG - 2015-12-01 16:36:06 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:36:06 --> Session routines successfully run
DEBUG - 2015-12-01 16:36:06 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:36:06 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:36:06 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:36:06 --> Email Class Initialized
DEBUG - 2015-12-01 16:36:06 --> Controller Class Initialized
DEBUG - 2015-12-01 16:36:06 --> Admin MX_Controller Initialized
DEBUG - 2015-12-01 16:36:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:36:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:36:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:36:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:36:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:36:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:36:07 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:07 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-01 16:36:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:36:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:36:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:36:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:36:08 --> Final output sent to browser
DEBUG - 2015-12-01 16:36:08 --> Total execution time: 4.9312
DEBUG - 2015-12-01 16:36:22 --> Config Class Initialized
DEBUG - 2015-12-01 16:36:22 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:36:22 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:36:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:36:22 --> URI Class Initialized
DEBUG - 2015-12-01 16:36:22 --> Router Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Output Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Security Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Input Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:36:23 --> Language Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Language Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Config Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Loader Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:36:23 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:36:23 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Session Class Initialized
DEBUG - 2015-12-01 16:36:23 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:36:23 --> Session routines successfully run
DEBUG - 2015-12-01 16:36:23 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:36:24 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:36:24 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:36:24 --> Email Class Initialized
DEBUG - 2015-12-01 16:36:24 --> Controller Class Initialized
DEBUG - 2015-12-01 16:36:24 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 16:36:24 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:24 --> Image Lib Class Initialized
DEBUG - 2015-12-01 16:36:25 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 16:36:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:36:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:36:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:36:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:36:25 --> Final output sent to browser
DEBUG - 2015-12-01 16:36:25 --> Total execution time: 2.4923
DEBUG - 2015-12-01 16:36:42 --> Config Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:36:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:36:43 --> URI Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Router Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Output Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Security Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Input Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:36:43 --> Language Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Language Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Config Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Loader Class Initialized
DEBUG - 2015-12-01 16:36:43 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:36:43 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:36:44 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:36:44 --> Session Class Initialized
DEBUG - 2015-12-01 16:36:44 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:36:44 --> Session routines successfully run
DEBUG - 2015-12-01 16:36:44 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:36:44 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:36:44 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:36:44 --> Email Class Initialized
DEBUG - 2015-12-01 16:36:44 --> Controller Class Initialized
DEBUG - 2015-12-01 16:36:44 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 16:36:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:36:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:36:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:36:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:36:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 16:36:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:36:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 16:36:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 16:36:45 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 16:36:45 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 16:36:45 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 16:36:45 --> Model Class Initialized
DEBUG - 2015-12-01 16:36:45 --> Image Lib Class Initialized
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:36:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:36:45 --> Final output sent to browser
DEBUG - 2015-12-01 16:36:45 --> Total execution time: 3.0523
DEBUG - 2015-12-01 16:38:04 --> Config Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:38:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:38:05 --> URI Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Router Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Output Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Security Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Input Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:38:05 --> Language Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Language Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Config Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Loader Class Initialized
DEBUG - 2015-12-01 16:38:05 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:38:05 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:38:05 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:38:06 --> Session Class Initialized
DEBUG - 2015-12-01 16:38:06 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:38:06 --> Session routines successfully run
DEBUG - 2015-12-01 16:38:06 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:38:06 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:38:06 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:38:06 --> Email Class Initialized
DEBUG - 2015-12-01 16:38:06 --> Controller Class Initialized
DEBUG - 2015-12-01 16:38:06 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:38:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:38:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:38:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:38:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:38:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:38:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:38:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:38:06 --> Model Class Initialized
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:38:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:38:06 --> Final output sent to browser
DEBUG - 2015-12-01 16:38:06 --> Total execution time: 1.7834
DEBUG - 2015-12-01 16:54:25 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:26 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Router Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Output Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Security Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Input Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:54:26 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Loader Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:54:26 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:54:26 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Session Class Initialized
DEBUG - 2015-12-01 16:54:26 --> Helper loaded: string_helper
ERROR - 2015-12-01 16:54:26 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-12-01 16:54:26 --> Session routines successfully run
DEBUG - 2015-12-01 16:54:27 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Email Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Controller Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:54:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:54:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:54:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:54:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:54:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:54:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:54:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:27 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Router Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Output Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Security Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Input Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:54:27 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Loader Class Initialized
DEBUG - 2015-12-01 16:54:27 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:54:27 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:54:28 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:54:28 --> Session Class Initialized
DEBUG - 2015-12-01 16:54:28 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:54:28 --> Session routines successfully run
DEBUG - 2015-12-01 16:54:28 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:54:28 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:54:28 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:54:28 --> Email Class Initialized
DEBUG - 2015-12-01 16:54:28 --> Controller Class Initialized
DEBUG - 2015-12-01 16:54:28 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 16:54:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:54:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:54:28 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:54:28 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-01 16:54:28 --> Final output sent to browser
DEBUG - 2015-12-01 16:54:28 --> Total execution time: 0.9783
DEBUG - 2015-12-01 16:54:29 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:29 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:29 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:29 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:29 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:29 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Router Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Router Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Router Class Initialized
DEBUG - 2015-12-01 16:54:29 --> Router Class Initialized
ERROR - 2015-12-01 16:54:29 --> 404 Page Not Found --> 
ERROR - 2015-12-01 16:54:29 --> 404 Page Not Found --> 
ERROR - 2015-12-01 16:54:29 --> 404 Page Not Found --> 
ERROR - 2015-12-01 16:54:29 --> 404 Page Not Found --> 
DEBUG - 2015-12-01 16:54:30 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:30 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:30 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:30 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:31 --> Router Class Initialized
DEBUG - 2015-12-01 16:54:31 --> Output Class Initialized
DEBUG - 2015-12-01 16:54:31 --> Security Class Initialized
DEBUG - 2015-12-01 16:54:31 --> Input Class Initialized
DEBUG - 2015-12-01 16:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:54:31 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:31 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:31 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:31 --> Loader Class Initialized
DEBUG - 2015-12-01 16:54:32 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:54:32 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:54:32 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:54:32 --> Session Class Initialized
DEBUG - 2015-12-01 16:54:32 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:54:32 --> Session routines successfully run
DEBUG - 2015-12-01 16:54:32 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:54:32 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:54:32 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:54:32 --> Email Class Initialized
DEBUG - 2015-12-01 16:54:32 --> Controller Class Initialized
DEBUG - 2015-12-01 16:54:32 --> Auth MX_Controller Initialized
DEBUG - 2015-12-01 16:54:32 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:54:32 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:54:33 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 16:54:33 --> XSS Filtering completed
DEBUG - 2015-12-01 16:54:33 --> Unable to find validation rule: exists
DEBUG - 2015-12-01 16:54:33 --> XSS Filtering completed
DEBUG - 2015-12-01 16:54:33 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:33 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:33 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:33 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Router Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Output Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Security Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Input Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:54:34 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Loader Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:54:34 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:54:34 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Session Class Initialized
DEBUG - 2015-12-01 16:54:34 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:54:34 --> Session routines successfully run
DEBUG - 2015-12-01 16:54:35 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:54:35 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:54:35 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:54:35 --> Email Class Initialized
DEBUG - 2015-12-01 16:54:35 --> Controller Class Initialized
DEBUG - 2015-12-01 16:54:35 --> Admin MX_Controller Initialized
DEBUG - 2015-12-01 16:54:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:54:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:54:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:54:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:54:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:54:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:54:35 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:35 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-01 16:54:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:54:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:54:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:54:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:54:36 --> Final output sent to browser
DEBUG - 2015-12-01 16:54:36 --> Total execution time: 2.8188
DEBUG - 2015-12-01 16:54:41 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:41 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:41 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:41 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:42 --> Router Class Initialized
DEBUG - 2015-12-01 16:54:42 --> Output Class Initialized
DEBUG - 2015-12-01 16:54:42 --> Security Class Initialized
DEBUG - 2015-12-01 16:54:42 --> Input Class Initialized
DEBUG - 2015-12-01 16:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:54:42 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:43 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:43 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:43 --> Loader Class Initialized
DEBUG - 2015-12-01 16:54:43 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:54:43 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:54:44 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:54:44 --> Session Class Initialized
DEBUG - 2015-12-01 16:54:44 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:54:44 --> Session routines successfully run
DEBUG - 2015-12-01 16:54:44 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:54:44 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:54:44 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:54:44 --> Email Class Initialized
DEBUG - 2015-12-01 16:54:44 --> Controller Class Initialized
DEBUG - 2015-12-01 16:54:44 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:54:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:54:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:54:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:54:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:54:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:54:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:54:44 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:54:45 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:45 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 16:54:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:54:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:54:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:54:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:54:45 --> Final output sent to browser
DEBUG - 2015-12-01 16:54:45 --> Total execution time: 4.8082
DEBUG - 2015-12-01 16:54:50 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:50 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:54:50 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:54:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:54:50 --> URI Class Initialized
DEBUG - 2015-12-01 16:54:50 --> Router Class Initialized
DEBUG - 2015-12-01 16:54:51 --> Output Class Initialized
DEBUG - 2015-12-01 16:54:51 --> Security Class Initialized
DEBUG - 2015-12-01 16:54:51 --> Input Class Initialized
DEBUG - 2015-12-01 16:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:54:51 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:51 --> Language Class Initialized
DEBUG - 2015-12-01 16:54:51 --> Config Class Initialized
DEBUG - 2015-12-01 16:54:51 --> Loader Class Initialized
DEBUG - 2015-12-01 16:54:52 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:54:52 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:54:52 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:54:53 --> Session Class Initialized
DEBUG - 2015-12-01 16:54:53 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:54:53 --> Session routines successfully run
DEBUG - 2015-12-01 16:54:53 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:54:53 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:54:53 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:54:53 --> Email Class Initialized
DEBUG - 2015-12-01 16:54:53 --> Controller Class Initialized
DEBUG - 2015-12-01 16:54:53 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:54:53 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:54:54 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:54:54 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:54:54 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:54:54 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:54:54 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:54:54 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:54:54 --> Model Class Initialized
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:54:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:54:55 --> Final output sent to browser
DEBUG - 2015-12-01 16:54:55 --> Total execution time: 4.7549
DEBUG - 2015-12-01 16:55:24 --> Config Class Initialized
DEBUG - 2015-12-01 16:55:24 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:55:24 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:55:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:55:24 --> URI Class Initialized
DEBUG - 2015-12-01 16:55:24 --> Router Class Initialized
DEBUG - 2015-12-01 16:55:24 --> Output Class Initialized
DEBUG - 2015-12-01 16:55:24 --> Security Class Initialized
DEBUG - 2015-12-01 16:55:24 --> Input Class Initialized
DEBUG - 2015-12-01 16:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:55:24 --> Language Class Initialized
DEBUG - 2015-12-01 16:55:25 --> Language Class Initialized
DEBUG - 2015-12-01 16:55:25 --> Config Class Initialized
DEBUG - 2015-12-01 16:55:25 --> Loader Class Initialized
DEBUG - 2015-12-01 16:55:25 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:55:25 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:55:25 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:55:25 --> Session Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:55:26 --> Session routines successfully run
DEBUG - 2015-12-01 16:55:26 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Email Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Controller Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:55:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:55:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:55:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:55:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:55:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:55:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:55:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:55:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 16:55:26 --> XSS Filtering completed
DEBUG - 2015-12-01 16:55:26 --> XSS Filtering completed
DEBUG - 2015-12-01 16:55:26 --> XSS Filtering completed
DEBUG - 2015-12-01 16:55:26 --> XSS Filtering completed
DEBUG - 2015-12-01 16:55:26 --> Config Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:55:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:55:26 --> URI Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Router Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Output Class Initialized
DEBUG - 2015-12-01 16:55:26 --> Security Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Input Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:55:27 --> Language Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Language Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Config Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Loader Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:55:27 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:55:27 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Session Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:55:27 --> Session routines successfully run
DEBUG - 2015-12-01 16:55:27 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Email Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Controller Class Initialized
DEBUG - 2015-12-01 16:55:27 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:55:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:55:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:55:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:55:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:55:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:55:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:55:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:55:27 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:28 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 16:55:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:55:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:55:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:55:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:55:28 --> Final output sent to browser
DEBUG - 2015-12-01 16:55:28 --> Total execution time: 1.5494
DEBUG - 2015-12-01 16:55:51 --> Config Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:55:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:55:51 --> URI Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Router Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Output Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Security Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Input Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:55:51 --> Language Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Language Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Config Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Loader Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:55:51 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:55:51 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Session Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:55:51 --> Session routines successfully run
DEBUG - 2015-12-01 16:55:51 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Email Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Controller Class Initialized
DEBUG - 2015-12-01 16:55:51 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:55:52 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:55:52 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:55:52 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:55:52 --> Model Class Initialized
DEBUG - 2015-12-01 16:55:52 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-01 16:55:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:55:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:55:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:55:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:55:52 --> Final output sent to browser
DEBUG - 2015-12-01 16:55:52 --> Total execution time: 1.2656
DEBUG - 2015-12-01 16:55:59 --> Config Class Initialized
DEBUG - 2015-12-01 16:55:59 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:55:59 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:55:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:55:59 --> URI Class Initialized
DEBUG - 2015-12-01 16:55:59 --> Router Class Initialized
DEBUG - 2015-12-01 16:55:59 --> Output Class Initialized
DEBUG - 2015-12-01 16:55:59 --> Security Class Initialized
DEBUG - 2015-12-01 16:55:59 --> Input Class Initialized
DEBUG - 2015-12-01 16:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:55:59 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Loader Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:56:00 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:56:00 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Session Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:56:00 --> Session routines successfully run
DEBUG - 2015-12-01 16:56:00 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Email Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Controller Class Initialized
DEBUG - 2015-12-01 16:56:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:56:00 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:56:00 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:56:00 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:56:00 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:56:00 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:56:00 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:56:00 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:56:00 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:56:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:56:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:56:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:56:01 --> Final output sent to browser
DEBUG - 2015-12-01 16:56:01 --> Total execution time: 1.6273
DEBUG - 2015-12-01 16:56:04 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:04 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:56:04 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:56:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:56:04 --> URI Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Router Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Output Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Security Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Input Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:56:05 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Loader Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:56:05 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:56:05 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Session Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:56:05 --> Session routines successfully run
DEBUG - 2015-12-01 16:56:05 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Email Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Controller Class Initialized
DEBUG - 2015-12-01 16:56:05 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:56:05 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:56:05 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:56:05 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:56:05 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:56:05 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:56:05 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:56:05 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:56:05 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:05 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-01 16:56:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:56:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:56:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:56:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:56:06 --> Final output sent to browser
DEBUG - 2015-12-01 16:56:06 --> Total execution time: 1.8198
DEBUG - 2015-12-01 16:56:18 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:56:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:56:19 --> URI Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Router Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Output Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Security Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Input Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:56:19 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Loader Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:56:19 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:56:19 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Session Class Initialized
DEBUG - 2015-12-01 16:56:19 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:56:19 --> Session routines successfully run
DEBUG - 2015-12-01 16:56:20 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:56:20 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:56:20 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:56:20 --> Email Class Initialized
DEBUG - 2015-12-01 16:56:20 --> Controller Class Initialized
DEBUG - 2015-12-01 16:56:20 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:56:20 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:56:20 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:56:20 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:56:20 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:56:20 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:56:20 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:56:20 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:56:20 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:56:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:56:20 --> Final output sent to browser
DEBUG - 2015-12-01 16:56:20 --> Total execution time: 1.5243
DEBUG - 2015-12-01 16:56:23 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:56:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:56:24 --> URI Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Router Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Output Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Security Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Input Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:56:24 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Loader Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:56:24 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:56:24 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Session Class Initialized
DEBUG - 2015-12-01 16:56:24 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:56:24 --> Session routines successfully run
DEBUG - 2015-12-01 16:56:24 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Email Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Controller Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:56:25 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:56:25 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:56:25 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:56:25 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:56:25 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:56:25 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:56:25 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:56:25 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 16:56:25 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:25 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:25 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:25 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:25 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:25 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:56:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:56:25 --> URI Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Router Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Output Class Initialized
DEBUG - 2015-12-01 16:56:25 --> Security Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Input Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:56:26 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Loader Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:56:26 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:56:26 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Session Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:56:26 --> Session routines successfully run
DEBUG - 2015-12-01 16:56:26 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Email Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Controller Class Initialized
DEBUG - 2015-12-01 16:56:26 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:56:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:56:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:56:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:56:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:56:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:56:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:56:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:56:26 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:56:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:56:26 --> Final output sent to browser
DEBUG - 2015-12-01 16:56:26 --> Total execution time: 1.3199
DEBUG - 2015-12-01 16:56:29 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:56:29 --> URI Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Router Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Output Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Security Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Input Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:56:29 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Loader Class Initialized
DEBUG - 2015-12-01 16:56:29 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:56:29 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:56:30 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:56:30 --> Session Class Initialized
DEBUG - 2015-12-01 16:56:30 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:56:30 --> Session routines successfully run
DEBUG - 2015-12-01 16:56:30 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:56:30 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:56:30 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:56:30 --> Email Class Initialized
DEBUG - 2015-12-01 16:56:30 --> Controller Class Initialized
DEBUG - 2015-12-01 16:56:30 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:56:30 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:56:30 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:56:30 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:56:30 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:56:30 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:56:30 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:56:30 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:56:30 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:56:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:56:30 --> Final output sent to browser
DEBUG - 2015-12-01 16:56:30 --> Total execution time: 1.3590
DEBUG - 2015-12-01 16:56:47 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:47 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:56:47 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:56:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:56:47 --> URI Class Initialized
DEBUG - 2015-12-01 16:56:47 --> Router Class Initialized
DEBUG - 2015-12-01 16:56:47 --> Output Class Initialized
DEBUG - 2015-12-01 16:56:47 --> Security Class Initialized
DEBUG - 2015-12-01 16:56:47 --> Input Class Initialized
DEBUG - 2015-12-01 16:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:56:47 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Loader Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:56:48 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:56:48 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Session Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:56:48 --> Session routines successfully run
DEBUG - 2015-12-01 16:56:48 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Email Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Controller Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:56:48 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:56:48 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:56:48 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:56:48 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:56:48 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:56:48 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:56:48 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:56:48 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 16:56:48 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:48 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:48 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:48 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:48 --> XSS Filtering completed
DEBUG - 2015-12-01 16:56:48 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:56:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:56:48 --> URI Class Initialized
DEBUG - 2015-12-01 16:56:48 --> Router Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Output Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Security Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Input Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:56:49 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Loader Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:56:49 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:56:49 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Session Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:56:49 --> Session routines successfully run
DEBUG - 2015-12-01 16:56:49 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Email Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Controller Class Initialized
DEBUG - 2015-12-01 16:56:49 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 16:56:49 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:56:49 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:56:49 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:56:49 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 16:56:49 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:56:49 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:56:49 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:56:49 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:50 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 16:56:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 16:56:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 16:56:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 16:56:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 16:56:50 --> Final output sent to browser
DEBUG - 2015-12-01 16:56:50 --> Total execution time: 1.3755
DEBUG - 2015-12-01 16:56:55 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:55 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:56:55 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:56:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:56:55 --> URI Class Initialized
DEBUG - 2015-12-01 16:56:56 --> Router Class Initialized
DEBUG - 2015-12-01 16:56:56 --> Output Class Initialized
DEBUG - 2015-12-01 16:56:56 --> Security Class Initialized
DEBUG - 2015-12-01 16:56:56 --> Input Class Initialized
DEBUG - 2015-12-01 16:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:56:56 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:57 --> Language Class Initialized
DEBUG - 2015-12-01 16:56:57 --> Config Class Initialized
DEBUG - 2015-12-01 16:56:57 --> Loader Class Initialized
DEBUG - 2015-12-01 16:56:57 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:56:57 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:56:57 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:56:57 --> Session Class Initialized
DEBUG - 2015-12-01 16:56:57 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:56:57 --> Session routines successfully run
DEBUG - 2015-12-01 16:56:58 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:56:58 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:56:58 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:56:58 --> Email Class Initialized
DEBUG - 2015-12-01 16:56:58 --> Controller Class Initialized
DEBUG - 2015-12-01 16:56:58 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 16:56:58 --> Model Class Initialized
DEBUG - 2015-12-01 16:56:58 --> DB Transaction Failure
ERROR - 2015-12-01 16:56:58 --> Query error: Table 'mfi.personnel_type' doesn't exist
DEBUG - 2015-12-01 16:56:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-01 16:58:44 --> Config Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Hooks Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Utf8 Class Initialized
DEBUG - 2015-12-01 16:58:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 16:58:45 --> URI Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Router Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Output Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Security Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Input Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 16:58:45 --> Language Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Language Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Config Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Loader Class Initialized
DEBUG - 2015-12-01 16:58:45 --> Helper loaded: url_helper
DEBUG - 2015-12-01 16:58:45 --> Helper loaded: form_helper
DEBUG - 2015-12-01 16:58:46 --> Database Driver Class Initialized
DEBUG - 2015-12-01 16:58:46 --> Session Class Initialized
DEBUG - 2015-12-01 16:58:46 --> Helper loaded: string_helper
DEBUG - 2015-12-01 16:58:46 --> Session routines successfully run
DEBUG - 2015-12-01 16:58:46 --> Form Validation Class Initialized
DEBUG - 2015-12-01 16:58:46 --> Pagination Class Initialized
DEBUG - 2015-12-01 16:58:46 --> Encrypt Class Initialized
DEBUG - 2015-12-01 16:58:46 --> Email Class Initialized
DEBUG - 2015-12-01 16:58:46 --> Controller Class Initialized
DEBUG - 2015-12-01 16:58:46 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 16:58:46 --> Model Class Initialized
DEBUG - 2015-12-01 16:58:46 --> DB Transaction Failure
ERROR - 2015-12-01 16:58:46 --> Query error: Unknown column 'personnel.personnel_type_id' in 'where clause'
DEBUG - 2015-12-01 16:58:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-01 17:00:54 --> Config Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:00:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:00:55 --> URI Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Router Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Output Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Security Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Input Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:00:55 --> Language Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Language Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Config Class Initialized
DEBUG - 2015-12-01 17:00:55 --> Loader Class Initialized
DEBUG - 2015-12-01 17:00:56 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:00:56 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:00:56 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:00:56 --> Session Class Initialized
DEBUG - 2015-12-01 17:00:56 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:00:56 --> Session routines successfully run
DEBUG - 2015-12-01 17:00:56 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:00:56 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:00:56 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:00:56 --> Email Class Initialized
DEBUG - 2015-12-01 17:00:56 --> Controller Class Initialized
DEBUG - 2015-12-01 17:00:56 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 17:00:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:00:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:00:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:00:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:00:57 --> Final output sent to browser
DEBUG - 2015-12-01 17:00:57 --> Total execution time: 2.2180
DEBUG - 2015-12-01 17:01:29 --> Config Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:01:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:01:30 --> URI Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Router Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Output Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Security Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Input Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:01:30 --> Language Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Language Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Config Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Loader Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:01:30 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:01:30 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Session Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:01:30 --> Session routines successfully run
DEBUG - 2015-12-01 17:01:30 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Email Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Controller Class Initialized
DEBUG - 2015-12-01 17:01:30 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 17:01:31 --> Model Class Initialized
DEBUG - 2015-12-01 17:01:31 --> DB Transaction Failure
ERROR - 2015-12-01 17:01:31 --> Query error: Table 'mfi.departments' doesn't exist
DEBUG - 2015-12-01 17:01:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-01 17:02:17 --> Config Class Initialized
DEBUG - 2015-12-01 17:02:18 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:02:18 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:02:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:02:18 --> URI Class Initialized
DEBUG - 2015-12-01 17:02:18 --> Router Class Initialized
DEBUG - 2015-12-01 17:02:18 --> Output Class Initialized
DEBUG - 2015-12-01 17:02:18 --> Security Class Initialized
DEBUG - 2015-12-01 17:02:18 --> Input Class Initialized
DEBUG - 2015-12-01 17:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:02:18 --> Language Class Initialized
DEBUG - 2015-12-01 17:02:19 --> Language Class Initialized
DEBUG - 2015-12-01 17:02:19 --> Config Class Initialized
DEBUG - 2015-12-01 17:02:19 --> Loader Class Initialized
DEBUG - 2015-12-01 17:02:19 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:02:19 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:02:20 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:02:20 --> Session Class Initialized
DEBUG - 2015-12-01 17:02:20 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:02:20 --> Session routines successfully run
DEBUG - 2015-12-01 17:02:20 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:02:20 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:02:20 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:02:20 --> Email Class Initialized
DEBUG - 2015-12-01 17:02:20 --> Controller Class Initialized
DEBUG - 2015-12-01 17:02:20 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 17:02:20 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:02:20 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:02:20 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:02:20 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:02:20 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:02:20 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:02:21 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:21 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 17:02:21 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:21 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 17:02:21 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:21 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 17:02:21 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:21 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 17:02:21 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:21 --> DB Transaction Failure
ERROR - 2015-12-01 17:02:21 --> Query error: Table 'mfi.leave_duration' doesn't exist
DEBUG - 2015-12-01 17:02:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-01 17:02:54 --> Config Class Initialized
DEBUG - 2015-12-01 17:02:54 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:02:54 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:02:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:02:54 --> URI Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Router Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Output Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Security Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Input Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:02:55 --> Language Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Language Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Config Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Loader Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:02:55 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:02:55 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Session Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:02:55 --> Session routines successfully run
DEBUG - 2015-12-01 17:02:55 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Email Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Controller Class Initialized
DEBUG - 2015-12-01 17:02:55 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 17:02:55 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 17:02:56 --> Model Class Initialized
DEBUG - 2015-12-01 17:02:56 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-01 17:02:56 --> DB Transaction Failure
ERROR - 2015-12-01 17:02:56 --> Query error: Table 'mfi.inventory_level_status' doesn't exist
DEBUG - 2015-12-01 17:02:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-01 17:04:08 --> Config Class Initialized
DEBUG - 2015-12-01 17:04:09 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:04:09 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:04:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:04:09 --> URI Class Initialized
DEBUG - 2015-12-01 17:04:09 --> Router Class Initialized
DEBUG - 2015-12-01 17:04:09 --> Output Class Initialized
DEBUG - 2015-12-01 17:04:09 --> Security Class Initialized
DEBUG - 2015-12-01 17:04:10 --> Input Class Initialized
DEBUG - 2015-12-01 17:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:04:10 --> Language Class Initialized
DEBUG - 2015-12-01 17:04:10 --> Language Class Initialized
DEBUG - 2015-12-01 17:04:10 --> Config Class Initialized
DEBUG - 2015-12-01 17:04:10 --> Loader Class Initialized
DEBUG - 2015-12-01 17:04:10 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:04:10 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:04:11 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:04:11 --> Session Class Initialized
DEBUG - 2015-12-01 17:04:11 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:04:11 --> Session routines successfully run
DEBUG - 2015-12-01 17:04:11 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:04:11 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:04:11 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:04:11 --> Email Class Initialized
DEBUG - 2015-12-01 17:04:11 --> Controller Class Initialized
DEBUG - 2015-12-01 17:04:11 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 17:04:11 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:04:12 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:04:12 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:04:12 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:04:12 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:04:12 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:04:13 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:13 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 17:04:13 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:13 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 17:04:13 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:13 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 17:04:13 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:13 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 17:04:13 --> Model Class Initialized
DEBUG - 2015-12-01 17:04:13 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-01 17:04:13 --> DB Transaction Failure
ERROR - 2015-12-01 17:04:13 --> Query error: Table 'mfi.inventory_level_status' doesn't exist
DEBUG - 2015-12-01 17:04:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-01 17:16:22 --> Config Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:16:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:16:23 --> URI Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Router Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Output Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Security Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Input Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:16:23 --> Language Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Language Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Config Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Loader Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:16:23 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:16:23 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Session Class Initialized
DEBUG - 2015-12-01 17:16:23 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:16:23 --> Session routines successfully run
DEBUG - 2015-12-01 17:16:24 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:16:24 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:16:24 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:16:24 --> Email Class Initialized
DEBUG - 2015-12-01 17:16:24 --> Controller Class Initialized
DEBUG - 2015-12-01 17:16:24 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 17:16:24 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:24 --> Image Lib Class Initialized
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-01 17:16:24 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-01 17:16:25 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-01 17:16:25 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-01 17:16:25 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-01 17:16:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:16:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:16:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:16:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:16:25 --> Final output sent to browser
DEBUG - 2015-12-01 17:16:25 --> Total execution time: 2.4252
DEBUG - 2015-12-01 17:16:35 --> Config Class Initialized
DEBUG - 2015-12-01 17:16:35 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:16:35 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:16:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:16:35 --> URI Class Initialized
DEBUG - 2015-12-01 17:16:35 --> Router Class Initialized
DEBUG - 2015-12-01 17:16:35 --> Output Class Initialized
DEBUG - 2015-12-01 17:16:35 --> Security Class Initialized
DEBUG - 2015-12-01 17:16:35 --> Input Class Initialized
DEBUG - 2015-12-01 17:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:16:35 --> Language Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Language Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Config Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Loader Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:16:36 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:16:36 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Session Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:16:36 --> Session routines successfully run
DEBUG - 2015-12-01 17:16:36 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Email Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Controller Class Initialized
DEBUG - 2015-12-01 17:16:36 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 17:16:36 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:16:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:16:36 --> Final output sent to browser
DEBUG - 2015-12-01 17:16:36 --> Total execution time: 0.6355
DEBUG - 2015-12-01 17:16:39 --> Config Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:16:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:16:39 --> URI Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Router Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Output Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Security Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Input Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:16:39 --> Language Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Language Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Config Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Loader Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:16:39 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:16:39 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Session Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:16:39 --> Session routines successfully run
DEBUG - 2015-12-01 17:16:39 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Email Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Controller Class Initialized
DEBUG - 2015-12-01 17:16:39 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 17:16:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:16:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:16:39 --> Final output sent to browser
DEBUG - 2015-12-01 17:16:39 --> Total execution time: 0.8265
DEBUG - 2015-12-01 17:20:49 --> Config Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:20:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:20:49 --> URI Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Router Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Output Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Security Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Input Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:20:49 --> Language Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Language Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Config Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Loader Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:20:49 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:20:49 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Session Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:20:49 --> Session routines successfully run
DEBUG - 2015-12-01 17:20:49 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Email Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Controller Class Initialized
DEBUG - 2015-12-01 17:20:49 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:20:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:20:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:20:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:20:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:20:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:20:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:20:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:20:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:20:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:20:49 --> Final output sent to browser
DEBUG - 2015-12-01 17:20:49 --> Total execution time: 0.6273
DEBUG - 2015-12-01 17:20:51 --> Config Class Initialized
DEBUG - 2015-12-01 17:20:51 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:20:51 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:20:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:20:51 --> URI Class Initialized
DEBUG - 2015-12-01 17:20:51 --> Router Class Initialized
DEBUG - 2015-12-01 17:20:51 --> Output Class Initialized
DEBUG - 2015-12-01 17:20:51 --> Security Class Initialized
DEBUG - 2015-12-01 17:20:51 --> Input Class Initialized
DEBUG - 2015-12-01 17:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:20:52 --> Language Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Language Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Config Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Loader Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:20:52 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:20:52 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Session Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:20:52 --> Session routines successfully run
DEBUG - 2015-12-01 17:20:52 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Email Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Controller Class Initialized
DEBUG - 2015-12-01 17:20:52 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:20:52 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:20:52 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:20:52 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:20:52 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:20:52 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:20:52 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:20:52 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:20:52 --> Model Class Initialized
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:20:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:20:52 --> Final output sent to browser
DEBUG - 2015-12-01 17:20:52 --> Total execution time: 0.3590
DEBUG - 2015-12-01 17:22:29 --> Config Class Initialized
DEBUG - 2015-12-01 17:22:29 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:22:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:22:30 --> URI Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Router Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Output Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Security Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Input Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:22:30 --> Language Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Language Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Config Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Loader Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:22:30 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:22:30 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Session Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:22:30 --> Session routines successfully run
DEBUG - 2015-12-01 17:22:30 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Email Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Controller Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 17:22:30 --> XSS Filtering completed
DEBUG - 2015-12-01 17:22:30 --> XSS Filtering completed
DEBUG - 2015-12-01 17:22:30 --> XSS Filtering completed
DEBUG - 2015-12-01 17:22:30 --> XSS Filtering completed
DEBUG - 2015-12-01 17:22:30 --> XSS Filtering completed
DEBUG - 2015-12-01 17:22:30 --> Config Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:22:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:22:30 --> URI Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Router Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Output Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Security Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Input Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:22:30 --> Language Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Language Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Config Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Loader Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:22:30 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:22:30 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Session Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:22:30 --> Session routines successfully run
DEBUG - 2015-12-01 17:22:30 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Email Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Controller Class Initialized
DEBUG - 2015-12-01 17:22:30 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:22:30 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:22:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:22:30 --> Final output sent to browser
DEBUG - 2015-12-01 17:22:30 --> Total execution time: 0.3060
DEBUG - 2015-12-01 17:22:39 --> Config Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:22:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:22:39 --> URI Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Router Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Output Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Security Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Input Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:22:39 --> Language Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Language Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Config Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Loader Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:22:39 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:22:39 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Session Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:22:39 --> Session routines successfully run
DEBUG - 2015-12-01 17:22:39 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Email Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Controller Class Initialized
DEBUG - 2015-12-01 17:22:39 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:22:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:22:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:22:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:22:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:22:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:22:39 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:22:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:22:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:22:40 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-01 17:22:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:22:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:22:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:22:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:22:40 --> Final output sent to browser
DEBUG - 2015-12-01 17:22:40 --> Total execution time: 0.3366
DEBUG - 2015-12-01 17:23:01 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:23:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:23:01 --> URI Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Router Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Output Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Security Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Input Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:23:01 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:01 --> Loader Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:23:02 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:23:02 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Session Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:23:02 --> Session routines successfully run
DEBUG - 2015-12-01 17:23:02 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Email Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Controller Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 17:23:02 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:02 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:02 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:02 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:02 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:02 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:23:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:23:02 --> URI Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Router Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Output Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Security Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Input Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:23:02 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Loader Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:23:02 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:23:02 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Session Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:23:02 --> Session routines successfully run
DEBUG - 2015-12-01 17:23:02 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Email Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Controller Class Initialized
DEBUG - 2015-12-01 17:23:02 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:23:02 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:23:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:23:02 --> Final output sent to browser
DEBUG - 2015-12-01 17:23:02 --> Total execution time: 0.3050
DEBUG - 2015-12-01 17:23:04 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:23:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:23:04 --> URI Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Router Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Output Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Security Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Input Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:23:04 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Loader Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:23:04 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:23:04 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Session Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:23:04 --> Session routines successfully run
DEBUG - 2015-12-01 17:23:04 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Email Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Controller Class Initialized
DEBUG - 2015-12-01 17:23:04 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:23:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:23:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:23:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:23:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:23:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:23:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:23:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:23:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:23:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:23:04 --> Final output sent to browser
DEBUG - 2015-12-01 17:23:04 --> Total execution time: 0.4192
DEBUG - 2015-12-01 17:23:17 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:17 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:23:17 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:23:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:23:17 --> URI Class Initialized
DEBUG - 2015-12-01 17:23:17 --> Router Class Initialized
DEBUG - 2015-12-01 17:23:17 --> Output Class Initialized
DEBUG - 2015-12-01 17:23:17 --> Security Class Initialized
DEBUG - 2015-12-01 17:23:17 --> Input Class Initialized
DEBUG - 2015-12-01 17:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:23:17 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:17 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Loader Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:23:18 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:23:18 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Session Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:23:18 --> Session routines successfully run
DEBUG - 2015-12-01 17:23:18 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Email Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Controller Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 17:23:18 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:18 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:18 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:18 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:18 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:18 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:23:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:23:18 --> URI Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Router Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Output Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Security Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Input Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:23:18 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Loader Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:23:18 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:23:18 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Session Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:23:18 --> Session routines successfully run
DEBUG - 2015-12-01 17:23:18 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Email Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Controller Class Initialized
DEBUG - 2015-12-01 17:23:18 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:23:18 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:23:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:23:18 --> Final output sent to browser
DEBUG - 2015-12-01 17:23:18 --> Total execution time: 0.3147
DEBUG - 2015-12-01 17:23:45 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:23:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:23:45 --> URI Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Router Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Output Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Security Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Input Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:23:45 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Loader Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:23:45 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:23:45 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:23:45 --> Session Class Initialized
DEBUG - 2015-12-01 17:23:46 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:23:46 --> Session routines successfully run
DEBUG - 2015-12-01 17:23:46 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:23:46 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:23:46 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:23:46 --> Email Class Initialized
DEBUG - 2015-12-01 17:23:46 --> Controller Class Initialized
DEBUG - 2015-12-01 17:23:46 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:23:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:23:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:23:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:23:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:23:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:23:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:23:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:23:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:23:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:23:46 --> Final output sent to browser
DEBUG - 2015-12-01 17:23:46 --> Total execution time: 0.3423
DEBUG - 2015-12-01 17:23:49 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:23:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:23:49 --> URI Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Router Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Output Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Security Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Input Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:23:49 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Loader Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:23:49 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:23:49 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Session Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:23:49 --> Session routines successfully run
DEBUG - 2015-12-01 17:23:49 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Email Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Controller Class Initialized
DEBUG - 2015-12-01 17:23:49 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:23:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:23:49 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-01 17:23:50 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:50 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:50 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:50 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:50 --> XSS Filtering completed
DEBUG - 2015-12-01 17:23:50 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:23:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:23:50 --> URI Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Router Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Output Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Security Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Input Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:23:50 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Loader Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:23:50 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:23:50 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Session Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:23:50 --> Session routines successfully run
DEBUG - 2015-12-01 17:23:50 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Email Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Controller Class Initialized
DEBUG - 2015-12-01 17:23:50 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:23:50 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:23:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:23:50 --> Final output sent to browser
DEBUG - 2015-12-01 17:23:50 --> Total execution time: 0.4291
DEBUG - 2015-12-01 17:23:57 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:23:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:23:57 --> URI Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Router Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Output Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Security Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Input Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:23:57 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Language Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Config Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Loader Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:23:57 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:23:57 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Session Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:23:57 --> Session routines successfully run
DEBUG - 2015-12-01 17:23:57 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Email Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Controller Class Initialized
DEBUG - 2015-12-01 17:23:57 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-01 17:23:57 --> Model Class Initialized
DEBUG - 2015-12-01 17:23:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:23:57 --> Model Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Config Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:24:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:24:03 --> URI Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Router Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Output Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Security Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Input Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:24:03 --> Language Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Language Class Initialized
DEBUG - 2015-12-01 17:24:03 --> Config Class Initialized
DEBUG - 2015-12-01 17:24:04 --> Loader Class Initialized
DEBUG - 2015-12-01 17:24:04 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:24:04 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:24:04 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:24:04 --> Session Class Initialized
DEBUG - 2015-12-01 17:24:04 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:24:04 --> Session routines successfully run
DEBUG - 2015-12-01 17:24:04 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:24:04 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:24:04 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:24:04 --> Email Class Initialized
DEBUG - 2015-12-01 17:24:04 --> Controller Class Initialized
DEBUG - 2015-12-01 17:24:04 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-01 17:24:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:24:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:24:04 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Config Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:25:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:25:00 --> URI Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Router Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Output Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Security Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Input Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:25:00 --> Language Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Language Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Config Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Loader Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:25:00 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:25:00 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Session Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:25:00 --> Session routines successfully run
DEBUG - 2015-12-01 17:25:00 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Email Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Controller Class Initialized
DEBUG - 2015-12-01 17:25:00 --> Sections MX_Controller Initialized
DEBUG - 2015-12-01 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-01 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:25:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:25:00 --> Final output sent to browser
DEBUG - 2015-12-01 17:25:00 --> Total execution time: 0.3081
DEBUG - 2015-12-01 17:25:07 --> Config Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:25:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:25:07 --> URI Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Router Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Output Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Security Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Input Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:25:07 --> Language Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Language Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Config Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Loader Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:25:07 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:25:07 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Session Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:25:07 --> Session routines successfully run
DEBUG - 2015-12-01 17:25:07 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Email Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Controller Class Initialized
DEBUG - 2015-12-01 17:25:07 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:07 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-01 17:25:07 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Config Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:25:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:25:40 --> URI Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Router Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Output Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Security Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Input Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:25:40 --> Language Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Language Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Config Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Loader Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:25:40 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:25:40 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Session Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:25:40 --> Session routines successfully run
DEBUG - 2015-12-01 17:25:40 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Email Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Controller Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Individual MX_Controller Initialized
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-01 17:25:40 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:40 --> Image Lib Class Initialized
DEBUG - 2015-12-01 17:25:41 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-01 17:25:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:25:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:25:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:25:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:25:41 --> Final output sent to browser
DEBUG - 2015-12-01 17:25:41 --> Total execution time: 0.4496
DEBUG - 2015-12-01 17:25:46 --> Config Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Hooks Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Utf8 Class Initialized
DEBUG - 2015-12-01 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 17:25:46 --> URI Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Router Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Output Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Security Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Input Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 17:25:46 --> Language Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Language Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Config Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Loader Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Helper loaded: url_helper
DEBUG - 2015-12-01 17:25:46 --> Helper loaded: form_helper
DEBUG - 2015-12-01 17:25:46 --> Database Driver Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Session Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Helper loaded: string_helper
DEBUG - 2015-12-01 17:25:46 --> Session routines successfully run
DEBUG - 2015-12-01 17:25:46 --> Form Validation Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Pagination Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Encrypt Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Email Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Controller Class Initialized
DEBUG - 2015-12-01 17:25:46 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 17:25:46 --> Model Class Initialized
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-01 17:25:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-01 17:25:46 --> Final output sent to browser
DEBUG - 2015-12-01 17:25:46 --> Total execution time: 0.3631
DEBUG - 2015-12-01 21:30:28 --> Config Class Initialized
DEBUG - 2015-12-01 21:30:28 --> Hooks Class Initialized
DEBUG - 2015-12-01 21:30:28 --> Utf8 Class Initialized
DEBUG - 2015-12-01 21:30:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-01 21:30:29 --> URI Class Initialized
DEBUG - 2015-12-01 21:30:30 --> Router Class Initialized
DEBUG - 2015-12-01 21:30:31 --> Output Class Initialized
DEBUG - 2015-12-01 21:30:31 --> Security Class Initialized
DEBUG - 2015-12-01 21:30:31 --> Input Class Initialized
DEBUG - 2015-12-01 21:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-01 21:30:31 --> Language Class Initialized
DEBUG - 2015-12-01 21:30:32 --> Language Class Initialized
DEBUG - 2015-12-01 21:30:32 --> Config Class Initialized
DEBUG - 2015-12-01 21:30:32 --> Loader Class Initialized
DEBUG - 2015-12-01 21:30:33 --> Helper loaded: url_helper
DEBUG - 2015-12-01 21:30:33 --> Helper loaded: form_helper
DEBUG - 2015-12-01 21:30:34 --> Database Driver Class Initialized
DEBUG - 2015-12-01 21:30:51 --> Session Class Initialized
DEBUG - 2015-12-01 21:30:52 --> Helper loaded: string_helper
DEBUG - 2015-12-01 21:30:52 --> A session cookie was not found.
DEBUG - 2015-12-01 21:30:52 --> Session routines successfully run
DEBUG - 2015-12-01 21:30:52 --> Form Validation Class Initialized
DEBUG - 2015-12-01 21:30:52 --> Pagination Class Initialized
DEBUG - 2015-12-01 21:30:52 --> Encrypt Class Initialized
DEBUG - 2015-12-01 21:30:53 --> Email Class Initialized
DEBUG - 2015-12-01 21:30:53 --> Controller Class Initialized
DEBUG - 2015-12-01 21:30:53 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-01 21:30:53 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-01 21:30:53 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-01 21:30:53 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-01 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-01 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-01 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-01 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:54 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-01 21:30:54 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:55 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-01 21:30:55 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:55 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-01 21:30:55 --> Model Class Initialized
DEBUG - 2015-12-01 21:30:55 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-01 21:30:55 --> Model Class Initialized
