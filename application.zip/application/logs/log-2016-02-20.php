<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-20 00:03:33 --> Config Class Initialized
DEBUG - 2016-02-20 00:03:33 --> Hooks Class Initialized
DEBUG - 2016-02-20 00:03:34 --> Utf8 Class Initialized
DEBUG - 2016-02-20 00:03:34 --> UTF-8 Support Enabled
DEBUG - 2016-02-20 00:03:34 --> URI Class Initialized
DEBUG - 2016-02-20 00:03:34 --> Router Class Initialized
DEBUG - 2016-02-20 00:03:35 --> No URI present. Default controller set.
DEBUG - 2016-02-20 00:03:35 --> Output Class Initialized
DEBUG - 2016-02-20 00:03:35 --> Security Class Initialized
DEBUG - 2016-02-20 00:03:35 --> Input Class Initialized
DEBUG - 2016-02-20 00:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-20 00:03:35 --> Language Class Initialized
DEBUG - 2016-02-20 00:03:36 --> Language Class Initialized
DEBUG - 2016-02-20 00:03:36 --> Config Class Initialized
DEBUG - 2016-02-20 00:03:36 --> Loader Class Initialized
DEBUG - 2016-02-20 00:03:36 --> Helper loaded: url_helper
DEBUG - 2016-02-20 00:03:37 --> Helper loaded: form_helper
DEBUG - 2016-02-20 00:03:38 --> Database Driver Class Initialized
DEBUG - 2016-02-20 00:03:50 --> Session Class Initialized
DEBUG - 2016-02-20 00:03:50 --> Helper loaded: string_helper
DEBUG - 2016-02-20 00:03:50 --> A session cookie was not found.
DEBUG - 2016-02-20 00:03:50 --> Session routines successfully run
DEBUG - 2016-02-20 00:03:50 --> Form Validation Class Initialized
DEBUG - 2016-02-20 00:03:51 --> Pagination Class Initialized
DEBUG - 2016-02-20 00:03:51 --> Encrypt Class Initialized
DEBUG - 2016-02-20 00:03:51 --> Email Class Initialized
DEBUG - 2016-02-20 00:03:51 --> Controller Class Initialized
DEBUG - 2016-02-20 00:03:51 --> Auth MX_Controller Initialized
DEBUG - 2016-02-20 00:03:51 --> Model Class Initialized
DEBUG - 2016-02-20 00:03:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-20 00:03:51 --> Model Class Initialized
DEBUG - 2016-02-20 00:03:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-20 00:03:51 --> Model Class Initialized
