<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-09-24 14:08:11 --> Config Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Hooks Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Utf8 Class Initialized
DEBUG - 2015-09-24 14:08:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 14:08:11 --> URI Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Router Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Output Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Security Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Input Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 14:08:11 --> Language Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Language Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Config Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Loader Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Helper loaded: url_helper
DEBUG - 2015-09-24 14:08:11 --> Helper loaded: form_helper
DEBUG - 2015-09-24 14:08:11 --> Database Driver Class Initialized
ERROR - 2015-09-24 14:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 14:08:11 --> Session Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Helper loaded: string_helper
DEBUG - 2015-09-24 14:08:11 --> Session routines successfully run
DEBUG - 2015-09-24 14:08:11 --> Form Validation Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Pagination Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Encrypt Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Email Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Controller Class Initialized
DEBUG - 2015-09-24 14:08:11 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
DEBUG - 2015-09-24 14:08:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
DEBUG - 2015-09-24 14:08:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
DEBUG - 2015-09-24 14:08:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
DEBUG - 2015-09-24 14:08:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
DEBUG - 2015-09-24 14:08:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
DEBUG - 2015-09-24 14:08:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
DEBUG - 2015-09-24 14:08:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
DEBUG - 2015-09-24 14:08:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
DEBUG - 2015-09-24 14:08:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 14:08:11 --> Model Class Initialized
ERROR - 2015-09-24 14:08:11 --> 404 Page Not Found --> microfinance/loans-plan
DEBUG - 2015-09-24 14:10:17 --> Config Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Hooks Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Utf8 Class Initialized
DEBUG - 2015-09-24 14:10:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 14:10:17 --> URI Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Router Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Output Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Security Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Input Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 14:10:17 --> Language Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Language Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Config Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Loader Class Initialized
DEBUG - 2015-09-24 14:10:17 --> Helper loaded: url_helper
DEBUG - 2015-09-24 14:10:17 --> Helper loaded: form_helper
DEBUG - 2015-09-24 14:10:17 --> Database Driver Class Initialized
ERROR - 2015-09-24 14:10:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 14:10:18 --> Session Class Initialized
DEBUG - 2015-09-24 14:10:18 --> Helper loaded: string_helper
DEBUG - 2015-09-24 14:10:18 --> Session routines successfully run
DEBUG - 2015-09-24 14:10:18 --> Form Validation Class Initialized
DEBUG - 2015-09-24 14:10:18 --> Pagination Class Initialized
DEBUG - 2015-09-24 14:10:18 --> Encrypt Class Initialized
DEBUG - 2015-09-24 14:10:18 --> Email Class Initialized
DEBUG - 2015-09-24 14:10:18 --> Controller Class Initialized
DEBUG - 2015-09-24 14:10:18 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 14:10:18 --> Model Class Initialized
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-24 14:10:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-24 14:10:18 --> Final output sent to browser
DEBUG - 2015-09-24 14:10:18 --> Total execution time: 0.3914
DEBUG - 2015-09-24 14:19:09 --> Config Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Hooks Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Utf8 Class Initialized
DEBUG - 2015-09-24 14:19:09 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 14:19:09 --> URI Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Router Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Output Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Security Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Input Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 14:19:09 --> Language Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Language Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Config Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Loader Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Helper loaded: url_helper
DEBUG - 2015-09-24 14:19:09 --> Helper loaded: form_helper
DEBUG - 2015-09-24 14:19:09 --> Database Driver Class Initialized
ERROR - 2015-09-24 14:19:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 14:19:09 --> Session Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Helper loaded: string_helper
DEBUG - 2015-09-24 14:19:09 --> Session routines successfully run
DEBUG - 2015-09-24 14:19:09 --> Form Validation Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Pagination Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Encrypt Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Email Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Controller Class Initialized
DEBUG - 2015-09-24 14:19:09 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 14:19:09 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-24 14:19:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-24 14:19:09 --> Final output sent to browser
DEBUG - 2015-09-24 14:19:09 --> Total execution time: 0.2161
DEBUG - 2015-09-24 14:19:15 --> Config Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Hooks Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Utf8 Class Initialized
DEBUG - 2015-09-24 14:19:15 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 14:19:15 --> URI Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Router Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Output Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Security Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Input Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 14:19:15 --> Language Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Language Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Config Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Loader Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Helper loaded: url_helper
DEBUG - 2015-09-24 14:19:15 --> Helper loaded: form_helper
DEBUG - 2015-09-24 14:19:15 --> Database Driver Class Initialized
ERROR - 2015-09-24 14:19:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 14:19:15 --> Session Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Helper loaded: string_helper
DEBUG - 2015-09-24 14:19:15 --> Session routines successfully run
DEBUG - 2015-09-24 14:19:15 --> Form Validation Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Pagination Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Encrypt Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Email Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Controller Class Initialized
DEBUG - 2015-09-24 14:19:15 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 14:19:15 --> Model Class Initialized
ERROR - 2015-09-24 14:19:15 --> 404 Page Not Found --> microfinance/edit-savings_plan
DEBUG - 2015-09-24 14:19:21 --> Config Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Hooks Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Utf8 Class Initialized
DEBUG - 2015-09-24 14:19:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 14:19:21 --> URI Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Router Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Output Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Security Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Input Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 14:19:21 --> Language Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Language Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Config Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Loader Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Helper loaded: url_helper
DEBUG - 2015-09-24 14:19:21 --> Helper loaded: form_helper
DEBUG - 2015-09-24 14:19:21 --> Database Driver Class Initialized
ERROR - 2015-09-24 14:19:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 14:19:21 --> Session Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Helper loaded: string_helper
DEBUG - 2015-09-24 14:19:21 --> Session routines successfully run
DEBUG - 2015-09-24 14:19:21 --> Form Validation Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Pagination Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Encrypt Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Email Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Controller Class Initialized
DEBUG - 2015-09-24 14:19:21 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
DEBUG - 2015-09-24 14:19:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 14:19:21 --> Model Class Initialized
ERROR - 2015-09-24 14:19:21 --> Severity: Notice  --> Undefined property: stdClass::$savings_plan_onames C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\edit_savings_plan.php 5
ERROR - 2015-09-24 14:19:21 --> Severity: Notice  --> Undefined property: stdClass::$savings_plan_fname C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\edit_savings_plan.php 6
ERROR - 2015-09-24 14:19:21 --> Severity: Notice  --> Undefined property: stdClass::$savings_plan_email C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\edit_savings_plan.php 7
ERROR - 2015-09-24 14:19:21 --> Severity: Notice  --> Undefined property: stdClass::$savings_plan_phone C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\edit_savings_plan.php 8
DEBUG - 2015-09-24 14:58:54 --> Config Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Hooks Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Utf8 Class Initialized
DEBUG - 2015-09-24 14:58:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 14:58:54 --> URI Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Router Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Output Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Security Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Input Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 14:58:54 --> Language Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Language Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Config Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Loader Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Helper loaded: url_helper
DEBUG - 2015-09-24 14:58:54 --> Helper loaded: form_helper
DEBUG - 2015-09-24 14:58:54 --> Database Driver Class Initialized
ERROR - 2015-09-24 14:58:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 14:58:54 --> Session Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Helper loaded: string_helper
DEBUG - 2015-09-24 14:58:54 --> Session routines successfully run
DEBUG - 2015-09-24 14:58:54 --> Form Validation Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Pagination Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Encrypt Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Email Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Controller Class Initialized
DEBUG - 2015-09-24 14:58:54 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
DEBUG - 2015-09-24 14:58:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
DEBUG - 2015-09-24 14:58:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
DEBUG - 2015-09-24 14:58:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
DEBUG - 2015-09-24 14:58:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
DEBUG - 2015-09-24 14:58:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
DEBUG - 2015-09-24 14:58:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
DEBUG - 2015-09-24 14:58:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
DEBUG - 2015-09-24 14:58:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
DEBUG - 2015-09-24 14:58:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 14:58:54 --> Model Class Initialized
ERROR - 2015-09-24 14:58:54 --> 404 Page Not Found --> microfinance/loans
DEBUG - 2015-09-24 15:03:08 --> Config Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Hooks Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Utf8 Class Initialized
DEBUG - 2015-09-24 15:03:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 15:03:08 --> URI Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Router Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Output Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Security Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Input Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 15:03:08 --> Language Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Language Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Config Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Loader Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Helper loaded: url_helper
DEBUG - 2015-09-24 15:03:08 --> Helper loaded: form_helper
DEBUG - 2015-09-24 15:03:08 --> Database Driver Class Initialized
ERROR - 2015-09-24 15:03:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 15:03:08 --> Session Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Helper loaded: string_helper
DEBUG - 2015-09-24 15:03:08 --> Session routines successfully run
DEBUG - 2015-09-24 15:03:08 --> Form Validation Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Pagination Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Encrypt Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Email Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Controller Class Initialized
DEBUG - 2015-09-24 15:03:08 --> Sections MX_Controller Initialized
DEBUG - 2015-09-24 15:03:08 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 15:03:08 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 15:03:08 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 15:03:08 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-24 15:03:08 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 15:03:08 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-24 15:03:08 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 15:03:08 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-24 15:03:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-24 15:03:08 --> Final output sent to browser
DEBUG - 2015-09-24 15:03:08 --> Total execution time: 0.2185
DEBUG - 2015-09-24 15:03:16 --> Config Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Hooks Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Utf8 Class Initialized
DEBUG - 2015-09-24 15:03:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 15:03:16 --> URI Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Router Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Output Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Security Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Input Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 15:03:16 --> Language Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Language Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Config Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Loader Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Helper loaded: url_helper
DEBUG - 2015-09-24 15:03:16 --> Helper loaded: form_helper
DEBUG - 2015-09-24 15:03:16 --> Database Driver Class Initialized
ERROR - 2015-09-24 15:03:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 15:03:16 --> Session Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Helper loaded: string_helper
DEBUG - 2015-09-24 15:03:16 --> Session routines successfully run
DEBUG - 2015-09-24 15:03:16 --> Form Validation Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Pagination Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Encrypt Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Email Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Controller Class Initialized
DEBUG - 2015-09-24 15:03:16 --> Sections MX_Controller Initialized
DEBUG - 2015-09-24 15:03:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 15:03:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 15:03:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 15:03:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-24 15:03:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 15:03:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-24 15:03:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 15:03:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-24 15:03:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-24 15:03:16 --> Final output sent to browser
DEBUG - 2015-09-24 15:03:16 --> Total execution time: 0.2321
DEBUG - 2015-09-24 15:03:35 --> Config Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Hooks Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Utf8 Class Initialized
DEBUG - 2015-09-24 15:03:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 15:03:35 --> URI Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Router Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Output Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Security Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Input Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 15:03:35 --> Language Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Language Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Config Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Loader Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Helper loaded: url_helper
DEBUG - 2015-09-24 15:03:35 --> Helper loaded: form_helper
DEBUG - 2015-09-24 15:03:35 --> Database Driver Class Initialized
ERROR - 2015-09-24 15:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 15:03:35 --> Session Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Helper loaded: string_helper
DEBUG - 2015-09-24 15:03:35 --> Session routines successfully run
DEBUG - 2015-09-24 15:03:35 --> Form Validation Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Pagination Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Encrypt Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Email Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Controller Class Initialized
DEBUG - 2015-09-24 15:03:35 --> Sections MX_Controller Initialized
DEBUG - 2015-09-24 15:03:35 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 15:03:35 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 15:03:35 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 15:03:35 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-24 15:03:35 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 15:03:35 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-24 15:03:35 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 15:03:35 --> Model Class Initialized
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-24 15:03:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-24 15:03:35 --> Final output sent to browser
DEBUG - 2015-09-24 15:03:35 --> Total execution time: 0.2428
DEBUG - 2015-09-24 15:04:11 --> Config Class Initialized
DEBUG - 2015-09-24 15:04:11 --> Hooks Class Initialized
DEBUG - 2015-09-24 15:04:11 --> Utf8 Class Initialized
DEBUG - 2015-09-24 15:04:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 15:04:11 --> URI Class Initialized
DEBUG - 2015-09-24 15:04:11 --> Router Class Initialized
ERROR - 2015-09-24 15:04:11 --> 404 Page Not Found --> 
DEBUG - 2015-09-24 15:04:56 --> Config Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Hooks Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Utf8 Class Initialized
DEBUG - 2015-09-24 15:04:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 15:04:56 --> URI Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Router Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Output Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Security Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Input Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 15:04:56 --> Language Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Language Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Config Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Loader Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Helper loaded: url_helper
DEBUG - 2015-09-24 15:04:56 --> Helper loaded: form_helper
DEBUG - 2015-09-24 15:04:56 --> Database Driver Class Initialized
ERROR - 2015-09-24 15:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 15:04:56 --> Session Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Helper loaded: string_helper
DEBUG - 2015-09-24 15:04:56 --> Session routines successfully run
DEBUG - 2015-09-24 15:04:56 --> Form Validation Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Pagination Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Encrypt Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Email Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Controller Class Initialized
DEBUG - 2015-09-24 15:04:56 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 15:04:56 --> Model Class Initialized
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-24 15:04:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-24 15:04:56 --> Final output sent to browser
DEBUG - 2015-09-24 15:04:56 --> Total execution time: 0.2287
DEBUG - 2015-09-24 15:19:16 --> Config Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Hooks Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Utf8 Class Initialized
DEBUG - 2015-09-24 15:19:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 15:19:16 --> URI Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Router Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Output Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Security Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Input Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 15:19:16 --> Language Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Language Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Config Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Loader Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Helper loaded: url_helper
DEBUG - 2015-09-24 15:19:16 --> Helper loaded: form_helper
DEBUG - 2015-09-24 15:19:16 --> Database Driver Class Initialized
ERROR - 2015-09-24 15:19:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 15:19:16 --> Session Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Helper loaded: string_helper
DEBUG - 2015-09-24 15:19:16 --> Session routines successfully run
DEBUG - 2015-09-24 15:19:16 --> Form Validation Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Pagination Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Encrypt Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Email Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Controller Class Initialized
DEBUG - 2015-09-24 15:19:16 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 15:19:16 --> Model Class Initialized
DEBUG - 2015-09-24 15:19:16 --> DB Transaction Failure
ERROR - 2015-09-24 15:19:16 --> Query error: Table 'mfi.loans_plan' doesn't exist
DEBUG - 2015-09-24 15:19:16 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-24 15:23:53 --> Config Class Initialized
DEBUG - 2015-09-24 15:23:53 --> Hooks Class Initialized
DEBUG - 2015-09-24 15:23:53 --> Utf8 Class Initialized
DEBUG - 2015-09-24 15:23:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 15:23:53 --> URI Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Router Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Output Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Security Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Input Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 15:23:54 --> Language Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Language Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Config Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Loader Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Helper loaded: url_helper
DEBUG - 2015-09-24 15:23:54 --> Helper loaded: form_helper
DEBUG - 2015-09-24 15:23:54 --> Database Driver Class Initialized
ERROR - 2015-09-24 15:23:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 15:23:54 --> Session Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Helper loaded: string_helper
DEBUG - 2015-09-24 15:23:54 --> Session routines successfully run
DEBUG - 2015-09-24 15:23:54 --> Form Validation Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Pagination Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Encrypt Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Email Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Controller Class Initialized
DEBUG - 2015-09-24 15:23:54 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 15:23:54 --> Model Class Initialized
DEBUG - 2015-09-24 15:23:54 --> DB Transaction Failure
ERROR - 2015-09-24 15:23:54 --> Query error: Unknown column 'loans_plan.compounding_period_id' in 'where clause'
DEBUG - 2015-09-24 15:23:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-24 15:38:24 --> Config Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Hooks Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Utf8 Class Initialized
DEBUG - 2015-09-24 15:38:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-24 15:38:24 --> URI Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Router Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Output Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Security Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Input Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-24 15:38:24 --> Language Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Language Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Config Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Loader Class Initialized
DEBUG - 2015-09-24 15:38:24 --> Helper loaded: url_helper
DEBUG - 2015-09-24 15:38:24 --> Helper loaded: form_helper
DEBUG - 2015-09-24 15:38:24 --> Database Driver Class Initialized
ERROR - 2015-09-24 15:38:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-24 15:38:25 --> Session Class Initialized
DEBUG - 2015-09-24 15:38:25 --> Helper loaded: string_helper
DEBUG - 2015-09-24 15:38:25 --> Session routines successfully run
DEBUG - 2015-09-24 15:38:25 --> Form Validation Class Initialized
DEBUG - 2015-09-24 15:38:25 --> Pagination Class Initialized
DEBUG - 2015-09-24 15:38:25 --> Encrypt Class Initialized
DEBUG - 2015-09-24 15:38:25 --> Email Class Initialized
DEBUG - 2015-09-24 15:38:25 --> Controller Class Initialized
DEBUG - 2015-09-24 15:38:25 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-24 15:38:25 --> Model Class Initialized
DEBUG - 2015-09-24 15:38:25 --> DB Transaction Failure
ERROR - 2015-09-24 15:38:25 --> Query error: Unknown column 'loans_plan.compounding_period_id' in 'where clause'
DEBUG - 2015-09-24 15:38:25 --> Language file loaded: language/english/db_lang.php
