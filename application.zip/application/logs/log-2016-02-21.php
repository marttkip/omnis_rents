<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-21 14:33:43 --> Config Class Initialized
DEBUG - 2016-02-21 14:33:43 --> Hooks Class Initialized
DEBUG - 2016-02-21 14:33:43 --> Utf8 Class Initialized
DEBUG - 2016-02-21 14:33:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 14:33:44 --> URI Class Initialized
DEBUG - 2016-02-21 14:33:44 --> Router Class Initialized
DEBUG - 2016-02-21 14:33:44 --> No URI present. Default controller set.
DEBUG - 2016-02-21 14:33:45 --> Output Class Initialized
DEBUG - 2016-02-21 14:33:45 --> Security Class Initialized
DEBUG - 2016-02-21 14:33:45 --> Input Class Initialized
DEBUG - 2016-02-21 14:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-21 14:33:45 --> Language Class Initialized
DEBUG - 2016-02-21 14:33:45 --> Language Class Initialized
DEBUG - 2016-02-21 14:33:45 --> Config Class Initialized
DEBUG - 2016-02-21 14:33:46 --> Loader Class Initialized
DEBUG - 2016-02-21 14:33:46 --> Helper loaded: url_helper
DEBUG - 2016-02-21 14:33:46 --> Helper loaded: form_helper
DEBUG - 2016-02-21 14:33:47 --> Database Driver Class Initialized
DEBUG - 2016-02-21 14:33:50 --> Session Class Initialized
DEBUG - 2016-02-21 14:33:50 --> Helper loaded: string_helper
DEBUG - 2016-02-21 14:33:50 --> A session cookie was not found.
DEBUG - 2016-02-21 14:33:50 --> Session routines successfully run
DEBUG - 2016-02-21 14:33:50 --> Form Validation Class Initialized
DEBUG - 2016-02-21 14:33:50 --> Pagination Class Initialized
DEBUG - 2016-02-21 14:33:50 --> Encrypt Class Initialized
DEBUG - 2016-02-21 14:33:50 --> Email Class Initialized
DEBUG - 2016-02-21 14:33:50 --> Controller Class Initialized
DEBUG - 2016-02-21 14:33:50 --> Auth MX_Controller Initialized
DEBUG - 2016-02-21 14:33:50 --> Model Class Initialized
DEBUG - 2016-02-21 14:33:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-21 14:33:51 --> Model Class Initialized
DEBUG - 2016-02-21 14:33:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-21 14:33:51 --> Model Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Config Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Hooks Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Utf8 Class Initialized
DEBUG - 2016-02-21 14:33:51 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 14:33:51 --> URI Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Router Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Output Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Security Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Input Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-21 14:33:51 --> Language Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Language Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Config Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Loader Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Helper loaded: url_helper
DEBUG - 2016-02-21 14:33:51 --> Helper loaded: form_helper
DEBUG - 2016-02-21 14:33:51 --> Database Driver Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Session Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Helper loaded: string_helper
DEBUG - 2016-02-21 14:33:51 --> Session routines successfully run
DEBUG - 2016-02-21 14:33:51 --> Form Validation Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Pagination Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Encrypt Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Email Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Controller Class Initialized
DEBUG - 2016-02-21 14:33:51 --> Auth MX_Controller Initialized
DEBUG - 2016-02-21 14:33:51 --> Model Class Initialized
DEBUG - 2016-02-21 14:33:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-21 14:33:51 --> Model Class Initialized
DEBUG - 2016-02-21 14:33:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-21 14:33:51 --> Model Class Initialized
DEBUG - 2016-02-21 14:33:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-21 14:33:53 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-21 14:33:53 --> Final output sent to browser
DEBUG - 2016-02-21 14:33:53 --> Total execution time: 2.0449
DEBUG - 2016-02-21 14:33:55 --> Config Class Initialized
DEBUG - 2016-02-21 14:33:55 --> Hooks Class Initialized
DEBUG - 2016-02-21 14:33:55 --> Utf8 Class Initialized
DEBUG - 2016-02-21 14:33:55 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 14:33:55 --> URI Class Initialized
DEBUG - 2016-02-21 14:33:55 --> Router Class Initialized
ERROR - 2016-02-21 14:33:55 --> 404 Page Not Found --> 
DEBUG - 2016-02-21 14:33:55 --> Config Class Initialized
DEBUG - 2016-02-21 14:33:55 --> Hooks Class Initialized
DEBUG - 2016-02-21 14:33:55 --> Utf8 Class Initialized
DEBUG - 2016-02-21 14:33:55 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 14:33:56 --> URI Class Initialized
DEBUG - 2016-02-21 14:33:56 --> Router Class Initialized
ERROR - 2016-02-21 14:33:56 --> 404 Page Not Found --> 
DEBUG - 2016-02-21 14:33:56 --> Config Class Initialized
DEBUG - 2016-02-21 14:33:56 --> Hooks Class Initialized
DEBUG - 2016-02-21 14:33:56 --> Utf8 Class Initialized
DEBUG - 2016-02-21 14:33:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 14:33:56 --> URI Class Initialized
DEBUG - 2016-02-21 14:33:56 --> Router Class Initialized
ERROR - 2016-02-21 14:33:56 --> 404 Page Not Found --> 
DEBUG - 2016-02-21 14:33:56 --> Config Class Initialized
DEBUG - 2016-02-21 14:33:56 --> Hooks Class Initialized
DEBUG - 2016-02-21 14:33:56 --> Utf8 Class Initialized
DEBUG - 2016-02-21 14:33:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 14:33:56 --> URI Class Initialized
DEBUG - 2016-02-21 14:33:56 --> Router Class Initialized
ERROR - 2016-02-21 14:33:56 --> 404 Page Not Found --> 
