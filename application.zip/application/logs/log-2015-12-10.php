<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-10 12:41:29 --> Config Class Initialized
DEBUG - 2015-12-10 12:41:29 --> Hooks Class Initialized
DEBUG - 2015-12-10 12:41:29 --> Utf8 Class Initialized
DEBUG - 2015-12-10 12:41:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 12:41:29 --> URI Class Initialized
DEBUG - 2015-12-10 12:41:29 --> Router Class Initialized
DEBUG - 2015-12-10 12:41:29 --> No URI present. Default controller set.
DEBUG - 2015-12-10 12:41:29 --> Output Class Initialized
DEBUG - 2015-12-10 12:41:29 --> Security Class Initialized
DEBUG - 2015-12-10 12:41:29 --> Input Class Initialized
DEBUG - 2015-12-10 12:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 12:41:30 --> Language Class Initialized
DEBUG - 2015-12-10 12:41:30 --> Language Class Initialized
DEBUG - 2015-12-10 12:41:30 --> Config Class Initialized
DEBUG - 2015-12-10 12:41:30 --> Loader Class Initialized
DEBUG - 2015-12-10 12:41:30 --> Helper loaded: url_helper
DEBUG - 2015-12-10 12:41:30 --> Helper loaded: form_helper
DEBUG - 2015-12-10 12:41:30 --> Database Driver Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Session Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Helper loaded: string_helper
DEBUG - 2015-12-10 12:41:31 --> Session routines successfully run
DEBUG - 2015-12-10 12:41:31 --> Form Validation Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Pagination Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Encrypt Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Email Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Controller Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Auth MX_Controller Initialized
DEBUG - 2015-12-10 12:41:31 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 12:41:31 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 12:41:31 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Config Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Hooks Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Utf8 Class Initialized
DEBUG - 2015-12-10 12:41:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 12:41:31 --> URI Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Router Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Output Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Security Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Input Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 12:41:31 --> Language Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Language Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Config Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Loader Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Helper loaded: url_helper
DEBUG - 2015-12-10 12:41:31 --> Helper loaded: form_helper
DEBUG - 2015-12-10 12:41:31 --> Database Driver Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Session Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Helper loaded: string_helper
DEBUG - 2015-12-10 12:41:31 --> Session routines successfully run
DEBUG - 2015-12-10 12:41:31 --> Form Validation Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Pagination Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Encrypt Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Email Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Controller Class Initialized
DEBUG - 2015-12-10 12:41:31 --> Admin MX_Controller Initialized
DEBUG - 2015-12-10 12:41:31 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 12:41:31 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 12:41:31 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 12:41:31 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 12:41:32 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 12:41:32 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 12:41:32 --> Model Class Initialized
DEBUG - 2015-12-10 12:41:32 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-10 12:41:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 12:41:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 12:41:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 12:41:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 12:41:32 --> Final output sent to browser
DEBUG - 2015-12-10 12:41:32 --> Total execution time: 0.8433
DEBUG - 2015-12-10 12:41:58 --> Config Class Initialized
DEBUG - 2015-12-10 12:41:58 --> Hooks Class Initialized
DEBUG - 2015-12-10 12:41:58 --> Utf8 Class Initialized
DEBUG - 2015-12-10 12:41:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 12:41:58 --> URI Class Initialized
DEBUG - 2015-12-10 12:41:58 --> Router Class Initialized
ERROR - 2015-12-10 12:41:58 --> 404 Page Not Found --> 
DEBUG - 2015-12-10 12:42:03 --> Config Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Hooks Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Utf8 Class Initialized
DEBUG - 2015-12-10 12:42:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 12:42:03 --> URI Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Router Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Output Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Security Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Input Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 12:42:03 --> Language Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Language Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Config Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Loader Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Helper loaded: url_helper
DEBUG - 2015-12-10 12:42:03 --> Helper loaded: form_helper
DEBUG - 2015-12-10 12:42:03 --> Database Driver Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Session Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Helper loaded: string_helper
DEBUG - 2015-12-10 12:42:03 --> Session routines successfully run
DEBUG - 2015-12-10 12:42:03 --> Form Validation Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Pagination Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Encrypt Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Email Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Controller Class Initialized
DEBUG - 2015-12-10 12:42:03 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:00:29 --> Config Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:00:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:00:29 --> URI Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Router Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Output Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Security Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Input Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:00:29 --> Language Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Language Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Config Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Loader Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:00:29 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:00:29 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Session Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:00:29 --> Session routines successfully run
DEBUG - 2015-12-10 13:00:29 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Email Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Controller Class Initialized
DEBUG - 2015-12-10 13:00:29 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:01:04 --> Config Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:01:04 --> URI Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Router Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Output Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Security Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Input Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:01:04 --> Language Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Language Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Config Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Loader Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:01:04 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:01:04 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Session Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:01:04 --> Session routines successfully run
DEBUG - 2015-12-10 13:01:04 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Email Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Controller Class Initialized
DEBUG - 2015-12-10 13:01:04 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:01:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:01:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:01:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:01:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Config Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:01:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:01:17 --> URI Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Router Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Output Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Security Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Input Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:01:17 --> Language Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Language Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Config Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Loader Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:01:17 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:01:17 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Session Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:01:17 --> Session routines successfully run
DEBUG - 2015-12-10 13:01:17 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Email Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Controller Class Initialized
DEBUG - 2015-12-10 13:01:17 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:01:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:01:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:01:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:01:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:01:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:01:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:01:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:01:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:01:17 --> DB Transaction Failure
ERROR - 2015-12-10 13:01:17 --> Query error: Table 'rents.property_owners' doesn't exist
DEBUG - 2015-12-10 13:01:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:01:59 --> Config Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:01:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:01:59 --> URI Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Router Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Output Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Security Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Input Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:01:59 --> Language Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Language Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Config Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Loader Class Initialized
DEBUG - 2015-12-10 13:01:59 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:01:59 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:01:59 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:02:00 --> Session Class Initialized
DEBUG - 2015-12-10 13:02:00 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:02:00 --> Session routines successfully run
DEBUG - 2015-12-10 13:02:00 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:02:00 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:02:00 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:02:00 --> Email Class Initialized
DEBUG - 2015-12-10 13:02:00 --> Controller Class Initialized
DEBUG - 2015-12-10 13:02:00 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:02:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:02:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:02:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:02:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:02:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:02:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:02:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:02:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:00 --> DB Transaction Failure
ERROR - 2015-12-10 13:02:00 --> Query error: Unknown column 'first_name' in 'order clause'
DEBUG - 2015-12-10 13:02:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:02:35 --> Config Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:02:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:02:35 --> URI Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Router Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Output Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Security Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Input Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:02:35 --> Language Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Language Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Config Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Loader Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:02:35 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:02:35 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Session Class Initialized
DEBUG - 2015-12-10 13:02:35 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:02:35 --> Session routines successfully run
DEBUG - 2015-12-10 13:02:36 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:02:36 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:02:36 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:02:36 --> Email Class Initialized
DEBUG - 2015-12-10 13:02:36 --> Controller Class Initialized
DEBUG - 2015-12-10 13:02:36 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:02:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:02:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:02:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:02:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:02:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:02:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:02:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:02:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:36 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:02:52 --> Config Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:02:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:02:52 --> URI Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Router Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Output Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Security Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Input Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:02:52 --> Language Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Language Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Config Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Loader Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:02:52 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:02:52 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Session Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:02:52 --> Session routines successfully run
DEBUG - 2015-12-10 13:02:52 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Email Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Controller Class Initialized
DEBUG - 2015-12-10 13:02:52 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:02:52 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:02:52 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:02:52 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:02:52 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:02:52 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:02:52 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:02:52 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:02:52 --> Model Class Initialized
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:02:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:02:52 --> Final output sent to browser
DEBUG - 2015-12-10 13:02:52 --> Total execution time: 0.2172
DEBUG - 2015-12-10 13:11:55 --> Config Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:11:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:11:55 --> URI Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Router Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Output Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Security Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Input Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:11:55 --> Language Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Language Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Config Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Loader Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:11:55 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:11:55 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Session Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:11:55 --> Session routines successfully run
DEBUG - 2015-12-10 13:11:55 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Email Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Controller Class Initialized
DEBUG - 2015-12-10 13:11:55 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:11:55 --> Model Class Initialized
DEBUG - 2015-12-10 13:11:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:11:55 --> Model Class Initialized
DEBUG - 2015-12-10 13:11:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:11:55 --> Model Class Initialized
DEBUG - 2015-12-10 13:11:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:11:55 --> Model Class Initialized
DEBUG - 2015-12-10 13:11:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:11:55 --> Model Class Initialized
DEBUG - 2015-12-10 13:11:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:11:55 --> Model Class Initialized
DEBUG - 2015-12-10 13:11:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:11:55 --> Model Class Initialized
DEBUG - 2015-12-10 13:11:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:11:55 --> Model Class Initialized
ERROR - 2015-12-10 13:11:55 --> Severity: Notice  --> Undefined variable: query C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\all_property_owners.php 6
DEBUG - 2015-12-10 13:12:09 --> Config Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:12:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:12:09 --> URI Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Router Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Output Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Security Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Input Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:12:09 --> Language Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Language Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Config Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Loader Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:12:09 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:12:09 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Session Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:12:09 --> Session routines successfully run
DEBUG - 2015-12-10 13:12:09 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Email Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Controller Class Initialized
DEBUG - 2015-12-10 13:12:09 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:12:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:12:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:12:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:12:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:12:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:12:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:12:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:12:09 --> Model Class Initialized
ERROR - 2015-12-10 13:12:09 --> Severity: Notice  --> Undefined variable: query C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\all_property_owners.php 6
DEBUG - 2015-12-10 13:12:41 --> Config Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:12:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:12:41 --> URI Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Router Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Output Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Security Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Input Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:12:41 --> Language Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Language Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Config Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Loader Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:12:41 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:12:41 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Session Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:12:41 --> Session routines successfully run
DEBUG - 2015-12-10 13:12:41 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Email Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Controller Class Initialized
DEBUG - 2015-12-10 13:12:41 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:12:41 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:12:41 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:12:41 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:12:41 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:12:41 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:12:41 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:12:41 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:12:41 --> Model Class Initialized
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:12:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:12:41 --> Final output sent to browser
DEBUG - 2015-12-10 13:12:41 --> Total execution time: 0.2186
DEBUG - 2015-12-10 13:13:09 --> Config Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:13:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:13:09 --> URI Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Router Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Output Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Security Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Input Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:13:09 --> Language Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Language Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Config Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Loader Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:13:09 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:13:09 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Session Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:13:09 --> Session routines successfully run
DEBUG - 2015-12-10 13:13:09 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Email Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Controller Class Initialized
DEBUG - 2015-12-10 13:13:09 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:13:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:13:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:13:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:13:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:13:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:13:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:13:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:13:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:13:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:13:09 --> Final output sent to browser
DEBUG - 2015-12-10 13:13:09 --> Total execution time: 0.2316
DEBUG - 2015-12-10 13:13:30 --> Config Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:13:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:13:30 --> URI Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Router Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Output Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Security Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Input Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:13:30 --> Language Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Language Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Config Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Loader Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:13:30 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:13:30 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Session Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:13:30 --> Session routines successfully run
DEBUG - 2015-12-10 13:13:30 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Email Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Controller Class Initialized
DEBUG - 2015-12-10 13:13:30 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:13:30 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:13:30 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:13:30 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:13:30 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:13:30 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:13:30 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:13:30 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:13:30 --> Model Class Initialized
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:13:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:13:30 --> Final output sent to browser
DEBUG - 2015-12-10 13:13:30 --> Total execution time: 0.2524
DEBUG - 2015-12-10 13:14:43 --> Config Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:14:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:14:43 --> URI Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Router Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Output Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Security Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Input Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:14:43 --> Language Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Language Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Config Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Loader Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:14:43 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:14:43 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Session Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:14:43 --> Session routines successfully run
DEBUG - 2015-12-10 13:14:43 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Email Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Controller Class Initialized
DEBUG - 2015-12-10 13:14:43 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:14:43 --> Model Class Initialized
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:14:43 --> Model Class Initialized
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:14:43 --> Model Class Initialized
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:14:43 --> Model Class Initialized
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:14:43 --> Model Class Initialized
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:14:43 --> Model Class Initialized
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:14:43 --> Model Class Initialized
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:14:43 --> Model Class Initialized
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:14:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:14:43 --> Final output sent to browser
DEBUG - 2015-12-10 13:14:43 --> Total execution time: 0.2132
DEBUG - 2015-12-10 13:15:14 --> Config Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:15:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:15:14 --> URI Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Router Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Output Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Security Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Input Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:15:14 --> Language Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Language Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Config Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Loader Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:15:14 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:15:14 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Session Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:15:14 --> Session routines successfully run
DEBUG - 2015-12-10 13:15:14 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Email Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Controller Class Initialized
DEBUG - 2015-12-10 13:15:14 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:15:14 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:15:14 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:15:14 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:15:14 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:15:14 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:15:14 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:15:14 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:15:14 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:15:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:15:14 --> Final output sent to browser
DEBUG - 2015-12-10 13:15:14 --> Total execution time: 0.2516
DEBUG - 2015-12-10 13:15:38 --> Config Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:15:38 --> URI Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Router Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Output Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Security Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Input Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:15:38 --> Language Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Language Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Config Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Loader Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:15:38 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:15:38 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Session Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:15:38 --> Session routines successfully run
DEBUG - 2015-12-10 13:15:38 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Email Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Controller Class Initialized
DEBUG - 2015-12-10 13:15:38 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:15:38 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:15:38 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:15:38 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:15:38 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:15:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:15:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:15:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:15:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:15:39 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:15:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:15:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:15:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:15:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:15:39 --> Final output sent to browser
DEBUG - 2015-12-10 13:15:39 --> Total execution time: 0.2210
DEBUG - 2015-12-10 13:16:23 --> Config Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:16:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:16:23 --> URI Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Router Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Output Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Security Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Input Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:16:23 --> Language Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Language Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Config Class Initialized
DEBUG - 2015-12-10 13:16:23 --> Loader Class Initialized
DEBUG - 2015-12-10 13:16:24 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:16:24 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:16:24 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:16:24 --> Session Class Initialized
DEBUG - 2015-12-10 13:16:24 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:16:24 --> Session routines successfully run
DEBUG - 2015-12-10 13:16:24 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:16:24 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:16:24 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:16:24 --> Email Class Initialized
DEBUG - 2015-12-10 13:16:24 --> Controller Class Initialized
DEBUG - 2015-12-10 13:16:24 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:16:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:16:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:16:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:16:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:16:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:16:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:16:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:16:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:16:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:16:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:16:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:16:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:16:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:16:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:16:24 --> Model Class Initialized
ERROR - 2015-12-10 13:16:24 --> 404 Page Not Found --> property_owners/add_branch
DEBUG - 2015-12-10 13:19:53 --> Config Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:19:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:19:53 --> URI Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Router Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Output Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Security Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Input Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:19:53 --> Language Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Language Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Config Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Loader Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:19:53 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:19:53 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Session Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:19:53 --> Session routines successfully run
DEBUG - 2015-12-10 13:19:53 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Email Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Controller Class Initialized
DEBUG - 2015-12-10 13:19:53 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:19:53 --> Model Class Initialized
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:19:53 --> Model Class Initialized
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:19:53 --> Model Class Initialized
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:19:53 --> Model Class Initialized
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:19:53 --> Model Class Initialized
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:19:53 --> Model Class Initialized
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:19:53 --> Model Class Initialized
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:19:53 --> Model Class Initialized
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/real_estate_administration/views/property_owners/add_property_owner.php
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:19:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:19:53 --> Final output sent to browser
DEBUG - 2015-12-10 13:19:53 --> Total execution time: 0.2115
DEBUG - 2015-12-10 13:23:49 --> Config Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:23:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:23:49 --> URI Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Router Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Output Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Security Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Input Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:23:49 --> Language Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Language Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Config Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Loader Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:23:49 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:23:49 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Session Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:23:49 --> Session routines successfully run
DEBUG - 2015-12-10 13:23:49 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Email Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Controller Class Initialized
DEBUG - 2015-12-10 13:23:49 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:23:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:23:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:23:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:23:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:23:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:23:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:23:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:23:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:23:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:23:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:23:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:23:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:23:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:23:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:23:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:23:50 --> File loaded: application/modules/real_estate_administration/views/property_owners/add_property_owner.php
DEBUG - 2015-12-10 13:23:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:23:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:23:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:23:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:23:50 --> Final output sent to browser
DEBUG - 2015-12-10 13:23:50 --> Total execution time: 0.2152
DEBUG - 2015-12-10 13:24:25 --> Config Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:24:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:24:25 --> URI Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Router Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Output Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Security Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Input Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:24:25 --> Language Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Language Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Config Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Loader Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:24:25 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:24:25 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Session Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:24:25 --> Session routines successfully run
DEBUG - 2015-12-10 13:24:25 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Email Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Controller Class Initialized
DEBUG - 2015-12-10 13:24:25 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:24:25 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:24:25 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:24:25 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:24:25 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:24:25 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:24:26 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:24:26 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:24:26 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:26 --> File loaded: application/modules/real_estate_administration/views/property_owners/add_property_owner.php
DEBUG - 2015-12-10 13:24:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:24:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:24:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:24:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:24:26 --> Final output sent to browser
DEBUG - 2015-12-10 13:24:26 --> Total execution time: 0.2163
DEBUG - 2015-12-10 13:24:39 --> Config Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:24:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:24:39 --> URI Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Router Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Output Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Security Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Input Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:24:39 --> Language Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Language Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Config Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Loader Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:24:39 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:24:39 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Session Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:24:39 --> Session routines successfully run
DEBUG - 2015-12-10 13:24:39 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Email Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Controller Class Initialized
DEBUG - 2015-12-10 13:24:39 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:24:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:24:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:24:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:24:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:24:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:24:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:24:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:24:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/real_estate_administration/views/property_owners/add_property_owner.php
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:24:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:24:39 --> Final output sent to browser
DEBUG - 2015-12-10 13:24:39 --> Total execution time: 0.2144
DEBUG - 2015-12-10 13:25:13 --> Config Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:25:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:25:13 --> URI Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Router Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Output Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Security Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Input Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:25:13 --> Language Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Language Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Config Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Loader Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:25:13 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:25:13 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Session Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:25:13 --> Session routines successfully run
DEBUG - 2015-12-10 13:25:13 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Email Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Controller Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:25:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:25:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:25:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:25:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:25:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:25:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:25:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:25:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-10 13:25:13 --> XSS Filtering completed
DEBUG - 2015-12-10 13:25:13 --> XSS Filtering completed
DEBUG - 2015-12-10 13:25:13 --> XSS Filtering completed
DEBUG - 2015-12-10 13:25:13 --> XSS Filtering completed
DEBUG - 2015-12-10 13:25:13 --> DB Transaction Failure
ERROR - 2015-12-10 13:25:13 --> Query error: Unknown column 'branch_id' in 'field list'
DEBUG - 2015-12-10 13:25:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:25:45 --> Config Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:25:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:25:45 --> URI Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Router Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Output Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Security Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Input Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:25:45 --> Language Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Language Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Config Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Loader Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:25:45 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:25:45 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Session Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:25:45 --> Session routines successfully run
DEBUG - 2015-12-10 13:25:45 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Email Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Controller Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:25:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:25:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:25:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:25:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:25:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:25:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:25:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:45 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:25:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-10 13:25:45 --> XSS Filtering completed
DEBUG - 2015-12-10 13:25:45 --> XSS Filtering completed
DEBUG - 2015-12-10 13:25:45 --> XSS Filtering completed
DEBUG - 2015-12-10 13:25:45 --> XSS Filtering completed
DEBUG - 2015-12-10 13:25:46 --> Config Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:25:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:25:46 --> URI Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Router Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Output Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Security Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Input Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:25:46 --> Language Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Language Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Config Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Loader Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:25:46 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:25:46 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Session Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:25:46 --> Session routines successfully run
DEBUG - 2015-12-10 13:25:46 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Email Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Controller Class Initialized
DEBUG - 2015-12-10 13:25:46 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:25:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:25:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:25:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:25:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:25:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:25:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:25:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:25:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:25:46 --> Model Class Initialized
ERROR - 2015-12-10 13:25:46 --> Severity: Notice  --> Undefined property: CI::$users_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2015-12-10 13:26:24 --> Config Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:26:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:26:24 --> URI Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Router Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Output Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Security Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Input Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:26:24 --> Language Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Language Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Config Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Loader Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:26:24 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:26:24 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Session Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:26:24 --> Session routines successfully run
DEBUG - 2015-12-10 13:26:24 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Email Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Controller Class Initialized
DEBUG - 2015-12-10 13:26:24 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:26:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:26:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:26:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:26:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:26:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:26:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:26:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:26:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:26:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:26:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:26:24 --> Final output sent to browser
DEBUG - 2015-12-10 13:26:25 --> Total execution time: 0.2496
DEBUG - 2015-12-10 13:27:23 --> Config Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:27:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:27:23 --> URI Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Router Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Output Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Security Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Input Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:27:23 --> Language Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Language Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Config Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Loader Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:27:23 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:27:23 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Session Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:27:23 --> Session routines successfully run
DEBUG - 2015-12-10 13:27:23 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Email Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Controller Class Initialized
DEBUG - 2015-12-10 13:27:23 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:27:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:27:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:27:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:27:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:27:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:27:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:27:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:27:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:27:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:27:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:27:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:27:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:27:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:27:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:27:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:27:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:27:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:27:24 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:27:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:27:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:27:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:27:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:27:24 --> Final output sent to browser
DEBUG - 2015-12-10 13:27:24 --> Total execution time: 0.2233
DEBUG - 2015-12-10 13:28:01 --> Config Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:28:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:28:01 --> URI Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Router Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Output Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Security Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Input Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:28:01 --> Language Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Language Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Config Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Loader Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:28:01 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:28:01 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Session Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:28:01 --> Session routines successfully run
DEBUG - 2015-12-10 13:28:01 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Email Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Controller Class Initialized
DEBUG - 2015-12-10 13:28:01 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:28:01 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:28:01 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:28:01 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:28:01 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:28:01 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:28:01 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:28:01 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:28:01 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:28:01 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:28:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:28:01 --> Final output sent to browser
DEBUG - 2015-12-10 13:28:01 --> Total execution time: 0.2409
DEBUG - 2015-12-10 13:28:32 --> Config Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:28:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:28:32 --> URI Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Router Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Output Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Security Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Input Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:28:32 --> Language Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Language Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Config Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Loader Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:28:32 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:28:32 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Session Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:28:32 --> Session routines successfully run
DEBUG - 2015-12-10 13:28:32 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Email Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Controller Class Initialized
DEBUG - 2015-12-10 13:28:32 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:28:32 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:28:32 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:28:32 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:28:32 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:28:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:28:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:28:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:28:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:28:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:28:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:28:33 --> Final output sent to browser
DEBUG - 2015-12-10 13:28:33 --> Total execution time: 0.2739
DEBUG - 2015-12-10 13:28:50 --> Config Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:28:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:28:50 --> URI Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Router Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Output Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Security Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Input Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:28:50 --> Language Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Language Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Config Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Loader Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:28:50 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:28:50 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Session Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:28:50 --> Session routines successfully run
DEBUG - 2015-12-10 13:28:50 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Email Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Controller Class Initialized
DEBUG - 2015-12-10 13:28:50 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:28:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:28:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:28:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:28:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:28:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:28:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:28:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:28:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:28:50 --> Model Class Initialized
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:28:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:28:50 --> Final output sent to browser
DEBUG - 2015-12-10 13:28:50 --> Total execution time: 0.2427
DEBUG - 2015-12-10 13:29:23 --> Config Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:29:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:29:23 --> URI Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Router Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Output Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Security Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Input Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:29:23 --> Language Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Language Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Config Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Loader Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:29:23 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:29:23 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Session Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:29:23 --> Session routines successfully run
DEBUG - 2015-12-10 13:29:23 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Email Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Controller Class Initialized
DEBUG - 2015-12-10 13:29:23 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:29:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:29:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:29:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:29:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:29:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:29:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:29:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:29:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:29:23 --> Model Class Initialized
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:29:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:29:23 --> Final output sent to browser
DEBUG - 2015-12-10 13:29:23 --> Total execution time: 0.2266
DEBUG - 2015-12-10 13:31:04 --> Config Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:31:04 --> URI Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Router Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Output Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Security Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Input Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:31:04 --> Language Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Language Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Config Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Loader Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:31:04 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:31:04 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Session Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:31:04 --> Session routines successfully run
DEBUG - 2015-12-10 13:31:04 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Email Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Controller Class Initialized
DEBUG - 2015-12-10 13:31:04 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:31:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:31:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:31:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:31:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:31:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:31:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:31:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:31:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:31:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:04 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:31:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:31:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:31:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:31:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:31:05 --> Final output sent to browser
DEBUG - 2015-12-10 13:31:05 --> Total execution time: 0.5236
DEBUG - 2015-12-10 13:31:15 --> Config Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:31:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:31:15 --> URI Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Router Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Output Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Security Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Input Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:31:15 --> Language Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Language Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Config Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Loader Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:31:15 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:31:15 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Session Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:31:15 --> Session routines successfully run
DEBUG - 2015-12-10 13:31:15 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Email Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Controller Class Initialized
DEBUG - 2015-12-10 13:31:15 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:31:15 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:31:15 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:31:15 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:31:15 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:31:15 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:31:15 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:31:15 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:31:15 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:31:15 --> Model Class Initialized
DEBUG - 2015-12-10 13:31:15 --> DB Transaction Failure
ERROR - 2015-12-10 13:31:15 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:31:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:33:04 --> Config Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:33:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:33:04 --> URI Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Router Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Output Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Security Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Input Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:33:04 --> Language Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Language Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Config Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Loader Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:33:04 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:33:04 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Session Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:33:04 --> Session routines successfully run
DEBUG - 2015-12-10 13:33:04 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Email Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Controller Class Initialized
DEBUG - 2015-12-10 13:33:04 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:33:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:33:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:33:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:33:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:33:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:33:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:33:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:33:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:33:04 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:04 --> DB Transaction Failure
ERROR - 2015-12-10 13:33:04 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:33:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:33:05 --> Config Class Initialized
DEBUG - 2015-12-10 13:33:05 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:33:05 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:33:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:33:05 --> URI Class Initialized
DEBUG - 2015-12-10 13:33:05 --> Router Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Output Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Security Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Input Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:33:06 --> Language Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Language Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Config Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Loader Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:33:06 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:33:06 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Session Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:33:06 --> Session routines successfully run
DEBUG - 2015-12-10 13:33:06 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Email Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Controller Class Initialized
DEBUG - 2015-12-10 13:33:06 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:33:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:33:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:33:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:33:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:33:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:33:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:33:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:33:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:33:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:06 --> DB Transaction Failure
ERROR - 2015-12-10 13:33:06 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:33:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:33:56 --> Config Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:33:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:33:56 --> URI Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Router Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Output Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Security Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Input Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:33:56 --> Language Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Language Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Config Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Loader Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:33:56 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:33:56 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Session Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:33:56 --> Session routines successfully run
DEBUG - 2015-12-10 13:33:56 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Email Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Controller Class Initialized
DEBUG - 2015-12-10 13:33:56 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:33:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:33:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:33:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:33:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:33:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:33:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:33:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:33:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:33:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:33:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Config Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:34:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:34:17 --> URI Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Router Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Output Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Security Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Input Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:34:17 --> Language Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Language Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Config Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Loader Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:34:17 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:34:17 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Session Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:34:17 --> Session routines successfully run
DEBUG - 2015-12-10 13:34:17 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Email Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Controller Class Initialized
DEBUG - 2015-12-10 13:34:17 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:34:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:34:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:34:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:34:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:34:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:34:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:34:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:34:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:34:17 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:17 --> DB Transaction Failure
ERROR - 2015-12-10 13:34:17 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:34:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:34:22 --> Config Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:34:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:34:22 --> URI Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Router Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Output Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Security Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Input Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:34:22 --> Language Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Language Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Config Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Loader Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:34:22 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:34:22 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Session Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:34:22 --> Session routines successfully run
DEBUG - 2015-12-10 13:34:22 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Email Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Controller Class Initialized
DEBUG - 2015-12-10 13:34:22 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:34:22 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:34:22 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:34:22 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:34:22 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:34:22 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:34:22 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:34:22 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:34:22 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:34:22 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:34:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:34:22 --> Final output sent to browser
DEBUG - 2015-12-10 13:34:22 --> Total execution time: 0.2272
DEBUG - 2015-12-10 13:34:24 --> Config Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:34:24 --> URI Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Router Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Output Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Security Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Input Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:34:24 --> Language Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Language Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Config Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Loader Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:34:24 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:34:24 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Session Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:34:24 --> Session routines successfully run
DEBUG - 2015-12-10 13:34:24 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Email Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Controller Class Initialized
DEBUG - 2015-12-10 13:34:24 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:34:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:34:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:34:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:34:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:34:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:34:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:34:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:34:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:34:24 --> Model Class Initialized
DEBUG - 2015-12-10 13:34:24 --> DB Transaction Failure
ERROR - 2015-12-10 13:34:24 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:34:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:36:07 --> Config Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:36:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:36:07 --> URI Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Router Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Output Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Security Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Input Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:36:07 --> Language Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Language Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Config Class Initialized
DEBUG - 2015-12-10 13:36:07 --> Loader Class Initialized
DEBUG - 2015-12-10 13:36:08 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:36:08 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:36:08 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:36:08 --> Session Class Initialized
DEBUG - 2015-12-10 13:36:08 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:36:08 --> Session routines successfully run
DEBUG - 2015-12-10 13:36:08 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:36:08 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:36:08 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:36:08 --> Email Class Initialized
DEBUG - 2015-12-10 13:36:08 --> Controller Class Initialized
DEBUG - 2015-12-10 13:36:08 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:36:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:36:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:36:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:36:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:36:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:36:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:36:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:36:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:36:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:08 --> DB Transaction Failure
ERROR - 2015-12-10 13:36:08 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:36:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:36:09 --> Config Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:36:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:36:09 --> URI Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Router Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Output Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Security Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Input Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:36:09 --> Language Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Language Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Config Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Loader Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:36:09 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:36:09 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Session Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:36:09 --> Session routines successfully run
DEBUG - 2015-12-10 13:36:09 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Email Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Controller Class Initialized
DEBUG - 2015-12-10 13:36:09 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:36:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:36:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:36:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:36:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:36:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:36:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:36:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:36:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:36:09 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:09 --> DB Transaction Failure
ERROR - 2015-12-10 13:36:09 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:36:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:36:10 --> Config Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:36:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:36:10 --> URI Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Router Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Output Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Security Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Input Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:36:10 --> Language Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Language Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Config Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Loader Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:36:10 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:36:10 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Session Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:36:10 --> Session routines successfully run
DEBUG - 2015-12-10 13:36:10 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Email Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Controller Class Initialized
DEBUG - 2015-12-10 13:36:10 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:36:10 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:36:10 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:36:10 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:36:10 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:36:10 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:36:10 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:36:10 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:36:10 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:36:10 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:10 --> DB Transaction Failure
ERROR - 2015-12-10 13:36:10 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:36:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:36:11 --> Config Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:36:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:36:11 --> URI Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Router Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Output Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Security Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Input Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:36:11 --> Language Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Language Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Config Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Loader Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:36:11 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:36:11 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Session Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:36:11 --> Session routines successfully run
DEBUG - 2015-12-10 13:36:11 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Email Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Controller Class Initialized
DEBUG - 2015-12-10 13:36:11 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:36:11 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:36:11 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:36:11 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:36:11 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:36:11 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:36:11 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:36:11 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:36:11 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:36:11 --> Model Class Initialized
DEBUG - 2015-12-10 13:36:11 --> DB Transaction Failure
ERROR - 2015-12-10 13:36:11 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:36:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:38:44 --> Config Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:38:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:38:44 --> URI Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Router Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Output Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Security Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Input Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:38:44 --> Language Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Language Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Config Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Loader Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:38:44 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:38:44 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Session Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:38:44 --> Session routines successfully run
DEBUG - 2015-12-10 13:38:44 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Email Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Controller Class Initialized
DEBUG - 2015-12-10 13:38:44 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:38:44 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:38:44 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:38:44 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:38:44 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:38:44 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:38:44 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:38:44 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:38:44 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:38:44 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:44 --> DB Transaction Failure
ERROR - 2015-12-10 13:38:44 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:38:44 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:38:45 --> Config Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:38:45 --> URI Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Router Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Output Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Security Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Input Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:38:45 --> Language Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Language Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Config Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Loader Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:38:45 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:38:45 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Session Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:38:45 --> Session routines successfully run
DEBUG - 2015-12-10 13:38:45 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Email Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Controller Class Initialized
DEBUG - 2015-12-10 13:38:45 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:38:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:38:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:38:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:38:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:38:45 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> DB Transaction Failure
ERROR - 2015-12-10 13:38:46 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:38:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:38:46 --> Config Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:38:46 --> URI Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Router Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Output Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Security Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Input Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:38:46 --> Language Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Language Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Config Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Loader Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:38:46 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:38:46 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Session Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:38:46 --> Session routines successfully run
DEBUG - 2015-12-10 13:38:46 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Email Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Controller Class Initialized
DEBUG - 2015-12-10 13:38:46 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:38:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:46 --> DB Transaction Failure
ERROR - 2015-12-10 13:38:47 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:38:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:38:49 --> Config Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:38:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:38:49 --> URI Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Router Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Output Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Security Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Input Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:38:49 --> Language Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Language Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Config Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Loader Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:38:49 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:38:49 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Session Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:38:49 --> Session routines successfully run
DEBUG - 2015-12-10 13:38:49 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Email Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Controller Class Initialized
DEBUG - 2015-12-10 13:38:49 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:38:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:38:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:38:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:38:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:38:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:38:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:38:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:38:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:38:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:38:49 --> DB Transaction Failure
ERROR - 2015-12-10 13:38:49 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:38:49 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:39:46 --> Config Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:39:46 --> URI Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Router Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Output Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Security Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Input Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:39:46 --> Language Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Language Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Config Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Loader Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:39:46 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:39:46 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Session Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:39:46 --> Session routines successfully run
DEBUG - 2015-12-10 13:39:46 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Email Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Controller Class Initialized
DEBUG - 2015-12-10 13:39:46 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:39:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:39:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:39:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:39:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:39:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:39:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:39:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:39:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:39:46 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:46 --> DB Transaction Failure
ERROR - 2015-12-10 13:39:46 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:39:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:39:47 --> Config Class Initialized
DEBUG - 2015-12-10 13:39:47 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:39:47 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:39:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:39:47 --> URI Class Initialized
DEBUG - 2015-12-10 13:39:47 --> Router Class Initialized
DEBUG - 2015-12-10 13:39:47 --> Output Class Initialized
DEBUG - 2015-12-10 13:39:47 --> Security Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Input Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:39:48 --> Language Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Language Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Config Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Loader Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:39:48 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:39:48 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Session Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:39:48 --> Session routines successfully run
DEBUG - 2015-12-10 13:39:48 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Email Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Controller Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:39:48 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:39:48 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:39:48 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:39:48 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:39:48 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:39:48 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:39:48 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:39:48 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:39:48 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:48 --> DB Transaction Failure
ERROR - 2015-12-10 13:39:48 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:39:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:39:48 --> Config Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:39:48 --> URI Class Initialized
DEBUG - 2015-12-10 13:39:48 --> Router Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Output Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Security Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Input Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:39:49 --> Language Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Language Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Config Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Loader Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:39:49 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:39:49 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Session Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:39:49 --> Session routines successfully run
DEBUG - 2015-12-10 13:39:49 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Email Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Controller Class Initialized
DEBUG - 2015-12-10 13:39:49 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:39:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:39:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:39:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:39:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:39:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:39:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:39:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:39:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:39:49 --> Model Class Initialized
DEBUG - 2015-12-10 13:39:49 --> DB Transaction Failure
ERROR - 2015-12-10 13:39:49 --> Query error: Unknown column 'edit-property-owner' in 'order clause'
DEBUG - 2015-12-10 13:39:49 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:40:00 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:40:00 --> URI Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Router Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Output Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Security Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Input Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:40:00 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Loader Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:40:00 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:40:00 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Session Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:40:00 --> Session routines successfully run
DEBUG - 2015-12-10 13:40:00 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Email Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Controller Class Initialized
DEBUG - 2015-12-10 13:40:00 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:40:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:40:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:40:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:40:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:40:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:40:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:40:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:00 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:40:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:40:00 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:00 --> DB Transaction Failure
ERROR - 2015-12-10 13:40:00 --> Query error: Unknown column 'edit-property-owner-details' in 'order clause'
DEBUG - 2015-12-10 13:40:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:40:06 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:40:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:40:06 --> URI Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Router Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Output Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Security Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Input Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:40:06 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Loader Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:40:06 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:40:06 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Session Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:40:06 --> Session routines successfully run
DEBUG - 2015-12-10 13:40:06 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Email Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Controller Class Initialized
DEBUG - 2015-12-10 13:40:06 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:40:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:40:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:40:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:40:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:40:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:40:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:40:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:40:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:40:06 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:06 --> DB Transaction Failure
ERROR - 2015-12-10 13:40:06 --> Query error: Unknown column 'edit-property-owner-details' in 'order clause'
DEBUG - 2015-12-10 13:40:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:40:35 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:40:35 --> URI Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Router Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Output Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Security Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Input Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:40:35 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Loader Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:40:35 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:40:35 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Session Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:40:35 --> Session routines successfully run
DEBUG - 2015-12-10 13:40:35 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Email Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Controller Class Initialized
DEBUG - 2015-12-10 13:40:35 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:40:35 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:40:35 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:40:35 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:40:35 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:40:35 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:40:35 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:40:35 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:40:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:40:36 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:36 --> DB Transaction Failure
ERROR - 2015-12-10 13:40:36 --> Query error: Unknown column 'edit-property-owner-details' in 'order clause'
DEBUG - 2015-12-10 13:40:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:40:37 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:40:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:40:37 --> URI Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Router Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Output Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Security Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Input Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:40:37 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Loader Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:40:37 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:40:37 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Session Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:40:37 --> Session routines successfully run
DEBUG - 2015-12-10 13:40:37 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Email Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Controller Class Initialized
DEBUG - 2015-12-10 13:40:37 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:40:37 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:40:37 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:40:37 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:40:37 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:40:37 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:40:37 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:40:37 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:40:37 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:40:37 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:37 --> DB Transaction Failure
ERROR - 2015-12-10 13:40:37 --> Query error: Unknown column 'edit-property-owner-details' in 'order clause'
DEBUG - 2015-12-10 13:40:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:40:56 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:40:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:40:56 --> URI Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Router Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Output Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Security Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Input Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:40:56 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Loader Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:40:56 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:40:56 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Session Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:40:56 --> Session routines successfully run
DEBUG - 2015-12-10 13:40:56 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Email Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Controller Class Initialized
DEBUG - 2015-12-10 13:40:56 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:40:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:40:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:40:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:40:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:40:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:40:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:40:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:40:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:40:56 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:56 --> DB Transaction Failure
ERROR - 2015-12-10 13:40:56 --> Query error: Unknown column 'edit-property-owner-details' in 'order clause'
DEBUG - 2015-12-10 13:40:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:40:57 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:40:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:40:57 --> URI Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Router Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Output Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Security Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Input Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:40:57 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Language Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Config Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Loader Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:40:57 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:40:57 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Session Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:40:57 --> Session routines successfully run
DEBUG - 2015-12-10 13:40:57 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Email Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Controller Class Initialized
DEBUG - 2015-12-10 13:40:57 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:40:57 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:40:57 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:40:57 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:40:57 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:40:57 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:40:57 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:40:57 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:57 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:40:57 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:40:57 --> Model Class Initialized
DEBUG - 2015-12-10 13:40:57 --> DB Transaction Failure
ERROR - 2015-12-10 13:40:57 --> Query error: Unknown column 'edit-property-owner-details' in 'order clause'
DEBUG - 2015-12-10 13:40:57 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:41:07 --> Config Class Initialized
DEBUG - 2015-12-10 13:41:07 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:41:07 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:41:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:41:07 --> URI Class Initialized
DEBUG - 2015-12-10 13:41:07 --> Router Class Initialized
ERROR - 2015-12-10 13:41:07 --> 404 Page Not Found --> 
DEBUG - 2015-12-10 13:41:20 --> Config Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:41:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:41:20 --> URI Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Router Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Output Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Security Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Input Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:41:20 --> Language Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Language Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Config Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Loader Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:41:20 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:41:20 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Session Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:41:20 --> Session routines successfully run
DEBUG - 2015-12-10 13:41:20 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Email Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Controller Class Initialized
DEBUG - 2015-12-10 13:41:20 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:41:20 --> Model Class Initialized
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:41:20 --> Model Class Initialized
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:41:20 --> Model Class Initialized
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:41:20 --> Model Class Initialized
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:41:20 --> Model Class Initialized
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:41:20 --> Model Class Initialized
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:41:20 --> Model Class Initialized
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:41:20 --> Model Class Initialized
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:41:20 --> Model Class Initialized
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/real_estate_administration/views/property_owners/edit_property_owner.php
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:41:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:41:20 --> Final output sent to browser
DEBUG - 2015-12-10 13:41:20 --> Total execution time: 0.2921
DEBUG - 2015-12-10 13:46:39 --> Config Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:46:39 --> URI Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Router Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Output Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Security Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Input Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:46:39 --> Language Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Language Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Config Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Loader Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:46:39 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:46:39 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Session Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:46:39 --> Session routines successfully run
DEBUG - 2015-12-10 13:46:39 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Email Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Controller Class Initialized
DEBUG - 2015-12-10 13:46:39 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:46:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:46:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:46:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:46:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:46:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:46:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:46:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:46:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:46:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:46:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:46:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:46:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:46:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:46:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:46:39 --> Model Class Initialized
DEBUG - 2015-12-10 13:46:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:46:39 --> Model Class Initialized
ERROR - 2015-12-10 13:46:40 --> Severity: Notice  --> Undefined variable: personnel C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\edit_property_owner.php 3
DEBUG - 2015-12-10 13:47:13 --> Config Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:47:13 --> URI Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Router Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Output Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Security Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Input Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:47:13 --> Language Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Language Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Config Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Loader Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:47:13 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:47:13 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Session Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:47:13 --> Session routines successfully run
DEBUG - 2015-12-10 13:47:13 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Email Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Controller Class Initialized
DEBUG - 2015-12-10 13:47:13 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:47:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:47:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:47:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:47:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:47:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:47:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:47:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:47:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:47:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Config Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:47:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:47:33 --> URI Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Router Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Output Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Security Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Input Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:47:33 --> Language Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Language Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Config Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Loader Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:47:33 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:47:33 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Session Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:47:33 --> Session routines successfully run
DEBUG - 2015-12-10 13:47:33 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Email Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Controller Class Initialized
DEBUG - 2015-12-10 13:47:33 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:47:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:47:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:47:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:47:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:47:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:47:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:47:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:47:33 --> Model Class Initialized
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:47:33 --> Model Class Initialized
ERROR - 2015-12-10 13:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\edit_property_owner.php 4
ERROR - 2015-12-10 13:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\edit_property_owner.php 5
ERROR - 2015-12-10 13:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\edit_property_owner.php 6
ERROR - 2015-12-10 13:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\edit_property_owner.php 7
ERROR - 2015-12-10 13:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\edit_property_owner.php 8
ERROR - 2015-12-10 13:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\edit_property_owner.php 9
ERROR - 2015-12-10 13:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\edit_property_owner.php 10
ERROR - 2015-12-10 13:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property_owners\edit_property_owner.php 11
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/real_estate_administration/views/property_owners/edit_property_owner.php
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:47:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:47:33 --> Final output sent to browser
DEBUG - 2015-12-10 13:47:33 --> Total execution time: 0.2489
DEBUG - 2015-12-10 13:48:18 --> Config Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:48:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:48:18 --> URI Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Router Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Output Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Security Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Input Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:48:18 --> Language Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Language Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Config Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Loader Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:48:18 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:48:18 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Session Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:48:18 --> Session routines successfully run
DEBUG - 2015-12-10 13:48:18 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Email Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Controller Class Initialized
DEBUG - 2015-12-10 13:48:18 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:48:18 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:48:18 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:48:18 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:48:18 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:48:18 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:48:18 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:48:18 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:48:18 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:48:18 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/real_estate_administration/views/property_owners/edit_property_owner.php
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:48:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:48:18 --> Final output sent to browser
DEBUG - 2015-12-10 13:48:18 --> Total execution time: 0.2286
DEBUG - 2015-12-10 13:48:28 --> Config Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:48:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:48:28 --> URI Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Router Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Output Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Security Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Input Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:48:28 --> Language Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Language Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Config Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Loader Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:48:28 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:48:28 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Session Class Initialized
DEBUG - 2015-12-10 13:48:28 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:48:28 --> Session routines successfully run
DEBUG - 2015-12-10 13:48:28 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:48:29 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:48:29 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:48:29 --> Email Class Initialized
DEBUG - 2015-12-10 13:48:29 --> Controller Class Initialized
DEBUG - 2015-12-10 13:48:29 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:48:29 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:48:29 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:48:29 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:48:29 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:29 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:48:29 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:48:29 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:48:29 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:29 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:48:29 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:48:29 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-10 13:48:29 --> XSS Filtering completed
DEBUG - 2015-12-10 13:48:29 --> Unable to find validation rule: exists
DEBUG - 2015-12-10 13:48:29 --> XSS Filtering completed
DEBUG - 2015-12-10 13:48:29 --> XSS Filtering completed
DEBUG - 2015-12-10 13:48:29 --> XSS Filtering completed
DEBUG - 2015-12-10 13:48:29 --> DB Transaction Failure
ERROR - 2015-12-10 13:48:29 --> Query error: Unknown column 'branch_id' in 'field list'
DEBUG - 2015-12-10 13:48:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 13:48:57 --> Config Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:48:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:48:57 --> URI Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Router Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Output Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Security Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Input Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:48:57 --> Language Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Language Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Config Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Loader Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:48:57 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:48:57 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Session Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:48:57 --> Session routines successfully run
DEBUG - 2015-12-10 13:48:57 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:48:57 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Email Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Controller Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-10 13:48:58 --> XSS Filtering completed
DEBUG - 2015-12-10 13:48:58 --> Unable to find validation rule: exists
DEBUG - 2015-12-10 13:48:58 --> XSS Filtering completed
DEBUG - 2015-12-10 13:48:58 --> XSS Filtering completed
DEBUG - 2015-12-10 13:48:58 --> XSS Filtering completed
DEBUG - 2015-12-10 13:48:58 --> Config Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:48:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:48:58 --> URI Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Router Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Output Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Security Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Input Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:48:58 --> Language Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Language Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Config Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Loader Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:48:58 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:48:58 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Session Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:48:58 --> Session routines successfully run
DEBUG - 2015-12-10 13:48:58 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Email Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Controller Class Initialized
DEBUG - 2015-12-10 13:48:58 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:48:58 --> Model Class Initialized
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:48:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:48:58 --> Final output sent to browser
DEBUG - 2015-12-10 13:48:58 --> Total execution time: 0.2270
DEBUG - 2015-12-10 13:49:08 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:49:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:49:08 --> URI Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Router Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Output Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Security Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Input Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:49:08 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Loader Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:49:08 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:49:08 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Session Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:49:08 --> Session routines successfully run
DEBUG - 2015-12-10 13:49:08 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Email Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Controller Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:49:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:49:08 --> URI Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Router Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Output Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Security Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Input Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:49:08 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Loader Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:49:08 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:49:08 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Session Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:49:08 --> Session routines successfully run
DEBUG - 2015-12-10 13:49:08 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Email Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Controller Class Initialized
DEBUG - 2015-12-10 13:49:08 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:49:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:49:08 --> Final output sent to browser
DEBUG - 2015-12-10 13:49:08 --> Total execution time: 0.2353
DEBUG - 2015-12-10 13:49:12 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:12 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:49:12 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:49:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:49:12 --> URI Class Initialized
DEBUG - 2015-12-10 13:49:12 --> Router Class Initialized
DEBUG - 2015-12-10 13:49:12 --> Output Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Security Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Input Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:49:13 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Loader Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:49:13 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:49:13 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Session Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:49:13 --> Session routines successfully run
DEBUG - 2015-12-10 13:49:13 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Email Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Controller Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:49:13 --> URI Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Router Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Output Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Security Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Input Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:49:13 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Loader Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:49:13 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:49:13 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Session Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:49:13 --> Session routines successfully run
DEBUG - 2015-12-10 13:49:13 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Email Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Controller Class Initialized
DEBUG - 2015-12-10 13:49:13 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:49:13 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:49:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:49:13 --> Final output sent to browser
DEBUG - 2015-12-10 13:49:13 --> Total execution time: 0.2449
DEBUG - 2015-12-10 13:49:16 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:49:16 --> URI Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Router Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Output Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Security Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Input Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:49:16 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Loader Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:49:16 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:49:16 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Session Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:49:16 --> Session routines successfully run
DEBUG - 2015-12-10 13:49:16 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Email Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Controller Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Hooks Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Utf8 Class Initialized
DEBUG - 2015-12-10 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 13:49:16 --> URI Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Router Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Output Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Security Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Input Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 13:49:16 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Language Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Config Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Loader Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Helper loaded: url_helper
DEBUG - 2015-12-10 13:49:16 --> Helper loaded: form_helper
DEBUG - 2015-12-10 13:49:16 --> Database Driver Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Session Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Helper loaded: string_helper
DEBUG - 2015-12-10 13:49:16 --> Session routines successfully run
DEBUG - 2015-12-10 13:49:16 --> Form Validation Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Pagination Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Encrypt Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Email Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Controller Class Initialized
DEBUG - 2015-12-10 13:49:16 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 13:49:16 --> Model Class Initialized
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 13:49:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 13:49:16 --> Final output sent to browser
DEBUG - 2015-12-10 13:49:17 --> Total execution time: 0.2535
DEBUG - 2015-12-10 14:01:23 --> Config Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Hooks Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Utf8 Class Initialized
DEBUG - 2015-12-10 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 14:01:23 --> URI Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Router Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Output Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Security Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Input Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 14:01:23 --> Language Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Language Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Config Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Loader Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Helper loaded: url_helper
DEBUG - 2015-12-10 14:01:23 --> Helper loaded: form_helper
DEBUG - 2015-12-10 14:01:23 --> Database Driver Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Session Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Helper loaded: string_helper
DEBUG - 2015-12-10 14:01:23 --> Session routines successfully run
DEBUG - 2015-12-10 14:01:23 --> Form Validation Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Pagination Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Encrypt Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Email Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Controller Class Initialized
DEBUG - 2015-12-10 14:01:23 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 14:01:23 --> Model Class Initialized
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 14:01:23 --> Model Class Initialized
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 14:01:23 --> Model Class Initialized
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 14:01:23 --> Model Class Initialized
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 14:01:23 --> Model Class Initialized
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 14:01:23 --> Model Class Initialized
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 14:01:23 --> Model Class Initialized
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 14:01:23 --> Model Class Initialized
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 14:01:23 --> Model Class Initialized
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 14:01:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 14:01:23 --> Final output sent to browser
DEBUG - 2015-12-10 14:01:23 --> Total execution time: 0.2915
DEBUG - 2015-12-10 14:02:15 --> Config Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Hooks Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Utf8 Class Initialized
DEBUG - 2015-12-10 14:02:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 14:02:15 --> URI Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Router Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Output Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Security Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Input Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 14:02:15 --> Language Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Language Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Config Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Loader Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Helper loaded: url_helper
DEBUG - 2015-12-10 14:02:15 --> Helper loaded: form_helper
DEBUG - 2015-12-10 14:02:15 --> Database Driver Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Session Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Helper loaded: string_helper
DEBUG - 2015-12-10 14:02:15 --> Session routines successfully run
DEBUG - 2015-12-10 14:02:15 --> Form Validation Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Pagination Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Encrypt Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Email Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Controller Class Initialized
DEBUG - 2015-12-10 14:02:15 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-10 14:02:15 --> Model Class Initialized
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 14:02:15 --> Model Class Initialized
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 14:02:15 --> Model Class Initialized
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 14:02:15 --> Model Class Initialized
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 14:02:15 --> Model Class Initialized
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 14:02:15 --> Model Class Initialized
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 14:02:15 --> Model Class Initialized
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-10 14:02:15 --> Model Class Initialized
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 14:02:15 --> Model Class Initialized
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-10 14:02:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-10 14:02:15 --> Final output sent to browser
DEBUG - 2015-12-10 14:02:15 --> Total execution time: 0.2334
DEBUG - 2015-12-10 14:02:20 --> Config Class Initialized
DEBUG - 2015-12-10 14:02:20 --> Hooks Class Initialized
DEBUG - 2015-12-10 14:02:20 --> Utf8 Class Initialized
DEBUG - 2015-12-10 14:02:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 14:02:20 --> URI Class Initialized
DEBUG - 2015-12-10 14:02:20 --> Router Class Initialized
ERROR - 2015-12-10 14:02:20 --> 404 Page Not Found --> 
DEBUG - 2015-12-10 14:02:47 --> Config Class Initialized
DEBUG - 2015-12-10 14:02:47 --> Hooks Class Initialized
DEBUG - 2015-12-10 14:02:47 --> Utf8 Class Initialized
DEBUG - 2015-12-10 14:02:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 14:02:47 --> URI Class Initialized
DEBUG - 2015-12-10 14:02:47 --> Router Class Initialized
ERROR - 2015-12-10 14:02:47 --> 404 Page Not Found --> 
DEBUG - 2015-12-10 14:02:49 --> Config Class Initialized
DEBUG - 2015-12-10 14:02:49 --> Hooks Class Initialized
DEBUG - 2015-12-10 14:02:49 --> Utf8 Class Initialized
DEBUG - 2015-12-10 14:02:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 14:02:49 --> URI Class Initialized
DEBUG - 2015-12-10 14:02:49 --> Router Class Initialized
ERROR - 2015-12-10 14:02:49 --> 404 Page Not Found --> 
DEBUG - 2015-12-10 14:03:30 --> Config Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Hooks Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Utf8 Class Initialized
DEBUG - 2015-12-10 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 14:03:30 --> URI Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Router Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Output Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Security Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Input Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 14:03:30 --> Language Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Language Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Config Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Loader Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Helper loaded: url_helper
DEBUG - 2015-12-10 14:03:30 --> Helper loaded: form_helper
DEBUG - 2015-12-10 14:03:30 --> Database Driver Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Session Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Helper loaded: string_helper
DEBUG - 2015-12-10 14:03:30 --> Session routines successfully run
DEBUG - 2015-12-10 14:03:30 --> Form Validation Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Pagination Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Encrypt Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Email Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Controller Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Property MX_Controller Initialized
DEBUG - 2015-12-10 14:03:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:03:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 14:03:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:03:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 14:03:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:03:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 14:03:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:03:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 14:03:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:03:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 14:03:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:03:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 14:03:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:03:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 14:03:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:03:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-10 14:03:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:03:30 --> Image Lib Class Initialized
DEBUG - 2015-12-10 14:03:30 --> DB Transaction Failure
ERROR - 2015-12-10 14:03:30 --> Query error: Table 'rents.property' doesn't exist
DEBUG - 2015-12-10 14:03:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-10 14:06:07 --> Config Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Hooks Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Utf8 Class Initialized
DEBUG - 2015-12-10 14:06:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 14:06:07 --> URI Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Router Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Output Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Security Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Input Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 14:06:07 --> Language Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Language Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Config Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Loader Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Helper loaded: url_helper
DEBUG - 2015-12-10 14:06:07 --> Helper loaded: form_helper
DEBUG - 2015-12-10 14:06:07 --> Database Driver Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Session Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Helper loaded: string_helper
DEBUG - 2015-12-10 14:06:07 --> Session routines successfully run
DEBUG - 2015-12-10 14:06:07 --> Form Validation Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Pagination Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Encrypt Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Email Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Controller Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Property MX_Controller Initialized
DEBUG - 2015-12-10 14:06:07 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 14:06:07 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 14:06:07 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 14:06:07 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 14:06:07 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 14:06:07 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 14:06:07 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 14:06:07 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-10 14:06:07 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:07 --> Image Lib Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Config Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Hooks Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Utf8 Class Initialized
DEBUG - 2015-12-10 14:06:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 14:06:30 --> URI Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Router Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Output Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Security Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Input Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 14:06:30 --> Language Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Language Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Config Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Loader Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Helper loaded: url_helper
DEBUG - 2015-12-10 14:06:30 --> Helper loaded: form_helper
DEBUG - 2015-12-10 14:06:30 --> Database Driver Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Session Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Helper loaded: string_helper
DEBUG - 2015-12-10 14:06:30 --> Session routines successfully run
DEBUG - 2015-12-10 14:06:30 --> Form Validation Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Pagination Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Encrypt Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Email Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Controller Class Initialized
DEBUG - 2015-12-10 14:06:30 --> Property MX_Controller Initialized
DEBUG - 2015-12-10 14:06:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 14:06:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 14:06:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 14:06:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 14:06:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 14:06:31 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 14:06:31 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 14:06:31 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-10 14:06:31 --> Model Class Initialized
DEBUG - 2015-12-10 14:06:31 --> Image Lib Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Config Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Hooks Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Utf8 Class Initialized
DEBUG - 2015-12-10 14:07:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-10 14:07:30 --> URI Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Router Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Output Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Security Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Input Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-10 14:07:30 --> Language Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Language Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Config Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Loader Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Helper loaded: url_helper
DEBUG - 2015-12-10 14:07:30 --> Helper loaded: form_helper
DEBUG - 2015-12-10 14:07:30 --> Database Driver Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Session Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Helper loaded: string_helper
DEBUG - 2015-12-10 14:07:30 --> Session routines successfully run
DEBUG - 2015-12-10 14:07:30 --> Form Validation Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Pagination Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Encrypt Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Email Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Controller Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Property MX_Controller Initialized
DEBUG - 2015-12-10 14:07:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:07:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-10 14:07:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:07:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-10 14:07:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:07:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-10 14:07:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:07:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-10 14:07:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:07:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-10 14:07:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:07:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-10 14:07:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:07:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-10 14:07:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:07:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-10 14:07:30 --> Model Class Initialized
DEBUG - 2015-12-10 14:07:30 --> Image Lib Class Initialized
