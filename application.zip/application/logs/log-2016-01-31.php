<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-31 16:34:43 --> Config Class Initialized
DEBUG - 2016-01-31 16:34:43 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:34:44 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:34:44 --> URI Class Initialized
DEBUG - 2016-01-31 16:34:44 --> Router Class Initialized
DEBUG - 2016-01-31 16:34:44 --> No URI present. Default controller set.
DEBUG - 2016-01-31 16:34:44 --> Output Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Security Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Input Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-31 16:34:45 --> Language Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Config Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:34:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:34:45 --> URI Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Router Class Initialized
DEBUG - 2016-01-31 16:34:45 --> No URI present. Default controller set.
DEBUG - 2016-01-31 16:34:45 --> Output Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Security Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Input Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-31 16:34:45 --> Language Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Language Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Language Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Config Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Config Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Loader Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Loader Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Helper loaded: url_helper
DEBUG - 2016-01-31 16:34:45 --> Helper loaded: url_helper
DEBUG - 2016-01-31 16:34:45 --> Helper loaded: form_helper
DEBUG - 2016-01-31 16:34:45 --> Helper loaded: form_helper
DEBUG - 2016-01-31 16:34:45 --> Database Driver Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Database Driver Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Session Class Initialized
DEBUG - 2016-01-31 16:34:45 --> Session Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Helper loaded: string_helper
DEBUG - 2016-01-31 16:34:46 --> Helper loaded: string_helper
DEBUG - 2016-01-31 16:34:46 --> Session routines successfully run
DEBUG - 2016-01-31 16:34:46 --> Session routines successfully run
DEBUG - 2016-01-31 16:34:46 --> Form Validation Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Form Validation Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Pagination Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Pagination Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Encrypt Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Encrypt Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Email Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Controller Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Email Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Auth MX_Controller Initialized
DEBUG - 2016-01-31 16:34:46 --> Controller Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Auth MX_Controller Initialized
DEBUG - 2016-01-31 16:34:46 --> Model Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Model Class Initialized
DEBUG - 2016-01-31 16:34:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-31 16:34:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-31 16:34:46 --> Model Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Model Class Initialized
DEBUG - 2016-01-31 16:34:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-31 16:34:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-31 16:34:46 --> Model Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Model Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Config Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:34:46 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:34:46 --> URI Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Router Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Output Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Security Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Input Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-31 16:34:46 --> Language Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Language Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Config Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Loader Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Helper loaded: url_helper
DEBUG - 2016-01-31 16:34:46 --> Helper loaded: form_helper
DEBUG - 2016-01-31 16:34:46 --> Database Driver Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Session Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Helper loaded: string_helper
DEBUG - 2016-01-31 16:34:46 --> Session routines successfully run
DEBUG - 2016-01-31 16:34:46 --> Form Validation Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Pagination Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Encrypt Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Email Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Controller Class Initialized
DEBUG - 2016-01-31 16:34:46 --> Auth MX_Controller Initialized
DEBUG - 2016-01-31 16:34:46 --> Model Class Initialized
DEBUG - 2016-01-31 16:34:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-31 16:34:46 --> Model Class Initialized
DEBUG - 2016-01-31 16:34:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-31 16:34:46 --> Model Class Initialized
DEBUG - 2016-01-31 16:34:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-31 16:34:47 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-31 16:34:47 --> Final output sent to browser
DEBUG - 2016-01-31 16:34:47 --> Total execution time: 0.9421
DEBUG - 2016-01-31 16:34:50 --> Config Class Initialized
DEBUG - 2016-01-31 16:34:50 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:34:50 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:34:50 --> Config Class Initialized
DEBUG - 2016-01-31 16:34:50 --> URI Class Initialized
DEBUG - 2016-01-31 16:34:50 --> Config Class Initialized
DEBUG - 2016-01-31 16:34:50 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:34:50 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:34:50 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:34:50 --> URI Class Initialized
DEBUG - 2016-01-31 16:34:50 --> Router Class Initialized
DEBUG - 2016-01-31 16:34:50 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:34:50 --> Router Class Initialized
DEBUG - 2016-01-31 16:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:34:50 --> URI Class Initialized
DEBUG - 2016-01-31 16:34:50 --> Router Class Initialized
ERROR - 2016-01-31 16:34:50 --> 404 Page Not Found --> 
ERROR - 2016-01-31 16:34:51 --> 404 Page Not Found --> 
DEBUG - 2016-01-31 16:34:51 --> Config Class Initialized
ERROR - 2016-01-31 16:34:51 --> 404 Page Not Found --> 
DEBUG - 2016-01-31 16:34:51 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:34:51 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:34:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:34:51 --> URI Class Initialized
DEBUG - 2016-01-31 16:34:51 --> Router Class Initialized
ERROR - 2016-01-31 16:34:51 --> 404 Page Not Found --> 
DEBUG - 2016-01-31 16:35:03 --> Config Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:35:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:35:03 --> URI Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Router Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Output Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Security Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Input Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-31 16:35:03 --> Language Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Language Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Config Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Loader Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Helper loaded: url_helper
DEBUG - 2016-01-31 16:35:03 --> Helper loaded: form_helper
DEBUG - 2016-01-31 16:35:03 --> Database Driver Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Session Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Helper loaded: string_helper
DEBUG - 2016-01-31 16:35:03 --> Session routines successfully run
DEBUG - 2016-01-31 16:35:03 --> Form Validation Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Pagination Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Encrypt Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Email Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Controller Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Auth MX_Controller Initialized
DEBUG - 2016-01-31 16:35:03 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-31 16:35:03 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-31 16:35:03 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-31 16:35:03 --> XSS Filtering completed
DEBUG - 2016-01-31 16:35:03 --> Unable to find validation rule: exists
DEBUG - 2016-01-31 16:35:03 --> XSS Filtering completed
DEBUG - 2016-01-31 16:35:03 --> Config Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:35:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:35:03 --> URI Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Router Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Output Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Security Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Input Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-31 16:35:03 --> Language Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Language Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Config Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Loader Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Helper loaded: url_helper
DEBUG - 2016-01-31 16:35:03 --> Helper loaded: form_helper
DEBUG - 2016-01-31 16:35:03 --> Database Driver Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Session Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Helper loaded: string_helper
DEBUG - 2016-01-31 16:35:03 --> Session routines successfully run
DEBUG - 2016-01-31 16:35:03 --> Form Validation Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Pagination Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Encrypt Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Email Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Controller Class Initialized
DEBUG - 2016-01-31 16:35:03 --> Admin MX_Controller Initialized
DEBUG - 2016-01-31 16:35:04 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-31 16:35:04 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-31 16:35:04 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-31 16:35:04 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-31 16:35:04 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-31 16:35:04 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-31 16:35:04 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-31 16:35:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-31 16:35:04 --> Final output sent to browser
DEBUG - 2016-01-31 16:35:04 --> Total execution time: 0.9420
DEBUG - 2016-01-31 16:35:22 --> Config Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:35:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:35:22 --> URI Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Router Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Output Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Security Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Input Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-31 16:35:22 --> Language Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Language Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Config Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Loader Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Helper loaded: url_helper
DEBUG - 2016-01-31 16:35:22 --> Helper loaded: form_helper
DEBUG - 2016-01-31 16:35:22 --> Database Driver Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Session Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Helper loaded: string_helper
DEBUG - 2016-01-31 16:35:22 --> Session routines successfully run
DEBUG - 2016-01-31 16:35:22 --> Form Validation Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Pagination Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Encrypt Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Email Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Controller Class Initialized
DEBUG - 2016-01-31 16:35:22 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-31 16:35:22 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-31 16:35:22 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-31 16:35:22 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-31 16:35:22 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-31 16:35:22 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-31 16:35:22 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-31 16:35:22 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-31 16:35:23 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-31 16:35:23 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-31 16:35:23 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:23 --> Image Lib Class Initialized
DEBUG - 2016-01-31 16:35:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-31 16:35:23 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-31 16:35:23 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-31 16:35:23 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-31 16:35:23 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:27 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-31 16:35:27 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-31 16:35:27 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-31 16:35:27 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-31 16:35:27 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-31 16:35:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-31 16:35:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-31 16:35:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-31 16:35:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-31 16:35:27 --> Final output sent to browser
DEBUG - 2016-01-31 16:35:27 --> Total execution time: 4.6997
DEBUG - 2016-01-31 16:35:33 --> Config Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Hooks Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Utf8 Class Initialized
DEBUG - 2016-01-31 16:35:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-31 16:35:33 --> URI Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Router Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Output Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Security Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Input Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-31 16:35:33 --> Language Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Language Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Config Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Loader Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Helper loaded: url_helper
DEBUG - 2016-01-31 16:35:33 --> Helper loaded: form_helper
DEBUG - 2016-01-31 16:35:33 --> Database Driver Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Session Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Helper loaded: string_helper
DEBUG - 2016-01-31 16:35:33 --> Session routines successfully run
DEBUG - 2016-01-31 16:35:33 --> Form Validation Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Pagination Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Encrypt Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Email Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Controller Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> Image Lib Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:33 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-31 16:35:33 --> Model Class Initialized
DEBUG - 2016-01-31 16:35:34 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-31 16:35:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-31 16:35:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-31 16:35:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-31 16:35:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-31 16:35:34 --> Final output sent to browser
DEBUG - 2016-01-31 16:35:34 --> Total execution time: 0.9728
