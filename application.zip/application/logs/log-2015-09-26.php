<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-09-26 16:08:52 --> Config Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:08:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:08:52 --> URI Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Router Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Output Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Security Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Input Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:08:52 --> Language Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Language Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Config Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Loader Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:08:52 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:08:52 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-26 16:08:52 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:08:52 --> Session Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:08:52 --> A session cookie was not found.
DEBUG - 2015-09-26 16:08:52 --> Session routines successfully run
DEBUG - 2015-09-26 16:08:52 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Email Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Controller Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Config Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:08:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:08:52 --> URI Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Router Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Output Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Security Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Input Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:08:52 --> Language Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Language Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Config Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Loader Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:08:52 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:08:52 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:08:52 --> Session Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:08:52 --> Session routines successfully run
DEBUG - 2015-09-26 16:08:52 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Email Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Controller Class Initialized
DEBUG - 2015-09-26 16:08:52 --> Auth MX_Controller Initialized
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:08:52 --> Model Class Initialized
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 16:08:52 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-09-26 16:08:52 --> Final output sent to browser
DEBUG - 2015-09-26 16:08:52 --> Total execution time: 0.1032
DEBUG - 2015-09-26 16:08:53 --> Config Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Config Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:08:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:08:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:08:53 --> URI Class Initialized
DEBUG - 2015-09-26 16:08:53 --> URI Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Router Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Router Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Config Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:08:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:08:53 --> URI Class Initialized
ERROR - 2015-09-26 16:08:53 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 16:08:53 --> Router Class Initialized
ERROR - 2015-09-26 16:08:53 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 16:08:53 --> Config Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:08:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:08:53 --> URI Class Initialized
DEBUG - 2015-09-26 16:08:53 --> Router Class Initialized
ERROR - 2015-09-26 16:08:53 --> 404 Page Not Found --> 
ERROR - 2015-09-26 16:08:53 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 16:09:27 --> Config Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:09:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:09:27 --> URI Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Router Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Output Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Security Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Input Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:09:27 --> Language Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Language Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Config Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Loader Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:09:27 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:09:27 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:09:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-26 16:09:27 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:09:27 --> Session Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:09:27 --> Session routines successfully run
DEBUG - 2015-09-26 16:09:27 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Email Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Controller Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Auth MX_Controller Initialized
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-26 16:09:27 --> XSS Filtering completed
DEBUG - 2015-09-26 16:09:27 --> Unable to find validation rule: exists
DEBUG - 2015-09-26 16:09:27 --> XSS Filtering completed
DEBUG - 2015-09-26 16:09:27 --> Config Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:09:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:09:27 --> URI Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Router Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Output Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Security Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Input Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:09:27 --> Language Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Language Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Config Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Loader Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:09:27 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:09:27 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:09:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:09:27 --> Session Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:09:27 --> Session routines successfully run
DEBUG - 2015-09-26 16:09:27 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Email Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Controller Class Initialized
DEBUG - 2015-09-26 16:09:27 --> Admin MX_Controller Initialized
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-26 16:09:27 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 16:09:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 16:09:27 --> Final output sent to browser
DEBUG - 2015-09-26 16:09:27 --> Total execution time: 0.1365
DEBUG - 2015-09-26 16:09:37 --> Config Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:09:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:09:37 --> URI Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Router Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Output Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Security Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Input Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:09:37 --> Language Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Language Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Config Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Loader Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:09:37 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:09:37 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:09:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:09:37 --> Session Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:09:37 --> Session routines successfully run
DEBUG - 2015-09-26 16:09:37 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Email Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Controller Class Initialized
DEBUG - 2015-09-26 16:09:37 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 16:09:37 --> Model Class Initialized
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 16:09:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 16:09:37 --> Final output sent to browser
DEBUG - 2015-09-26 16:09:37 --> Total execution time: 0.1492
DEBUG - 2015-09-26 16:12:49 --> Config Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:12:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:12:49 --> URI Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Router Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Output Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Security Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Input Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:12:49 --> Language Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Language Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Config Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Loader Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:12:49 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:12:49 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:12:49 --> Session Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:12:49 --> Session routines successfully run
DEBUG - 2015-09-26 16:12:49 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Email Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Controller Class Initialized
DEBUG - 2015-09-26 16:12:49 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
DEBUG - 2015-09-26 16:12:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 16:12:49 --> Model Class Initialized
ERROR - 2015-09-26 16:12:49 --> 404 Page Not Found --> microfinance/add-loans-plan
DEBUG - 2015-09-26 16:37:00 --> Config Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:37:00 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:37:00 --> URI Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Router Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Output Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Security Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Input Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:37:00 --> Language Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Language Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Config Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Loader Class Initialized
DEBUG - 2015-09-26 16:37:00 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:37:01 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:37:01 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:37:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-26 16:37:01 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:37:01 --> Session Class Initialized
DEBUG - 2015-09-26 16:37:01 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:37:01 --> Session routines successfully run
DEBUG - 2015-09-26 16:37:01 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:37:01 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:37:01 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:37:01 --> Email Class Initialized
DEBUG - 2015-09-26 16:37:01 --> Controller Class Initialized
DEBUG - 2015-09-26 16:37:01 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 16:37:01 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 16:37:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 16:37:01 --> Final output sent to browser
DEBUG - 2015-09-26 16:37:01 --> Total execution time: 0.1494
DEBUG - 2015-09-26 16:37:26 --> Config Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:37:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:37:26 --> URI Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Router Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Output Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Security Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Input Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:37:26 --> Language Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Language Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Config Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Loader Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:37:26 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:37:26 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:37:26 --> Session Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:37:26 --> Session routines successfully run
DEBUG - 2015-09-26 16:37:26 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Email Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Controller Class Initialized
DEBUG - 2015-09-26 16:37:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 16:37:26 --> Model Class Initialized
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 16:37:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 16:37:26 --> Final output sent to browser
DEBUG - 2015-09-26 16:37:26 --> Total execution time: 0.1503
DEBUG - 2015-09-26 16:39:07 --> Config Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:39:07 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:39:07 --> URI Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Router Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Output Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Security Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Input Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:39:07 --> Language Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Language Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Config Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Loader Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:39:07 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:39:07 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:39:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:39:07 --> Session Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:39:07 --> Session routines successfully run
DEBUG - 2015-09-26 16:39:07 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Email Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Controller Class Initialized
DEBUG - 2015-09-26 16:39:07 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 16:39:07 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 16:39:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 16:39:07 --> Final output sent to browser
DEBUG - 2015-09-26 16:39:07 --> Total execution time: 0.1474
DEBUG - 2015-09-26 16:39:33 --> Config Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:39:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:39:33 --> URI Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Router Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Output Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Security Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Input Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:39:33 --> Language Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Language Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Config Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Loader Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:39:33 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:39:33 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:39:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:39:33 --> Session Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:39:33 --> Session routines successfully run
DEBUG - 2015-09-26 16:39:33 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Email Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Controller Class Initialized
DEBUG - 2015-09-26 16:39:33 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 16:39:33 --> Model Class Initialized
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 16:39:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 16:39:33 --> Final output sent to browser
DEBUG - 2015-09-26 16:39:33 --> Total execution time: 0.1382
DEBUG - 2015-09-26 16:40:57 --> Config Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:40:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:40:57 --> URI Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Router Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Output Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Security Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Input Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 16:40:57 --> Language Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Language Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Config Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Loader Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Helper loaded: url_helper
DEBUG - 2015-09-26 16:40:57 --> Helper loaded: form_helper
DEBUG - 2015-09-26 16:40:57 --> Database Driver Class Initialized
ERROR - 2015-09-26 16:40:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-09-26 16:40:57 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 16:40:57 --> Session Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Helper loaded: string_helper
DEBUG - 2015-09-26 16:40:57 --> Session routines successfully run
DEBUG - 2015-09-26 16:40:57 --> Form Validation Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Pagination Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Encrypt Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Email Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Controller Class Initialized
DEBUG - 2015-09-26 16:40:57 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 16:40:57 --> Model Class Initialized
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 16:40:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 16:40:57 --> Final output sent to browser
DEBUG - 2015-09-26 16:40:57 --> Total execution time: 0.1420
DEBUG - 2015-09-26 16:45:37 --> Config Class Initialized
DEBUG - 2015-09-26 16:45:37 --> Hooks Class Initialized
DEBUG - 2015-09-26 16:45:37 --> Utf8 Class Initialized
DEBUG - 2015-09-26 16:45:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 16:45:37 --> URI Class Initialized
DEBUG - 2015-09-26 16:45:37 --> Router Class Initialized
ERROR - 2015-09-26 16:45:37 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:02:17 --> Config Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:02:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:02:17 --> URI Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Router Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Output Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Security Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Input Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:02:17 --> Language Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Language Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Config Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Loader Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:02:17 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:02:17 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:02:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:02:17 --> Session Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:02:17 --> Session routines successfully run
DEBUG - 2015-09-26 17:02:17 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Email Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Controller Class Initialized
DEBUG - 2015-09-26 17:02:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:02:17 --> Model Class Initialized
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:02:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:02:17 --> Final output sent to browser
DEBUG - 2015-09-26 17:02:17 --> Total execution time: 0.1438
DEBUG - 2015-09-26 17:02:19 --> Config Class Initialized
DEBUG - 2015-09-26 17:02:19 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:02:19 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:02:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:02:19 --> URI Class Initialized
DEBUG - 2015-09-26 17:02:19 --> Router Class Initialized
ERROR - 2015-09-26 17:02:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:04:22 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:04:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:04:22 --> URI Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Router Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Output Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Security Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Input Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:04:22 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Loader Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:04:22 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:04:22 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:04:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:04:22 --> Session Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:04:22 --> Session routines successfully run
DEBUG - 2015-09-26 17:04:22 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Email Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Controller Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Individual MX_Controller Initialized
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:04:22 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:22 --> Image Lib Class Initialized
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:04:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:04:22 --> Final output sent to browser
DEBUG - 2015-09-26 17:04:22 --> Total execution time: 0.1906
DEBUG - 2015-09-26 17:04:27 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:04:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:04:27 --> URI Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Router Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Output Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Security Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Input Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:04:27 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Loader Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:04:27 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:04:27 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:04:27 --> Session Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:04:27 --> Session routines successfully run
DEBUG - 2015-09-26 17:04:27 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Email Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Controller Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Individual MX_Controller Initialized
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:04:27 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:27 --> Image Lib Class Initialized
DEBUG - 2015-09-26 17:04:27 --> DB Transaction Failure
ERROR - 2015-09-26 17:04:27 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-09-26 17:04:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-26 17:04:38 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:04:38 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:04:38 --> URI Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Router Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Output Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Security Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Input Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:04:38 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Loader Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:04:38 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:04:38 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:04:38 --> Session Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:04:38 --> Session routines successfully run
DEBUG - 2015-09-26 17:04:38 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Email Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Controller Class Initialized
DEBUG - 2015-09-26 17:04:38 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:04:38 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:04:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:04:38 --> Final output sent to browser
DEBUG - 2015-09-26 17:04:38 --> Total execution time: 0.1438
DEBUG - 2015-09-26 17:04:42 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:04:42 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:04:42 --> URI Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Router Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Output Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Security Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Input Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:04:42 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Loader Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:04:42 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:04:42 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:04:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:04:42 --> Session Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:04:42 --> Session routines successfully run
DEBUG - 2015-09-26 17:04:42 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Email Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Controller Class Initialized
DEBUG - 2015-09-26 17:04:42 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:04:42 --> Model Class Initialized
ERROR - 2015-09-26 17:04:42 --> 404 Page Not Found --> microfinance/edit-savings_plan
DEBUG - 2015-09-26 17:04:46 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:04:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:04:46 --> URI Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Router Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Output Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Security Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Input Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:04:46 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Loader Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:04:46 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:04:46 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:04:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:04:46 --> Session Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:04:46 --> Session routines successfully run
DEBUG - 2015-09-26 17:04:46 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Email Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Controller Class Initialized
DEBUG - 2015-09-26 17:04:46 --> Group MX_Controller Initialized
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:04:46 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/microfinance/views/group/all_group.php
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:04:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:04:46 --> Final output sent to browser
DEBUG - 2015-09-26 17:04:46 --> Total execution time: 0.1402
DEBUG - 2015-09-26 17:04:49 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:04:49 --> URI Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Router Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Output Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Security Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Input Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:04:49 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Loader Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:04:49 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:04:49 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:04:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:04:49 --> Session Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:04:49 --> Session routines successfully run
DEBUG - 2015-09-26 17:04:49 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Email Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Controller Class Initialized
DEBUG - 2015-09-26 17:04:49 --> Group MX_Controller Initialized
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:49 --> DB Transaction Failure
ERROR - 2015-09-26 17:04:49 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-09-26 17:04:49 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-26 17:04:53 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:04:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:04:53 --> URI Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Router Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Output Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Security Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Input Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:04:53 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Loader Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:04:53 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:04:53 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:04:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:04:53 --> Session Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:04:53 --> Session routines successfully run
DEBUG - 2015-09-26 17:04:53 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Email Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Controller Class Initialized
DEBUG - 2015-09-26 17:04:53 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:04:53 --> Model Class Initialized
ERROR - 2015-09-26 17:04:53 --> 404 Page Not Found --> microfinance/deposits
DEBUG - 2015-09-26 17:04:56 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:04:56 --> URI Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Router Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Output Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Security Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Input Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:04:56 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Loader Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:04:56 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:04:56 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:04:56 --> Session Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:04:56 --> Session routines successfully run
DEBUG - 2015-09-26 17:04:56 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Email Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Controller Class Initialized
DEBUG - 2015-09-26 17:04:56 --> Microfinance MX_Controller Initialized
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:04:56 --> Model Class Initialized
ERROR - 2015-09-26 17:04:56 --> 404 Page Not Found --> microfinance/deposits
DEBUG - 2015-09-26 17:04:59 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:04:59 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:04:59 --> URI Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Router Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Output Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Security Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Input Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:04:59 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Language Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Config Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Loader Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:04:59 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:04:59 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:04:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:04:59 --> Session Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:04:59 --> Session routines successfully run
DEBUG - 2015-09-26 17:04:59 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Email Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Controller Class Initialized
DEBUG - 2015-09-26 17:04:59 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:04:59 --> Model Class Initialized
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:04:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:04:59 --> Final output sent to browser
DEBUG - 2015-09-26 17:04:59 --> Total execution time: 0.1330
DEBUG - 2015-09-26 17:05:09 --> Config Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:05:09 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:05:09 --> URI Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Router Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Output Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Security Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Input Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:05:09 --> Language Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Language Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Config Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Loader Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:05:09 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:05:09 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:05:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:05:09 --> Session Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:05:09 --> Session routines successfully run
DEBUG - 2015-09-26 17:05:09 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Email Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Controller Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Branches MX_Controller Initialized
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:05:09 --> Model Class Initialized
DEBUG - 2015-09-26 17:05:09 --> Image Lib Class Initialized
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/views/branches/all_branches.php
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:05:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:05:09 --> Final output sent to browser
DEBUG - 2015-09-26 17:05:09 --> Total execution time: 0.1355
DEBUG - 2015-09-26 17:05:21 --> Config Class Initialized
DEBUG - 2015-09-26 17:05:21 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:05:21 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:05:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:05:21 --> URI Class Initialized
DEBUG - 2015-09-26 17:05:21 --> Router Class Initialized
ERROR - 2015-09-26 17:05:21 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:05:32 --> Config Class Initialized
DEBUG - 2015-09-26 17:05:32 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:05:32 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:05:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:05:32 --> URI Class Initialized
DEBUG - 2015-09-26 17:05:32 --> Router Class Initialized
ERROR - 2015-09-26 17:05:32 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:14:55 --> Config Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:14:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:14:55 --> URI Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Router Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Output Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Security Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Input Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:14:55 --> Language Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Language Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Config Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Loader Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:14:55 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:14:55 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:14:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:14:55 --> Session Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:14:55 --> Session routines successfully run
DEBUG - 2015-09-26 17:14:55 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Email Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Controller Class Initialized
DEBUG - 2015-09-26 17:14:55 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:14:55 --> Model Class Initialized
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:14:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:14:55 --> Final output sent to browser
DEBUG - 2015-09-26 17:14:55 --> Total execution time: 0.1296
DEBUG - 2015-09-26 17:14:56 --> Config Class Initialized
DEBUG - 2015-09-26 17:14:56 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:14:56 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:14:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:14:56 --> URI Class Initialized
DEBUG - 2015-09-26 17:14:56 --> Router Class Initialized
ERROR - 2015-09-26 17:14:56 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:16:26 --> Config Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:16:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:16:26 --> URI Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Router Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Output Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Security Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Input Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:16:26 --> Language Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Language Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Config Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Loader Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:16:26 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:16:26 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:16:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:16:26 --> Session Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:16:26 --> Session routines successfully run
DEBUG - 2015-09-26 17:16:26 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Email Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Controller Class Initialized
DEBUG - 2015-09-26 17:16:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:16:26 --> Model Class Initialized
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:16:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:16:26 --> Final output sent to browser
DEBUG - 2015-09-26 17:16:26 --> Total execution time: 0.1389
DEBUG - 2015-09-26 17:16:27 --> Config Class Initialized
DEBUG - 2015-09-26 17:16:27 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:16:27 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:16:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:16:27 --> URI Class Initialized
DEBUG - 2015-09-26 17:16:27 --> Router Class Initialized
ERROR - 2015-09-26 17:16:27 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:17:27 --> Config Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:17:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:17:27 --> URI Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Router Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Output Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Security Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Input Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:17:27 --> Language Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Language Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Config Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Loader Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:17:27 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:17:27 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:17:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:17:27 --> Session Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:17:27 --> Session routines successfully run
DEBUG - 2015-09-26 17:17:27 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:17:27 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:17:28 --> Email Class Initialized
DEBUG - 2015-09-26 17:17:28 --> Controller Class Initialized
DEBUG - 2015-09-26 17:17:28 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:17:28 --> Model Class Initialized
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:17:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:17:28 --> Final output sent to browser
DEBUG - 2015-09-26 17:17:28 --> Total execution time: 0.1348
DEBUG - 2015-09-26 17:17:29 --> Config Class Initialized
DEBUG - 2015-09-26 17:17:29 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:17:29 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:17:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:17:29 --> URI Class Initialized
DEBUG - 2015-09-26 17:17:29 --> Router Class Initialized
ERROR - 2015-09-26 17:17:29 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:18:57 --> Config Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:18:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:18:57 --> URI Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Router Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Output Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Security Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Input Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:18:57 --> Language Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Language Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Config Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Loader Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:18:57 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:18:57 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:18:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:18:57 --> Session Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:18:57 --> Session routines successfully run
DEBUG - 2015-09-26 17:18:57 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Email Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Controller Class Initialized
DEBUG - 2015-09-26 17:18:57 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:18:57 --> Model Class Initialized
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:18:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:18:57 --> Final output sent to browser
DEBUG - 2015-09-26 17:18:57 --> Total execution time: 0.1473
DEBUG - 2015-09-26 17:18:59 --> Config Class Initialized
DEBUG - 2015-09-26 17:18:59 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:18:59 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:18:59 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:18:59 --> URI Class Initialized
DEBUG - 2015-09-26 17:18:59 --> Router Class Initialized
ERROR - 2015-09-26 17:18:59 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:19:43 --> Config Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:19:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:19:43 --> URI Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Router Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Output Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Security Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Input Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:19:43 --> Language Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Language Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Config Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Loader Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:19:43 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:19:43 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:19:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:19:43 --> Session Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:19:43 --> Session routines successfully run
DEBUG - 2015-09-26 17:19:43 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Email Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Controller Class Initialized
DEBUG - 2015-09-26 17:19:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:19:43 --> Model Class Initialized
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:19:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:19:43 --> Final output sent to browser
DEBUG - 2015-09-26 17:19:43 --> Total execution time: 0.1572
DEBUG - 2015-09-26 17:19:45 --> Config Class Initialized
DEBUG - 2015-09-26 17:19:45 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:19:45 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:19:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:19:45 --> URI Class Initialized
DEBUG - 2015-09-26 17:19:45 --> Router Class Initialized
ERROR - 2015-09-26 17:19:45 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:19:56 --> Config Class Initialized
DEBUG - 2015-09-26 17:19:56 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:19:56 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:19:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:19:56 --> URI Class Initialized
DEBUG - 2015-09-26 17:19:56 --> Router Class Initialized
ERROR - 2015-09-26 17:19:56 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 17:25:21 --> Config Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:25:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:25:21 --> URI Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Router Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Output Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Security Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Input Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 17:25:21 --> Language Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Language Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Config Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Loader Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Helper loaded: url_helper
DEBUG - 2015-09-26 17:25:21 --> Helper loaded: form_helper
DEBUG - 2015-09-26 17:25:21 --> Database Driver Class Initialized
ERROR - 2015-09-26 17:25:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 17:25:21 --> Session Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Helper loaded: string_helper
DEBUG - 2015-09-26 17:25:21 --> Session routines successfully run
DEBUG - 2015-09-26 17:25:21 --> Form Validation Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Pagination Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Encrypt Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Email Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Controller Class Initialized
DEBUG - 2015-09-26 17:25:21 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 17:25:21 --> Model Class Initialized
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 17:25:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 17:25:21 --> Final output sent to browser
DEBUG - 2015-09-26 17:25:21 --> Total execution time: 0.1388
DEBUG - 2015-09-26 17:25:23 --> Config Class Initialized
DEBUG - 2015-09-26 17:25:23 --> Hooks Class Initialized
DEBUG - 2015-09-26 17:25:23 --> Utf8 Class Initialized
DEBUG - 2015-09-26 17:25:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 17:25:23 --> URI Class Initialized
DEBUG - 2015-09-26 17:25:23 --> Router Class Initialized
ERROR - 2015-09-26 17:25:23 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 18:47:42 --> Config Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:47:42 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:47:42 --> URI Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Router Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Output Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Security Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Input Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 18:47:42 --> Language Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Language Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Config Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Loader Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Helper loaded: url_helper
DEBUG - 2015-09-26 18:47:42 --> Helper loaded: form_helper
DEBUG - 2015-09-26 18:47:42 --> Database Driver Class Initialized
ERROR - 2015-09-26 18:47:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 18:47:42 --> Session Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Helper loaded: string_helper
DEBUG - 2015-09-26 18:47:42 --> Session routines successfully run
DEBUG - 2015-09-26 18:47:42 --> Form Validation Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Pagination Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Encrypt Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Email Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Controller Class Initialized
DEBUG - 2015-09-26 18:47:42 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 18:47:42 --> Model Class Initialized
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 18:47:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 18:47:42 --> Final output sent to browser
DEBUG - 2015-09-26 18:47:42 --> Total execution time: 0.1390
DEBUG - 2015-09-26 18:47:43 --> Config Class Initialized
DEBUG - 2015-09-26 18:47:43 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:47:43 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:47:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:47:43 --> URI Class Initialized
DEBUG - 2015-09-26 18:47:43 --> Router Class Initialized
ERROR - 2015-09-26 18:47:43 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 18:49:18 --> Config Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:49:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:49:18 --> URI Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Router Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Output Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Security Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Input Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 18:49:18 --> Language Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Language Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Config Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Loader Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Helper loaded: url_helper
DEBUG - 2015-09-26 18:49:18 --> Helper loaded: form_helper
DEBUG - 2015-09-26 18:49:18 --> Database Driver Class Initialized
ERROR - 2015-09-26 18:49:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 18:49:18 --> Session Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Helper loaded: string_helper
DEBUG - 2015-09-26 18:49:18 --> Session routines successfully run
DEBUG - 2015-09-26 18:49:18 --> Form Validation Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Pagination Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Encrypt Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Email Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Controller Class Initialized
DEBUG - 2015-09-26 18:49:18 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 18:49:18 --> Model Class Initialized
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 18:49:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 18:49:18 --> Final output sent to browser
DEBUG - 2015-09-26 18:49:18 --> Total execution time: 0.1339
DEBUG - 2015-09-26 18:49:20 --> Config Class Initialized
DEBUG - 2015-09-26 18:49:20 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:49:20 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:49:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:49:20 --> URI Class Initialized
DEBUG - 2015-09-26 18:49:20 --> Router Class Initialized
ERROR - 2015-09-26 18:49:20 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 18:56:26 --> Config Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:56:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:56:26 --> URI Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Router Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Output Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Security Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Input Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 18:56:26 --> Language Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Language Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Config Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Loader Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Helper loaded: url_helper
DEBUG - 2015-09-26 18:56:26 --> Helper loaded: form_helper
DEBUG - 2015-09-26 18:56:26 --> Database Driver Class Initialized
ERROR - 2015-09-26 18:56:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 18:56:26 --> Session Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Helper loaded: string_helper
DEBUG - 2015-09-26 18:56:26 --> Session routines successfully run
DEBUG - 2015-09-26 18:56:26 --> Form Validation Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Pagination Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Encrypt Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Email Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Controller Class Initialized
DEBUG - 2015-09-26 18:56:26 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 18:56:26 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 18:56:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 18:56:26 --> Final output sent to browser
DEBUG - 2015-09-26 18:56:26 --> Total execution time: 0.1487
DEBUG - 2015-09-26 18:56:28 --> Config Class Initialized
DEBUG - 2015-09-26 18:56:28 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:56:28 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:56:28 --> URI Class Initialized
DEBUG - 2015-09-26 18:56:28 --> Router Class Initialized
ERROR - 2015-09-26 18:56:28 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 18:56:43 --> Config Class Initialized
DEBUG - 2015-09-26 18:56:43 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:56:43 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:56:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:56:44 --> URI Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Router Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Output Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Security Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Input Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 18:56:44 --> Language Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Language Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Config Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Loader Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Helper loaded: url_helper
DEBUG - 2015-09-26 18:56:44 --> Helper loaded: form_helper
DEBUG - 2015-09-26 18:56:44 --> Database Driver Class Initialized
ERROR - 2015-09-26 18:56:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 18:56:44 --> Session Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Helper loaded: string_helper
DEBUG - 2015-09-26 18:56:44 --> Session routines successfully run
DEBUG - 2015-09-26 18:56:44 --> Form Validation Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Pagination Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Encrypt Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Email Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Controller Class Initialized
DEBUG - 2015-09-26 18:56:44 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 18:56:44 --> Model Class Initialized
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 18:56:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 18:56:44 --> Final output sent to browser
DEBUG - 2015-09-26 18:56:44 --> Total execution time: 0.1416
DEBUG - 2015-09-26 18:56:45 --> Config Class Initialized
DEBUG - 2015-09-26 18:56:45 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:56:45 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:56:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:56:45 --> URI Class Initialized
DEBUG - 2015-09-26 18:56:45 --> Router Class Initialized
ERROR - 2015-09-26 18:56:45 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 18:57:17 --> Config Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:57:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:57:17 --> URI Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Router Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Output Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Security Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Input Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 18:57:17 --> Language Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Language Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Config Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Loader Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Helper loaded: url_helper
DEBUG - 2015-09-26 18:57:17 --> Helper loaded: form_helper
DEBUG - 2015-09-26 18:57:17 --> Database Driver Class Initialized
ERROR - 2015-09-26 18:57:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 18:57:17 --> Session Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Helper loaded: string_helper
DEBUG - 2015-09-26 18:57:17 --> Session routines successfully run
DEBUG - 2015-09-26 18:57:17 --> Form Validation Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Pagination Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Encrypt Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Email Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Controller Class Initialized
DEBUG - 2015-09-26 18:57:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 18:57:17 --> Model Class Initialized
DEBUG - 2015-09-26 18:57:18 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 18:57:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 18:57:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 18:57:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 18:57:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 18:57:18 --> Final output sent to browser
DEBUG - 2015-09-26 18:57:18 --> Total execution time: 0.1484
DEBUG - 2015-09-26 18:57:19 --> Config Class Initialized
DEBUG - 2015-09-26 18:57:19 --> Hooks Class Initialized
DEBUG - 2015-09-26 18:57:19 --> Utf8 Class Initialized
DEBUG - 2015-09-26 18:57:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 18:57:19 --> URI Class Initialized
DEBUG - 2015-09-26 18:57:19 --> Router Class Initialized
ERROR - 2015-09-26 18:57:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:00:13 --> Config Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:00:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:00:13 --> URI Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Router Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Output Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Security Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Input Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:00:13 --> Language Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Language Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Config Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Loader Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:00:13 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:00:13 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:00:13 --> Session Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:00:13 --> Session routines successfully run
DEBUG - 2015-09-26 19:00:13 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Email Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Controller Class Initialized
DEBUG - 2015-09-26 19:00:13 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:00:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:00:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:00:13 --> Final output sent to browser
DEBUG - 2015-09-26 19:00:13 --> Total execution time: 0.1433
DEBUG - 2015-09-26 19:00:14 --> Config Class Initialized
DEBUG - 2015-09-26 19:00:14 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:00:14 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:00:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:00:14 --> URI Class Initialized
DEBUG - 2015-09-26 19:00:14 --> Router Class Initialized
ERROR - 2015-09-26 19:00:14 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:01:03 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:03 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:03 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Router Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Output Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Security Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Input Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:01:03 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Loader Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:01:03 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:01:03 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:01:03 --> Session Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:01:03 --> Session routines successfully run
DEBUG - 2015-09-26 19:01:03 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Email Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Controller Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Individual MX_Controller Initialized
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:01:03 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:03 --> Image Lib Class Initialized
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:01:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:01:03 --> Final output sent to browser
DEBUG - 2015-09-26 19:01:03 --> Total execution time: 0.1676
DEBUG - 2015-09-26 19:01:04 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:04 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:04 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:04 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:04 --> Router Class Initialized
ERROR - 2015-09-26 19:01:04 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:01:10 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:10 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Router Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Output Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Security Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Input Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:01:10 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Loader Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:01:10 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:01:10 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:01:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:01:10 --> Session Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:01:10 --> Session routines successfully run
DEBUG - 2015-09-26 19:01:10 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Email Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Controller Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Individual MX_Controller Initialized
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:01:10 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:10 --> Image Lib Class Initialized
DEBUG - 2015-09-26 19:01:10 --> DB Transaction Failure
ERROR - 2015-09-26 19:01:10 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-09-26 19:01:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-09-26 19:01:12 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:12 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:12 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Router Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Output Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Security Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Input Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:01:12 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Loader Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:01:12 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:01:12 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:01:12 --> Session Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:01:12 --> Session routines successfully run
DEBUG - 2015-09-26 19:01:12 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Email Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Controller Class Initialized
DEBUG - 2015-09-26 19:01:12 --> Individual MX_Controller Initialized
DEBUG - 2015-09-26 19:01:12 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:01:12 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:01:12 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:01:12 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:01:12 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:01:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:01:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:01:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:01:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:01:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:01:13 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:13 --> Image Lib Class Initialized
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:01:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:01:13 --> Final output sent to browser
DEBUG - 2015-09-26 19:01:13 --> Total execution time: 0.1553
DEBUG - 2015-09-26 19:01:14 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:14 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:14 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:14 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:14 --> Router Class Initialized
ERROR - 2015-09-26 19:01:14 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:01:19 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:19 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Router Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Output Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Security Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Input Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:01:19 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Loader Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:01:19 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:01:19 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:01:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:01:19 --> Session Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:01:19 --> Session routines successfully run
DEBUG - 2015-09-26 19:01:19 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Email Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Controller Class Initialized
DEBUG - 2015-09-26 19:01:19 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:01:19 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:01:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:01:19 --> Final output sent to browser
DEBUG - 2015-09-26 19:01:19 --> Total execution time: 0.1334
DEBUG - 2015-09-26 19:01:21 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:21 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:21 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:21 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:21 --> Router Class Initialized
ERROR - 2015-09-26 19:01:21 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:01:25 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:25 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Router Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Output Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Security Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Input Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:01:25 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Loader Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:01:25 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:01:25 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:01:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:01:25 --> Session Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:01:25 --> Session routines successfully run
DEBUG - 2015-09-26 19:01:25 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Email Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Controller Class Initialized
DEBUG - 2015-09-26 19:01:25 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:01:25 --> Model Class Initialized
ERROR - 2015-09-26 19:01:25 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-26 19:01:25 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-26 19:01:25 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-26 19:01:25 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
ERROR - 2015-09-26 19:01:25 --> Severity: Notice  --> Undefined variable: compounding_period_id C:\wamp\www\mfi\application\modules\microfinance\views\savings_plan\add_savings_plan.php 99
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/microfinance/views/savings_plan/add_savings_plan.php
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:01:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:01:25 --> Final output sent to browser
DEBUG - 2015-09-26 19:01:25 --> Total execution time: 0.1383
DEBUG - 2015-09-26 19:01:26 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:26 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:26 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:26 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:26 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:26 --> Router Class Initialized
ERROR - 2015-09-26 19:01:26 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:01:31 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:31 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Router Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Output Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Security Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Input Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:01:31 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Loader Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:01:31 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:01:31 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:01:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:01:31 --> Session Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:01:31 --> Session routines successfully run
DEBUG - 2015-09-26 19:01:31 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Email Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Controller Class Initialized
DEBUG - 2015-09-26 19:01:31 --> Savings_plan MX_Controller Initialized
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:01:31 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/microfinance/views/savings_plan/all_savings_plan.php
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:01:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:01:31 --> Final output sent to browser
DEBUG - 2015-09-26 19:01:31 --> Total execution time: 0.1493
DEBUG - 2015-09-26 19:01:32 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:32 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:32 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:32 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:32 --> Router Class Initialized
ERROR - 2015-09-26 19:01:32 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:01:50 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:50 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Router Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Output Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Security Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Input Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:01:50 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Language Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Loader Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:01:50 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:01:50 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:01:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:01:50 --> Session Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:01:50 --> Session routines successfully run
DEBUG - 2015-09-26 19:01:50 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Email Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Controller Class Initialized
DEBUG - 2015-09-26 19:01:50 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:01:50 --> Model Class Initialized
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:01:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:01:50 --> Final output sent to browser
DEBUG - 2015-09-26 19:01:50 --> Total execution time: 0.1295
DEBUG - 2015-09-26 19:01:51 --> Config Class Initialized
DEBUG - 2015-09-26 19:01:51 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:01:51 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:01:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:01:51 --> URI Class Initialized
DEBUG - 2015-09-26 19:01:51 --> Router Class Initialized
ERROR - 2015-09-26 19:01:51 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:02:58 --> Config Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:02:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:02:58 --> URI Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Router Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Output Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Security Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Input Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:02:58 --> Language Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Language Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Config Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Loader Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:02:58 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:02:58 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:02:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:02:58 --> Session Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:02:58 --> Session routines successfully run
DEBUG - 2015-09-26 19:02:58 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Email Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Controller Class Initialized
DEBUG - 2015-09-26 19:02:58 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:02:58 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:02:59 --> Model Class Initialized
DEBUG - 2015-09-26 19:02:59 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 19:02:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:02:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:02:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:02:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:02:59 --> Final output sent to browser
DEBUG - 2015-09-26 19:02:59 --> Total execution time: 0.1346
DEBUG - 2015-09-26 19:03:00 --> Config Class Initialized
DEBUG - 2015-09-26 19:03:00 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:03:00 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:03:00 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:03:00 --> URI Class Initialized
DEBUG - 2015-09-26 19:03:00 --> Router Class Initialized
ERROR - 2015-09-26 19:03:00 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:04:49 --> Config Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:04:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:04:49 --> URI Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Router Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Output Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Security Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Input Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:04:49 --> Language Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Language Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Config Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Loader Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:04:49 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:04:49 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:04:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:04:49 --> Session Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:04:49 --> Session routines successfully run
DEBUG - 2015-09-26 19:04:49 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Email Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Controller Class Initialized
DEBUG - 2015-09-26 19:04:49 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:04:49 --> Model Class Initialized
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:04:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:04:49 --> Final output sent to browser
DEBUG - 2015-09-26 19:04:49 --> Total execution time: 0.1565
DEBUG - 2015-09-26 19:04:50 --> Config Class Initialized
DEBUG - 2015-09-26 19:04:50 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:04:50 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:04:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:04:50 --> URI Class Initialized
DEBUG - 2015-09-26 19:04:50 --> Router Class Initialized
ERROR - 2015-09-26 19:04:50 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 19:07:55 --> Config Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:07:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:07:55 --> URI Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Router Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Output Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Security Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Input Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 19:07:55 --> Language Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Language Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Config Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Loader Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Helper loaded: url_helper
DEBUG - 2015-09-26 19:07:55 --> Helper loaded: form_helper
DEBUG - 2015-09-26 19:07:55 --> Database Driver Class Initialized
ERROR - 2015-09-26 19:07:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 19:07:55 --> Session Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Helper loaded: string_helper
DEBUG - 2015-09-26 19:07:55 --> Session routines successfully run
DEBUG - 2015-09-26 19:07:55 --> Form Validation Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Pagination Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Encrypt Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Email Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Controller Class Initialized
DEBUG - 2015-09-26 19:07:55 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 19:07:55 --> Model Class Initialized
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 19:07:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 19:07:55 --> Final output sent to browser
DEBUG - 2015-09-26 19:07:55 --> Total execution time: 0.1486
DEBUG - 2015-09-26 19:07:57 --> Config Class Initialized
DEBUG - 2015-09-26 19:07:57 --> Hooks Class Initialized
DEBUG - 2015-09-26 19:07:57 --> Utf8 Class Initialized
DEBUG - 2015-09-26 19:07:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 19:07:57 --> URI Class Initialized
DEBUG - 2015-09-26 19:07:57 --> Router Class Initialized
ERROR - 2015-09-26 19:07:57 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:02:11 --> Config Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:02:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:02:11 --> URI Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Router Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Output Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Security Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Input Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:02:11 --> Language Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Language Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Config Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Loader Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:02:11 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:02:11 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:02:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:02:11 --> Session Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:02:11 --> Session routines successfully run
DEBUG - 2015-09-26 20:02:11 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Email Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Controller Class Initialized
DEBUG - 2015-09-26 20:02:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:02:11 --> Model Class Initialized
DEBUG - 2015-09-26 20:02:12 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:02:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:02:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:02:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:02:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:02:12 --> Final output sent to browser
DEBUG - 2015-09-26 20:02:12 --> Total execution time: 0.1419
DEBUG - 2015-09-26 20:02:13 --> Config Class Initialized
DEBUG - 2015-09-26 20:02:13 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:02:13 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:02:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:02:13 --> URI Class Initialized
DEBUG - 2015-09-26 20:02:13 --> Router Class Initialized
ERROR - 2015-09-26 20:02:13 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:03:47 --> Config Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:03:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:03:47 --> URI Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Router Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Output Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Security Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Input Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:03:47 --> Language Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Language Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Config Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Loader Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:03:47 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:03:47 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:03:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:03:47 --> Session Class Initialized
DEBUG - 2015-09-26 20:03:47 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:03:47 --> Session routines successfully run
DEBUG - 2015-09-26 20:03:48 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:03:48 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:03:48 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:03:48 --> Email Class Initialized
DEBUG - 2015-09-26 20:03:48 --> Controller Class Initialized
DEBUG - 2015-09-26 20:03:48 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:03:48 --> Model Class Initialized
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:03:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:03:48 --> Final output sent to browser
DEBUG - 2015-09-26 20:03:48 --> Total execution time: 0.1385
DEBUG - 2015-09-26 20:03:49 --> Config Class Initialized
DEBUG - 2015-09-26 20:03:49 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:03:49 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:03:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:03:49 --> URI Class Initialized
DEBUG - 2015-09-26 20:03:49 --> Router Class Initialized
ERROR - 2015-09-26 20:03:49 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:07:50 --> Config Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:07:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:07:50 --> URI Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Router Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Output Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Security Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Input Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:07:50 --> Language Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Language Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Config Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Loader Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:07:50 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:07:50 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:07:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:07:50 --> Session Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:07:50 --> Session routines successfully run
DEBUG - 2015-09-26 20:07:50 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Email Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Controller Class Initialized
DEBUG - 2015-09-26 20:07:50 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:07:50 --> Model Class Initialized
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:07:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:07:50 --> Final output sent to browser
DEBUG - 2015-09-26 20:07:50 --> Total execution time: 0.2812
DEBUG - 2015-09-26 20:07:52 --> Config Class Initialized
DEBUG - 2015-09-26 20:07:52 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:07:52 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:07:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:07:52 --> URI Class Initialized
DEBUG - 2015-09-26 20:07:52 --> Router Class Initialized
ERROR - 2015-09-26 20:07:52 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:10:39 --> Config Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:10:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:10:39 --> URI Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Router Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Output Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Security Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Input Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:10:39 --> Language Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Language Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Config Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Loader Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:10:39 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:10:39 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:10:39 --> Session Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:10:39 --> Session routines successfully run
DEBUG - 2015-09-26 20:10:39 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Email Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Controller Class Initialized
DEBUG - 2015-09-26 20:10:39 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:10:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:10:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:10:39 --> Final output sent to browser
DEBUG - 2015-09-26 20:10:39 --> Total execution time: 0.2852
DEBUG - 2015-09-26 20:13:22 --> Config Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:13:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:13:22 --> URI Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Router Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Output Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Security Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Input Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:13:22 --> Language Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Language Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Config Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Loader Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:13:22 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:13:22 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:13:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:13:22 --> Session Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:13:22 --> Session routines successfully run
DEBUG - 2015-09-26 20:13:22 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Email Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Controller Class Initialized
DEBUG - 2015-09-26 20:13:22 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:13:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:13:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:13:22 --> Final output sent to browser
DEBUG - 2015-09-26 20:13:22 --> Total execution time: 0.2405
DEBUG - 2015-09-26 20:18:55 --> Config Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:18:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:18:55 --> URI Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Router Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Output Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Security Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Input Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:18:55 --> Language Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Language Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Config Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Loader Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:18:55 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:18:55 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:18:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:18:55 --> Session Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:18:55 --> Session routines successfully run
DEBUG - 2015-09-26 20:18:55 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Email Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Controller Class Initialized
DEBUG - 2015-09-26 20:18:55 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:18:55 --> Model Class Initialized
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:18:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:18:55 --> Final output sent to browser
DEBUG - 2015-09-26 20:18:55 --> Total execution time: 0.2503
DEBUG - 2015-09-26 20:21:16 --> Config Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:21:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:21:16 --> URI Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Router Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Output Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Security Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Input Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:21:16 --> Language Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Language Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Config Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Loader Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:21:16 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:21:16 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:21:16 --> Session Class Initialized
DEBUG - 2015-09-26 20:21:16 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:21:16 --> Session routines successfully run
DEBUG - 2015-09-26 20:21:16 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:21:17 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:21:17 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:21:17 --> Email Class Initialized
DEBUG - 2015-09-26 20:21:17 --> Controller Class Initialized
DEBUG - 2015-09-26 20:21:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:21:17 --> Model Class Initialized
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:21:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:21:17 --> Final output sent to browser
DEBUG - 2015-09-26 20:21:17 --> Total execution time: 0.2368
DEBUG - 2015-09-26 20:23:19 --> Config Class Initialized
DEBUG - 2015-09-26 20:23:19 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:23:19 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:23:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:23:19 --> URI Class Initialized
DEBUG - 2015-09-26 20:23:19 --> Router Class Initialized
ERROR - 2015-09-26 20:23:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:25:05 --> Config Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:25:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:25:05 --> URI Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Router Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Output Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Security Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Input Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:25:05 --> Language Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Language Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Config Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Loader Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:25:05 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:25:05 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:25:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:25:05 --> Session Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:25:05 --> Session routines successfully run
DEBUG - 2015-09-26 20:25:05 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Email Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Controller Class Initialized
DEBUG - 2015-09-26 20:25:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:25:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:25:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:25:05 --> Final output sent to browser
DEBUG - 2015-09-26 20:25:05 --> Total execution time: 0.2754
DEBUG - 2015-09-26 20:25:08 --> Config Class Initialized
DEBUG - 2015-09-26 20:25:08 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:25:08 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:25:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:25:08 --> URI Class Initialized
DEBUG - 2015-09-26 20:25:08 --> Router Class Initialized
ERROR - 2015-09-26 20:25:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:26:52 --> Config Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:26:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:26:52 --> URI Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Router Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Output Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Security Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Input Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:26:52 --> Language Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Language Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Config Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Loader Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:26:52 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:26:52 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:26:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:26:52 --> Session Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:26:52 --> Session routines successfully run
DEBUG - 2015-09-26 20:26:52 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Email Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Controller Class Initialized
DEBUG - 2015-09-26 20:26:52 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:26:52 --> Model Class Initialized
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:26:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:26:52 --> Final output sent to browser
DEBUG - 2015-09-26 20:26:52 --> Total execution time: 0.2655
DEBUG - 2015-09-26 20:26:54 --> Config Class Initialized
DEBUG - 2015-09-26 20:26:54 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:26:54 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:26:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:26:54 --> URI Class Initialized
DEBUG - 2015-09-26 20:26:54 --> Router Class Initialized
ERROR - 2015-09-26 20:26:54 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:28:19 --> Config Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:28:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:28:19 --> URI Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Router Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Output Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Security Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Input Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:28:19 --> Language Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Language Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Config Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Loader Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:28:19 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:28:19 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:28:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:28:19 --> Session Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:28:19 --> Session routines successfully run
DEBUG - 2015-09-26 20:28:19 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Email Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Controller Class Initialized
DEBUG - 2015-09-26 20:28:19 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:28:19 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:28:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:28:19 --> Final output sent to browser
DEBUG - 2015-09-26 20:28:19 --> Total execution time: 0.2552
DEBUG - 2015-09-26 20:28:22 --> Config Class Initialized
DEBUG - 2015-09-26 20:28:22 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:28:22 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:28:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:28:22 --> URI Class Initialized
DEBUG - 2015-09-26 20:28:22 --> Router Class Initialized
ERROR - 2015-09-26 20:28:22 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:28:43 --> Config Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:28:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:28:43 --> URI Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Router Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Output Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Security Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Input Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:28:43 --> Language Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Language Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Config Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Loader Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:28:43 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:28:43 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:28:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:28:43 --> Session Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:28:43 --> Session routines successfully run
DEBUG - 2015-09-26 20:28:43 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Email Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Controller Class Initialized
DEBUG - 2015-09-26 20:28:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:28:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:28:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:28:43 --> Final output sent to browser
DEBUG - 2015-09-26 20:28:43 --> Total execution time: 0.3153
DEBUG - 2015-09-26 20:28:45 --> Config Class Initialized
DEBUG - 2015-09-26 20:28:45 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:28:45 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:28:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:28:45 --> URI Class Initialized
DEBUG - 2015-09-26 20:28:46 --> Router Class Initialized
ERROR - 2015-09-26 20:28:46 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:30:01 --> Config Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:30:01 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:30:01 --> URI Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Router Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Output Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Security Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Input Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:30:01 --> Language Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Language Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Config Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Loader Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:30:01 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:30:01 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:30:01 --> Session Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:30:01 --> Session routines successfully run
DEBUG - 2015-09-26 20:30:01 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Email Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Controller Class Initialized
DEBUG - 2015-09-26 20:30:01 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:30:01 --> Model Class Initialized
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:30:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:30:01 --> Final output sent to browser
DEBUG - 2015-09-26 20:30:01 --> Total execution time: 0.2481
DEBUG - 2015-09-26 20:30:03 --> Config Class Initialized
DEBUG - 2015-09-26 20:30:03 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:30:03 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:30:03 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:30:03 --> URI Class Initialized
DEBUG - 2015-09-26 20:30:03 --> Router Class Initialized
ERROR - 2015-09-26 20:30:03 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:32:38 --> Config Class Initialized
DEBUG - 2015-09-26 20:32:38 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:32:38 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:32:38 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:32:38 --> URI Class Initialized
DEBUG - 2015-09-26 20:32:38 --> Router Class Initialized
DEBUG - 2015-09-26 20:32:38 --> Output Class Initialized
DEBUG - 2015-09-26 20:32:38 --> Security Class Initialized
DEBUG - 2015-09-26 20:32:38 --> Input Class Initialized
DEBUG - 2015-09-26 20:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:32:38 --> Language Class Initialized
DEBUG - 2015-09-26 20:32:38 --> Language Class Initialized
DEBUG - 2015-09-26 20:32:39 --> Config Class Initialized
DEBUG - 2015-09-26 20:32:39 --> Loader Class Initialized
DEBUG - 2015-09-26 20:32:39 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:32:39 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:32:39 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:32:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:32:39 --> Session Class Initialized
DEBUG - 2015-09-26 20:32:39 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:32:39 --> Session routines successfully run
DEBUG - 2015-09-26 20:32:39 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:32:39 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:32:39 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:32:39 --> Email Class Initialized
DEBUG - 2015-09-26 20:32:39 --> Controller Class Initialized
DEBUG - 2015-09-26 20:32:39 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:32:39 --> Model Class Initialized
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:32:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:32:39 --> Final output sent to browser
DEBUG - 2015-09-26 20:32:39 --> Total execution time: 0.2644
DEBUG - 2015-09-26 20:32:41 --> Config Class Initialized
DEBUG - 2015-09-26 20:32:41 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:32:41 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:32:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:32:41 --> URI Class Initialized
DEBUG - 2015-09-26 20:32:41 --> Router Class Initialized
ERROR - 2015-09-26 20:32:41 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:34:20 --> Config Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:34:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:34:20 --> URI Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Router Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Output Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Security Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Input Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:34:20 --> Language Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Language Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Config Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Loader Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:34:20 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:34:20 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:34:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:34:20 --> Session Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:34:20 --> Session routines successfully run
DEBUG - 2015-09-26 20:34:20 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Email Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Controller Class Initialized
DEBUG - 2015-09-26 20:34:20 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:34:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:34:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:34:20 --> Final output sent to browser
DEBUG - 2015-09-26 20:34:20 --> Total execution time: 0.2261
DEBUG - 2015-09-26 20:34:22 --> Config Class Initialized
DEBUG - 2015-09-26 20:34:22 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:34:22 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:34:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:34:22 --> URI Class Initialized
DEBUG - 2015-09-26 20:34:22 --> Router Class Initialized
ERROR - 2015-09-26 20:34:22 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:34:41 --> Config Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:34:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:34:41 --> URI Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Router Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Output Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Security Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Input Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:34:41 --> Language Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Language Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Config Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Loader Class Initialized
DEBUG - 2015-09-26 20:34:41 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:34:41 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:34:41 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:34:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:34:42 --> Session Class Initialized
DEBUG - 2015-09-26 20:34:42 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:34:42 --> Session routines successfully run
DEBUG - 2015-09-26 20:34:42 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:34:42 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:34:42 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:34:42 --> Email Class Initialized
DEBUG - 2015-09-26 20:34:42 --> Controller Class Initialized
DEBUG - 2015-09-26 20:34:42 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:34:42 --> Model Class Initialized
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:34:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:34:42 --> Final output sent to browser
DEBUG - 2015-09-26 20:34:42 --> Total execution time: 0.2565
DEBUG - 2015-09-26 20:34:44 --> Config Class Initialized
DEBUG - 2015-09-26 20:34:44 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:34:44 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:34:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:34:44 --> URI Class Initialized
DEBUG - 2015-09-26 20:34:44 --> Router Class Initialized
ERROR - 2015-09-26 20:34:44 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:42:46 --> Config Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:42:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:42:46 --> URI Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Router Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Output Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Security Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Input Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:42:46 --> Language Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Language Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Config Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Loader Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:42:46 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:42:46 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:42:46 --> Session Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:42:46 --> Session routines successfully run
DEBUG - 2015-09-26 20:42:46 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Email Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Controller Class Initialized
DEBUG - 2015-09-26 20:42:46 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:42:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:42:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:42:46 --> Final output sent to browser
DEBUG - 2015-09-26 20:42:46 --> Total execution time: 0.3046
DEBUG - 2015-09-26 20:42:49 --> Config Class Initialized
DEBUG - 2015-09-26 20:42:49 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:42:49 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:42:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:42:49 --> URI Class Initialized
DEBUG - 2015-09-26 20:42:49 --> Router Class Initialized
ERROR - 2015-09-26 20:42:49 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:43:20 --> Config Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:43:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:43:20 --> URI Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Router Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Output Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Security Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Input Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:43:20 --> Language Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Language Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Config Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Loader Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:43:20 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:43:20 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:43:20 --> Session Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:43:20 --> Session routines successfully run
DEBUG - 2015-09-26 20:43:20 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Email Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Controller Class Initialized
DEBUG - 2015-09-26 20:43:20 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:43:20 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:43:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:43:20 --> Final output sent to browser
DEBUG - 2015-09-26 20:43:20 --> Total execution time: 0.2598
DEBUG - 2015-09-26 20:43:23 --> Config Class Initialized
DEBUG - 2015-09-26 20:43:23 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:43:23 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:43:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:43:23 --> URI Class Initialized
DEBUG - 2015-09-26 20:43:23 --> Router Class Initialized
ERROR - 2015-09-26 20:43:23 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:43:46 --> Config Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:43:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:43:46 --> URI Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Router Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Output Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Security Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Input Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:43:46 --> Language Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Language Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Config Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Loader Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:43:46 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:43:46 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:43:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:43:46 --> Session Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:43:46 --> Session routines successfully run
DEBUG - 2015-09-26 20:43:46 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Email Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Controller Class Initialized
DEBUG - 2015-09-26 20:43:46 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:43:46 --> Model Class Initialized
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:43:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:43:46 --> Final output sent to browser
DEBUG - 2015-09-26 20:43:46 --> Total execution time: 0.2360
DEBUG - 2015-09-26 20:43:49 --> Config Class Initialized
DEBUG - 2015-09-26 20:43:49 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:43:49 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:43:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:43:49 --> URI Class Initialized
DEBUG - 2015-09-26 20:43:49 --> Router Class Initialized
ERROR - 2015-09-26 20:43:49 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:44:05 --> Config Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:44:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:44:05 --> URI Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Router Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Output Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Security Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Input Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:44:05 --> Language Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Language Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Config Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Loader Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:44:05 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:44:05 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:44:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:44:05 --> Session Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:44:05 --> Session routines successfully run
DEBUG - 2015-09-26 20:44:05 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Email Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Controller Class Initialized
DEBUG - 2015-09-26 20:44:05 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:44:05 --> Model Class Initialized
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:44:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:44:05 --> Final output sent to browser
DEBUG - 2015-09-26 20:44:05 --> Total execution time: 0.2696
DEBUG - 2015-09-26 20:44:08 --> Config Class Initialized
DEBUG - 2015-09-26 20:44:08 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:44:08 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:44:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:44:08 --> URI Class Initialized
DEBUG - 2015-09-26 20:44:08 --> Router Class Initialized
ERROR - 2015-09-26 20:44:08 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:47:42 --> Config Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:47:42 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:47:42 --> URI Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Router Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Output Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Security Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Input Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:47:42 --> Language Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Language Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Config Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Loader Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:47:42 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:47:42 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:47:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:47:42 --> Session Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:47:42 --> Session routines successfully run
DEBUG - 2015-09-26 20:47:42 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Email Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Controller Class Initialized
DEBUG - 2015-09-26 20:47:42 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:47:43 --> Model Class Initialized
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:47:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:47:43 --> Final output sent to browser
DEBUG - 2015-09-26 20:47:43 --> Total execution time: 0.2347
DEBUG - 2015-09-26 20:47:45 --> Config Class Initialized
DEBUG - 2015-09-26 20:47:45 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:47:45 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:47:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:47:45 --> URI Class Initialized
DEBUG - 2015-09-26 20:47:45 --> Router Class Initialized
ERROR - 2015-09-26 20:47:45 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 20:52:21 --> Config Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:52:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:52:21 --> URI Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Router Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Output Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Security Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Input Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 20:52:21 --> Language Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Language Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Config Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Loader Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Helper loaded: url_helper
DEBUG - 2015-09-26 20:52:21 --> Helper loaded: form_helper
DEBUG - 2015-09-26 20:52:21 --> Database Driver Class Initialized
ERROR - 2015-09-26 20:52:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 20:52:21 --> Session Class Initialized
DEBUG - 2015-09-26 20:52:21 --> Helper loaded: string_helper
DEBUG - 2015-09-26 20:52:21 --> Session routines successfully run
DEBUG - 2015-09-26 20:52:21 --> Form Validation Class Initialized
DEBUG - 2015-09-26 20:52:22 --> Pagination Class Initialized
DEBUG - 2015-09-26 20:52:22 --> Encrypt Class Initialized
DEBUG - 2015-09-26 20:52:22 --> Email Class Initialized
DEBUG - 2015-09-26 20:52:22 --> Controller Class Initialized
DEBUG - 2015-09-26 20:52:22 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 20:52:22 --> Model Class Initialized
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 20:52:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 20:52:22 --> Final output sent to browser
DEBUG - 2015-09-26 20:52:22 --> Total execution time: 0.2546
DEBUG - 2015-09-26 20:52:24 --> Config Class Initialized
DEBUG - 2015-09-26 20:52:24 --> Hooks Class Initialized
DEBUG - 2015-09-26 20:52:24 --> Utf8 Class Initialized
DEBUG - 2015-09-26 20:52:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 20:52:24 --> URI Class Initialized
DEBUG - 2015-09-26 20:52:24 --> Router Class Initialized
ERROR - 2015-09-26 20:52:24 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 21:57:09 --> Config Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Hooks Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Utf8 Class Initialized
DEBUG - 2015-09-26 21:57:09 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 21:57:09 --> URI Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Router Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Output Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Security Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Input Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 21:57:09 --> Language Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Language Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Config Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Loader Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Helper loaded: url_helper
DEBUG - 2015-09-26 21:57:09 --> Helper loaded: form_helper
DEBUG - 2015-09-26 21:57:09 --> Database Driver Class Initialized
ERROR - 2015-09-26 21:57:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 21:57:09 --> Session Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Helper loaded: string_helper
DEBUG - 2015-09-26 21:57:09 --> Session routines successfully run
DEBUG - 2015-09-26 21:57:09 --> Form Validation Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Pagination Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Encrypt Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Email Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Controller Class Initialized
DEBUG - 2015-09-26 21:57:09 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 21:57:09 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 21:57:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 21:57:09 --> Final output sent to browser
DEBUG - 2015-09-26 21:57:09 --> Total execution time: 0.2446
DEBUG - 2015-09-26 21:57:11 --> Config Class Initialized
DEBUG - 2015-09-26 21:57:11 --> Hooks Class Initialized
DEBUG - 2015-09-26 21:57:11 --> Utf8 Class Initialized
DEBUG - 2015-09-26 21:57:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 21:57:11 --> URI Class Initialized
DEBUG - 2015-09-26 21:57:11 --> Router Class Initialized
ERROR - 2015-09-26 21:57:11 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 21:57:47 --> Config Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Hooks Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Utf8 Class Initialized
DEBUG - 2015-09-26 21:57:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 21:57:47 --> URI Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Router Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Output Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Security Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Input Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 21:57:47 --> Language Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Language Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Config Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Loader Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Helper loaded: url_helper
DEBUG - 2015-09-26 21:57:47 --> Helper loaded: form_helper
DEBUG - 2015-09-26 21:57:47 --> Database Driver Class Initialized
ERROR - 2015-09-26 21:57:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 21:57:47 --> Session Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Helper loaded: string_helper
DEBUG - 2015-09-26 21:57:47 --> Session routines successfully run
DEBUG - 2015-09-26 21:57:47 --> Form Validation Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Pagination Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Encrypt Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Email Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Controller Class Initialized
DEBUG - 2015-09-26 21:57:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 21:57:47 --> Model Class Initialized
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 21:57:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 21:57:47 --> Final output sent to browser
DEBUG - 2015-09-26 21:57:47 --> Total execution time: 0.2310
DEBUG - 2015-09-26 21:58:34 --> Config Class Initialized
DEBUG - 2015-09-26 21:58:34 --> Hooks Class Initialized
DEBUG - 2015-09-26 21:58:34 --> Utf8 Class Initialized
DEBUG - 2015-09-26 21:58:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 21:58:34 --> URI Class Initialized
DEBUG - 2015-09-26 21:58:34 --> Router Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Output Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Security Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Input Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 21:58:35 --> Language Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Language Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Config Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Loader Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Helper loaded: url_helper
DEBUG - 2015-09-26 21:58:35 --> Helper loaded: form_helper
DEBUG - 2015-09-26 21:58:35 --> Database Driver Class Initialized
ERROR - 2015-09-26 21:58:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 21:58:35 --> Session Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Helper loaded: string_helper
DEBUG - 2015-09-26 21:58:35 --> Session routines successfully run
DEBUG - 2015-09-26 21:58:35 --> Form Validation Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Pagination Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Encrypt Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Email Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Controller Class Initialized
DEBUG - 2015-09-26 21:58:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 21:58:35 --> Model Class Initialized
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 21:58:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 21:58:35 --> Final output sent to browser
DEBUG - 2015-09-26 21:58:35 --> Total execution time: 0.2510
DEBUG - 2015-09-26 21:58:45 --> Config Class Initialized
DEBUG - 2015-09-26 21:58:45 --> Hooks Class Initialized
DEBUG - 2015-09-26 21:58:45 --> Utf8 Class Initialized
DEBUG - 2015-09-26 21:58:45 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 21:58:45 --> URI Class Initialized
DEBUG - 2015-09-26 21:58:45 --> Router Class Initialized
ERROR - 2015-09-26 21:58:45 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 21:59:54 --> Config Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Hooks Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Utf8 Class Initialized
DEBUG - 2015-09-26 21:59:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 21:59:54 --> URI Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Router Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Output Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Security Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Input Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 21:59:54 --> Language Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Language Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Config Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Loader Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Helper loaded: url_helper
DEBUG - 2015-09-26 21:59:54 --> Helper loaded: form_helper
DEBUG - 2015-09-26 21:59:54 --> Database Driver Class Initialized
ERROR - 2015-09-26 21:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 21:59:54 --> Session Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Helper loaded: string_helper
DEBUG - 2015-09-26 21:59:54 --> Session routines successfully run
DEBUG - 2015-09-26 21:59:54 --> Form Validation Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Pagination Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Encrypt Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Email Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Controller Class Initialized
DEBUG - 2015-09-26 21:59:54 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 21:59:54 --> Model Class Initialized
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 21:59:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 21:59:54 --> Final output sent to browser
DEBUG - 2015-09-26 21:59:54 --> Total execution time: 0.2821
DEBUG - 2015-09-26 21:59:56 --> Config Class Initialized
DEBUG - 2015-09-26 21:59:56 --> Hooks Class Initialized
DEBUG - 2015-09-26 21:59:56 --> Utf8 Class Initialized
DEBUG - 2015-09-26 21:59:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 21:59:56 --> URI Class Initialized
DEBUG - 2015-09-26 21:59:56 --> Router Class Initialized
ERROR - 2015-09-26 21:59:56 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:00:16 --> Config Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:00:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:00:16 --> URI Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Router Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Output Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Security Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Input Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:00:16 --> Language Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Language Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Config Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Loader Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:00:16 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:00:16 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:00:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:00:16 --> Session Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:00:16 --> Session routines successfully run
DEBUG - 2015-09-26 22:00:16 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Email Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Controller Class Initialized
DEBUG - 2015-09-26 22:00:16 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:00:16 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:00:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:00:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:00:17 --> Final output sent to browser
DEBUG - 2015-09-26 22:00:17 --> Total execution time: 0.3212
DEBUG - 2015-09-26 22:00:19 --> Config Class Initialized
DEBUG - 2015-09-26 22:00:19 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:00:19 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:00:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:00:19 --> URI Class Initialized
DEBUG - 2015-09-26 22:00:19 --> Router Class Initialized
ERROR - 2015-09-26 22:00:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:00:56 --> Config Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:00:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:00:56 --> URI Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Router Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Output Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Security Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Input Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:00:56 --> Language Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Language Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Config Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Loader Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:00:56 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:00:56 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:00:56 --> Session Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:00:56 --> Session routines successfully run
DEBUG - 2015-09-26 22:00:56 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Email Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Controller Class Initialized
DEBUG - 2015-09-26 22:00:56 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:00:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:00:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:00:56 --> Final output sent to browser
DEBUG - 2015-09-26 22:00:56 --> Total execution time: 0.2915
DEBUG - 2015-09-26 22:00:58 --> Config Class Initialized
DEBUG - 2015-09-26 22:00:58 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:00:58 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:00:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:00:58 --> URI Class Initialized
DEBUG - 2015-09-26 22:00:58 --> Router Class Initialized
ERROR - 2015-09-26 22:00:58 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:03:35 --> Config Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:03:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:03:35 --> URI Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Router Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Output Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Security Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Input Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:03:35 --> Language Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Language Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Config Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Loader Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:03:35 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:03:35 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:03:35 --> Session Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:03:35 --> Session routines successfully run
DEBUG - 2015-09-26 22:03:35 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Email Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Controller Class Initialized
DEBUG - 2015-09-26 22:03:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:03:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:03:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:03:35 --> Final output sent to browser
DEBUG - 2015-09-26 22:03:35 --> Total execution time: 0.2338
DEBUG - 2015-09-26 22:03:38 --> Config Class Initialized
DEBUG - 2015-09-26 22:03:38 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:03:38 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:03:38 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:03:38 --> URI Class Initialized
DEBUG - 2015-09-26 22:03:38 --> Router Class Initialized
ERROR - 2015-09-26 22:03:38 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:03:58 --> Config Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:03:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:03:58 --> URI Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Router Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Output Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Security Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Input Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:03:58 --> Language Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Language Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Config Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Loader Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:03:58 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:03:58 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:03:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:03:58 --> Session Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:03:58 --> Session routines successfully run
DEBUG - 2015-09-26 22:03:58 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Email Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Controller Class Initialized
DEBUG - 2015-09-26 22:03:58 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:03:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:03:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:03:58 --> Final output sent to browser
DEBUG - 2015-09-26 22:03:58 --> Total execution time: 0.2926
DEBUG - 2015-09-26 22:04:00 --> Config Class Initialized
DEBUG - 2015-09-26 22:04:00 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:04:00 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:04:00 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:04:00 --> URI Class Initialized
DEBUG - 2015-09-26 22:04:00 --> Router Class Initialized
ERROR - 2015-09-26 22:04:00 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:04:58 --> Config Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:04:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:04:58 --> URI Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Router Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Output Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Security Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Input Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:04:58 --> Language Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Language Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Config Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Loader Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:04:58 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:04:58 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:04:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:04:58 --> Session Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:04:58 --> Session routines successfully run
DEBUG - 2015-09-26 22:04:58 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Email Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Controller Class Initialized
DEBUG - 2015-09-26 22:04:58 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:04:58 --> Model Class Initialized
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:04:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:04:58 --> Final output sent to browser
DEBUG - 2015-09-26 22:04:58 --> Total execution time: 0.2547
DEBUG - 2015-09-26 22:05:00 --> Config Class Initialized
DEBUG - 2015-09-26 22:05:00 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:05:00 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:05:00 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:05:00 --> URI Class Initialized
DEBUG - 2015-09-26 22:05:00 --> Router Class Initialized
ERROR - 2015-09-26 22:05:00 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:05:18 --> Config Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:05:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:05:18 --> URI Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Router Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Output Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Security Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Input Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:05:18 --> Language Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Language Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Config Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Loader Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:05:18 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:05:18 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:05:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:05:18 --> Session Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:05:18 --> Session routines successfully run
DEBUG - 2015-09-26 22:05:18 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Email Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Controller Class Initialized
DEBUG - 2015-09-26 22:05:18 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:05:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:05:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:05:18 --> Final output sent to browser
DEBUG - 2015-09-26 22:05:18 --> Total execution time: 0.2331
DEBUG - 2015-09-26 22:05:21 --> Config Class Initialized
DEBUG - 2015-09-26 22:05:21 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:05:21 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:05:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:05:21 --> URI Class Initialized
DEBUG - 2015-09-26 22:05:21 --> Router Class Initialized
ERROR - 2015-09-26 22:05:21 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:11:01 --> Config Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:11:01 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:11:01 --> URI Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Router Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Output Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Security Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Input Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:11:01 --> Language Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Language Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Config Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Loader Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:11:01 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:11:01 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:11:01 --> Session Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:11:01 --> Session routines successfully run
DEBUG - 2015-09-26 22:11:01 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Email Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Controller Class Initialized
DEBUG - 2015-09-26 22:11:01 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:11:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:11:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:11:01 --> Final output sent to browser
DEBUG - 2015-09-26 22:11:01 --> Total execution time: 0.2534
DEBUG - 2015-09-26 22:11:03 --> Config Class Initialized
DEBUG - 2015-09-26 22:11:03 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:11:03 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:11:03 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:11:03 --> URI Class Initialized
DEBUG - 2015-09-26 22:11:03 --> Router Class Initialized
ERROR - 2015-09-26 22:11:03 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:11:27 --> Config Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:11:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:11:27 --> URI Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Router Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Output Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Security Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Input Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:11:27 --> Language Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Language Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Config Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Loader Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:11:27 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:11:27 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:11:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:11:27 --> Session Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:11:27 --> Session routines successfully run
DEBUG - 2015-09-26 22:11:27 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Email Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Controller Class Initialized
DEBUG - 2015-09-26 22:11:27 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:11:27 --> Model Class Initialized
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:11:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:11:27 --> Final output sent to browser
DEBUG - 2015-09-26 22:11:27 --> Total execution time: 0.2503
DEBUG - 2015-09-26 22:11:29 --> Config Class Initialized
DEBUG - 2015-09-26 22:11:29 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:11:29 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:11:29 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:11:29 --> URI Class Initialized
DEBUG - 2015-09-26 22:11:29 --> Router Class Initialized
ERROR - 2015-09-26 22:11:29 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:12:47 --> Config Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:12:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:12:47 --> URI Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Router Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Output Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Security Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Input Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:12:47 --> Language Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Language Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Config Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Loader Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:12:47 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:12:47 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:12:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:12:47 --> Session Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:12:47 --> Session routines successfully run
DEBUG - 2015-09-26 22:12:47 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:12:47 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:12:48 --> Email Class Initialized
DEBUG - 2015-09-26 22:12:48 --> Controller Class Initialized
DEBUG - 2015-09-26 22:12:48 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:12:48 --> Model Class Initialized
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:12:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:12:48 --> Final output sent to browser
DEBUG - 2015-09-26 22:12:48 --> Total execution time: 0.2451
DEBUG - 2015-09-26 22:12:50 --> Config Class Initialized
DEBUG - 2015-09-26 22:12:50 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:12:50 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:12:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:12:50 --> URI Class Initialized
DEBUG - 2015-09-26 22:12:50 --> Router Class Initialized
ERROR - 2015-09-26 22:12:50 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:14:00 --> Config Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:14:00 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:14:00 --> URI Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Router Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Output Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Security Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Input Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:14:00 --> Language Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Language Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Config Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Loader Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:14:00 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:14:00 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:14:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:14:00 --> Session Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:14:00 --> Session routines successfully run
DEBUG - 2015-09-26 22:14:00 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Email Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Controller Class Initialized
DEBUG - 2015-09-26 22:14:00 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:14:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:14:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:14:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:14:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:14:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:14:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:14:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:14:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:14:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:14:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:14:01 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:01 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:14:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:14:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:14:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:14:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:14:01 --> Final output sent to browser
DEBUG - 2015-09-26 22:14:01 --> Total execution time: 0.2579
DEBUG - 2015-09-26 22:14:03 --> Config Class Initialized
DEBUG - 2015-09-26 22:14:03 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:14:03 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:14:03 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:14:03 --> URI Class Initialized
DEBUG - 2015-09-26 22:14:03 --> Router Class Initialized
ERROR - 2015-09-26 22:14:03 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:14:46 --> Config Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:14:46 --> URI Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Router Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Output Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Security Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Input Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:14:46 --> Language Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Language Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Config Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Loader Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:14:46 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:14:46 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:14:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:14:46 --> Session Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:14:46 --> Session routines successfully run
DEBUG - 2015-09-26 22:14:46 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Email Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Controller Class Initialized
DEBUG - 2015-09-26 22:14:46 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:14:46 --> Model Class Initialized
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:14:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:14:46 --> Final output sent to browser
DEBUG - 2015-09-26 22:14:46 --> Total execution time: 0.2901
DEBUG - 2015-09-26 22:14:49 --> Config Class Initialized
DEBUG - 2015-09-26 22:14:49 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:14:49 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:14:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:14:49 --> URI Class Initialized
DEBUG - 2015-09-26 22:14:49 --> Router Class Initialized
ERROR - 2015-09-26 22:14:49 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:15:11 --> Config Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:15:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:15:11 --> URI Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Router Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Output Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Security Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Input Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:15:11 --> Language Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Language Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Config Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Loader Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:15:11 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:15:11 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:15:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:15:11 --> Session Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:15:11 --> Session routines successfully run
DEBUG - 2015-09-26 22:15:11 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Email Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Controller Class Initialized
DEBUG - 2015-09-26 22:15:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:15:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:15:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:15:11 --> Final output sent to browser
DEBUG - 2015-09-26 22:15:11 --> Total execution time: 0.2800
DEBUG - 2015-09-26 22:15:14 --> Config Class Initialized
DEBUG - 2015-09-26 22:15:14 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:15:14 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:15:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:15:14 --> URI Class Initialized
DEBUG - 2015-09-26 22:15:14 --> Router Class Initialized
ERROR - 2015-09-26 22:15:14 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:17:11 --> Config Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:17:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:17:11 --> URI Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Router Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Output Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Security Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Input Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:17:11 --> Language Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Language Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Config Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Loader Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:17:11 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:17:11 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:17:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:17:11 --> Session Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:17:11 --> Session routines successfully run
DEBUG - 2015-09-26 22:17:11 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Email Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Controller Class Initialized
DEBUG - 2015-09-26 22:17:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:17:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:17:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:17:11 --> Final output sent to browser
DEBUG - 2015-09-26 22:17:11 --> Total execution time: 0.3123
DEBUG - 2015-09-26 22:17:14 --> Config Class Initialized
DEBUG - 2015-09-26 22:17:14 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:17:14 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:17:14 --> URI Class Initialized
DEBUG - 2015-09-26 22:17:14 --> Router Class Initialized
ERROR - 2015-09-26 22:17:14 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:17:30 --> Config Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:17:30 --> URI Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Router Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Output Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Security Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Input Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:17:30 --> Language Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Language Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Config Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Loader Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:17:30 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:17:30 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:17:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:17:30 --> Session Class Initialized
DEBUG - 2015-09-26 22:17:30 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:17:30 --> Session routines successfully run
DEBUG - 2015-09-26 22:17:31 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:17:31 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:17:31 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:17:31 --> Email Class Initialized
DEBUG - 2015-09-26 22:17:31 --> Controller Class Initialized
DEBUG - 2015-09-26 22:17:31 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:17:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:17:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:17:31 --> Final output sent to browser
DEBUG - 2015-09-26 22:17:31 --> Total execution time: 0.2803
DEBUG - 2015-09-26 22:17:33 --> Config Class Initialized
DEBUG - 2015-09-26 22:17:33 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:17:33 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:17:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:17:33 --> URI Class Initialized
DEBUG - 2015-09-26 22:17:33 --> Router Class Initialized
ERROR - 2015-09-26 22:17:33 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:17:57 --> Config Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:17:57 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:17:57 --> URI Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Router Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Output Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Security Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Input Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:17:57 --> Language Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Language Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Config Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Loader Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:17:57 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:17:57 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:17:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:17:57 --> Session Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:17:57 --> Session routines successfully run
DEBUG - 2015-09-26 22:17:57 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Email Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Controller Class Initialized
DEBUG - 2015-09-26 22:17:57 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:17:57 --> Model Class Initialized
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:17:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:17:57 --> Final output sent to browser
DEBUG - 2015-09-26 22:17:57 --> Total execution time: 0.2894
DEBUG - 2015-09-26 22:18:00 --> Config Class Initialized
DEBUG - 2015-09-26 22:18:00 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:18:00 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:18:00 --> URI Class Initialized
DEBUG - 2015-09-26 22:18:00 --> Router Class Initialized
ERROR - 2015-09-26 22:18:00 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:18:13 --> Config Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:18:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:18:13 --> URI Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Router Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Output Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Security Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Input Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:18:13 --> Language Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Language Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Config Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Loader Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:18:13 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:18:13 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:18:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:18:13 --> Session Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:18:13 --> Session routines successfully run
DEBUG - 2015-09-26 22:18:13 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Email Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Controller Class Initialized
DEBUG - 2015-09-26 22:18:13 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:18:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:18:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:18:13 --> Final output sent to browser
DEBUG - 2015-09-26 22:18:13 --> Total execution time: 0.2549
DEBUG - 2015-09-26 22:18:16 --> Config Class Initialized
DEBUG - 2015-09-26 22:18:16 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:18:16 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:18:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:18:16 --> URI Class Initialized
DEBUG - 2015-09-26 22:18:16 --> Router Class Initialized
ERROR - 2015-09-26 22:18:16 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:18:30 --> Config Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:18:30 --> URI Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Router Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Output Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Security Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Input Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:18:30 --> Language Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Language Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Config Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Loader Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:18:30 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:18:30 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:18:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:18:30 --> Session Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:18:30 --> Session routines successfully run
DEBUG - 2015-09-26 22:18:30 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Email Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Controller Class Initialized
DEBUG - 2015-09-26 22:18:30 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:18:30 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:18:30 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:18:30 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:18:30 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:18:30 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:18:30 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:18:30 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:18:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:18:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:18:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:18:31 --> Model Class Initialized
DEBUG - 2015-09-26 22:18:31 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:18:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:18:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:18:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:18:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:18:31 --> Final output sent to browser
DEBUG - 2015-09-26 22:18:31 --> Total execution time: 0.2601
DEBUG - 2015-09-26 22:18:33 --> Config Class Initialized
DEBUG - 2015-09-26 22:18:33 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:18:33 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:18:33 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:18:33 --> URI Class Initialized
DEBUG - 2015-09-26 22:18:33 --> Router Class Initialized
ERROR - 2015-09-26 22:18:33 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:21:39 --> Config Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:21:39 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:21:39 --> URI Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Router Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Output Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Security Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Input Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:21:39 --> Language Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Language Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Config Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Loader Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:21:39 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:21:39 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:21:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:21:39 --> Session Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:21:39 --> Session routines successfully run
DEBUG - 2015-09-26 22:21:39 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Email Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Controller Class Initialized
DEBUG - 2015-09-26 22:21:39 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:21:39 --> Model Class Initialized
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:21:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:21:39 --> Final output sent to browser
DEBUG - 2015-09-26 22:21:39 --> Total execution time: 0.2460
DEBUG - 2015-09-26 22:21:41 --> Config Class Initialized
DEBUG - 2015-09-26 22:21:41 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:21:41 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:21:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:21:41 --> URI Class Initialized
DEBUG - 2015-09-26 22:21:41 --> Router Class Initialized
ERROR - 2015-09-26 22:21:41 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:22:47 --> Config Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:22:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:22:47 --> URI Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Router Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Output Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Security Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Input Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:22:47 --> Language Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Language Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Config Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Loader Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:22:47 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:22:47 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:22:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:22:47 --> Session Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:22:47 --> Session routines successfully run
DEBUG - 2015-09-26 22:22:47 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Email Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Controller Class Initialized
DEBUG - 2015-09-26 22:22:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:22:47 --> Model Class Initialized
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:22:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:22:47 --> Final output sent to browser
DEBUG - 2015-09-26 22:22:47 --> Total execution time: 0.2713
DEBUG - 2015-09-26 22:22:50 --> Config Class Initialized
DEBUG - 2015-09-26 22:22:50 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:22:50 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:22:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:22:50 --> URI Class Initialized
DEBUG - 2015-09-26 22:22:50 --> Router Class Initialized
ERROR - 2015-09-26 22:22:50 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:23:13 --> Config Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:23:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:23:13 --> URI Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Router Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Output Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Security Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Input Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:23:13 --> Language Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Language Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Config Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Loader Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:23:13 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:23:13 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:23:13 --> Session Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:23:13 --> Session routines successfully run
DEBUG - 2015-09-26 22:23:13 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Email Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Controller Class Initialized
DEBUG - 2015-09-26 22:23:13 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:23:13 --> Model Class Initialized
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:23:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:23:13 --> Final output sent to browser
DEBUG - 2015-09-26 22:23:13 --> Total execution time: 0.2394
DEBUG - 2015-09-26 22:23:15 --> Config Class Initialized
DEBUG - 2015-09-26 22:23:15 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:23:15 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:23:15 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:23:15 --> URI Class Initialized
DEBUG - 2015-09-26 22:23:15 --> Router Class Initialized
ERROR - 2015-09-26 22:23:15 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:29:11 --> Config Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:29:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:29:11 --> URI Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Router Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Output Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Security Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Input Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:29:11 --> Language Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Language Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Config Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Loader Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:29:11 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:29:11 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:29:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:29:11 --> Session Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:29:11 --> Session routines successfully run
DEBUG - 2015-09-26 22:29:11 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Email Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Controller Class Initialized
DEBUG - 2015-09-26 22:29:11 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:29:11 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:29:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:29:11 --> Final output sent to browser
DEBUG - 2015-09-26 22:29:11 --> Total execution time: 0.2272
DEBUG - 2015-09-26 22:29:13 --> Config Class Initialized
DEBUG - 2015-09-26 22:29:13 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:29:13 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:29:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:29:13 --> URI Class Initialized
DEBUG - 2015-09-26 22:29:13 --> Router Class Initialized
ERROR - 2015-09-26 22:29:13 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:29:34 --> Config Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:29:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:29:34 --> URI Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Router Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Output Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Security Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Input Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:29:34 --> Language Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Language Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Config Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Loader Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:29:34 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:29:34 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:29:34 --> Session Class Initialized
DEBUG - 2015-09-26 22:29:34 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:29:34 --> Session routines successfully run
DEBUG - 2015-09-26 22:29:35 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:29:35 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:29:35 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:29:35 --> Email Class Initialized
DEBUG - 2015-09-26 22:29:35 --> Controller Class Initialized
DEBUG - 2015-09-26 22:29:35 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:29:35 --> Model Class Initialized
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:29:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:29:35 --> Final output sent to browser
DEBUG - 2015-09-26 22:29:35 --> Total execution time: 0.2758
DEBUG - 2015-09-26 22:29:37 --> Config Class Initialized
DEBUG - 2015-09-26 22:29:37 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:29:37 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:29:37 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:29:37 --> URI Class Initialized
DEBUG - 2015-09-26 22:29:37 --> Router Class Initialized
ERROR - 2015-09-26 22:29:37 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:32:20 --> Config Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:32:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:32:20 --> URI Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Router Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Output Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Security Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Input Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:32:20 --> Language Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Language Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Config Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Loader Class Initialized
DEBUG - 2015-09-26 22:32:20 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:32:20 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:32:21 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:32:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:32:21 --> Session Class Initialized
DEBUG - 2015-09-26 22:32:21 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:32:21 --> Session routines successfully run
DEBUG - 2015-09-26 22:32:21 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:32:21 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:32:21 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:32:21 --> Email Class Initialized
DEBUG - 2015-09-26 22:32:21 --> Controller Class Initialized
DEBUG - 2015-09-26 22:32:21 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:32:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:32:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:32:21 --> Final output sent to browser
DEBUG - 2015-09-26 22:32:21 --> Total execution time: 0.2867
DEBUG - 2015-09-26 22:32:23 --> Config Class Initialized
DEBUG - 2015-09-26 22:32:23 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:32:23 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:32:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:32:23 --> URI Class Initialized
DEBUG - 2015-09-26 22:32:23 --> Router Class Initialized
ERROR - 2015-09-26 22:32:23 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:33:10 --> Config Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:33:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:33:10 --> URI Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Router Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Output Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Security Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Input Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:33:10 --> Language Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Language Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Config Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Loader Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:33:10 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:33:10 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:33:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:33:10 --> Session Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:33:10 --> Session routines successfully run
DEBUG - 2015-09-26 22:33:10 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Email Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Controller Class Initialized
DEBUG - 2015-09-26 22:33:10 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:33:10 --> Model Class Initialized
DEBUG - 2015-09-26 22:33:11 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:33:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:33:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:33:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:33:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:33:11 --> Final output sent to browser
DEBUG - 2015-09-26 22:33:11 --> Total execution time: 0.2573
DEBUG - 2015-09-26 22:33:13 --> Config Class Initialized
DEBUG - 2015-09-26 22:33:13 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:33:13 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:33:13 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:33:13 --> URI Class Initialized
DEBUG - 2015-09-26 22:33:13 --> Router Class Initialized
ERROR - 2015-09-26 22:33:13 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:34:02 --> Config Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:34:02 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:34:02 --> URI Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Router Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Output Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Security Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Input Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:34:02 --> Language Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Language Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Config Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Loader Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:34:02 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:34:02 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:34:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:34:02 --> Session Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:34:02 --> Session routines successfully run
DEBUG - 2015-09-26 22:34:02 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Email Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Controller Class Initialized
DEBUG - 2015-09-26 22:34:02 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:34:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:34:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:34:02 --> Final output sent to browser
DEBUG - 2015-09-26 22:34:02 --> Total execution time: 0.2862
DEBUG - 2015-09-26 22:34:05 --> Config Class Initialized
DEBUG - 2015-09-26 22:34:05 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:34:05 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:34:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:34:05 --> URI Class Initialized
DEBUG - 2015-09-26 22:34:05 --> Router Class Initialized
ERROR - 2015-09-26 22:34:05 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:34:49 --> Config Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:34:49 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:34:49 --> URI Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Router Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Output Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Security Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Input Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:34:49 --> Language Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Language Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Config Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Loader Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:34:49 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:34:49 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:34:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:34:49 --> Session Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:34:49 --> Session routines successfully run
DEBUG - 2015-09-26 22:34:49 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Email Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Controller Class Initialized
DEBUG - 2015-09-26 22:34:49 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:34:49 --> Model Class Initialized
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:34:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:34:49 --> Final output sent to browser
DEBUG - 2015-09-26 22:34:49 --> Total execution time: 0.2298
DEBUG - 2015-09-26 22:34:51 --> Config Class Initialized
DEBUG - 2015-09-26 22:34:51 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:34:51 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:34:51 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:34:51 --> URI Class Initialized
DEBUG - 2015-09-26 22:34:51 --> Router Class Initialized
ERROR - 2015-09-26 22:34:51 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:35:18 --> Config Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:35:18 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:35:18 --> URI Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Router Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Output Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Security Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Input Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:35:18 --> Language Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Language Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Config Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Loader Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:35:18 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:35:18 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:35:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:35:18 --> Session Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:35:18 --> Session routines successfully run
DEBUG - 2015-09-26 22:35:18 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Email Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Controller Class Initialized
DEBUG - 2015-09-26 22:35:18 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:35:18 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:35:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:35:18 --> Final output sent to browser
DEBUG - 2015-09-26 22:35:18 --> Total execution time: 0.3057
DEBUG - 2015-09-26 22:35:21 --> Config Class Initialized
DEBUG - 2015-09-26 22:35:21 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:35:21 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:35:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:35:21 --> URI Class Initialized
DEBUG - 2015-09-26 22:35:21 --> Router Class Initialized
ERROR - 2015-09-26 22:35:21 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:35:56 --> Config Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:35:56 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:35:56 --> URI Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Router Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Output Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Security Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Input Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:35:56 --> Language Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Language Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Config Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Loader Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:35:56 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:35:56 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:35:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:35:56 --> Session Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:35:56 --> Session routines successfully run
DEBUG - 2015-09-26 22:35:56 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Email Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Controller Class Initialized
DEBUG - 2015-09-26 22:35:56 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:35:56 --> Model Class Initialized
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:35:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:35:56 --> Final output sent to browser
DEBUG - 2015-09-26 22:35:56 --> Total execution time: 0.2340
DEBUG - 2015-09-26 22:35:58 --> Config Class Initialized
DEBUG - 2015-09-26 22:35:58 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:35:58 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:35:58 --> URI Class Initialized
DEBUG - 2015-09-26 22:35:58 --> Router Class Initialized
ERROR - 2015-09-26 22:35:58 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:41:17 --> Config Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:41:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:41:17 --> URI Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Router Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Output Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Security Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Input Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:41:17 --> Language Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Language Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Config Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Loader Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:41:17 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:41:17 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:41:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:41:17 --> Session Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:41:17 --> Session routines successfully run
DEBUG - 2015-09-26 22:41:17 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Email Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Controller Class Initialized
DEBUG - 2015-09-26 22:41:17 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:41:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:41:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:41:17 --> Final output sent to browser
DEBUG - 2015-09-26 22:41:17 --> Total execution time: 0.2526
DEBUG - 2015-09-26 22:41:20 --> Config Class Initialized
DEBUG - 2015-09-26 22:41:20 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:41:20 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:41:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:41:20 --> URI Class Initialized
DEBUG - 2015-09-26 22:41:20 --> Router Class Initialized
ERROR - 2015-09-26 22:41:20 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:42:44 --> Config Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:42:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:42:44 --> URI Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Router Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Output Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Security Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Input Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:42:44 --> Language Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Language Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Config Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Loader Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:42:44 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:42:44 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:42:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:42:44 --> Session Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:42:44 --> Session routines successfully run
DEBUG - 2015-09-26 22:42:44 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Email Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Controller Class Initialized
DEBUG - 2015-09-26 22:42:44 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:42:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:42:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:42:44 --> Final output sent to browser
DEBUG - 2015-09-26 22:42:44 --> Total execution time: 0.2329
DEBUG - 2015-09-26 22:42:46 --> Config Class Initialized
DEBUG - 2015-09-26 22:42:46 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:42:46 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:42:46 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:42:46 --> URI Class Initialized
DEBUG - 2015-09-26 22:42:46 --> Router Class Initialized
ERROR - 2015-09-26 22:42:46 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:44:52 --> Config Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:44:52 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:44:52 --> URI Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Router Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Output Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Security Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Input Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:44:52 --> Language Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Language Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Config Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Loader Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:44:52 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:44:52 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:44:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:44:52 --> Session Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:44:52 --> Session routines successfully run
DEBUG - 2015-09-26 22:44:52 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Email Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Controller Class Initialized
DEBUG - 2015-09-26 22:44:52 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:44:52 --> Model Class Initialized
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:44:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:44:52 --> Final output sent to browser
DEBUG - 2015-09-26 22:44:52 --> Total execution time: 0.2474
DEBUG - 2015-09-26 22:44:54 --> Config Class Initialized
DEBUG - 2015-09-26 22:44:54 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:44:55 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:44:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:44:55 --> URI Class Initialized
DEBUG - 2015-09-26 22:44:55 --> Router Class Initialized
ERROR - 2015-09-26 22:44:55 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:46:12 --> Config Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:46:12 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:46:12 --> URI Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Router Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Output Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Security Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Input Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:46:12 --> Language Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Language Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Config Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Loader Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:46:12 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:46:12 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:46:12 --> Session Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:46:12 --> Session routines successfully run
DEBUG - 2015-09-26 22:46:12 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Email Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Controller Class Initialized
DEBUG - 2015-09-26 22:46:12 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:46:12 --> Model Class Initialized
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:46:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:46:12 --> Final output sent to browser
DEBUG - 2015-09-26 22:46:12 --> Total execution time: 0.2400
DEBUG - 2015-09-26 22:46:15 --> Config Class Initialized
DEBUG - 2015-09-26 22:46:15 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:46:15 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:46:15 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:46:15 --> URI Class Initialized
DEBUG - 2015-09-26 22:46:15 --> Router Class Initialized
ERROR - 2015-09-26 22:46:15 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:47:02 --> Config Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:47:02 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:47:02 --> URI Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Router Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Output Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Security Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Input Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:47:02 --> Language Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Language Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Config Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Loader Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:47:02 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:47:02 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:47:02 --> Session Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:47:02 --> Session routines successfully run
DEBUG - 2015-09-26 22:47:02 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Email Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Controller Class Initialized
DEBUG - 2015-09-26 22:47:02 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:47:02 --> Model Class Initialized
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:47:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:47:02 --> Final output sent to browser
DEBUG - 2015-09-26 22:47:02 --> Total execution time: 0.2588
DEBUG - 2015-09-26 22:47:05 --> Config Class Initialized
DEBUG - 2015-09-26 22:47:05 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:47:05 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:47:05 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:47:05 --> URI Class Initialized
DEBUG - 2015-09-26 22:47:05 --> Router Class Initialized
ERROR - 2015-09-26 22:47:05 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:48:23 --> Config Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:48:23 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:48:23 --> URI Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Router Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Output Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Security Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Input Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:48:23 --> Language Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Language Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Config Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Loader Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:48:23 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:48:23 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:48:23 --> Session Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:48:23 --> Session routines successfully run
DEBUG - 2015-09-26 22:48:23 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Email Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Controller Class Initialized
DEBUG - 2015-09-26 22:48:23 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:48:23 --> Model Class Initialized
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:48:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:48:23 --> Final output sent to browser
DEBUG - 2015-09-26 22:48:23 --> Total execution time: 0.2443
DEBUG - 2015-09-26 22:48:25 --> Config Class Initialized
DEBUG - 2015-09-26 22:48:25 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:48:25 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:48:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:48:25 --> URI Class Initialized
DEBUG - 2015-09-26 22:48:25 --> Router Class Initialized
ERROR - 2015-09-26 22:48:25 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:49:59 --> Config Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:49:59 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:49:59 --> URI Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Router Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Output Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Security Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Input Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:49:59 --> Language Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Language Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Config Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Loader Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:49:59 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:49:59 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:49:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:49:59 --> Session Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:49:59 --> Session routines successfully run
DEBUG - 2015-09-26 22:49:59 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Email Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Controller Class Initialized
DEBUG - 2015-09-26 22:49:59 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:49:59 --> Model Class Initialized
DEBUG - 2015-09-26 22:49:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:49:59 --> Model Class Initialized
DEBUG - 2015-09-26 22:49:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:49:59 --> Model Class Initialized
DEBUG - 2015-09-26 22:49:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:49:59 --> Model Class Initialized
DEBUG - 2015-09-26 22:49:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:49:59 --> Model Class Initialized
DEBUG - 2015-09-26 22:49:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:49:59 --> Model Class Initialized
DEBUG - 2015-09-26 22:49:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:49:59 --> Model Class Initialized
DEBUG - 2015-09-26 22:49:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:49:59 --> Model Class Initialized
DEBUG - 2015-09-26 22:50:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:50:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:50:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:50:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:50:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:50:00 --> Model Class Initialized
DEBUG - 2015-09-26 22:50:00 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:50:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:50:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:50:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:50:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:50:00 --> Final output sent to browser
DEBUG - 2015-09-26 22:50:00 --> Total execution time: 0.2614
DEBUG - 2015-09-26 22:50:02 --> Config Class Initialized
DEBUG - 2015-09-26 22:50:02 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:50:02 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:50:02 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:50:02 --> URI Class Initialized
DEBUG - 2015-09-26 22:50:02 --> Router Class Initialized
ERROR - 2015-09-26 22:50:02 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:51:16 --> Config Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:51:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:51:16 --> URI Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Router Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Output Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Security Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Input Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:51:16 --> Language Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Language Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Config Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Loader Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:51:16 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:51:16 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:51:16 --> Session Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:51:16 --> Session routines successfully run
DEBUG - 2015-09-26 22:51:16 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Email Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Controller Class Initialized
DEBUG - 2015-09-26 22:51:16 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:51:16 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:51:16 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:51:16 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:51:16 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:51:16 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:51:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:51:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:51:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:51:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:51:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:51:17 --> Model Class Initialized
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:51:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:51:17 --> Final output sent to browser
DEBUG - 2015-09-26 22:51:17 --> Total execution time: 0.2863
DEBUG - 2015-09-26 22:51:19 --> Config Class Initialized
DEBUG - 2015-09-26 22:51:19 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:51:19 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:51:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:51:19 --> URI Class Initialized
DEBUG - 2015-09-26 22:51:19 --> Router Class Initialized
ERROR - 2015-09-26 22:51:19 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:52:08 --> Config Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:52:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:52:08 --> URI Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Router Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Output Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Security Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Input Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:52:08 --> Language Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Language Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Config Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Loader Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:52:08 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:52:08 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:52:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:52:08 --> Session Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:52:08 --> Session routines successfully run
DEBUG - 2015-09-26 22:52:08 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Email Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Controller Class Initialized
DEBUG - 2015-09-26 22:52:08 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-26 22:52:09 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:52:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:52:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:52:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:52:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:52:09 --> Final output sent to browser
DEBUG - 2015-09-26 22:52:09 --> Total execution time: 0.2330
DEBUG - 2015-09-26 22:52:11 --> Config Class Initialized
DEBUG - 2015-09-26 22:52:11 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:52:11 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:52:11 --> URI Class Initialized
DEBUG - 2015-09-26 22:52:11 --> Router Class Initialized
ERROR - 2015-09-26 22:52:11 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:54:43 --> Config Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:54:43 --> URI Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Router Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Output Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Security Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Input Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:54:43 --> Language Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Language Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Config Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Loader Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:54:43 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:54:43 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:54:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:54:43 --> Session Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:54:43 --> Session routines successfully run
DEBUG - 2015-09-26 22:54:43 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Email Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Controller Class Initialized
DEBUG - 2015-09-26 22:54:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:54:43 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:54:43 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:54:43 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:54:43 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:54:43 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:54:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:54:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:54:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:54:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:54:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:54:44 --> Model Class Initialized
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:54:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:54:44 --> Final output sent to browser
DEBUG - 2015-09-26 22:54:44 --> Total execution time: 0.2774
DEBUG - 2015-09-26 22:54:48 --> Config Class Initialized
DEBUG - 2015-09-26 22:54:48 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:54:48 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:54:48 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:54:48 --> URI Class Initialized
DEBUG - 2015-09-26 22:54:48 --> Router Class Initialized
ERROR - 2015-09-26 22:54:48 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:56:21 --> Config Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:56:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:56:21 --> URI Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Router Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Output Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Security Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Input Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:56:21 --> Language Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Language Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Config Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Loader Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:56:21 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:56:21 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:56:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:56:21 --> Session Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:56:21 --> Session routines successfully run
DEBUG - 2015-09-26 22:56:21 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Email Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Controller Class Initialized
DEBUG - 2015-09-26 22:56:21 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:56:21 --> Model Class Initialized
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:56:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:56:21 --> Final output sent to browser
DEBUG - 2015-09-26 22:56:21 --> Total execution time: 0.2396
DEBUG - 2015-09-26 22:56:23 --> Config Class Initialized
DEBUG - 2015-09-26 22:56:23 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:56:24 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:56:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:56:24 --> URI Class Initialized
DEBUG - 2015-09-26 22:56:24 --> Router Class Initialized
ERROR - 2015-09-26 22:56:24 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:58:55 --> Config Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:58:55 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:58:55 --> URI Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Router Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Output Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Security Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Input Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:58:55 --> Language Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Language Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Config Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Loader Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:58:55 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:58:55 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:58:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:58:55 --> Session Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:58:55 --> Session routines successfully run
DEBUG - 2015-09-26 22:58:55 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Email Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Controller Class Initialized
DEBUG - 2015-09-26 22:58:55 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:58:55 --> Model Class Initialized
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:58:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:58:55 --> Final output sent to browser
DEBUG - 2015-09-26 22:58:55 --> Total execution time: 0.2317
DEBUG - 2015-09-26 22:58:58 --> Config Class Initialized
DEBUG - 2015-09-26 22:58:58 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:58:58 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:58:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:58:58 --> URI Class Initialized
DEBUG - 2015-09-26 22:58:58 --> Router Class Initialized
ERROR - 2015-09-26 22:58:58 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 22:59:24 --> Config Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:59:24 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:59:24 --> URI Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Router Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Output Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Security Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Input Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 22:59:24 --> Language Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Language Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Config Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Loader Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Helper loaded: url_helper
DEBUG - 2015-09-26 22:59:24 --> Helper loaded: form_helper
DEBUG - 2015-09-26 22:59:24 --> Database Driver Class Initialized
ERROR - 2015-09-26 22:59:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 22:59:24 --> Session Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Helper loaded: string_helper
DEBUG - 2015-09-26 22:59:24 --> Session routines successfully run
DEBUG - 2015-09-26 22:59:24 --> Form Validation Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Pagination Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Encrypt Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Email Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Controller Class Initialized
DEBUG - 2015-09-26 22:59:24 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 22:59:24 --> Model Class Initialized
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 22:59:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 22:59:24 --> Final output sent to browser
DEBUG - 2015-09-26 22:59:24 --> Total execution time: 0.2645
DEBUG - 2015-09-26 22:59:27 --> Config Class Initialized
DEBUG - 2015-09-26 22:59:27 --> Hooks Class Initialized
DEBUG - 2015-09-26 22:59:27 --> Utf8 Class Initialized
DEBUG - 2015-09-26 22:59:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 22:59:27 --> URI Class Initialized
DEBUG - 2015-09-26 22:59:27 --> Router Class Initialized
ERROR - 2015-09-26 22:59:27 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 23:01:32 --> Config Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:01:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:01:32 --> URI Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Router Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Output Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Security Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Input Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 23:01:32 --> Language Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Language Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Config Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Loader Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Helper loaded: url_helper
DEBUG - 2015-09-26 23:01:32 --> Helper loaded: form_helper
DEBUG - 2015-09-26 23:01:32 --> Database Driver Class Initialized
ERROR - 2015-09-26 23:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 23:01:32 --> Session Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Helper loaded: string_helper
DEBUG - 2015-09-26 23:01:32 --> Session routines successfully run
DEBUG - 2015-09-26 23:01:32 --> Form Validation Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Pagination Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Encrypt Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Email Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Controller Class Initialized
DEBUG - 2015-09-26 23:01:32 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 23:01:32 --> Model Class Initialized
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 23:01:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 23:01:32 --> Final output sent to browser
DEBUG - 2015-09-26 23:01:32 --> Total execution time: 0.2440
DEBUG - 2015-09-26 23:01:35 --> Config Class Initialized
DEBUG - 2015-09-26 23:01:35 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:01:35 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:01:35 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:01:35 --> URI Class Initialized
DEBUG - 2015-09-26 23:01:35 --> Router Class Initialized
ERROR - 2015-09-26 23:01:35 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 23:02:08 --> Config Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:02:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:02:08 --> URI Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Router Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Output Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Security Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Input Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 23:02:08 --> Language Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Language Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Config Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Loader Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Helper loaded: url_helper
DEBUG - 2015-09-26 23:02:08 --> Helper loaded: form_helper
DEBUG - 2015-09-26 23:02:08 --> Database Driver Class Initialized
ERROR - 2015-09-26 23:02:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 23:02:08 --> Session Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Helper loaded: string_helper
DEBUG - 2015-09-26 23:02:08 --> Session routines successfully run
DEBUG - 2015-09-26 23:02:08 --> Form Validation Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Pagination Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Encrypt Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Email Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Controller Class Initialized
DEBUG - 2015-09-26 23:02:08 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 23:02:08 --> Model Class Initialized
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 23:02:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 23:02:08 --> Final output sent to browser
DEBUG - 2015-09-26 23:02:08 --> Total execution time: 0.2527
DEBUG - 2015-09-26 23:02:10 --> Config Class Initialized
DEBUG - 2015-09-26 23:02:10 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:02:10 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:02:10 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:02:10 --> URI Class Initialized
DEBUG - 2015-09-26 23:02:10 --> Router Class Initialized
ERROR - 2015-09-26 23:02:10 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 23:04:19 --> Config Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:04:19 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:04:19 --> URI Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Router Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Output Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Security Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Input Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 23:04:19 --> Language Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Language Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Config Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Loader Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Helper loaded: url_helper
DEBUG - 2015-09-26 23:04:19 --> Helper loaded: form_helper
DEBUG - 2015-09-26 23:04:19 --> Database Driver Class Initialized
ERROR - 2015-09-26 23:04:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 23:04:19 --> Session Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Helper loaded: string_helper
DEBUG - 2015-09-26 23:04:19 --> Session routines successfully run
DEBUG - 2015-09-26 23:04:19 --> Form Validation Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Pagination Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Encrypt Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Email Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Controller Class Initialized
DEBUG - 2015-09-26 23:04:19 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 23:04:19 --> Model Class Initialized
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 23:04:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 23:04:19 --> Final output sent to browser
DEBUG - 2015-09-26 23:04:19 --> Total execution time: 0.2388
DEBUG - 2015-09-26 23:04:21 --> Config Class Initialized
DEBUG - 2015-09-26 23:04:21 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:04:21 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:04:21 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:04:21 --> URI Class Initialized
DEBUG - 2015-09-26 23:04:21 --> Router Class Initialized
ERROR - 2015-09-26 23:04:21 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 23:05:25 --> Config Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:05:25 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:05:25 --> URI Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Router Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Output Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Security Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Input Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 23:05:25 --> Language Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Language Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Config Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Loader Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Helper loaded: url_helper
DEBUG - 2015-09-26 23:05:25 --> Helper loaded: form_helper
DEBUG - 2015-09-26 23:05:25 --> Database Driver Class Initialized
ERROR - 2015-09-26 23:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 23:05:25 --> Session Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Helper loaded: string_helper
DEBUG - 2015-09-26 23:05:25 --> Session routines successfully run
DEBUG - 2015-09-26 23:05:25 --> Form Validation Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Pagination Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Encrypt Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Email Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Controller Class Initialized
DEBUG - 2015-09-26 23:05:25 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 23:05:25 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 23:05:26 --> Model Class Initialized
DEBUG - 2015-09-26 23:05:26 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 23:05:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 23:05:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 23:05:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 23:05:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 23:05:26 --> Final output sent to browser
DEBUG - 2015-09-26 23:05:26 --> Total execution time: 0.2458
DEBUG - 2015-09-26 23:05:28 --> Config Class Initialized
DEBUG - 2015-09-26 23:05:28 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:05:28 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:05:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:05:28 --> URI Class Initialized
DEBUG - 2015-09-26 23:05:28 --> Router Class Initialized
ERROR - 2015-09-26 23:05:28 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 23:09:41 --> Config Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:09:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:09:41 --> URI Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Router Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Output Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Security Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Input Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 23:09:41 --> Language Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Language Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Config Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Loader Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Helper loaded: url_helper
DEBUG - 2015-09-26 23:09:41 --> Helper loaded: form_helper
DEBUG - 2015-09-26 23:09:41 --> Database Driver Class Initialized
ERROR - 2015-09-26 23:09:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 23:09:41 --> Session Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Helper loaded: string_helper
DEBUG - 2015-09-26 23:09:41 --> Session routines successfully run
DEBUG - 2015-09-26 23:09:41 --> Form Validation Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Pagination Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Encrypt Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Email Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Controller Class Initialized
DEBUG - 2015-09-26 23:09:41 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 23:09:41 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 23:09:41 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 23:09:42 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 23:09:42 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 23:09:42 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 23:09:42 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 23:09:42 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 23:09:42 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 23:09:42 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 23:09:42 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 23:09:42 --> Model Class Initialized
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 23:09:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 23:09:42 --> Final output sent to browser
DEBUG - 2015-09-26 23:09:42 --> Total execution time: 0.3176
DEBUG - 2015-09-26 23:09:44 --> Config Class Initialized
DEBUG - 2015-09-26 23:09:44 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:09:44 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:09:44 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:09:44 --> URI Class Initialized
DEBUG - 2015-09-26 23:09:44 --> Router Class Initialized
ERROR - 2015-09-26 23:09:44 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 23:12:20 --> Config Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:12:20 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:12:20 --> URI Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Router Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Output Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Security Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Input Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 23:12:20 --> Language Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Language Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Config Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Loader Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Helper loaded: url_helper
DEBUG - 2015-09-26 23:12:20 --> Helper loaded: form_helper
DEBUG - 2015-09-26 23:12:20 --> Database Driver Class Initialized
ERROR - 2015-09-26 23:12:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 23:12:20 --> Session Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Helper loaded: string_helper
DEBUG - 2015-09-26 23:12:20 --> Session routines successfully run
DEBUG - 2015-09-26 23:12:20 --> Form Validation Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Pagination Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Encrypt Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Email Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Controller Class Initialized
DEBUG - 2015-09-26 23:12:20 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 23:12:20 --> Model Class Initialized
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 23:12:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 23:12:20 --> Final output sent to browser
DEBUG - 2015-09-26 23:12:20 --> Total execution time: 0.2450
DEBUG - 2015-09-26 23:12:22 --> Config Class Initialized
DEBUG - 2015-09-26 23:12:22 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:12:22 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:12:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:12:22 --> URI Class Initialized
DEBUG - 2015-09-26 23:12:22 --> Router Class Initialized
ERROR - 2015-09-26 23:12:22 --> 404 Page Not Found --> 
DEBUG - 2015-09-26 23:13:47 --> Config Class Initialized
DEBUG - 2015-09-26 23:13:47 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:13:47 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:13:47 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:13:47 --> URI Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Router Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Output Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Security Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Input Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-26 23:13:48 --> Language Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Language Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Config Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Loader Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Helper loaded: url_helper
DEBUG - 2015-09-26 23:13:48 --> Helper loaded: form_helper
DEBUG - 2015-09-26 23:13:48 --> Database Driver Class Initialized
ERROR - 2015-09-26 23:13:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-09-26 23:13:48 --> Session Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Helper loaded: string_helper
DEBUG - 2015-09-26 23:13:48 --> Session routines successfully run
DEBUG - 2015-09-26 23:13:48 --> Form Validation Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Pagination Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Encrypt Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Email Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Controller Class Initialized
DEBUG - 2015-09-26 23:13:48 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-09-26 23:13:48 --> Model Class Initialized
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-09-26 23:13:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-09-26 23:13:48 --> Final output sent to browser
DEBUG - 2015-09-26 23:13:48 --> Total execution time: 0.2643
DEBUG - 2015-09-26 23:13:50 --> Config Class Initialized
DEBUG - 2015-09-26 23:13:50 --> Hooks Class Initialized
DEBUG - 2015-09-26 23:13:50 --> Utf8 Class Initialized
DEBUG - 2015-09-26 23:13:50 --> UTF-8 Support Enabled
DEBUG - 2015-09-26 23:13:50 --> URI Class Initialized
DEBUG - 2015-09-26 23:13:50 --> Router Class Initialized
ERROR - 2015-09-26 23:13:50 --> 404 Page Not Found --> 
