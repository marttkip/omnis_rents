<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-03-02 15:12:26 --> Config Class Initialized
DEBUG - 2016-03-02 15:12:26 --> Hooks Class Initialized
DEBUG - 2016-03-02 15:12:26 --> Utf8 Class Initialized
DEBUG - 2016-03-02 15:12:26 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 15:12:26 --> URI Class Initialized
DEBUG - 2016-03-02 15:12:26 --> Router Class Initialized
ERROR - 2016-03-02 15:12:26 --> 404 Page Not Found --> 
DEBUG - 2016-03-02 15:14:58 --> Config Class Initialized
DEBUG - 2016-03-02 15:14:58 --> Hooks Class Initialized
DEBUG - 2016-03-02 15:14:58 --> Utf8 Class Initialized
DEBUG - 2016-03-02 15:14:58 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 15:14:58 --> URI Class Initialized
DEBUG - 2016-03-02 15:14:58 --> Router Class Initialized
ERROR - 2016-03-02 15:14:58 --> 404 Page Not Found --> 
DEBUG - 2016-03-02 15:15:06 --> Config Class Initialized
DEBUG - 2016-03-02 15:15:06 --> Hooks Class Initialized
DEBUG - 2016-03-02 15:15:06 --> Utf8 Class Initialized
DEBUG - 2016-03-02 15:15:06 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 15:15:06 --> URI Class Initialized
DEBUG - 2016-03-02 15:15:06 --> Router Class Initialized
ERROR - 2016-03-02 15:15:06 --> 404 Page Not Found --> 
DEBUG - 2016-03-02 15:15:31 --> Config Class Initialized
DEBUG - 2016-03-02 15:15:31 --> Hooks Class Initialized
DEBUG - 2016-03-02 15:15:31 --> Utf8 Class Initialized
DEBUG - 2016-03-02 15:15:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 15:15:31 --> URI Class Initialized
DEBUG - 2016-03-02 15:15:31 --> Router Class Initialized
ERROR - 2016-03-02 15:15:31 --> 404 Page Not Found --> 
DEBUG - 2016-03-02 15:15:48 --> Config Class Initialized
DEBUG - 2016-03-02 15:15:48 --> Hooks Class Initialized
DEBUG - 2016-03-02 15:15:48 --> Utf8 Class Initialized
DEBUG - 2016-03-02 15:15:48 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 15:15:48 --> URI Class Initialized
DEBUG - 2016-03-02 15:15:48 --> Router Class Initialized
ERROR - 2016-03-02 15:15:48 --> 404 Page Not Found --> 
DEBUG - 2016-03-02 15:16:14 --> Config Class Initialized
DEBUG - 2016-03-02 15:16:14 --> Hooks Class Initialized
DEBUG - 2016-03-02 15:16:14 --> Utf8 Class Initialized
DEBUG - 2016-03-02 15:16:14 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 15:16:14 --> URI Class Initialized
DEBUG - 2016-03-02 15:16:14 --> Router Class Initialized
ERROR - 2016-03-02 15:16:14 --> 404 Page Not Found --> 
